#!/usr/bin/env bash
set -euo pipefail
export $(grep -v '^#' .env | xargs -d '\n' -I {} bash -lc 'echo {}' | xargs)
( cd python && source .venv/bin/activate && uvicorn api_server:app --host 0.0.0.0 --port 8000 --reload ) &
( cd worker && npx wrangler dev --local --port 8787 ) &
( cd python && source .venv/bin/activate && export HRDE_WORKSPACE=${HRDE_WORKSPACE:-./hrde_workspace} && python -m hrde.h_cli ) &
wait
