'use client'

import React, { useEffect, useMemo, useRef, useState } from 'react'
import * as THREE from 'three'
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js'
import * as CANNON from 'cannon-es'
import { Play, Pause, Sparkles, Zap, Settings, ShieldCheck, RotateCcw, Download, Upload, KeyRound, Bot } from 'lucide-react'

/**
 * Agentic Physics Sandbox — React + Three + cannon‑es (v3, LLM‑enabled)
 * --------------------------------------------------------------------
 * Additions in this version:
 * - Built‑in optional GPT‑5 bridge (browser fetch to OpenAI Chat Completions)
 * - Settings panel in the dock to enter/store API key + select model
 * - Translate NL prompt → AgentPlan(JSON) using the bridge when enabled
 * - Stores API key/model/provider in localStorage (client‑only)
 *
 * ⚠️ Security note: API keys stored in localStorage are visible to anyone
 * who can run JS in this origin. This is OK for local tinkering, but for
 * production use you should proxy requests through a secure backend.
 */

// --------------------------
// Types & Tooling Contracts
// --------------------------

export type Vec3 = [number, number, number]

export type SpawnPrimitive = {
  op: 'spawn'
  kind: 'box' | 'sphere' | 'cylinder' | 'capsule' | 'torus'
  size?: Vec3 | number // depending on kind
  position?: Vec3
  rotationEuler?: Vec3 // radians
  mass?: number
  color?: string
  restitution?: number
  friction?: number
}

export type SpawnLight = {
  op: 'light'
  kind: 'ambient' | 'directional' | 'point' | 'spot'
  id?: string
  color?: string
  intensity?: number
  position?: Vec3
}

export type SetGravity = { op: 'gravity'; g: Vec3 }

export type Impulse = { op: 'impulse'; id: string; impulse: Vec3; worldPoint?: Vec3 }

export type Tint = { op: 'tint'; id: string; color: string }

export type Destroy = { op: 'destroy'; id: string }

export type ConstrainDist = { op: 'constraint:distance'; a: string; b: string; max: number }

export type Reset = { op: 'reset' }

export type Action = SpawnPrimitive | SpawnLight | SetGravity | Impulse | Tint | Destroy | ConstrainDist | Reset

export type AgentPlan = { actions: Action[]; meta?: Record<string, any> }

/** Optional external LLM bridge: implement prompt→AgentPlan(JSON) */
export type LLMBridge = (prompt: string, context: any) => Promise<AgentPlan>

// Agent tick API
export type SnapshotBody = {
  id: string
  kind: string
  mass: number
  position: Vec3
  velocity: Vec3
  quaternion: [number, number, number, number]
}
export type WorldSnapshot = {
  time: number
  gravity: Vec3
  objects: SnapshotBody[]
}
export type EnvAPI = {
  run: (plan: AgentPlan) => void
  spawn: (a: SpawnPrimitive) => string | null
  impulse: (a: Impulse) => void
  setGravity: (a: SetGravity) => void
  reset: () => void
  tint: (a: Tint) => void
}

// -----------------
// Small utilities
// -----------------
function useLocalStorage<T>(key: string, initial: T) {
  const [value, setValue] = useState<T>(() => {
    if (typeof window === 'undefined') return initial
    try {
      const s = window.localStorage.getItem(key)
      return s ? (JSON.parse(s) as T) : initial
    } catch {
      return initial
    }
  })
  useEffect(() => {
    try {
      window.localStorage.setItem(key, JSON.stringify(value))
    } catch {}
  }, [key, value])
  return [value, setValue] as const
}

// ---------------
// Component Props
// ---------------
export default function AgenticPhysicsSandbox({
  bridge,
  agentTick,
  seed,
}: {
  /** Optional LLM bridge for NL → JSON */
  bridge?: LLMBridge
  /** Optional per‑step agent hook (called at fixed physics cadence) */
  agentTick?: (env: EnvAPI, snapshot: WorldSnapshot) => void | Promise<void>
  /** Optional RNG seed for deterministic spawns */
  seed?: number
}) {
  const mountRef = useRef<HTMLDivElement | null>(null)
  const canvasRef = useRef<HTMLCanvasElement | null>(null)

  // three
  const sceneRef = useRef<THREE.Scene | null>(null)
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null)
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null)
  const controlsRef = useRef<OrbitControls | null>(null)

  // physics
  const worldRef = useRef<CANNON.World | null>(null)
  const fixedDT = 1 / 60
  const accumulatorRef = useRef(0)

  // mapping and ids
  type BodyEntry = { id: string; body: CANNON.Body; mesh: THREE.Object3D; kind: string; material: CANNON.Material }
  const bodiesRef = useRef<Map<string, BodyEntry>>(new Map())
  const idCounterRef = useRef(0)
  const genId = () => `obj_${idCounterRef.current++}`

  // contact material management
  const matProps = useRef(new Map<number, { f: number; r: number }>())
  const contactPairs = useRef(new Set<string>())
  const pairKey = (a: CANNON.Material, b: CANNON.Material) => (a.id < b.id ? `${a.id}|${b.id}` : `${b.id}|${a.id}`)

  // constraints & lights registry for cleanup
  const constraintsRef = useRef<CANNON.Constraint[]>([])
  const lightsRef = useRef<Map<string, THREE.Light>>(new Map())

  // RNG (LCG)
  const rngState = useRef<number>(seed ?? Math.floor(Math.random() * 1e9))
  function rand() {
    rngState.current = (1664525 * rngState.current + 1013904223) >>> 0
    return rngState.current / 0xffffffff
  }

  // loop
  const rafRef = useRef<number | null>(null)
  const clockRef = useRef(new THREE.Clock())

  // UI state
  const [running, setRunning] = useState(true)
  const [godmode, setGodmode] = useState(false)
  const [objectCap, setObjectCap] = useState(96)
  const [energyCap, setEnergyCap] = useState(5e4)
  const [stats, setStats] = useState({ time: 0, objects: 0, energy: 0, fps: 0 })
  const [log, setLog] = useState<string[]>(['Sandbox ready.'])
  const [prompt, setPrompt] = useState('stack 20 boxes into a leaning tower and add a spotlight')
  const [jsonText, setJsonText] = useState(
    () =>
      JSON.stringify(
        {
          actions: [
            { op: 'spawn', kind: 'box', size: [1, 1, 1], position: [0, 5, 0], mass: 5, color: '#8be9fd', friction: 0.4, restitution: 0.05 },
            { op: 'spawn', kind: 'sphere', size: 0.6, position: [1, 8, 0], mass: 2, color: '#ff79c6', friction: 0.2, restitution: 0.6 },
            { op: 'impulse', id: 'last', impulse: [50, 0, 0] },
            { op: 'light', kind: 'spot', position: [10, 15, 10], intensity: 1.2 },
          ],
        },
        null,
        2,
      ),
  )

  // LLM settings (persisted)
  type Provider = 'off' | 'openai'
  const [provider, setProvider] = useLocalStorage<Provider>('sandbox.llm.provider', 'off')
  const [gptModel, setGptModel] = useLocalStorage<string>('sandbox.llm.model', 'gpt-5')
  const [gptKey, setGptKey] = useLocalStorage<string>('sandbox.llm.key', '')
  const [llmBusy, setLlmBusy] = useState(false)

  // safety bounds (world box)
  const worldBounds = useMemo(() => ({ halfExtents: new CANNON.Vec3(40, 40, 40) }), [])

  // ----------------------
  // Initialization/Teardown
  // ----------------------
  useEffect(() => {
    const mount = mountRef.current!
    const canvas = canvasRef.current!

    // Scene + Camera
    const scene = new THREE.Scene()
    scene.background = new THREE.Color('#0b0b12')
    sceneRef.current = scene

    const camera = new THREE.PerspectiveCamera(60, 1, 0.1, 2000)
    camera.position.set(12, 12, 18)
    camera.lookAt(0, 4, 0)
    cameraRef.current = camera

    const renderer = new THREE.WebGLRenderer({ canvas, antialias: true })
    renderer.outputColorSpace = THREE.SRGBColorSpace
    renderer.setPixelRatio(Math.min(window.devicePixelRatio ?? 1, 2))
    rendererRef.current = renderer

    const controls = new OrbitControls(camera, renderer.domElement)
    controls.enableDamping = true
    controls.target.set(0, 4, 0)
    controlsRef.current = controls

    // Lights (ambient hemi + dir)
    const hemi = new THREE.HemisphereLight(0xffffff, 0x404040, 0.7)
    scene.add(hemi)
    const dir = new THREE.DirectionalLight(0xffffff, 0.9)
    dir.position.set(6, 10, 4)
    dir.castShadow = true
    scene.add(dir)
    lightsRef.current.set('hemi', hemi)
    lightsRef.current.set('dir', dir)

    // Physics world
    const world = new CANNON.World({ gravity: new CANNON.Vec3(0, -9.81, 0) })
    world.broadphase = new CANNON.SAPBroadphase(world)
    world.allowSleep = true
    world.solver.iterations = 10
    world.defaultContactMaterial.friction = 0.3
    world.defaultContactMaterial.restitution = 0.05
    worldRef.current = world

    // Ground plane
    {
      const groundBody = new CANNON.Body({ mass: 0 })
      const groundShape = new CANNON.Plane()
      groundBody.addShape(groundShape)
      groundBody.quaternion.setFromEuler(-Math.PI / 2, 0, 0)
      world.addBody(groundBody)
      const groundMesh = new THREE.Mesh(
        new THREE.PlaneGeometry(200, 200),
        new THREE.MeshStandardMaterial({ color: '#23232f', metalness: 0, roughness: 1 }),
      )
      groundMesh.receiveShadow = true
      groundMesh.rotation.x = -Math.PI / 2
      scene.add(groundMesh)
    }

    // World bounds (six static planes forming a box)
    addBounds(worldBounds.halfExtents)

    // Resize
    const ro = new ResizeObserver(() => fitRenderer())
    ro.observe(mount)
    fitRenderer()

    // Events / shortcuts
    const onKey = (e: KeyboardEvent) => {
      if (e.key === ' ') setRunning((v) => !v)
      if (e.key.toLowerCase() === 'r') resetWorld()
      if (e.key.toLowerCase() === 'g') setGodmode((v) => !v)
    }
    window.addEventListener('keydown', onKey)

    // Start
    startLoop()

    logMsg('Initialized.')

    // Expose minimal API for external driving
    ;(window as any).sandbox = {
      run: (plan: AgentPlan) => runPlan(plan),
      reset: () => resetWorld(),
      list: () => Array.from(bodiesRef.current.values()).map((e) => e.id),
      snapshot: () => buildSnapshot(),
    }

    // Run lightweight self-tests once after init
    setTimeout(() => runSelfTests(), 0)

    return () => {
      stopLoop()
      window.removeEventListener('keydown', onKey)
      ro.disconnect()
      controls.dispose()
      renderer.dispose()
      for (const [, entry] of bodiesRef.current) {
        removeEntry(entry)
      }
      constraintsRef.current.forEach((c) => world.removeConstraint(c))
      constraintsRef.current.length = 0
      for (const [, L] of lightsRef.current) scene.remove(L)
      lightsRef.current.clear()
      world.bodies.forEach((b) => world.remove(b))
      scene.clear()
      sceneRef.current = null
      rendererRef.current = null
      cameraRef.current = null
      worldRef.current = null
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  function fitRenderer() {
    const mount = mountRef.current!
    const renderer = rendererRef.current!
    const camera = cameraRef.current!
    const { clientWidth: w, clientHeight: h } = mount
    renderer.setSize(w, h, false)
    camera.aspect = Math.max(1e-6, w / Math.max(1, h))
    camera.updateProjectionMatrix()
  }

  function startLoop() {
    if (rafRef.current != null) return
    let accumFPS = 0
    let frames = 0
    clockRef.current.getDelta()
    const loop = () => {
      const dt = clockRef.current.getDelta()
      if (running) stepPhysics(dt)
      const renderer = rendererRef.current!
      const scene = sceneRef.current!
      const camera = cameraRef.current!
      controlsRef.current!.update()
      renderer.render(scene, camera)

      accumFPS += 1 / Math.max(1e-6, dt)
      frames++
      if (frames % 10 === 0) {
        const fps = (accumFPS / 10) | 0
        accumFPS = 0
        setStats((s) => ({ ...s, fps }))
      }

      rafRef.current = requestAnimationFrame(loop)
    }
    rafRef.current = requestAnimationFrame(loop)
  }
  function stopLoop() {
    if (rafRef.current != null) {
      cancelAnimationFrame(rafRef.current)
      rafRef.current = null
    }
  }

  // -----------------
  // Physics + Energy
  // -----------------
  function stepPhysics(dt: number) {
    const world = worldRef.current!
    accumulatorRef.current += dt
    while (accumulatorRef.current >= fixedDT) {
      world.step(fixedDT)
      accumulatorRef.current -= fixedDT

      if (agentTick) {
        const snapshot = buildSnapshot()
        const env: EnvAPI = {
          run: runPlan,
          spawn: (a) => spawnPrimitive(a),
          impulse: (a) => applyImpulse(a),
          setGravity: (g) => setGravity(g),
          reset: resetWorld,
          tint: (t) => tint(t),
        }
        try {
          Promise.resolve(agentTick(env, snapshot)).catch((e) => logMsg('agentTick error: ' + (e as Error).message))
        } catch (e) {
          logMsg('agentTick threw: ' + (e as Error).message)
        }
      }
    }

    for (const [, entry] of bodiesRef.current) {
      const { body, mesh } = entry
      ;(mesh.position as any).set(body.position.x, body.position.y, body.position.z)
      ;(mesh.quaternion as any).set(body.quaternion.x, body.quaternion.y, body.quaternion.z, body.quaternion.w)
    }

    const energy = computeEnergy()
    const objects = bodiesRef.current.size
    if (!godmode) {
      if (objects > objectCap) {
        cullExcess(objects - objectCap)
        logMsg(`Safety: culled ${objects - objectCap} objects (cap ${objectCap}).`)
      }
      if (energy > energyCap) {
        dampVelocities(0.85)
        logMsg(`Safety: energy ${energy.toFixed(0)} > cap ${energyCap}. Applied damping.`)
      }
    }
    setStats((s) => ({ time: s.time + dt, objects, energy, fps: s.fps }))
  }

  function buildSnapshot(): WorldSnapshot {
    const world = worldRef.current!
    const objects: SnapshotBody[] = []
    bodiesRef.current.forEach(({ id, body, kind }) => {
      objects.push({
        id,
        kind,
        mass: body.mass,
        position: [body.position.x, body.position.y, body.position.z],
        velocity: [body.velocity.x, body.velocity.y, body.velocity.z],
        quaternion: [body.quaternion.x, body.quaternion.y, body.quaternion.z, body.quaternion.w],
      })
    })
    return { time: stats.time, gravity: [world.gravity.x, world.gravity.y, world.gravity.z], objects }
  }

  function computeEnergy() {
    const g = worldRef.current!.gravity.y
    let E = 0
    bodiesRef.current.forEach(({ body }) => {
      if (body.mass === 0) return
      const v2 = body.velocity.lengthSquared()
      const KE = 0.5 * body.mass * v2
      const PE = -body.mass * g * body.position.y
      E += KE + PE
    })
    return E
  }

  function dampVelocities(factor: number) {
    bodiesRef.current.forEach(({ body }) => {
      body.velocity.scale(factor, body.velocity)
      body.angularVelocity.scale(factor, body.angularVelocity)
    })
  }

  function cullExcess(n: number) {
    const keys = Array.from(bodiesRef.current.keys())
    for (let i = 0; i < n; i++) {
      const id = keys[i]
      const entry = bodiesRef.current.get(id)
      if (entry) removeEntry(entry)
    }
  }

  function addBounds(half: CANNON.Vec3) {
    const world = worldRef.current!
    const scene = sceneRef.current!
    const createPlane = (normal: CANNON.Vec3, distance: number) => {
      const shape = new CANNON.Plane()
      const body = new CANNON.Body({ mass: 0 })
      body.addShape(shape)
      const q = new CANNON.Quaternion()
      q.setFromVectors(new CANNON.Vec3(0, 1, 0), normal)
      body.quaternion.copy(q)
      body.position.set(normal.x * distance, normal.y * distance, normal.z * distance)
      world.addBody(body)
      const helper = new THREE.GridHelper(half.x * 2, 40, '#262637', '#1b1b26')
      ;(helper.position as any).set(body.position.x, body.position.y, body.position.z)
      if (normal.x !== 0) helper.rotation.z = Math.PI / 2
      if (normal.z !== 0) helper.rotation.x = Math.PI / 2
      if (normal.y !== 1) helper.rotation.y = 0
      scene.add(helper)
    }
    createPlane(new CANNON.Vec3(0, 1, 0), -half.y)
    createPlane(new CANNON.Vec3(0, -1, 0), -half.y)
    createPlane(new CANNON.Vec3(1, 0, 0), -half.x)
    createPlane(new CANNON.Vec3(-1, 0, 0), -half.x)
    createPlane(new CANNON.Vec3(0, 0, 1), -half.z)
    createPlane(new CANNON.Vec3(0, 0, -1), -half.z)
  }

  // -----------------
  // Tool Implementations
  // -----------------

  function hexToThree(c?: string) {
    return new THREE.Color(c || '#9ad1ff')
  }

  function addEntry(entry: BodyEntry) {
    bodiesRef.current.set(entry.id, entry)
    const world = worldRef.current!
  
(Content truncated due to size limit. Use page ranges or line ranges to read remaining content)