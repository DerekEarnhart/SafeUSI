export class Policy {
  cfg: any;
  constructor(cfg: any) { this.cfg = cfg; }
  allowShell(bin: string) {
    return !!this.cfg.policies?.allow_shell && ['npm','pnpm','yarn','pytest','python','node','npx','go','make'].includes(bin);
  }
  allowNetwork(url: string) {
    if (!this.cfg.policies?.allow_network) return false;
    try {
      const u = new URL(url);
      return (this.cfg.policies?.allow_domains || []).includes(u.hostname);
    } catch { return false; }
  }
}
