CLI: compressia -c/-d; REST: /v1/compress
