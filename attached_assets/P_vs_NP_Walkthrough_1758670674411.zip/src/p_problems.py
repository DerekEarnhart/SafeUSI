import time

def linear_search(arr, target):
    """
    Demonstrates a P-problem: Linear Search.
    Time Complexity: O(n) - Linear time.
    """
    print(f"  > Performing Linear Search for {target} in {arr}...")
    start_time = time.perf_counter()
    for i, element in enumerate(arr):
        if element == target:
            end_time = time.perf_counter()
            print(f"  > Found {target} at index {i} in {end_time - start_time:.6f} seconds.")
            return True
    end_time = time.perf_counter()
    print(f"  > {target} not found in {end_time - start_time:.6f} seconds.")
    return False

def bubble_sort(arr):
    """
    Demonstrates another P-problem: Bubble Sort.
    Time Complexity: O(n^2) - Quadratic time.
    """
    original_arr = list(arr) # Keep original for printing
    n = len(arr)
    print(f"  > Performing Bubble Sort on {original_arr}...")
    start_time = time.perf_counter()
    for i in range(n):
        for j in range(0, n-i-1):
            if arr[j] > arr[j+1]:
                arr[j], arr[j+1] = arr[j+1], arr[j]
    end_time = time.perf_counter()
    print(f"  > Sorted array: {arr} in {end_time - start_time:.6f} seconds.")
    return arr

if __name__ == "__main__":
    print("--- P-Problems Demonstration ---")
    my_list_p = [5, 1, 8, 2, 9, 3, 7, 4, 6]
    linear_search(my_list_p, 8)
    linear_search(my_list_p, 10)
    print("-" * 30)
    bubble_sort(my_list_p)
    print("-" * 30)
