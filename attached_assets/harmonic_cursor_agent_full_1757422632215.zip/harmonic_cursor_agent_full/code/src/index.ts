import 'dotenv/config';
import yargs from 'yargs';
import { hideBin } from 'yargs/helpers';
import { Agent } from './core/agent.js';

const argv = await yargs(hideBin(process.argv))
  .usage('$0 [task]', 'Run Harmonic Agent on a task', (y) => y
    .positional('task', { type: 'string', describe: 'Task prompt' })
    .option('config', { type: 'string', describe: 'Path to config JSON' }))
  .help().parse();

const task = (argv._.join(' ') || '').trim();
const agent = new Agent({ configPath: argv.config as string | undefined });
const result = await agent.run(task || 'No task provided.');

console.log('\n=== RESULT ===');
console.log(result.summary);
process.exit(result.success ? 0 : 1);
