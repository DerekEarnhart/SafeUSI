# Quantum Geometry VM — Scaffold (Patched)

**Critical:** Run all commands from the project root — the folder that contains both `app\` and `qgvm2\`.

## Windows Quickstart
1) Open **Command Prompt** in this folder (project root).
2) Create venv + install deps:
   ```bat
   scripts\setup_venv.bat
   ```
3) Start the server (module mode ensures imports work):
   ```bat
   scripts\run_server_module.bat
   ```
4) In a second terminal, test endpoints:
   ```bat
   scripts\test_endpoints.bat
   ```

If you prefer running the script directly, use:
```bat
scripts\set_pythonpath_and_run.bat
```

## Expected Layout
```
<project_root>\
  app\mini_server.py
  qgvm2\vm_api.py
  qgvm2\universal_task_orchestrator.py
  ...
  scripts\*.bat
```
