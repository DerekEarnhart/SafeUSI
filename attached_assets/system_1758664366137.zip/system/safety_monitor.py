class SafetyMonitor:
    """
    Ensures safe operation.
    """
    def check(self):
        pass
