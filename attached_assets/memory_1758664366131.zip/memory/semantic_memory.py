class SemanticMemory:
    """
    Conceptual knowledge and relationships.
    """
    def __init__(self):
        self.concepts = {}

    def add_concept(self, name, data):
        """Store a concept."""
        self.concepts[name] = data
