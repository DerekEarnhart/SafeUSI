
import argparse, torch
from wsmpro.model import WSMForCausalLM
from wsmpro.tokenization import load_tokenizer

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--teacher", type=str, default=None, help="HF id or local path of teacher")
    ap.add_argument("--tokenizer", type=str, default="./assets/tokenizer")
    ap.add_argument("--out", type=str, default="./wsm_ckpt.pt")
    args = ap.parse_args()
    # Skeleton: user should load a teacher model locally and compute KL loss.
    # We provide just a placeholder here.
    tok = load_tokenizer(args.tokenizer)
    model = WSMForCausalLM()
    torch.save(model.state_dict(), args.out)
    print("Distill placeholder: saved random-init", args.out)

if __name__ == "__main__":
    main()
