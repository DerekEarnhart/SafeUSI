# WSM Pro (Proprietary Replacement for LLMs)
- Symplectic RNN (Weyl-State Machine) with `expm` or `cayley` updates
- Offline-ready, includes training, distillation, serving, eval, tests
- Adapter for quick swap-in

Quickstart:
  python -m venv .venv && source .venv/bin/activate
  pip install torch transformers tokenizers pyyaml fastapi uvicorn
  python scripts/train.py --config configs/pro_base.yaml --data_dir ./data --out ./wsm_ckpt.pt --tokenizer ./assets/tokenizer
  python scripts/serve.py --ckpt ./wsm_ckpt.pt --port 8080
