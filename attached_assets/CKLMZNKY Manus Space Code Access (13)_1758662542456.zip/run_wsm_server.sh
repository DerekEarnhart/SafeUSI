cd /home/ubuntu/HUS_WSM_full_bundle/Pipeline/
export PYTHONPATH=$PYTHONPATH:/home/ubuntu/HUS_WSM_full_bundle/WSM_Pro_v4
uvicorn pipeline_server_fixed:app --reload --port 8081

