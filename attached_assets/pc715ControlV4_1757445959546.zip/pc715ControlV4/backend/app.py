"""FastAPI entry point for Sovereign HA‑AGI"""
from fastapi import FastAPI
from pydantic import BaseModel
from backend.core import harmonic_algebra, nlp_encoder, safety_operator
from backend.core.knowledge_loader import ensure_index
from backend.plugins import pc_control
import uvicorn, os

app = FastAPI(title="Sovereign HA‑AGI", version="0.1.0" )

class Query(BaseModel):
    text: str

@app.on_event("startup")
def _init():
    # build / load embedding index
    ensure_index()

@app.post("/chat")
def chat(q: Query):
    # 1. Encode
    vec = nlp_encoder.encode(q.text)
    # 2. Run through AGI core (placeholder)
    reply = f"(stub) You said: {q.text[:100]}"
    # 3. Safety filter
    reply = safety_operator.apply(reply)
    return {"reply": reply}

# default route
@app.get("/")
def root():
    return {"msg": "Sovereign HA‑AGI online"}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=int(os.getenv("PORT", 8000)))
