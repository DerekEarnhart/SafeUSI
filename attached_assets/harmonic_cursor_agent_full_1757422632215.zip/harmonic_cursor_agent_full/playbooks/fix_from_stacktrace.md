# Playbook: Fix from Stacktrace

- Parse error → locate file/line with context.  
- Reproduce with minimal input.  
- Add failing unit test first.  
- Patch minimal surface; ensure types.  
- Rerun tests → reflect on failure cause; document fix.
