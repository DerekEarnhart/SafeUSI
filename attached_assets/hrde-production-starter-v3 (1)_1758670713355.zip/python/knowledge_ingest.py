import argparse, os, sqlite3
from pathlib import Path
def walk_texts(root: Path):
    for p in root.rglob("*"):
        if p.suffix.lower() in {".txt",".md",".json"} and p.is_file(): yield p
def ingest(path: str, db_path: str):
    root = Path(path); conn = sqlite3.connect(db_path); cur = conn.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS docs (id INTEGER PRIMARY KEY, path TEXT, content TEXT)")
    for f in walk_texts(root):
        try: content = f.read_text(errors="ignore")
        except Exception: continue
        cur.execute("INSERT INTO docs(path, content) VALUES(?, ?)", (str(f), content))
    conn.commit(); conn.close()
if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--path", required=True); ap.add_argument("--db", required=True); a = ap.parse_args()
    os.makedirs(os.path.dirname(a.db), exist_ok=True); ingest(a.path, a.db); print("Ingest complete ->", a.db)
