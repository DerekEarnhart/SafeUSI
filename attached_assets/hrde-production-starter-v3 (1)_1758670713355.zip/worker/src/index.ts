export default {
  async fetch(req: Request, env: any): Promise<Response> {
    const url = new URL(req.url);
    const apiKeys = (env.API_KEYS || "").split(",").map((s: string)=>s.trim()).filter(Boolean);
    const key = req.headers.get("X-API-Key");
    if (apiKeys.length && !apiKeys.includes(key || "")) return new Response("Forbidden", { status: 403 });
    const body = await req.arrayBuffer();
    const enc = new TextEncoder();
    const secret = enc.encode(env.HMAC_SECRET || "change_me");
    const keyObj = await crypto.subtle.importKey("raw", secret, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
    const sigBuf = await crypto.subtle.sign({ name: "HMAC", hash: "SHA-256" }, keyObj, body);
    const sigHex = [...new Uint8Array(sigBuf)].map(b=>b.toString(16).padStart(2,"0")).join("");
    const upstream = env.UPSTREAM_URL || "http://127.0.0.1:8000";
    const fwd = new Request(upstream + url.pathname + url.search, { method: req.method, headers: new Headers(req.headers), body });
    fwd.headers.set("X-Signature", sigHex);
    return fetch(fwd);
  }
};
