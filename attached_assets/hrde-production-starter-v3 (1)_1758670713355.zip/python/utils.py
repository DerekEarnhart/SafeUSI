import hmac, hashlib, os
from typing import Optional
def hmac_signature(body: bytes, secret: str) -> str:
    return hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
def getenv(name: str, default: Optional[str] = None) -> str:
    val = os.getenv(name, default)
    if val is None: raise RuntimeError(f"Missing required env var: {name}")
    return val
