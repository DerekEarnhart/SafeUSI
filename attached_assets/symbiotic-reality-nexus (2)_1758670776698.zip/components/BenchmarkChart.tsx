import React, { useState, useEffect } from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

interface BenchmarkChartProps {
  label: string;
  value: number;
  color: string;
  unit: string;
  maxHistory: number;
}

const BenchmarkChart: React.FC<BenchmarkChartProps> = ({ label, value, color, unit, maxHistory }) => {
  const [history, setHistory] = useState<{ time: number, value: number }[]>([]);

  useEffect(() => {
    setHistory(prev => {
      const newHistory = [...prev, { time: Date.now(), value }];
      if (newHistory.length > maxHistory) {
        return newHistory.slice(1);
      }
      return newHistory;
    });
  }, [value, maxHistory]);

  const gradientId = `color-${label}`;

  return (
    <div className="h-full w-full flex flex-col p-2 bg-black/20 rounded-lg">
      <div className="flex justify-between items-baseline font-mono text-sm">
        <span className="text-gray-400">{label}</span>
        <span className="text-lg font-bold" style={{ color }}>
          {value.toFixed(2)}
          <span className="text-xs text-gray-500 ml-1">{unit}</span>
        </span>
      </div>
      <div className="flex-1">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={history} margin={{ top: 5, right: 0, left: 0, bottom: 0 }}>
            <defs>
              <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={color} stopOpacity={0.8}/>
                <stop offset="95%" stopColor={color} stopOpacity={0}/>
              </linearGradient>
            </defs>
            <Tooltip
                contentStyle={{ 
                    backgroundColor: 'rgba(20, 20, 30, 0.8)', 
                    border: '1px solid #334155',
                    color: '#e2e8f0'
                }}
                labelStyle={{ display: 'none' }}
                formatter={(val: number) => [`${val.toFixed(2)} ${unit}`, null]}
            />
            <Area type="monotone" dataKey="value" stroke={color} fillOpacity={1} fill={`url(#${gradientId})`} strokeWidth={2} />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default BenchmarkChart;
