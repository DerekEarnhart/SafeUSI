"""Minimal placeholder for Harmonic Algebra operations."""
import numpy as np

def weyl_unitary(q: float, p: float):
    # TODO: implement proper Weyl unitary
    return np.array([[np.exp(1j*(q+p))]])

def commutator(a, b):
    return a @ b - b @ a
