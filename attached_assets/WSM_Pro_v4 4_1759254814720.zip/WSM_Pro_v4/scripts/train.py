
import argparse, torch, torch.nn as nn
from torch.utils.data import DataLoader, Dataset
from wsmpro.model import WSMForCausalLM
from wsmpro.tokenization import load_tokenizer

class TextDataset(Dataset):
    def __init__(self, texts, tok, block=64):
        self.ids = []
        for t in texts:
            ids = tok.encode(t, add_special_tokens=False)
            # chop into blocks
            for i in range(0, max(1, len(ids)-block), block):
                x = ids[i:i+block]
                y = ids[i+block-1] if i+block-1 < len(ids) else ids[-1]
                self.ids.append((x, y))
    def __len__(self): return len(self.ids)
    def __getitem__(self, i):
        x, y = self.ids[i]
        x = torch.tensor(x, dtype=torch.long).unsqueeze(0)  # (1,T)
        y = torch.tensor(y, dtype=torch.long)
        return x, y

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", type=str, default=None, help="path to a text file (one doc per line)")
    ap.add_argument("--tokenizer", type=str, default="./assets/tokenizer")
    ap.add_argument("--out", type=str, default="./wsm_ckpt.pt")
    ap.add_argument("--epochs", type=int, default=1)
    ap.add_argument("--lr", type=float, default=3e-4)
    args = ap.parse_args()

    tok = load_tokenizer(args.tokenizer)
    texts = []
    if args.data and os.path.exists(args.data):
        with open(args.data, "r", encoding="utf-8") as f:
            texts = [line.strip() for line in f if line.strip()]
    else:
        texts = ["Hello world.", "This is a tiny dataset. Replace with your own."]

    ds = TextDataset(texts, tok)
    dl = DataLoader(ds, batch_size=8, shuffle=True)

    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = WSMForCausalLM().to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=args.lr)

    for epoch in range(args.epochs):
        for x, y in dl:
            x, y = x.to(device), y.to(device)
            out = model(x, labels=y)
            loss = out["loss"]
            loss.backward()
            opt.step(); opt.zero_grad()
        print(f"Epoch {epoch+1} done.")
    torch.save(model.state_dict(), args.out)
    print("Saved", args.out)

if __name__ == "__main__":
    import os
    main()
