import fs from 'fs';
import path from 'path';

function tokenize(text: string) {
  return text.toLowerCase().replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter(Boolean);
}
function bow(text: string) {
  const toks = tokenize(text); const map: Record<string, number> = {};
  toks.forEach(t => map[t] = (map[t]||0)+1);
  return map;
}
function cosine(a: Record<string, number>, b: Record<string, number>) {
  const keys = new Set([...Object.keys(a), ...Object.keys(b)]);
  let dot=0, na=0, nb=0;
  for (const k of keys) {
    const va = a[k]||0, vb = b[k]||0;
    dot += va*vb; na += va*va; nb += vb*vb;
  }
  return dot / (Math.sqrt(na||1)*Math.sqrt(nb||1));
}

export class Memory {
  dir: string;
  kvPath: string;
  constructor(cfg: any) {
    this.dir = cfg.memory?.dir || '.harmonic_agent';
    this.kvPath = path.join(this.dir, 'kv.json');
    if (!fs.existsSync(this.dir)) fs.mkdirSync(this.dir, { recursive: true });
    if (!fs.existsSync(this.kvPath)) fs.writeFileSync(this.kvPath, '[]', 'utf8');
  }
  async store(task: string, summary: string) {
    const items = JSON.parse(fs.readFileSync(this.kvPath, 'utf8'));
    items.push({ ts: Date.now(), task, summary });
    fs.writeFileSync(this.kvPath, JSON.stringify(items, null, 2), 'utf8');
  }
  async retrieve(query: string, k=5) {
    const items = JSON.parse(fs.readFileSync(this.kvPath, 'utf8'));
    const qv = bow(query);
    return items.map((it: any) => ({ it, score: cosine(qv, bow(it.task + ' ' + it.summary)) }))
      .sort((a: any,b: any) => b.score - a.score)
      .slice(0,k)
      .map((x: any) => x.it.summary).join('\n---\n');
  }
  appendLog(entry: any) {
    const logPath = path.join(this.dir, 'run.log');
    fs.appendFileSync(logPath, JSON.stringify(entry) + '\n', 'utf8');
  }
}
