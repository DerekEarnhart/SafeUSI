#!/usr/bin/env python3
"""
{{SPEC_NAME}} — Micro Benchmark: Sorting Performance (standard library only)

Runs timed trials for built-in sorting strategies across multiple array sizes.
Usage:
    python micro_benchmark.py --sizes 5000 10000 20000 --runs 5
"""
import argparse
import random
import statistics as stats
import time
from typing import List, Tuple

def gen_data(n: int, seed: int = 1337) -> List[int]:
    rnd = random.Random(seed)  # deterministic
    return [rnd.randint(-10**9, 10**9) for _ in range(n)]

def bench_once(data: List[int]) -> Tuple[float, float]:
    """Return (t_sorted, t_inplace) times in seconds."""
    # Measure sorted() (returns new list)
    d1 = list(data)
    t0 = time.perf_counter()
    _ = sorted(d1)
    t1 = time.perf_counter()
    t_sorted = t1 - t0

    # Measure list.sort() (in place)
    d2 = list(data)
    t0 = time.perf_counter()
    d2.sort()
    t1 = time.perf_counter()
    t_inplace = t1 - t0
    return t_sorted, t_inplace

def run_bench(sizes: List[int], runs: int):
    results = []
    for n in sizes:
        data = gen_data(n, seed=1337 + n)
        s_times, i_times = [], []
        for _ in range(runs):
            ts, ti = bench_once(data)
            s_times.append(ts)
            i_times.append(ti)
        results.append({
            "size": n,
            "sorted_mean_ms": 1000 * stats.mean(s_times),
            "sorted_stdev_ms": 1000 * (stats.stdev(s_times) if len(s_times) > 1 else 0.0),
            "inplace_mean_ms": 1000 * stats.mean(i_times),
            "inplace_stdev_ms": 1000 * (stats.stdev(i_times) if len(i_times) > 1 else 0.0),
            "runs": runs,
        })
    return results

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sizes", nargs="+", type=int, default=[5000, 10000, 20000])
    ap.add_argument("--runs", type=int, default=5)
    args = ap.parse_args()

    print("# Sorting Micro-Benchmark")
    print(f"# sizes={args.sizes} runs={args.runs}")
    results = run_bench(args.sizes, args.runs)
    print("size,sorted_mean_ms,sorted_stdev_ms,inplace_mean_ms,inplace_stdev_ms,runs")
    for r in results:
        print("{size},{sorted_mean_ms:.3f},{sorted_stdev_ms:.3f},{inplace_mean_ms:.3f},{inplace_stdev_ms:.3f},{runs}".format(**r))

if __name__ == "__main__":
    main()
