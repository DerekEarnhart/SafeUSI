"""
Financial Market Analyzer

This module provides tools for analyzing financial market data,
detecting anomalies, and generating predictions using harmonic
algebraic probability principles.
"""

import os
import sys
import json
import logging
import math
import random
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Union, Tuple, Set

import numpy as np
import pandas as pd
import plotly.graph_objects as go

# Import HAP components if available
from harmonic_algebraic_probability import HAPProcessor, DistributionType

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class MarketDataPoint:
    """Represents a single market data point."""
    
    def __init__(self, symbol: str, timestamp: Union[str, datetime], 
                open_price: float, high_price: float, low_price: float, 
                close_price: float, volume: float, additional_data: Optional[Dict[str, Any]] = None):
        """
        Initialize a market data point.
        
        Args:
            symbol: Market symbol (e.g., "AAPL")
            timestamp: Timestamp of the data point
            open_price: Opening price
            high_price: Highest price
            low_price: Lowest price
            close_price: Closing price
            volume: Trading volume
            additional_data: Additional market data
        """
        self.symbol = symbol
        
        # Convert string timestamp to datetime if needed
        if isinstance(timestamp, str):
            try:
                self.timestamp = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
            except ValueError:
                self.timestamp = datetime.strptime(timestamp, "%Y-%m-%d %H:%M:%S")
        else:
            self.timestamp = timestamp
        
        self.open = open_price
        self.high = high_price
        self.low = low_price
        self.close = close_price
        self.volume = volume
        self.additional_data = additional_data or {}
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "symbol": self.symbol,
            "timestamp": self.timestamp.isoformat(),
            "open": self.open,
            "high": self.high,
            "low": self.low,
            "close": self.close,
            "volume": self.volume,
            **self.additional_data
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'MarketDataPoint':
        """Create from dictionary."""
        return cls(
            symbol=data["symbol"],
            timestamp=data["timestamp"],
            open_price=data["open"],
            high_price=data["high"],
            low_price=data["low"],
            close_price=data["close"],
            volume=data["volume"],
            additional_data={k: v for k, v in data.items() 
                            if k not in ["symbol", "timestamp", "open", "high", "low", "close", "volume"]}
        )

class MarketAnomaly:
    """Represents an anomaly detected in market data."""
    
    def __init__(self, symbol: str, timestamp: Union[str, datetime], 
                anomaly_type: str, severity: float, description: str, 
                data_point: Optional[MarketDataPoint] = None):
        """
        Initialize a market anomaly.
        
        Args:
            symbol: Market symbol (e.g., "AAPL")
            timestamp: Timestamp of the anomaly
            anomaly_type: Type of anomaly (e.g., "price_spike", "volume_surge")
            severity: Severity of the anomaly (0.0 to 1.0)
            description: Description of the anomaly
            data_point: Associated market data point
        """
        self.symbol = symbol
        
        # Convert string timestamp to datetime if needed
        if isinstance(timestamp, str):
            try:
                self.timestamp = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
            except ValueError:
                self.timestamp = datetime.strptime(timestamp, "%Y-%m-%d %H:%M:%S")
        else:
            self.timestamp = timestamp
        
        self.anomaly_type = anomaly_type
        self.severity = severity
        self.description = description
        self.data_point = data_point
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "symbol": self.symbol,
            "timestamp": self.timestamp.isoformat(),
            "anomaly_type": self.anomaly_type,
            "severity": self.severity,
            "description": self.description,
            "data_point": self.data_point.to_dict() if self.data_point else None
        }

class MarketPrediction:
    """Represents a market prediction."""
    
    def __init__(self, symbol: str, model_id: str, target_timestamp: Union[str, datetime],
                current_timestamp: Union[str, datetime], predicted_value: float,
                confidence: float, prediction_type: str = "price"):
        """
        Initialize a market prediction.
        
        Args:
            symbol: Market symbol (e.g., "AAPL")
            model_id: Identifier of the model making the prediction
            target_timestamp: Target timestamp for the prediction
            current_timestamp: Timestamp when the prediction was made
            predicted_value: Predicted value
            confidence: Confidence level (0.0 to 1.0)
            prediction_type: Type of prediction (e.g., "price", "trend")
        """
        self.symbol = symbol
        self.model_id = model_id
        self.prediction_type = prediction_type
        
        # Convert string timestamps to datetime if needed
        if isinstance(target_timestamp, str):
            try:
                self.target_timestamp = datetime.fromisoformat(target_timestamp.replace('Z', '+00:00'))
            except ValueError:
                self.target_timestamp = datetime.strptime(target_timestamp, "%Y-%m-%d %H:%M:%S")
        else:
            self.target_timestamp = target_timestamp
        
        if isinstance(current_timestamp, str):
            try:
                self.current_timestamp = datetime.fromisoformat(current_timestamp.replace('Z', '+00:00'))
            except ValueError:
                self.current_timestamp = datetime.strptime(current_timestamp, "%Y-%m-%d %H:%M:%S")
        else:
            self.current_timestamp = current_timestamp
        
        self.predicted_value = predicted_value
        self.confidence = confidence
        
        # Additional metadata
        self.prediction_horizon = (self.target_timestamp - self.current_timestamp).total_seconds() / 86400  # days
        self.actual_value = None  # To be filled when actual data becomes available
        self.error = None  # To be calculated when actual data becomes available
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "symbol": self.symbol,
            "model_id": self.model_id,
            "prediction_type": self.prediction_type,
            "target_timestamp": self.target_timestamp.isoformat(),
            "current_timestamp": self.current_timestamp.isoformat(),
            "predicted_value": self.predicted_value,
            "confidence": self.confidence,
            "prediction_horizon": self.prediction_horizon,
            "actual_value": self.actual_value,
            "error": self.error
        }
    
    def update_with_actual(self, actual_value: float) -> None:
        """
        Update with actual value once available.
        
        Args:
            actual_value: Actual observed value
        """
        self.actual_value = actual_value
        self.error = actual_value - self.predicted_value

class BacktestResult:
    """Represents the result of a backtest."""
    
    def __init__(self, symbol: str, strategy_name: str, start_date: Union[str, datetime],
                end_date: Union[str, datetime], initial_capital: float = 10000.0):
        """
        Initialize backtest result.
        
        Args:
            symbol: Market symbol (e.g., "AAPL")
            strategy_name: Name of the strategy
            start_date: Start date of the backtest
            end_date: End date of the backtest
            initial_capital: Initial capital for the backtest
        """
        self.symbol = symbol
        self.strategy_name = strategy_name
        
        # Convert string dates to datetime if needed
        if isinstance(start_date, str):
            try:
                self.start_date = datetime.fromisoformat(start_date.replace('Z', '+00:00'))
            except ValueError:
                self.start_date = datetime.strptime(start_date, "%Y-%m-%d")
        else:
            self.start_date = start_date
        
        if isinstance(end_date, str):
            try:
                self.end_date = datetime.fromisoformat(end_date.replace('Z', '+00:00'))
            except ValueError:
                self.end_date = datetime.strptime(end_date, "%Y-%m-%d")
        else:
            self.end_date = end_date
        
        self.initial_capital = initial_capital
        self.final_capital = initial_capital  # To be updated during backtest
        
        # Performance metrics
        self.net_profit = 0.0
        self.net_profit_percent = 0.0
        self.sharpe_ratio = 0.0
        self.max_drawdown = 0.0
        self.win_rate = 0.0
        self.trades = []
        self.equity_curve = []
        
        # Settings used for the backtest
        self.settings = {}
        
        # Timestamp
        self.timestamp = datetime.now().isoformat()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "symbol": self.symbol,
            "strategy_name": self.strategy_name,
            "start_date": self.start_date.isoformat(),
            "end_date": self.end_date.isoformat(),
            "initial_capital": self.initial_capital,
            "final_capital": self.final_capital,
            "net_profit": self.net_profit,
            "net_profit_percent": self.net_profit_percent,
            "sharpe_ratio": self.sharpe_ratio,
            "max_drawdown": self.max_drawdown,
            "win_rate": self.win_rate,
            "trades_count": len(self.trades),
            "settings": self.settings,
            "timestamp": self.timestamp
        }
    
    def update_performance_metrics(self, trades: List[Dict[str, Any]], equity_curve: List[float]) -> None:
        """
        Update performance metrics based on trades and equity curve.
        
        Args:
            trades: List of trades executed during backtest
            equity_curve: Equity curve during backtest
        """
        self.trades = trades
        self.equity_curve = equity_curve
        
        if not trades or not equity_curve:
            return
        
        # Calculate performance metrics
        self.final_capital = equity_curve[-1] if equity_curve else self.initial_capital
        self.net_profit = self.final_capital - self.initial_capital
        self.net_profit_percent = self.net_profit / self.initial_capital if self.initial_capital > 0 else 0.0
        
        # Calculate win rate
        winning_trades = [t for t in trades if t.get("profit", 0) > 0]
        self.win_rate = len(winning_trades) / len(trades) if trades else 0.0
        
        # Calculate max drawdown
        max_value = equity_curve[0]
        max_drawdown = 0.0
        
        for value in equity_curve:
            if value > max_value:
                max_value = value
            drawdown = (max_value - value) / max_value if max_value > 0 else 0.0
            max_drawdown = max(max_drawdown, drawdown)
        
        self.max_drawdown = max_drawdown
        
        # Calculate Sharpe ratio (simplified)
        if len(equity_curve) > 1:
            returns = [
                (equity_curve[i] - equity_curve[i-1]) / equity_curve[i-1] 
                for i in range(1, len(equity_curve))
            ]
            avg_return = sum(returns) / len(returns) if returns else 0.0
            std_return = (sum((r - avg_return) ** 2 for r in returns) / len(returns)) ** 0.5 if returns else 1.0
            self.sharpe_ratio = avg_return / std_return if std_return > 0 else 0.0

class FinancialMarketAnalyzer:
    """
    A comprehensive tool for analyzing financial market data,
    detecting anomalies, and generating predictions.
    """
    
    def __init__(self, use_hap: bool = True, harmonic_base: float = 1.618, 
                quantum_influence: float = 0.01):
        """
        Initialize the Financial Market Analyzer.
        
        Args:
            use_hap: Whether to use Harmonic Algebraic Probability
            harmonic_base: Harmonic base parameter (phi by default)
            quantum_influence: Quantum influence factor (0.0 to 1.0)
        """
        self.use_hap = use_hap
        self.harmonic_base = harmonic_base
        self.quantum_influence = quantum_influence
        
        # Initialize HAP processor
        if use_hap:
            self.hap_processor = HAPProcessor(
                harmonic_base=harmonic_base,
                dimension=3,
                quantum_factor=quantum_influence
            )
        else:
            self.hap_processor = None
        
        # Initialize data storage
        self.market_data_cache = {}  # symbol -> list of MarketDataPoint
        self.anomalies = {}  # symbol -> list of MarketAnomaly
        self.predictions = {}  # model_id -> symbol -> list of MarketPrediction
        self.backtest_results = {}  # strategy -> symbol -> list of BacktestResult
        
        # Initialize models
        self.models = {}
        self._initialize_base_models()
        
        # Performance tracking
        self.prediction_performance = {}  # model_id -> performance metrics
        
        # Trading strategies
        self.strategies = {
            "trend_following": self._trend_following_strategy,
            "mean_reversion": self._mean_reversion_strategy,
            "breakout": self._breakout_strategy,
            "anomaly_based": self._anomaly_based_strategy,
            "harmonic_resonance": self._harmonic_resonance_strategy
        }
        
        # Initialize timestamp
        self.timestamp = datetime.now().isoformat()
        
        logger.info(f"Initialized Financial Market Analyzer (HAP: {use_hap}, Base: {harmonic_base})")
    
    def _initialize_base_models(self) -> None:
        """Initialize base prediction models."""
        # Simple Moving Average model
        self.models["sma"] = {
            "name": "Simple Moving Average",
            "type": "technical",
            "parameters": {
                "short_period": 20,
                "long_period": 50
            }
        }
        
        # Harmonic Fibonacci model
        self.models["harmonic_fibonacci"] = {
            "name": "Harmonic Fibonacci",
            "type": "harmonic",
            "parameters": {
                "pattern_types": ["gartley", "butterfly", "bat"],
                "harmonic_base": self.harmonic_base
            }
        }
        
        # Linear Regression model
        self.models["linear_regression"] = {
            "name": "Linear Regression",
            "type": "statistical",
            "parameters": {
                "lookback_period": 30,
                "prediction_horizon": 5
            }
        }
        
        # HAP-based Quantum model
        if self.use_hap:
            self.models["hap_quantum"] = {
                "name": "HAP Quantum",
                "type": "quantum_harmonic",
                "parameters": {
                    "harmonic_base": self.harmonic_base,
                    "quantum_factor": self.quantum_influence,
                    "distribution_type": DistributionType.QUANTUM_HARMONIC
                }
            }
    
    def update_market_data(self, symbol: str, data_points: Union[List[Dict], List[MarketDataPoint]]) -> bool:
        """
        Update market data for a symbol.
        
        Args:
            symbol: Market symbol (e.g., "AAPL")
            data_points: List of market data points
            
        Returns:
            Success flag
        """
        if not data_points:
            logger.warning(f"No data points provided for {symbol}")
            return False
        
        # Convert dict data points to MarketDataPoint objects if needed
        market_data = []
        
        for point in data_points:
            if isinstance(point, dict):
                try:
                    market_data.append(MarketDataPoint.from_dict(point))
                except (KeyError, ValueError) as e:
                    logger.error(f"Error converting data point for {symbol}: {e}")
                    continue
            else:
                market_data.append(point)
        
        if not market_data:
            logger.warning(f"No valid data points for {symbol} after conversion")
            return False
        
        # Initialize cache for symbol if needed
        if symbol not in self.market_data_cache:
            self.market_data_cache[symbol] = []
        
        # Add new data points
        self.market_data_cache[symbol].extend(market_data)
        
        # Sort by timestamp
        self.market_data_cache[symbol].sort(key=lambda x: x.timestamp)
        
        # Limit cache size (keep last 1000 points)
        if len(self.market_data_cache[symbol]) > 1000:
            self.market_data_cache[symbol] = self.market_data_cache[symbol][-1000:]
        
        logger.info(f"Updated market data for {symbol} with {len(market_data)} points")
        return True
    
    def detect_anomalies(self, symbol: str, method: str = "hap", threshold: float = 0.8) -> List[MarketAnomaly]:
        """
        Detect anomalies in market data.
        
        Args:
            symbol: Market symbol (e.g., "AAPL")
            method: Anomaly detection method ("hap", "statistical", "combined")
            threshold: Anomaly detection threshold
            
        Returns:
            List of detected anomalies
        """
        if symbol not in self.market_data_cache or not self.market_data_cache[symbol]:
            logger.warning(f"No market data available for {symbol}")
            return []
        
        data_points = self.market_data_cache[symbol]
        anomalies = []
        
        if method == "hap" and self.use_hap:
            # Use HAP-based anomaly detection
            close_prices = np.array([p.close for p in data_points])
            volumes = np.array([p.volume for p in data_points])
            
            # Process data with HAP processor
            price_result = self.hap_processor.process_time_series(close_prices)
            volume_result = self.hap_processor.process_time_series(volumes)
            
            # Detect price anomalies
            resonance = price_result["resonance"]
            for i in range(len(resonance)):
                if resonance[i] > threshold:
                    # Potential price anomaly
                    anomalies.append(MarketAnomaly(
                        symbol=symbol,
                        timestamp=data_points[i].timestamp,
                        anomaly_type="price_pattern",
                        severity=resonance[i],
                        description=f"HAP pattern resonance detected in price data ({resonance[i]:.2f})",
                        data_point=data_points[i]
                    ))
            
            # Detect volume anomalies
            volume_resonance = volume_result["resonance"]
            for i in range(len(volume_resonance)):
                if volume_resonance[i] > threshold and i < len(data_points):
                    # Potential volume anomaly
                    anomalies.append(MarketAnomaly(
                        symbol=symbol,
                        timestamp=data_points[i].timestamp,
                        anomaly_type="volume_pattern",
                        severity=volume_resonance[i],
                        description=f"HAP pattern resonance detected in volume data ({volume_resonance[i]:.2f})",
                        data_point=data_points[i]
                    ))
        
        elif method == "statistical" or (method == "hap" and not self.use_hap):
            # Use statistical anomaly detection
            # Calculate mean and standard deviation of returns
            close_prices = np.array([p.close for p in data_points])
            volumes = np.array([p.volume for p in data_points])
            
            # Calculate returns
            returns = np.zeros_like(close_prices)
            for i in range(1, len(close_prices)):
                returns[i] = (close_prices[i] - close_prices[i-1]) / close_prices[i-1] if close_prices[i-1] > 0 else 0
            
            # Calculate mean and standard deviation
            mean_return = np.mean(returns[1:])
            std_return = np.std(returns[1:])
            
            # Calculate volume changes
            volume_changes = np.zeros_like(volumes)
            for i in range(1, len(volumes)):
                volume_changes[i] = (volumes[i] - volumes[i-1]) / volumes[i-1] if volumes[i-1] > 0 else 0
            
            # Calculate mean and standard deviation for volume
            mean_volume_change = np.mean(volume_changes[1:])
            std_volume_change = np.std(volume_changes[1:])
            
            # Detect price anomalies
            for i in range(1, len(returns)):
                if abs(returns[i] - mean_return) > threshold * std_return:
                    # Potential price anomaly
                    severity = min(1.0, abs(returns[i] - mean_return) / (3 * std_return))
                    anomalies.append(MarketAnomaly(
                        symbol=symbol,
                        timestamp=data_points[i].timestamp,
                        anomaly_type="price_movement",
                        severity=severity,
                        description=f"Unusual price movement detected ({returns[i]*100:.2f}%)",
                        data_point=data_points[i]
                    ))
            
            # Detect volume anomalies
            for i in range(1, len(volume_changes)):
                if abs(volume_changes[i] - mean_volume_change) > threshold * std_volume_change:
                    # Potential volume anomaly
                    severity = min(1.0, abs(volume_changes[i] - mean_volume_change) / (3 * std_volume_change))
                    anomalies.append(MarketAnomaly(
                        symbol=symbol,
                        timestamp=data_points[i].timestamp,
                        anomaly_type="volume_surge",
                        severity=severity,
                        description=f"Unusual volume activity detected ({volume_changes[i]*100:.2f}%)",
                        data_point=data_points[i]
                    ))
        
        else:  # combined
            # Combine both methods
            hap_anomalies = self.detect_anomalies(symbol, "hap", threshold)
            stat_anomalies = self.detect_anomalies(symbol, "statistical", threshold)
            
            # Merge avoiding duplicates
            anomalies = hap_anomalies
            
            for anomaly in stat_anomalies:
                # Check if we already have an anomaly at this timestamp
                if not any(abs((a.timestamp - anomaly.timestamp).total_seconds()) < 3600 and 
                          a.anomaly_type == anomaly.anomaly_type for a in anomalies):
                    anomalies.append(anomaly)
        
        # Store detected anomalies
        if symbol not in self.anomalies:
            self.anomalies[symbol] = []
        
        self.anomalies[symbol].extend(anomalies)
        
        # Sort anomalies by timestamp
        self.anomalies[symbol].sort(key=lambda x: x.timestamp)
        
        # Limit anomalies cache size (keep last 100)
        if len(self.anomalies[symbol]) > 100:
            self.anomalies[symbol] = self.anomalies[symbol][-100:]
        
        logger.info(f"Detected {len(anomalies)} anomalies for {symbol} using {method} method")
        return anomalies
    
    def analyze_market_data(self, symbol: str, metrics: Optional[List[str]] = None) -> Dict[str, Any]:
        """
        Analyze market data for a symbol.
        
        Args:
            symbol: Market symbol (e.g., "AAPL")
            metrics: List of metrics to calculate
            
        Returns:
            Dictionary with analysis results
        """
        if symbol not in self.market_data_cache or not self.market_data_cache[symbol]:
            logger.warning(f"No market data available for {symbol}")
            return {}
        
        data_points = self.market_data_cache[symbol]
        
        # Default metrics to calculate
        if metrics is None:
            metrics = ["trend", "volatility", "momentum", "support_resistance", "patterns"]
        
        analysis_results = {
            "symbol": symbol,
            "analysis_timestamp": datetime.now().isoformat(),
            "data_points_count": len(data_points),
            "date_range": {
                "start": data_points[0].timestamp.isoformat(),
                "end": data_points[-1].timestamp.isoformat()
            }
        }
        
        # Extract prices
        close_prices = np.array([p.close for p in data_points])
        
        # Calculate technical metrics
        if "trend" in metrics:
            analysis_results["trend"] = self._calculate_trend(close_prices)
        
        if "volatility" in metrics:
            analysis_results["volatility"] = self._calculate_volatility(close_prices)
        
        if "momentum" in metrics:
            analysis_results["momentum"] = self._calculate_momentum(close_prices)
        
        if "support_resistance" in metrics:
            analysis_results["support_resistance"] = self._calculate_support_resistance(close_prices)
        
        if "patterns" in metrics:
            analysis_results["patterns"] = self._detect_patterns(close_prices)
        
        # Add HAP analysis if available
        if self.use_hap and self.hap_processor:
            hap_results = self.hap_processor.apply_harmonic_transform(close_prices)
            analysis_results["hap_analysis"] = {
                "resonance_score": np.mean(hap_results["harmonic_resonance"]),
                "quantum_probability": np.mean(hap_results["quantum_probability"]),
                "harmonic_base": hap_results["harmonic_base"]
            }
        
        logger.info(f"Completed market analysis for {symbol} with {len(metrics)} metrics")
        return analysis_results
    
    def _calculate_trend(self, prices: np.ndarray) -> Dict[str, Any]:
        """
        Calculate trend metrics.
        
        Args:
            prices: Array of prices
            
        Returns:
            Dictionary with trend metrics
        """
        if len(prices) < 2:
            return {"trend_strength": 0, "trend_direction": "neutral"}
        
        # Calculate simple moving averages
        sma_short = np.mean(prices[-20:]) if len(prices) >= 20 else np.mean(prices)
        sma_long = np.mean(prices[-50:]) if len(prices) >= 50 else np.mean(prices)
        
        # Calculate linear regression
        x = np.arange(len(prices))
        slope, intercept = np.polyfit(x, prices, 1)
        
        # Calculate R-squared
        y_pred = slope * x + intercept
        ss_total = np.sum((prices - np.mean(prices)) ** 2)
        ss_residual = np.sum((prices - y_pred) ** 2)
        r_squared = 1 - (ss_residual / ss_total) if ss_total > 0 else 0
        
        # Determine trend direction
        if sma_short > sma_long and slope > 0:
            trend_direction = "bullish"
        elif sma_short < sma_long and slope < 0:
            trend_direction = "bearish"
        else:
            trend_direction = "neutral"
        
        # Determine trend strength
        trend_strength = min(1.0, abs(slope) * len(prices) / prices[-1] * 10)
        
        return {
            "trend_direction": trend_direction,
            "trend_strength": trend_strength,
            "slope": slope,
            "r_squared": r_squared,
            "sma_short": sma_short,
            "sma_long": sma_long
        }
    
    def _calculate_volatility(self, prices: np.ndarray) -> Dict[str, Any]:
        """
        Calculate volatility metrics.
        
        Args:
            prices: Array of prices
            
        Returns:
            Dictionary with volatility metrics
        """
        if len(prices) < 2:
            return {"volatility": 0, "atr": 0}
        
        # Calculate returns
        returns = np.zeros(len(prices) - 1)
        for i in range(1, len(prices)):
            returns[i-1] = (prices[i] - prices[i-1]) / prices[i-1] if prices[i-1] > 0 else 0
        
        # Calculate standard deviation of returns
        volatility = np.std(returns)
        
        # Calculate average true range (simplified)
        atr = np.mean(np.abs(returns[-14:])) if len(returns) >= 14 else np.mean(np.abs(returns))
        
        return {
            "volatility": volatility,
            "annualized_volatility": volatility * np.sqrt(252),  # Assuming daily data
            "atr": atr,
            "returns_mean": np.mean(returns),
            "returns_min": np.min(returns),
            "returns_max": np.max(returns)
        }
    
    def _calculate_momentum(self, prices: np.ndarray) -> Dict[str, Any]:
        """
        Calculate momentum metrics.
        
        Args:
            prices: Array of prices
            
        Returns:
            Dictionary with momentum metrics
        """
        if len(prices) < 14:
            return {"rsi": 50, "momentum": 0}
        
        # Calculate price changes
        changes = np.zeros(len(prices) - 1)
        for i in range(1, len(prices)):
            changes[i-1] = prices[i] - prices[i-1]
        
        # Calculate RSI
        gains = np.zeros_like(changes)
        losses = np.zeros_like(changes)
        
        for i in range(len(changes)):
            if changes[i] > 0:
                gains[i] = changes[i]
            elif changes[i] < 0:
                losses[i] = abs(changes[i])
        
        # Calculate average gains and losses over 14 periods
        avg_gain = np.mean(gains[-14:])
        avg_loss = np.mean(losses[-14:])
        
        if avg_loss == 0:
            rsi = 100
        else:
            rs = avg_gain / avg_loss
            rsi = 100 - (100 / (1 + rs))
        
        # Calculate momentum (price change over last n periods)
        momentum_10 = (prices[-1] - prices[-10]) / prices[-10] if len(prices) >= 10 else 0
        momentum_20 = (prices[-1] - prices[-20]) / prices[-20] if len(prices) >= 20 else 0
        
        return {
            "rsi": rsi,
            "momentum_10": momentum_10,
            "momentum_20": momentum_20,
            "momentum_strength": abs(momentum_10) * 10  # Scaled momentum strength
        }
    
    def _calculate_support_resistance(self, prices: np.ndarray) -> Dict[str, Any]:
        """
        Calculate support and resistance levels.
        
        Args:
            prices: Array of prices
            
        Returns:
            Dictionary with support and resistance levels
        """
        if len(prices) < 20:
            return {"support": [], "resistance": []}
        
        # Simplified pivot point detection
        support_levels = []
        resistance_levels = []
        
        # Window size for pivot point detection
        window = 5
        
        for i in range(window, len(prices) - window):
            is_pivot_low = True
            is_pivot_high = True
            
            # Check if pivot low
            for j in range(i - window, i + window + 1):
                if j != i and prices[j] < prices[i]:
                    is_pivot_low = False
                    break
            
            # Check if pivot high
            for j in range(i - window, i + window + 1):
                if j != i and prices[j] > prices[i]:
                    is_pivot_high = False
                    break
            
            if is_pivot_low:
                support_levels.append(prices[i])
            
            if is_pivot_high:
                resistance_levels.append(prices[i])
        
        # Cluster similar levels (within 2% of each other)
        support_clusters = self._cluster_levels(support_levels, 0.02)
        resistance_clusters = self._cluster_levels(resistance_levels, 0.02)
        
        # Calculate strength based on touch count
        support_with_strength = [(level, len(cluster)) for level, cluster in support_clusters]
        resistance_with_strength = [(level, len(cluster)) for level, cluster in resistance_clusters]
        
        # Sort by price level
        support_with_strength.sort()
        resistance_with_strength.sort()
        
        return {
            "support": support_with_strength,
            "resistance": resistance_with_strength,
            "current_price": prices[-1],
            "nearest_support": min(support_with_strength, key=lambda x: abs(x[0] - prices[-1]))[0] if support_with_strength else None,
            "nearest_resistance": min(resistance_with_strength, key=lambda x: abs(x[0] - prices[-1]))[0] if resistance_with_strength else None
        }
    
    def _cluster_levels(self, levels: List[float], threshold: float) -> List[Tuple[float, List[float]]]:
        """
        Cluster similar price levels.
        
        Args:
            levels: List of price levels
            threshold: Threshold for clustering (as fraction)
            
        Returns:
            List of (level, cluster) tuples
        """
        if not levels:
            return []
        
        # Sort levels
        sorted_levels = sorted(levels)
        clusters = []
        current_cluster = [sorted_levels[0]]
        
        for i in range(1, len(sorted_levels)):
            # Check if level is close to current cluster
            if (sorted_levels[i] - current_cluster[0]) / current_cluster[0] <= threshold:
                current_cluster.append(sorted_levels[i])
            else:
                # Start new cluster
                avg_level = sum(current_cluster) / len(current_cluster)
                clusters.append((avg_level, current_cluster.copy()))
                current_cluster = [sorted_levels[i]]
        
        # Add last cluster
        if current_cluster:
            avg_level = sum(current_cluster) / len(current_cluster)
            clusters.append((avg_level, current_cluster))
        
        return clusters
    
    def _detect_patterns(self, prices: np.ndarray) -> Dict[str, Any]:
        """
        Detect technical patterns in price data.
        
        Args:
            prices: Array of prices
            
        Returns:
            Dictionary with detected patterns
        """
        if len(prices) < 20:
            return {"patterns": []}
        
        detected_patterns = []
        
        # Head and Shoulders pattern detection (simplified)
        if len(prices) >= 60:
            # Look for potential head and shoulders pattern
            for i in range(20, len(prices) - 20):
                # Look for left shoulder, head, right shoulder
                left_shoulder = max(prices[i-20:i])
                head = max(prices[i:i+20])
                right_shoulder = max(prices[i+20:])
                
                # Check if pattern might be valid
                if head > left_shoulder and head > right_shoulder and abs(left_shoulder - right_shoulder) / left_shoulder < 0.1:
                    detected_patterns.append({
                        "type": "head_and_shoulders",
                        "confidence": 0.7,
                        "position": i
                    })
                    break
        
        # Double Bottom pattern detection (simplified)
        if len(prices) >= 40:
            for i in range(10, len(prices) - 10):
                first_bottom = min(prices[i-10:i])
                second_bottom = min(prices[i:i+10])
                
                # Check if bottoms are similar
                if abs(first_bottom - second_bottom) / first_bottom < 0.05:
                    confidence = 0.6
                    detected_patterns.append({
                        "type": "double_bottom",
                        "confidence": confidence,
                        "position": i
                    })
                    break
        
        # Use HAP for pattern detection if available
        if self.use_hap and self.hap_processor:
            pattern_matches, resonance_score = self.hap_processor.calculate_resonance_pattern(prices)
            
            if resonance_score > 0.6:
                # Find positions with high resonance
                high_resonance_positions = []
                for i in range(len(pattern_matches)):
                    if pattern_matches[i] > 0.7:
                        high_resonance_positions.append(i)
                
                if high_resonance_positions:
                    detected_patterns.append({
                        "type": "harmonic_pattern",
                        "confidence": resonance_score,
                        "positions": high_resonance_positions
                    })
        
        return {
            "patterns": detected_patterns,
            "pattern_count": len(detected_patterns)
        }
    
    def generate_predictions(self, symbol: str, model_id: str, 
                            horizon_days: int = 5, confidence_threshold: float = 0.5) -> List[MarketPrediction]:
        """
        Generate predictions for a symbol.
        
        Args:
            symbol: Market symbol (e.g., "AAPL")
            model_id: Identifier of the model to use
            horizon_days: Prediction horizon in days
            confidence_threshold: Minimum confidence threshold
            
        Returns:
            List of market predictions
        """
        if symbol not in self.market_data_cache or not self.market_data_cache[symbol]:
            logger.warning(f"No market data available for {symbol}")
            return []
        
        if model_id not in self.models:
            logger.warning(f"Model {model_id} not found")
            return []
        
        data_points = self.market_data_cache[symbol]
        close_prices = np.array([p.close for p in data_points])
        
        # Current timestamp and price
        current_timestamp = data_points[-1].timestamp
        current_price = close_prices[-1]
        
        # Make predictions
        predictions = []
        prediction_values = []
        confidence_levels = []
        
        # Different prediction methods based on model type
        model = self.models[model_id]
        
        if model["type"] == "technical":
            # For technical models (like SMA)
            short_period = model["parameters"].get("short_period", 20)
            long_period = model["parameters"].get("long_period", 50)
            
            # Ensure we have enough data
            if len(close_prices) < max(short_period, long_period):
                logger.warning(f"Not enough data for {model_id} model")
                return []
            
            # Calculate moving averages
            sma_short = np.mean(close_prices[-short_period:])
            sma_long = np.mean(close_prices[-long_period:])
            
            # Determine trend
            if sma_short > sma_long:
                # Bullish trend
                trend_strength = (sma_short - sma_long) / sma_long
                # Predict upward movement
                for i in range(1, horizon_days + 1):
                    # Simple model: price increases with trend strength
                    predicted_value = current_price * (1 + trend_strength * 0.01 * i)
                    confidence = 0.5 + min(0.3, trend_strength)
                    
                    # Decrease confidence for longer horizons
                    confidence *= (1 - (i - 1) * 0.1)
                    
                    if confidence >= confidence_threshold:
                        target_timestamp = current_timestamp + timedelta(days=i)
                        predictions.append(MarketPrediction(
                            symbol=symbol,
                            model_id=model_id,
                            target_timestamp=target_timestamp,
                            current_timestamp=current_timestamp,
                            predicted_value=predicted_value,
                            confidence=confidence
                        ))
                        
                        prediction_values.append(predicted_value)
                        confidence_levels.append(confidence)
            else:
                # Bearish trend
                trend_strength = (sma_long - sma_short) / sma_long
                # Predict downward movement
                for i in range(1, horizon_days + 1):
                    # Simple model: price decreases with trend strength
                    predicted_value = current_price * (1 - trend_strength * 0.01 * i)
                    confidence = 0.5 + min(0.3, trend_strength)
                    
                    # Decrease confidence for longer horizons
                    confidence *= (1 - (i - 1) * 0.1)
                    
                    if confidence >= confidence_threshold:
                        target_timestamp = current_timestamp + timedelta(days=i)
                        predictions.append(MarketPrediction(
                            symbol=symbol,
                            model_id=model_id,
                            target_timestamp=target_timestamp,
                            current_timestamp=current_timestamp,
                            predicted_value=predicted_value,
                            confidence=confidence
                        ))
                        
                        prediction_values.append(predicted_value)
                        confidence_levels.append(confidence)
        
        elif model["type"] == "harmonic" and self.use_hap:
            # For harmonic models, use HAP
            harmonic_base = model["parameters"].get("harmonic_base", self.harmonic_base)
            
            # Process data with HAP processor
            hap_result = self.hap_processor.apply_harmonic_transform(close_prices)
            
            # Calculate harmonic probabilities
            probabilities = hap_result["quantum_probability"][-20:]  # Use last 20 points
            
            # Generate predictions using HAP
            for i in range(1, horizon_days + 1):
                # Weight predictions by probabilities
                up_probability = np.mean(probabilities[probabilities > 0.5])
                down_probability = np.mean(1 - probabilities[probabilities < 0.5])
                
                # Predict price change
                if up_probability > down_probability:
                    # More likely to go up
                    change_factor = up_probability * 0.02 * i  # 0-2% per day
                    confidence = up_probability
                else:
                    # More likely to go down
                    change_factor = -down_probability * 0.02 * i  # 0-2% per day
                    confidence = down_probability
                
                # Decrease confidence for longer horizons
                confidence *= (1 - (i - 1) * 0.1)
                
                if confidence >= confidence_threshold:
                    predicted_value = current_price * (1 + change_factor)
                    target_timestamp = current_timestamp + timedelta(days=i)
                    
                    predictions.append(MarketPrediction(
                        symbol=symbol,
                        model_id=model_id,
                        target_timestamp=target_timestamp,
                        current_timestamp=current_timestamp,
                        predicted_value=predicted_value,
                        confidence=confidence
                    ))
                    
                    prediction_values.append(predicted_value)
                    confidence_levels.append(confidence)
        
        elif model["type"] == "statistical":
            # For statistical models, use linear regression
            from sklearn.linear_model import LinearRegression
            
            lookback_period = model["parameters"].get("lookback_period", 30)
            
            if len(close_prices) < lookback_period:
                logger.warning(f"Not enough data for {model_id} model")
                return []
            
            # Prepare data for regression
            X = np.arange(lookback_period).reshape(-1, 1)
            y = close_prices[-lookback_period:]
            
            # Fit linear regression model
            reg = LinearRegression().fit(X, y)
            
            # Predict future values
            for i in range(1, horizon_days + 1):
                # Predict price
                x_pred = np.array([[lookback_period + i - 1]])
                predicted_value = reg.predict(x_pred)[0]
                
                # Calculate confidence based on R-squared
                confidence = 0.5 + min(0.3, reg.score(X, y))
                
                # Decrease confidence for longer horizons
                confidence *= (1 - (i - 1) * 0.1)
                
                if confidence >= confidence_threshold:
                    target_timestamp = current_timestamp + timedelta(days=i)
                    predictions.append(MarketPrediction(
                        symbol=symbol,
                        model_id=model_id,
                        target_timestamp=target_timestamp,
                        current_timestamp=current_timestamp,
                        predicted_value=predicted_value,
                        confidence=confidence
                    ))
                    
                    prediction_values.append(predicted_value)
                    confidence_levels.append(confidence)
        
        elif model["type"] == "quantum_harmonic" and self.use_hap:
            # For quantum harmonic models, use HAP with quantum properties
            distribution_type = model["parameters"].get("distribution_type", DistributionType.QUANTUM_HARMONIC)
            
            # Process data with HAP processor
            hap_result = self.hap_processor.apply_harmonic_transform(close_prices)
            
            # Calculate harmonic resonance
            resonance = hap_result["harmonic_resonance"]
            
            # Calculate quantum probabilities
            quantum_probs = hap_result["quantum_probability"]
            
            # Generate predictions using quantum probabilities
            for i in range(1, horizon_days + 1):
                # Weight by resonance and quantum probability
                weighted_prob = np.mean(quantum_probs[-10:] * resonance[-10:]) / np.mean(resonance[-10:])
                
                # Determine direction and magnitude
                if weighted_prob > 0.5:
                    # More likely to go up
                    change_factor = (weighted_prob - 0.5) * 0.04 * i  # 0-2% per day
                else:
                    # More likely to go down
                    change_factor = (weighted_prob - 0.5) * 0.04 * i  # 0-2% per day
                
                # Calculate confidence
                confidence = abs(weighted_prob - 0.5) * 2  # Scale to 0-1
                
                # Decrease confidence for longer horizons
                confidence *= (1 - (i - 1) * 0.1)
                
                if confidence >= confidence_threshold:
                    predicted_value = current_price * (1 + change_factor)
                    target_timestamp = current_timestamp + timedelta(days=i)
                    
                    predictions.append(MarketPrediction(
                        symbol=symbol,
                        model_id=model_id,
                        target_timestamp=target_timestamp,
                        current_timestamp=current_timestamp,
                        predicted_value=predicted_value,
                        confidence=confidence
                    ))
                    
                    prediction_values.append(predicted_value)
                    confidence_levels.append(confidence)
        
        else:
            # For other models (e.g., unknown types)
            # Generate simple predictions based on recent trends
            returns = []
            for i in range(1, min(21, len(close_prices))):
                returns.append((close_prices[-i] - close_prices[-i-1]) / close_prices[-i-1])
            
            avg_return = np.mean(returns)
            std_return = np.std(returns)
            
            for i in range(1, horizon_days + 1):
                # Predict price with average return
                predicted_value = current_price * (1 + avg_return * i)
                
                # Calculate confidence based on return consistency
                confidence = 0.5 * (1 - min(1.0, std_return / abs(avg_return) if avg_return != 0 else 1.0))
                
                # Decrease confidence for longer horizons
                confidence *= (1 - (i - 1) * 0.1)
                
                if confidence >= confidence_threshold:
                    target_timestamp = current_timestamp + timedelta(days=i)
                    predictions.append(MarketPrediction(
                        symbol=symbol,
                        model_id=model_id,
                        target_timestamp=target_timestamp,
                        current_timestamp=current_timestamp,
                        predicted_value=predicted_value,
                        confidence=confidence
                    ))
                    
                    prediction_values.append(predicted_value)
                    confidence_levels.append(confidence)
        
        # Store predictions
        if model_id not in self.predictions:
            self.predictions[model_id] = {}
        
        if symbol not in self.predictions[model_id]:
            self.predictions[model_id][symbol] = []
        
        # Append new predictions
        self.predictions[model_id][symbol].extend(predictions)
        
        # Sort by target timestamp
        self.predictions[model_id][symbol].sort(key=lambda x: x.target_timestamp)
        
        # Limit predictions cache size (keep last 100)
        if len(self.predictions[model_id][symbol]) > 100:
            self.predictions[model_id][symbol] = self.predictions[model_id][symbol][-100:]
        
        logger.info(f"Generated {len(predictions)} predictions for {symbol} using {model_id} model")
        return predictions
    
    def backtest_strategy(self, symbol: str, strategy_name: str, params: Dict[str, Any] = None) -> Optional[BacktestResult]:
        """
        Backtest a trading strategy.
        
        Args:
            symbol: Market symbol (e.g., "AAPL")
            strategy_name: Name of the strategy to backtest
            params: Strategy parameters
            
        Returns:
            Backtest result
        """
        if symbol not in self.market_data_cache or not self.market_data_cache[symbol]:
            logger.warning(f"No market data available for {symbol}")
            return None
        
        if strategy_name not in self.strategies:
            logger.warning(f"Strategy {strategy_name} not found")
            return None
        
        data_points = self.market_data_cache[symbol]
        
        # Create backtest result
        start_date = data_points[0].timestamp
        end_date = data_points[-1].timestamp
        
        result = BacktestResult(
            symbol=symbol,
            strategy_name=strategy_name,
            start_date=start_date,
            end_date=end_date
        )
        
        # Set strategy parameters
        if params:
            result.settings = params
        else:
            # Default parameters
            result.settings = {
                "initial_capital": 10000.0,
                "position_size": 0.1,  # 10% of capital per position
                "stop_loss": 0.05,     # 5% stop loss
                "take_profit": 0.1     # 10% take profit
            }
        
        # Get strategy function
        strategy_func = self.strategies[strategy_name]
        
        # Run backtest
        capital = result.initial_capital
        position = 0
        entry_price = 0
        trades = []
        equity_curve = [capital]
        
        # Apply strategy to data
        for i in range(1, len(data_points)):
            current_point = data_points[i]
            previous_point = data_points[i-1]
            
            # Check for stop loss or take profit if in position
            if position != 0:
                # Calculate return
                current_return = (current_point.close - entry_price) / entry_price
                
                # Check stop loss
                if position > 0 and current_return <= -result.settings["stop_loss"]:
                    # Hit stop loss, close position
                    trade_return = -result.settings["stop_loss"] * position * capital
                    capital += trade_return
                    trades.append({
                        "type": "sell",
                        "reason": "stop_loss",
                        "price": entry_price * (1 - result.settings["stop_loss"]),
                        "timestamp": current_point.timestamp.isoformat(),
                        "profit": trade_return,
                        "profit_percent": -result.settings["stop_loss"] * 100
                    })
                    position = 0
                    
                # Check take profit
                elif position > 0 and current_return >= result.settings["take_profit"]:
                    # Hit take profit, close position
                    trade_return = result.settings["take_profit"] * position * capital
                    capital += trade_return
                    trades.append({
                        "type": "sell",
                        "reason": "take_profit",
                        "price": entry_price * (1 + result.settings["take_profit"]),
                        "timestamp": current_point.timestamp.isoformat(),
                        "profit": trade_return,
                        "profit_percent": result.settings["take_profit"] * 100
                    })
                    position = 0
                
                # Check for short position stop loss
                elif position < 0 and current_return >= result.settings["stop_loss"]:
                    # Hit stop loss for short, close position
                    trade_return = -result.settings["stop_loss"] * abs(position) * capital
                    capital += trade_return
                    trades.append({
                        "type": "buy",
                        "reason": "stop_loss",
                        "price": entry_price * (1 + result.settings["stop_loss"]),
                        "timestamp": current_point.timestamp.isoformat(),
                        "profit": trade_return,
                        "profit_percent": -result.settings["stop_loss"] * 100
                    })
                    position = 0
                
                # Check for short position take profit
                elif position < 0 and current_return <= -result.settings["take_profit"]:
                    # Hit take profit for short, close position
                    trade_return = result.settings["take_profit"] * abs(position) * capital
                    capital += trade_return
                    trades.append({
                        "type": "buy",
                        "reason": "take_profit",
                        "price": entry_price * (1 - result.settings["take_profit"]),
                        "timestamp": current_point.timestamp.isoformat(),
                        "profit": trade_return,
                        "profit_percent": result.settings["take_profit"] * 100
                    })
                    position = 0
            
            # Get signal from strategy
            signal = strategy_func(data_points[:i+1], result.settings)
            
            # Execute signal
            if signal == "buy" and position <= 0:
                # Close any short position
                if position < 0:
                    current_return = (entry_price - current_point.close) / entry_price
                    trade_return = current_return * abs(position) * capital
                    capital += trade_return
                    trades.append({
                        "type": "buy",
                        "reason": "signal",
                        "price": current_point.close,
                        "timestamp": current_point.timestamp.isoformat(),
                        "profit": trade_return,
                        "profit_percent": current_return * 100
                    })
                
                # Open long position
                position = result.settings["position_size"]
                entry_price = current_point.close
                trades.append({
                    "type": "buy",
                    "reason": "signal",
                    "price": entry_price,
                    "timestamp": current_point.timestamp.isoformat(),
                    "profit": 0,
                    "profit_percent": 0
                })
            
            elif signal == "sell" and position >= 0:
                # Close any long position
                if position > 0:
                    current_return = (current_point.close - entry_price) / entry_price
                    trade_return = current_return * position * capital
                    capital += trade_return
                    trades.append({
                        "type": "sell",
                        "reason": "signal",
                        "price": current_point.close,
                        "timestamp": current_point.timestamp.isoformat(),
                        "profit": trade_return,
                        "profit_percent": current_return * 100
                    })
                
                # Open short position
                position = -result.settings["position_size"]
                entry_price = current_point.close
                trades.append({
                    "type": "sell",
                    "reason": "signal",
                    "price": entry_price,
                    "timestamp": current_point.timestamp.isoformat(),
                    "profit": 0,
                    "profit_percent": 0
                })
            
            # Update equity curve
            if position != 0:
                # Update unrealized P&L
                current_return = (current_point.close - entry_price) / entry_price
                if position < 0:
                    current_return = -current_return
                unrealized_pnl = current_return * abs(position) * capital
                equity_curve.append(capital + unrealized_pnl)
            else:
                equity_curve.append(capital)
        
        # Close any open position at the end
        if position != 0:
            current_point = data_points[-1]
            current_return = (current_point.close - entry_price) / entry_price
            if position < 0:
                current_return = -current_return
            
            trade_return = current_return * abs(position) * capital
            capital += trade_return
            
            trades.append({
                "type": "close",
                "reason": "end_of_backtest",
                "price": current_point.close,
                "timestamp": current_point.timestamp.isoformat(),
                "profit": trade_return,
                "profit_percent": current_return * 100
            })
            
            # Update final equity
            equity_curve[-1] = capital
        
        # Update performance metrics
        result.update_performance_metrics(trades, equity_curve)
        
        # Store backtest result
        if strategy_name not in self.backtest_results:
            self.backtest_results[strategy_name] = {}
        
        if symbol not in self.backtest_results[strategy_name]:
            self.backtest_results[strategy_name][symbol] = []
        
        self.backtest_results[strategy_name][symbol].append(result)
        
        # Limit backtest results cache size (keep last 10)
        if len(self.backtest_results[strategy_name][symbol]) > 10:
            self.backtest_results[strategy_name][symbol] = self.backtest_results[strategy_name][symbol][-10:]
        
        logger.info(f"Completed backtest for {symbol} using {strategy_name} strategy, net profit: {result.net_profit_percent:.2%}")
        return result
    
    def _trend_following_strategy(self, data_points: List[MarketDataPoint], params: Dict[str, Any]) -> str:
        """
        Trend following strategy.
        
        Args:
            data_points: Market data points
            params: Strategy parameters
            
        Returns:
            Signal ("buy", "sell", or None)
        """
        if len(data_points) < 50:
            return None
        
        # Get parameters
        short_period = params.get("short_period", 20)
        long_period = params.get("long_period", 50)
        
        # Calculate moving averages
        short_prices = [p.close for p in data_points[-short_period:]]
        long_prices = [p.close for p in data_points[-long_period:]]
        
        short_ma = sum(short_prices) / len(short_prices)
        long_ma = sum(long_prices) / len(long_prices)
        
        # Check previous values for crossover
        if len(data_points) > (long_period + 1):
            prev_short_prices = [p.close for p in data_points[-(short_period+1):-1]]
            prev_long_prices = [p.close for p in data_points[-(long_period+1):-1]]
            
            prev_short_ma = sum(prev_short_prices) / len(prev_short_prices)
            prev_long_ma = sum(prev_long_prices) / len(prev_long_prices)
            
            # Check for crossover
            if short_ma > long_ma and prev_short_ma <= prev_long_ma:
                # Bullish crossover
                return "buy"
            elif short_ma < long_ma and prev_short_ma >= prev_long_ma:
                # Bearish crossover
                return "sell"
        
        return None
    
    def _mean_reversion_strategy(self, data_points: List[MarketDataPoint], params: Dict[str, Any]) -> str:
        """
        Mean reversion strategy.
        
        Args:
            data_points: Market data points
            params: Strategy parameters
            
        Returns:
            Signal ("buy", "sell", or None)
        """
        if len(data_points) < 20:
            return None
        
        # Get parameters
        period = params.get("period", 20)
        std_dev_factor = params.get("std_dev_factor", 2.0)
        
        # Calculate moving average and standard deviation
        prices = [p.close for p in data_points[-period:]]
        
        mean = sum(prices) / len(prices)
        std_dev = (sum((p - mean) ** 2 for p in prices) / len(prices)) ** 0.5
        
        # Current price
        current_price = data_points[-1].close
        
        # Check for overbought/oversold
        if current_price < (mean - std_dev_factor * std_dev):
            # Price is significantly below average, buy signal
            return "buy"
        elif current_price > (mean + std_dev_factor * std_dev):
            # Price is significantly above average, sell signal
            return "sell"
        
        return None
    
    def _breakout_strategy(self, data_points: List[MarketDataPoint], params: Dict[str, Any]) -> str:
        """
        Breakout strategy.
        
        Args:
            data_points: Market data points
            params: Strategy parameters
            
        Returns:
            Signal ("buy", "sell", or None)
        """
        if len(data_points) < 20:
            return None
        
        # Get parameters
        period = params.get("period", 20)
        
        # Calculate highest high and lowest low
        highs = [p.high for p in data_points[-period:-1]]
        lows = [p.low for p in data_points[-period:-1]]
        
        highest_high = max(highs)
        lowest_low = min(lows)
        
        # Current price
        current_price = data_points[-1].close
        
        # Check for breakout
        if current_price > highest_high:
            # Price breaks above resistance, buy signal
            return "buy"
        elif current_price < lowest_low:
            # Price breaks below support, sell signal
            return "sell"
        
        return None
    
    def _anomaly_based_strategy(self, data_points: List[MarketDataPoint], params: Dict[str, Any]) -> str:
        """
        Anomaly-based strategy.
        
        Args:
            data_points: Market data points
            params: Strategy parameters
            
        Returns:
            Signal ("buy", "sell", or None)
        """
        if len(data_points) < 30:
            return None
        
        # Get parameters
        threshold = params.get("threshold", 0.8)
        
        # Current point
        current_point = data_points[-1]
        
        # Check for price anomalies using HAP if available
        if self.use_hap and self.hap_processor:
            # Get recent prices
            prices = np.array([p.close for p in data_points[-30:]])
            
            # Process with HAP
            result = self.hap_processor.process_time_series(prices)
            
            # Check resonance
            resonance = result["resonance"][-1]
            
            if resonance > threshold:
                # Strong resonance detected
                
                # Determine direction
                short_prices = [p.close for p in data_points[-5:]]
                recent_trend = short_prices[-1] - short_prices[0]
                
                if recent_trend > 0:
                    # Upward trend with strong resonance
                    return "buy"
                else:
                    # Downward trend with strong resonance
                    return "sell"
        
        # Fallback to statistical anomaly detection
        prices = [p.close for p in data_points[-30:]]
        
        # Calculate mean and standard deviation
        mean = sum(prices) / len(prices)
        std_dev = (sum((p - mean) ** 2 for p in prices) / len(prices)) ** 0.5
        
        # Check for anomaly
        current_price = current_point.close
        z_score = (current_price - mean) / std_dev if std_dev > 0 else 0
        
        if abs(z_score) > 2.0:
            # Anomaly detected
            # Mean reversion strategy - bet against the anomaly
            if z_score > 0:
                return "sell"
            else:
                return "buy"
        
        return None
    
    def _harmonic_resonance_strategy(self, data_points: List[MarketDataPoint], params: Dict[str, Any]) -> str:
        """
        Harmonic resonance strategy.
        
        Args:
            data_points: Market data points
            params: Strategy parameters
            
        Returns:
            Signal ("buy", "sell", or None)
        """
        if len(data_points) < 50 or not self.use_hap or not self.hap_processor:
            return None
        
        # Get parameters
        resonance_threshold = params.get("resonance_threshold", 0.7)
        quantum_factor = params.get("quantum_factor", self.quantum_influence)
        
        # Get prices
        prices = np.array([p.close for p in data_points[-50:]])
        
        # Apply harmonic transformation
        hap_result = self.hap_processor.apply_harmonic_transform(prices)
        
        # Check resonance pattern
        pattern_matches, resonance_score = self.hap_processor.calculate_resonance_pattern(prices)
        
        if resonance_score > resonance_threshold:
            # Harmonic pattern detected
            
            # Check quantum probability for direction
            quantum_prob = np.mean(hap_result["quantum_probability"][-5:])
            
            if quantum_prob > 0.55:
                # Higher probability of upward movement
                return "buy"
            elif quantum_prob < 0.45:
                # Higher probability of downward movement
                return "sell"
        
        return None
    
    def evaluate_prediction_accuracy(self, model_id: str, symbol: Optional[str] = None) -> Dict[str, Any]:
        """
        Evaluate prediction accuracy for a model.
        
        Args:
            model_id: Identifier of the model
            symbol: Optional symbol to evaluate (or all symbols if None)
            
        Returns:
            Dictionary with accuracy metrics
        """
        if model_id not in self.predictions:
            logger.warning(f"No predictions found for model {model_id}")
            return {
                "model_id": model_id,
                "accuracy": 0.0,
                "predictions_count": 0,
                "resolved_count": 0,
                "timestamp": datetime.now().isoformat()
            }
        
        # Get predictions
        all_predictions = []
        
        if symbol:
            # For specific symbol
            if symbol in self.predictions[model_id]:
                all_predictions = self.predictions[model_id][symbol]
        else:
            # For all symbols
            for sym_predictions in self.predictions[model_id].values():
                all_predictions.extend(sym_predictions)
        
        # Filter predictions with actual values
        resolved_predictions = [p for p in all_predictions if p.actual_value is not None]
        
        if not resolved_predictions:
            logger.warning(f"No resolved predictions found for model {model_id}")
            return {
                "model_id": model_id,
                "accuracy": 0.0,
                "predictions_count": len(all_predictions),
                "resolved_count": 0,
                "timestamp": datetime.now().isoformat()
            }
        
        # Calculate metrics
        mse = sum((p.predicted_value - p.actual_value) ** 2 for p in resolved_predictions) / len(resolved_predictions)
        mae = sum(abs(p.predicted_value - p.actual_value) for p in resolved_predictions) / len(resolved_predictions)
        
        # Calculate direction accuracy
        correct_direction = 0
        for p in resolved_predictions:
            pred_direction = 1 if p.predicted_value > p.actual_value else (-1 if p.predicted_value < p.actual_value else 0)
            actual_direction = 1 if p.actual_value > p.predicted_value else (-1 if p.actual_value < p.predicted_value else 0)
            
            if pred_direction == actual_direction:
                correct_direction += 1
        
        direction_accuracy = correct_direction / len(resolved_predictions) if resolved_predictions else 0
        
        # Calculate weighted accuracy based on confidence
        weighted_accuracy = 0
        total_weights = 0
        
        for p in resolved_predictions:
            weight = p.confidence
            error = abs(p.predicted_value - p.actual_value) / p.actual_value if p.actual_value != 0 else 1.0
            accuracy = max(0, 1 - error)
            
            weighted_accuracy += accuracy * weight
            total_weights += weight
        
        final_accuracy = weighted_accuracy / total_weights if total_weights > 0 else 0
        
        # Store accuracy metrics
        self.prediction_performance[model_id] = {
            "mse": mse,
            "mae": mae,
            "direction_accuracy": direction_accuracy,
            "weighted_accuracy": final_accuracy,
            "resolved_count": len(resolved_predictions),
            "total_count": len(all_predictions),
            "timestamp": datetime.now().isoformat()
        }
        
        logger.info(f"Evaluated prediction accuracy for model {model_id}: {final_accuracy:.4f}")
        
        return {
            "model_id": model_id,
            "mse": mse,
            "mae": mae,
            "direction_accuracy": direction_accuracy,
            "accuracy": final_accuracy,
            "predictions_count": len(all_predictions),
            "resolved_count": len(resolved_predictions),
            "timestamp": datetime.now().isoformat()
        }
    
    def make_trading_decision(self, symbol: str) -> Dict[str, Any]:
        """
        Make a trading decision for a symbol.
        
        Args:
            symbol: Market symbol (e.g., "AAPL")
            
        Returns:
            Dictionary with decision details
        """
        if symbol not in self.market_data_cache or not self.market_data_cache[symbol]:
            logger.warning(f"No market data available for {symbol}")
            return {
                "symbol": symbol,
                "action": "none",
                "confidence": 0.0,
                "timestamp": datetime.now().isoformat()
            }
        
        # Collect strategy signals
        signals = {}
        decision_params = {}
        
        # Run all strategies
        for strategy_name, strategy_func in self.strategies.items():
            signal = strategy_func(self.market_data_cache[symbol], {})
            signals[strategy_name] = signal
        
        # Collect predictions from all models
        all_predictions = []
        
        for model_id in self.models:
            # Generate predictions if not already available
            if model_id not in self.predictions or symbol not in self.predictions[model_id]:
                predictions = self.generate_predictions(symbol, model_id)
            else:
                predictions = self.predictions[model_id][symbol]
            
            # Filter to recent predictions
            recent_predictions = [p for p in predictions if 
                               (datetime.now() - p.current_timestamp).total_seconds() < 86400]  # Last 24 hours
            
            all_predictions.extend(recent_predictions)
        
        # Count signals
        buy_signals = sum(1 for s in signals.values() if s == "buy")
        sell_signals = sum(1 for s in signals.values() if s == "sell")
        
        # Count prediction directions
        buy_predictions = 0
        sell_predictions = 0
        total_confidence = 0
        
        for p in all_predictions:
            if p.predicted_value > p.current_timestamp:
                buy_predictions += 1
                total_confidence += p.confidence
            else:
                sell_predictions += 1
                total_confidence += p.confidence
        
        # Combine signals and predictions
        total_signals = len(signals)
        total_predictions = len(all_predictions)
        
        if total_signals + total_predictions == 0:
            # No signals or predictions
            return {
                "symbol": symbol,
                "action": "none",
                "confidence": 0.0,
                "timestamp": datetime.now().isoformat(),
                "signals": signals,
                "predictions_count": total_predictions
            }
        
        # Calculate decision confidence
        buy_confidence = (buy_signals / total_signals if total_signals > 0 else 0) * 0.5 + \
                        (buy_predictions / total_predictions if total_predictions > 0 else 0) * 0.5
        
        sell_confidence = (sell_signals / total_signals if total_signals > 0 else 0) * 0.5 + \
                        (sell_predictions / total_predictions if total_predictions > 0 else 0) * 0.5
        
        # Determine action
        if buy_confidence > sell_confidence and buy_confidence > 0.6:
            action = "buy"
            confidence = buy_confidence
        elif sell_confidence > buy_confidence and sell_confidence > 0.6:
            action = "sell"
            confidence = sell_confidence
        else:
            action = "hold"
            confidence = max(buy_confidence, sell_confidence)
        
        # If using HAP, incorporate quantum probability
        if self.use_hap and self.hap_processor:
            # Get recent prices
            prices = np.array([p.close for p in self.market_data_cache[symbol][-30:]])
            
            # Process with HAP
            hap_result = self.hap_processor.apply_harmonic_transform(prices)
            
            # Get quantum probability
            quantum_prob = np.mean(hap_result["quantum_probability"][-5:])
            
            # Adjust confidence based on quantum probability
            if action == "buy" and quantum_prob < 0.4:
                confidence *= 0.8  # Reduce confidence if quantum probability disagrees
            elif action == "sell" and quantum_prob > 0.6:
                confidence *= 0.8  # Reduce confidence if quantum probability disagrees
            
            decision_params["quantum_probability"] = quantum_prob
        
        # Include anomalies if available
        if symbol in self.anomalies and self.anomalies[symbol]:
            recent_anomalies = [a for a in self.anomalies[symbol] if 
                            (datetime.now() - a.timestamp).total_seconds() < 86400]  # Last 24 hours
            
            if recent_anomalies:
                decision_params["recent_anomalies"] = [a.to_dict() for a in recent_anomalies]
        
        # Create trading decision
        decision = {
            "symbol": symbol,
            "action": action,
            "confidence": confidence,
            "timestamp": datetime.now().isoformat(),
            "signals": signals,
            "predictions_count": total_predictions,
            "params": decision_params
        }
        
        logger.info(f"Made trading decision for {symbol}: {action} (confidence: {confidence:.2f})")
        return decision
    
    def visualize_market_data(self, symbol: str, filename: Optional[str] = None) -> Optional[str]:
        """
        Visualize market data for a symbol.
        
        Args:
            symbol: Market symbol (e.g., "AAPL")
            filename: Output filename, or None for automatic name
            
        Returns:
            Path to the saved visualization or None
        """
        if symbol not in self.market_data_cache or not self.market_data_cache[symbol]:
            logger.warning(f"No market data available for {symbol}")
            return None
        
        data_points = self.market_data_cache[symbol]
        
        try:
            # Create output directory if not exists
            os.makedirs("market_visualizations", exist_ok=True)
            
            if filename is None:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                filename = f"market_visualizations/{symbol}_analysis_{timestamp}.html"
            
            # Create figure
            fig = go.Figure()
            
            # Add candlestick chart
            timestamps = [p.timestamp for p in data_points]
            timestamps_str = [ts.strftime("%Y-%m-%d %H:%M:%S") for ts in timestamps]
            
            fig.add_trace(go.Candlestick(
                x=timestamps_str,
                open=[p.open for p in data_points],
                high=[p.high for p in data_points],
                low=[p.low for p in data_points],
                close=[p.close for p in data_points],
                name="Price"
            ))
            
            # Add volume bars
            fig.add_trace(go.Bar(
                x=timestamps_str,
                y=[p.volume for p in data_points],
                name="Volume",
                yaxis="y2",
                marker=dict(color="rgba(0, 0, 255, 0.3)")
            ))
            
            # Add anomalies if available
            if symbol in self.anomalies and self.anomalies[symbol]:
                anomaly_times = [a.timestamp.strftime("%Y-%m-%d %H:%M:%S") for a in self.anomalies[symbol]]
                anomaly_prices = []
                anomaly_texts = []
                
                for anomaly in self.anomalies[symbol]:
                    if anomaly.data_point:
                        anomaly_prices.append(anomaly.data_point.close)
                    else:
                        # Find closest data point
                        closest_point = min(data_points, key=lambda p: abs((p.timestamp - anomaly.timestamp).total_seconds()))
                        anomaly_prices.append(closest_point.close)
                    
                    anomaly_texts.append(f"{anomaly.anomaly_type} ({anomaly.severity:.2f})")
                
                fig.add_trace(go.Scatter(
                    x=anomaly_times,
                    y=anomaly_prices,
                    mode="markers",
                    marker=dict(
                        size=10,
                        color="red",
                        symbol="x"
                    ),
                    name="Anomalies",
                    text=anomaly_texts
                ))
            
            # Add predictions if available
            all_predictions = []
            
            for model_id, predictions_dict in self.predictions.items():
                if symbol in predictions_dict:
                    all_predictions.extend(predictions_dict[symbol])
            
            if all_predictions:
                pred_times = [p.target_timestamp.strftime("%Y-%m-%d %H:%M:%S") for p in all_predictions]
                pred_values = [p.predicted_value for p in all_predictions]
                pred_confidences = [p.confidence for p in all_predictions]
                pred_texts = [f"{p.model_id} (conf: {p.confidence:.2f})" for p in all_predictions]
                
                fig.add_trace(go.Scatter(
                    x=pred_times,
                    y=pred_values,
                    mode="markers",
                    marker=dict(
                        size=8,
                        color="green",
                        symbol="circle",
                        opacity=pred_confidences
                    ),
                    name="Predictions",
                    text=pred_texts
                ))
            
            # Add trading decision if available
            decision = self.make_trading_decision(symbol)
            
            if decision["action"] != "none":
                fig.add_annotation(
                    x=timestamps_str[-1],
                    y=data_points[-1].close,
                    text=f"Decision: {decision['action'].upper()} (conf: {decision['confidence']:.2f})",
                    showarrow=True,
                    arrowhead=2,
                    arrowcolor="blue",
                    arrowsize=1,
                    arrowwidth=2,
                    bgcolor="rgba(255, 255, 255, 0.8)"
                )
            
            # Update layout
            fig.update_layout(
                title=f"{symbol} Market Analysis",
                yaxis_title="Price",
                xaxis_title="Date",
                yaxis2=dict(
                    title="Volume",
                    titlefont=dict(color="blue"),
                    tickfont=dict(color="blue"),
                    overlaying="y",
                    side="right"
                ),
                template="plotly_dark",
                height=800,
                width=1200
            )
            
            # Save figure
            fig.write_html(filename)
            
            logger.info(f"Saved market visualization to {filename}")
            return filename
            
        except Exception as e:
            logger.error(f"Error creating visualization: {e}")
            return None