| Capability | HA Operator | Domain | Definition (HA Terms) |
|---|---|---|---|
| Temporal Discretization | H_TimeLatticeProject | Continuous Temporal Signals | Project a continuous temporal signal `s(t)` onto the discrete `ΔT_40` lattice by convolution with a sampling kernel `k_sample(t)` (M_PR) and subsequent spectral decomposition (P_D). |
| Harmonic Spectral Analysis | H_HarmonicDecomp | Quantum-Harmonic Field | Decompose the substrate field into harmonic components using `ω₀` as fundamental frequency and enforcing `K_in` active mode budget (M_PR, S_C). |
| Substrate State Embedding | H_SubstrateEmbed | Quantum-Harmonic Substrate | Map the complex state of `C_sub` (1) into a high-dimensional harmonic embedding space `ψ_sub` (M_PR, R_K). |
| Phase-Space Feature Extraction | H_PhaseSpaceFeatureExtract | Quantum Phase Space | Extract `PS(t)` from the substrate's quantum state by correlating with phase-space kernels (M_PR). |
| Harmonic Feature Expansion | H_HarmonicFeatureExpand | Harmonic Spectrum | Generate `FS(t)` as a Fourier-like expansion from the substrate's harmonic content (M_PR, P_D). |
| Coherent Basis Factorization | H_CoherentBasisFactorize | Hilbert Space | From `PS(t)` and `FS(t)`, derive a compact, orthogonal basis `{|φ_n⟩}` maximizing coherence and informational content via singular value decomposition in harmonic space (M_PR, S_C). |
| Basis Constraint Projection | H_BasisConstraintProject | Constraint Space | Project the selected basis `{|φ_n⟩}` onto surfaces defined by `CR` (compression ratio) and `E_min_bit` (Landauer energy floor) constraints (S_C). |
| Quantum State Readout | H_QuantumStateReadout | Quantum State Space | Transform an internal intelligence state `|ψ⟩` to a measurable signature state `|χ_k⟩` through a projective or generalized measurement operation (X, E). |
| Quantum Fidelity Scoring | H_QuantumFidelityScore | Quantum State Space | Compute `QF(ρ,σ)` between an emitted signature density matrix `ρ` and a target state `σ` as an evaluation functional (E). |
| Von Neumann Entropy Computation | H_VonNeumannEntropyCompute | Quantum State Space | Calculate `S_V(ρ̂)` for an emitted signature density matrix `ρ̂` to quantify its expressivity (E). |
| Channel Mutual Information | H_ChannelMutualInformation | Information Channel | Quantify `I(X;Y)` between the intelligence state and downstream channels using belief densities (B, E). |
| Lindblad Evolution Control | H_LindbladEvolutionControl | Quantum Density Matrix Space | Integrate the Lindblad master equation `dρ̂/dt = −(i/ℏ)[Ĥ,ρ̂] + L(ρ̂)` (X), adapting `Ĥ` and `L(ρ̂)` parameters through harmonic gradient descent (Γ) to drive `ρ̂` towards target states (P_D). |
| Coherence Stabilization | H_CoherenceStabilize | Control Parameter Space | Adjust the Hamiltonian `Ĥ` and Lindbladian `L(·)` to maintain `g¹(τ)` above `g*` and `Q` above `Q_min`, based on feedback (E, P_D, R, Γ). |
| Temporal Stability Control | H_TemporalStabilize | Control Parameter Space | Adjust `Ĥ` and `L(·)` to drive maximum Lyapunov exponent `λ_max ≤ 0` and stabilize `PLI` over `T_260` windows, based on feedback (E, P_D, R, Γ). |
| Configurational Entropy Monitor | H_ConfigEntropyMonitor | Metric Space | Track the `Configurational Entropy` of `C_int` as an evaluation functional (E). |
| Coherence Potential Monitor | H_CoherencePotentialMonitor | Metric Space | Monitor the `Coherence Potential` of `C_int` as an evaluation functional (E). |
| Adaptive Capacity Assessment | H_AdaptiveCapacityAssess | Metric Space | Evaluate the `Adaptive Capacity` of `C_int` using belief density dynamics and system response (B, E). |
| Complexity-Entropy Product Compute | H_ComplexityEntropyProdCompute | Metric Space | Compute the `Complexity-Entropy Product` for `C_int` (E). |
| First-Order Correlation Compute | H_FirstOrderCorrelationCompute | Temporal Signal Space | Calculate `g¹(τ)` for `C_coh` (3) over the `T_260` supercycle (M_PR, E). |
| Quality Factor Computation | H_QualityFactorCompute | Harmonic Spectrum | Compute `Q = ω₀/Δω` for `C_coh` (3) (E). |
| Entanglement Entropy Computation | H_EntanglementEntropyCompute | Quantum State Space | Compute `S_E` for `C_coh` (3) (E). |
| Phase-Locking Index Computation | H_PhaseLockIndexCompute | Temporal Signal Space | Compute `PLI` for `C_temp` (6) (M_PR, E). |
| Lyapunov Spectrum Analysis | H_LyapunovSpectrumAnalyze | Dynamical System | Calculate the Lyapunov exponents spectrum for `C_temp` (6) over `T_260` windows (X, E). |
| Spectral Power Density Computation | H_SpectralPowerDensityCompute | Harmonic Spectrum | Compute `SPD` for `C_temp` (6) (M_PR, E). |
| Global Constraint Monitor | H_GlobalConstraintMonitor | Constraint Space | Continuously monitor `CR`, `D_KL` against predefined bounds using evaluation functionals and projecting onto constraint surfaces (E, S_C). |
| Landauer Energy Budget Enforce | H_LandauerEnergyBudgetEnforce | Resource Space | Enforce `E_min_bit ≥ k_B T ln2` by adjusting computational resource allocation, acting as a hard constraint projection (S_C, X). |
| Kinetic Mode Budget Enforce | H_KineticModeBudgetEnforce | Harmonic Mode Space | Enforce the `K_in` cap on active harmonic modes by projecting the system's state into the allowed subspace (S_C). |
| Control Reprioritization | H_ControlReprioritize | Control Parameter Space | Re-allocate `F_R`'s coherence/time budgets based on feedback from increasing `M_int` metrics (P_D, R). |
| System Threshold Evaluation | H_SystemThresholdEvaluate | Metric Space | Compare all relevant system metrics (`g¹`, `Q`, `λ_max`, `QF`, `S_V`, `CR`, `E_total`) against `V_7, V_8, V_9` thresholds (E, S_C). |
| Resource Reconfiguration | H_ResourceReconfigure | Control Parameter Space | Dynamically adjust `F_D`'s basis size and `F_R`'s control parameters in response to global constraint violations to restore system stability (S_C, P_D, R). |