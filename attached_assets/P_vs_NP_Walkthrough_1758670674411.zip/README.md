# P vs NP: An Educational Walkthrough

This project provides an educational walkthrough of one of the most significant unsolved problems in computer science and mathematics: **P vs NP**.

## What is P vs NP?

At its core, the P vs NP problem asks whether every problem whose solution can be *quickly verified* can also be *quickly solved*.

*   **P (Polynomial Time)**: This class contains problems that can be *solved* by a computer in polynomial time. "Polynomial time" means that the time required to solve the problem grows as a polynomial function of the input size (e.g., O(n), O(n^2), O(n^3)). These are generally considered "easy" or "tractable" problems.
    *   **Example**: Sorting a list of numbers, searching for an item in a list.

*   **NP (Nondeterministic Polynomial Time)**: This class contains problems for which a *given solution* can be *verified* in polynomial time. It's crucial to distinguish "solving" from "verifying." For NP problems, if someone hands you a potential answer, you can quickly check if it's correct. However, finding that answer in the first place might be very difficult (e.g., requiring exponential time).
    *   **Example**: The Subset Sum problem (given a set of numbers and a target sum, can a subset of those numbers sum up to the target?). If someone gives you a subset, you can quickly sum its elements and check if it matches the target. But finding such a subset from scratch can be very hard.

The "P vs NP" question is: **Is P = NP?**
*   If **P = NP**, it means that if a solution to a problem can be verified quickly, then the problem itself can also be solved quickly. This would have profound implications for cryptography, artificial intelligence, optimization, and many other fields. Many currently intractable problems would become tractable.
*   If **P != NP** (which is the widely believed conjecture), it means there are problems whose solutions can be quickly verified, but which cannot be quickly solved. This confirms our intuitive understanding of "hard" problems.

The Clay Mathematics Institute offers a US$1,000,000 prize for the first correct solution to the P vs NP problem.

## Project Structure

This walkthrough is structured as follows:

*   `src/p_problems.py`: Demonstrates examples of P-class problems.
*   `src/np_problems.py`: Demonstrates examples of NP-class problems, focusing on the distinction between finding a solution and verifying one.
*   `src/main.py`: Orchestrates the entire educational narrative, running examples and providing explanations.

## How to Run

1.  Save the `README.md`, `requirements.txt`, and the files within the `src/` directory to your local machine, preserving the directory structure.
2.  Navigate to the project's root directory in your terminal.
3.  Run the main script:
    ```bash
    python src/main.py
    ```
4.  Follow the output in your terminal as it guides you through the concepts and examples.
