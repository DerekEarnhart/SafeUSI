from .model import WSMForCausalLM
