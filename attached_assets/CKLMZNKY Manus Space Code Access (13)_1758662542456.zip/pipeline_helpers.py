
# pipeline_helpers.py
import re
from typing import Dict

PLAIN_SYNONYMS = {
    "quantization": "smaller numbers for speed",
    "distillation": "copy a big model into a small one",
    "tokenizer": "word-splitter",
    "backend": "which brain to use",
    "invariants": "things that must not change",
    "symplectic": "stable, area-preserving math step",
    "Cayley": "fast stable math update",
    "matrix exponential": "precise math update",
}

def wrap_prompt(prompt: str, style: str = "grade6"):
    # Keep it tiny: a short instruction + the user's ask
    if style == "grade6":
        head = "Explain simply. Avoid jargon. Short sentences.\n"
    else:
        head = "Explain clearly in natural language.\n"
    return head + prompt.strip()

def simplify_text(text: str, style: str = "grade6"):
    # Very gentle simplifier: replace a few terms and shorten long sentences
    out = text
    for term, plain in PLAIN_SYNONYMS.items():
        out = re.sub(rf"\b{re.escape(term)}\b", plain, out, flags=re.I)
    # Split long sentences crudely
    parts = re.split(r"([.!?])", out)
    rebuilt = []
    cur = ""
    for p in parts:
        cur += p
        if p in ".!?":
            if len(cur) > 160 and style == "grade6":
                # naive chop: add a newline
                rebuilt.append(cur.strip())
                cur = ""
            else:
                rebuilt.append(cur.strip()); cur = ""
    if cur.strip():
        rebuilt.append(cur.strip())
    return " ".join(rebuilt)

def auto_glossary_once(text: str, terms: Dict[str,str] = None):
    # Add (plain) after first occurrence of known terms
    if not terms: terms = PLAIN_SYNONYMS
    used = set()
    def repl(match):
        word = match.group(0)
        key = next((k for k in terms if k.lower()==word.lower()), None)
        if key and key not in used:
            used.add(key)
            return f"{word} ({terms[key]})"
        return word
    pattern = r"\b(" + "|".join(re.escape(k) for k in terms.keys()) + r")\b"
    return re.sub(pattern, repl, text, flags=re.I)
