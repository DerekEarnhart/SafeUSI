class ToolRegistry:
    """
    Catalogs available and created tools.
    """
    def __init__(self):
        self.tools = {}

    def register(self, name, tool_code):
        self.tools[name] = tool_code
