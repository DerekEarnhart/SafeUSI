
from core.hodge_toolkit import HodgeToolkit
import argparse

def main():
    parser = argparse.ArgumentParser(description="Hodge Toolkit")
    parser.add_argument('--data', type=str, help='Path to data source file')
    parser.add_argument('--visualize', action='store_true')
    args = parser.parse_args()

    toolkit = HodgeToolkit(data_source=args.data)

    if args.visualize:
        toolkit.visualizer.hodge_diamond("default").show()

if __name__ == "__main__":
    main()
