import React, { useState, useEffect } from 'react';
import axios from 'axios';

const InfiniteWorld = () => {
  const [world, setWorld] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const API_BASE_URL = 'http://localhost:8000';

  const generateWorld = async () => {
    setLoading(true);
    setError('');
    try {
      const response = await axios.post(`${API_BASE_URL}/generate_terrain`, {});
      setWorld(response.data.heightmap);
    } catch (err) {
      setError('Failed to generate world');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    generateWorld();
  }, []);

  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-6">
      <h2 className="text-xl font-semibold mb-4">Infinite World</h2>
      {loading && <p>Loading world...</p>}
      {error && <p className="text-red-500">{error}</p>}
      {world && (
        <div style={{ overflow: 'auto', maxHeight: '400px' }}>
          <table style={{ borderCollapse: 'collapse' }}>
            <tbody>
              {world.map((row, rowIndex) => (
                <tr key={rowIndex}>
                  {row.map((cell, colIndex) => (
                    <td
                      key={colIndex}
                      style={{
                        width: '10px',
                        height: '10px',
                        backgroundColor: `rgba(0, 0, 0, ${cell})`,
                      }}
                    ></td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <button
        onClick={generateWorld}
        className="mt-4 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
      >
        Generate New World
      </button>
    </div>
  );
};

export default InfiniteWorld;


