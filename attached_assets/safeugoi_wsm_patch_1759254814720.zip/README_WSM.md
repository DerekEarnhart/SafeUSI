# WSM Patch (SafeUGoI)

This patch drops a **Weyl-State Machine** (symplectic RNN) into a repo that previously used an LLM.

## Files
- `wsm/model.py` — WSM core (symplectic layers, cell, CausalLM wrapper).
- `wsm/tokenization.py` — tokenizer wrapper (defaults to HuggingFace GPT-2 tokenizer).
- `scripts/train_wsm.py` — train from scratch on a folder of `.txt` files.
- `scripts/distill_wsm.py` — distill from a HuggingFace teacher (default `gpt2-medium`).
- `scripts/serve_wsm.py` — FastAPI server exposing `/generate` (LLM-style API).
- `configs/wsm_base.yaml` — hyperparameters.
- `requirements_wsm.txt` — minimal dependencies.

## Quickstart

```bash
python -m venv .venv && source .venv/bin/activate  # (Windows: .venv\Scripts\activate)
pip install -r requirements_wsm.txt
```

### Option A: Distill from a teacher (recommended)
Put some domain `.txt` under `./data/` and run:
```bash
python scripts/distill_wsm.py --config configs/wsm_base.yaml --data_dir ./data --out ./wsm_ckpt.pt
```

### Option B: Train from scratch
```bash
python scripts/train_wsm.py --config configs/wsm_base.yaml --data_dir ./data --out ./wsm_ckpt.pt
```

### Serve
```bash
python scripts/serve_wsm.py --ckpt ./wsm_ckpt.pt --port 8080
# POST to /generate:
curl -X POST http://localhost:8080/generate   -H "Content-Type: application/json"   -d '{"prompt":"Hello Derek,", "max_new_tokens":64, "temperature":0.9, "top_p":0.9}'
```

## Integrating in your code
Replace your transformer call with:
```python
from wsm.model import WSMForCausalLM
# load ckpt (see serve script for example)
```

Keep your tokenizer if the repo already has one—swap `TokenizerWrapper` to call into it.
