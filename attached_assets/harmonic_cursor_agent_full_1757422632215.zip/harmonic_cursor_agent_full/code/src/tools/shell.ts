import { exec as cpExec } from 'child_process';
import { promisify } from 'util';
const execAsync = promisify(cpExec);
const ALLOW = ['npm', 'pnpm', 'yarn', 'pytest', 'python', 'node', 'npx', 'go', 'make'];

export async function exec(cmd: string, cwd?: string) {
  const bin = cmd.split(' ')[0];
  if (!ALLOW.includes(bin)) throw new Error('Command not allowed: ' + bin);
  const { stdout, stderr } = await execAsync(cmd, { cwd, timeout: 120000 });
  return { stdout, stderr };
}
