import { ToolRouter } from './toolRouter.js';
import { LLM } from './llm.js';
import { Memory } from './memory.js';
import { Policy } from './policy.js';
import { loadConfig } from './config.js';
import { planPrompt, reflectPrompt } from './prompts.js';

export type AgentOpts = { configPath?: string };

export class Agent {
  router: ToolRouter;
  llm: LLM;
  mem: Memory;
  policy: Policy;
  config: any;

  constructor(opts: AgentOpts = {}) {
    this.config = loadConfig(opts.configPath);
    this.router = new ToolRouter(this.config);
    this.llm = new LLM(this.config);
    this.mem = new Memory(this.config);
    this.policy = new Policy(this.config);
  }

  async run(task: string) {
    const context = await this.mem.retrieve(task, 5);
    const planMsg = planPrompt(task, context);
    const plan = await this.llm.chat(planMsg);
    const steps = (plan?.content || '').split('\n').filter(Boolean).slice(0, 6);

    let success = false, summary = '';
    for (let attempt = 0; attempt < (this.config.planning?.max_iterations ?? 4); attempt++) {
      for (const step of steps) {
        const res = await this.router.execute(step);
        this.mem.appendLog({ step, res });
        if (!res.ok) break;
      }
      // run tests
      const testRes = await this.router.execute('run tests');
      if (testRes.ok) { success = true; break; }
      // reflect and retry
      const refl = await this.llm.chat(reflectPrompt(task, steps, testRes.data));
      const newSteps = (refl?.content || '').split('\n').filter(Boolean).slice(0, 6);
      if (newSteps.length) steps.splice(0, steps.length, ...newSteps);
    }
    summary = `Task: ${task}\nPlan: ${steps.join(' → ')}\nStatus: ${success ? 'GREEN' : 'RED'}`;
    await this.mem.store(task, summary);
    return { success, summary };
  }
}
