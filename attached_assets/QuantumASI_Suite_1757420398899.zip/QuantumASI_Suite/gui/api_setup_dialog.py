#!/usr/bin/env python3
"""
API Setup Dialog for Quantum ASI
================================
Dialog for configuring Gemini 2.5 Flash API key
"""

import tkinter as tk
from tkinter import ttk, messagebox
import os
import json
from pathlib import Path

class APISetupDialog:
    """Dialog for API key configuration"""
    
    def __init__(self, parent):
        self.parent = parent
        self.result = None
        self.api_key = ""
        
        # Create dialog window
        self.dialog = tk.Toplevel(parent)
        self.dialog.title("🔑 API Configuration - Quantum ASI")
        self.dialog.geometry("500x400")
        self.dialog.configure(bg='#0a0a0a')
        self.dialog.transient(parent)
        self.dialog.grab_set()
        
        # Center dialog
        self.center_dialog()
        
        self.setup_dialog()
        
    def center_dialog(self):
        """Center dialog on parent window"""
        self.dialog.update_idletasks()
        x = self.parent.winfo_x() + (self.parent.winfo_width() // 2) - (500 // 2)
        y = self.parent.winfo_y() + (self.parent.winfo_height() // 2) - (400 // 2)
        self.dialog.geometry(f"500x400+{x}+{y}")
        
    def setup_dialog(self):
        """Setup dialog widgets"""
        
        # Main frame
        main_frame = tk.Frame(self.dialog, bg='#0a0a0a', padx=20, pady=20)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Title
        title_label = tk.Label(main_frame, 
                              text="🌌 Quantum ASI API Configuration",
                              bg='#0a0a0a', fg='#00ffff',
                              font=('Consolas', 14, 'bold'))
        title_label.pack(pady=(0, 20))
        
        # Provider selection
        provider_frame = tk.LabelFrame(main_frame, 
                                     text="Select AI Provider",
                                     bg='#0a0a0a', fg='#00ffff',
                                     font=('Consolas', 10))
        provider_frame.pack(fill=tk.X, pady=(0, 20))
        
        self.provider_var = tk.StringVar(value="gemini")
        
        providers = [
            ("🚀 Gemini 2.5 Flash (Recommended)", "gemini"),
            ("🧠 Local Quantum Only", "local")
        ]
        
        for text, value in providers:
            rb = tk.Radiobutton(provider_frame, text=text, 
                               variable=self.provider_var, value=value,
                               bg='#0a0a0a', fg='#00ffff',
                               selectcolor='#1a1a1a',
                               font=('Consolas', 10))
            rb.pack(anchor=tk.W, padx=10, pady=5)
        
        # API Key section
        self.api_frame = tk.LabelFrame(main_frame,
                                      text="🔑 Gemini API Configuration",
                                      bg='#0a0a0a', fg='#00ffff',
                                      font=('Consolas', 10))
        self.api_frame.pack(fill=tk.X, pady=(0, 20))
        
        # Instructions
        instructions = """To get your Gemini API key:
1. Go to: https://aistudio.google.com/app/apikey
2. Click "Create API key"
3. Copy and paste the key below

Your API key will be stored securely locally."""
        
        inst_label = tk.Label(self.api_frame, text=instructions,
                             bg='#0a0a0a', fg='#ffffff',
                             font=('Consolas', 9),
                             justify=tk.LEFT)
        inst_label.pack(padx=10, pady=10, anchor=tk.W)
        
        # API key entry
        tk.Label(self.api_frame, text="API Key:",
                bg='#0a0a0a', fg='#00ffff',
                font=('Consolas', 10)).pack(anchor=tk.W, padx=10)
        
        self.api_key_var = tk.StringVar()
        self.api_entry = tk.Entry(self.api_frame, 
                                 textvariable=self.api_key_var,
                                 show='*',
                                 bg='#1a1a1a', fg='#00ffff',
                                 font=('Consolas', 10),
                                 width=50)
        self.api_entry.pack(padx=10, pady=(0, 10), fill=tk.X)
        
        # Show/hide key button
        self.show_key_var = tk.BooleanVar()
        show_key_cb = tk.Checkbutton(self.api_frame, text="Show API key",
                                    variable=self.show_key_var,
                                    command=self.toggle_key_visibility,
                                    bg='#0a0a0a', fg='#00ffff',
                                    selectcolor='#1a1a1a')
        show_key_cb.pack(anchor=tk.W, padx=10)
        
        # Test connection button
        self.test_btn = tk.Button(self.api_frame, text="🧪 Test Connection",
                                 command=self.test_connection,
                                 bg='#1a1a1a', fg='#00ffff',
                                 font=('Consolas', 10))
        self.test_btn.pack(padx=10, pady=10)
        
        # Status label
        self.status_var = tk.StringVar(value="Enter API key to test connection")
        self.status_label = tk.Label(self.api_frame,
                                    textvariable=self.status_var,
                                    bg='#0a0a0a', fg='#ffff00',
                                    font=('Consolas', 9))
        self.status_label.pack(padx=10)
        
        # Buttons frame
        button_frame = tk.Frame(main_frame, bg='#0a0a0a')
        button_frame.pack(fill=tk.X, pady=20)
        
        # Cancel button
        cancel_btn = tk.Button(button_frame, text="❌ Cancel",
                              command=self.cancel,
                              bg='#1a1a1a', fg='#ff4444',
                              font=('Consolas', 10))
        cancel_btn.pack(side=tk.LEFT, padx=(0, 10))
        
        # OK button
        ok_btn = tk.Button(button_frame, text="✅ Start Quantum ASI",
                          command=self.ok,
                          bg='#1a1a1a', fg='#44ff44',
                          font=('Consolas', 10, 'bold'))
        ok_btn.pack(side=tk.RIGHT)
        
        # Load saved API key if exists
        self.load_saved_key()
        
        # Bind provider change
        self.provider_var.trace('w', self.on_provider_change)
        self.on_provider_change()
        
    def toggle_key_visibility(self):
        """Toggle API key visibility"""
        if self.show_key_var.get():
            self.api_entry.config(show='')
        else:
            self.api_entry.config(show='*')
    
    def on_provider_change(self, *args):
        """Handle provider selection change"""
        if self.provider_var.get() == "local":
            self.api_frame.pack_forget()
        else:
            self.api_frame.pack(fill=tk.X, pady=(0, 20))
    
    def test_connection(self):
        """Test API connection"""
        api_key = self.api_key_var.get().strip()
        
        if not api_key:
            self.status_var.set("❌ Please enter an API key")
            return
        
        self.status_var.set("🔄 Testing connection...")
        self.test_btn.config(state='disabled')
        
        # Test in background
        import threading
        threading.Thread(target=self._test_api_key, args=(api_key,), daemon=True).start()
    
    def _test_api_key(self, api_key: str):
        """Test API key in background thread"""
        try:
            import requests
            
            url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent"
            
            payload = {
                "contents": [{
                    "parts": [{
                        "text": "Hello, this is a test message."
                    }]
                }],
                "generationConfig": {
                    "maxOutputTokens": 10
                }
            }
            
            headers = {
                "Content-Type": "application/json",
                "x-goog-api-key": api_key
            }
            
            response = requests.post(url, json=payload, headers=headers, timeout=10)
            
            if response.status_code == 200:
                self.dialog.after(0, lambda: self.status_var.set("✅ Connection successful!"))
            else:
                error_msg = f"❌ API Error: {response.status_code}"
                self.dialog.after(0, lambda: self.status_var.set(error_msg))
                
        except Exception as e:
            error_msg = f"❌ Connection failed: {str(e)}"
            self.dialog.after(0, lambda: self.status_var.set(error_msg))
        finally:
            self.dialog.after(0, lambda: self.test_btn.config(state='normal'))
    
    def load_saved_key(self):
        """Load saved API key"""
        try:
            config_path = Path.home() / '.quantum_asi' / 'config.json'
            if config_path.exists():
                with open(config_path, 'r') as f:
                    config = json.load(f)
                    if 'gemini_api_key' in config:
                        self.api_key_var.set(config['gemini_api_key'])
                        self.status_var.set("✅ Loaded saved API key")
        except Exception as e:
            pass  # Ignore errors loading config
    
    def save_config(self, provider: str, api_key: str = ""):
        """Save configuration"""
        try:
            config_dir = Path.home() / '.quantum_asi'
            config_dir.mkdir(exist_ok=True)
            
            config = {
                'provider': provider,
                'gemini_api_key': api_key if provider == 'gemini' else '',
                'timestamp': str(datetime.now())
            }
            
            config_path = config_dir / 'config.json'
            with open(config_path, 'w') as f:
                json.dump(config, f, indent=2)
                
        except Exception as e:
            messagebox.showwarning("Save Error", f"Could not save config: {e}")
    
    def ok(self):
        """OK button clicked"""
        provider = self.provider_var.get()
        
        if provider == "gemini":
            api_key = self.api_key_var.get().strip()
            if not api_key:
                messagebox.showwarning("Missing API Key", 
                                     "Please enter your Gemini API key or select Local mode.")
                return
            
            self.save_config(provider, api_key)
            self.result = {'provider': provider, 'api_key': api_key}
        else:
            self.save_config(provider)
            self.result = {'provider': provider, 'api_key': None}
        
        self.dialog.destroy()
    
    def cancel(self):
        """Cancel button clicked"""
        self.result = None
        self.dialog.destroy()
    
    def show(self):
        """Show dialog and return result"""
        self.dialog.wait_window()
        return self.result

# Add datetime import at top if not already there
from datetime import datetime