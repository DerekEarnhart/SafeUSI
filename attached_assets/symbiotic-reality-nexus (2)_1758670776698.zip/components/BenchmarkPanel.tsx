import React from 'react';
import { BenchmarkMetrics } from '../types';
import BenchmarkChart from './BenchmarkChart';

interface BenchmarkPanelProps {
  metrics: BenchmarkMetrics;
}

const BenchmarkPanel: React.FC<BenchmarkPanelProps> = ({ metrics }) => {
  return (
    <aside className="w-64 bg-gray-900/30 p-2 flex flex-col space-y-2 overflow-y-auto">
        <h2 className="text-sm font-semibold text-cyan-400 uppercase tracking-widest text-center pb-1">ASI CORE METRICS</h2>
        <div className="grid grid-cols-1 gap-2 flex-1" style={{minHeight: '600px'}}>
            <BenchmarkChart label="CGR" value={metrics.cgr} color="#06b6d4" unit="LOC/s" maxHistory={30} />
            <BenchmarkChart label="PDC" value={metrics.pdc} color="#84cc16" unit="hrs" maxHistory={30} />
            <BenchmarkChart label="HCS" value={metrics.hcs} color="#ec4899" unit="" maxHistory={30} />
            <BenchmarkChart label="BDR" value={metrics.bdr} color="#f97316" unit="/kLOC" maxHistory={30} />
            <BenchmarkChart label="NI" value={metrics.ni} color="#a855f7" unit="" maxHistory={30} />
            <BenchmarkChart label="PIR" value={metrics.pir} color="#eab308" unit="solved" maxHistory={30} />
            <BenchmarkChart label="PCI" value={metrics.pci} color="#3b82f6" unit="" maxHistory={30} />
        </div>
    </aside>
  );
};

export default BenchmarkPanel;
