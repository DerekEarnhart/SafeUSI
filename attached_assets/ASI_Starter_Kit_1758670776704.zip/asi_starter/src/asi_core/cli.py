import typer, yaml, json
from pathlib import Path
from typing import Optional
from .orchestrator import Orchestrator, Tool
from .bridges.uploaded_plugins import generate as gen_plugins
from . import generated_plugins as gp

app = typer.Typer(add_completion=False)

def load_config(path: str):
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

@app.command()
def list_capabilities(config: str = "configs/default.yaml"):
    cfg = load_config(config)
    tools = gen_plugins(cfg["plugins"]["search_paths"], Path(__file__).parent / "generated_plugins.py")
    typer.echo(f"Discovered {len(tools)} capabilities:")
    for name in sorted(tools.keys()):
        typer.echo(f"- {name}")

@app.command()
def run(task: str, config: str = "configs/default.yaml", steps: Optional[int] = None, agents: int = 2):
    cfg = load_config(config)
    tools = gen_plugins(cfg["plugins"]["search_paths"], Path(__file__).parent / "generated_plugins.py")
    orch = Orchestrator()
    for t in tools.values():
        orch.register_tool(t)
    for i in range(agents):
        orch.add_agent(name=f"agent_{i+1}", memory_top_k=cfg.get("memory",{}).get("top_k", 8))
    max_steps = steps or cfg.get("orchestrator",{}).get("max_steps", 8)
    result = orch.run(task, max_steps=max_steps)
    typer.echo(json.dumps(result, indent=2))
