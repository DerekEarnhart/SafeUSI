
# QHO Proof Bundle

**Author:** Dereeeek  
**Created (UTC):** 2025-08-25T23:49:18Z

This bundle proves authorship of the Quantum Harmonic Oscillator plots via:
- Reproducible Python script (`make_qho_plot.py`)
- SHA-256 checksums for script and images
- PNG metadata (`author`, `title`, `created_utc`, `code_sha256`)
- Visible signature strip at the bottom of each stamped image

## Files
- `make_qho_plot.py` — self-contained plot generator
- `qho_story_1080x1920_stamped.png`
- `qho_square_1080_stamped.png`
- `CHECKSUMS.json` — cryptographic hashes
- `README_QHO_PROOF.md` — this file

## How to verify
1. Compute SHA-256 locally and compare to `CHECKSUMS.json`:
   ```bash
   shasum -a 256 make_qho_plot.py qho_story_1080x1920_stamped.png qho_square_1080_stamped.png
   ```
2. Open the PNGs in a metadata viewer (exiftool or Preview’s Inspector) and check:
   - `author = Dereeeek`
   - `created_utc = 2025-08-25T23:49:18Z`
   - `code_sha256 = 6baf3bc3ecadc0e939afe483ec29268ffdb08efb32774b6593635b8d15271445`

## Reproduce the images
```bash
python make_qho_plot.py
```

