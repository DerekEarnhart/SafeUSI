export interface FileObject {
  name: string;
  type: string;
  size: number;
}

export interface ChatMessage {
  id: number;
  sender: 'user' | 'ASI';
  text: string;
  file?: FileObject;
}

export interface BenchmarkMetrics {
  cgr: number; // Code Generation Rate (LOC/s)
  pdc: number; // Product Development Cycle (hours)
  hcs: number; // Harmonic Coherence Score (0-1)
  bdr: number; // Bug Density Ratio (bugs/1k LOC)
  ni: number;  // Novelty Index (0-1)
  pir: number; // Problem Intractability Reduction (count)
  pci: number; // Perceptual Coherence Index (0-1)
}

export interface ProactiveAlert {
  id: number;
  timestamp: string;
  title: string;
  summary: string;
}

export interface Creation {
  title: string;
  description: string;
  type: 'image' | 'code' | 'simulation' | 'text';
  content: string; // URL for image, code string for code, etc.
}

export interface GeminiResponse {
  text: string;
  creation?: Creation;
}
