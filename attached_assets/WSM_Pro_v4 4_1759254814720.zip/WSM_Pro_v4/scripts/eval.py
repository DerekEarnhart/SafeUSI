
import argparse, torch
from wsmpro.model import WSMForCausalLM
from wsmpro.tokenization import load_tokenizer
import math

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", type=str, default="./wsm_ckpt.pt")
    ap.add_argument("--tokenizer", type=str, default="./assets/tokenizer")
    args = ap.parse_args()

    tok = load_tokenizer(args.tokenizer)
    model = WSMForCausalLM()
    try:
        model.load_state_dict(torch.load(args.ckpt, map_location="cpu"), strict=False)
    except FileNotFoundError:
        pass
    # Placeholder perplexity on dummy data
    txts = ["This is a test.", "Replace with a validation corpus."]
    total_loss, total_tokens = 0.0, 0
    for t in txts:
        ids = tok(t, return_tensors="pt")["input_ids"]
        labels = ids[:, -1]
        out = model(ids, labels=labels)
        total_loss += out["loss"].item()
        total_tokens += labels.numel()
    ppl = math.exp(total_loss / max(1,total_tokens))
    print("Pseudo-perplexity:", ppl)

if __name__ == "__main__":
    main()
