import ast, operator as op
ALLOWED = {ast.Expression, ast.BinOp, ast.UnaryOp, ast.Num, ast.Constant, ast.Name, ast.Add, ast.Sub, ast.Mult, ast.Div, ast.FloorDiv, ast.Mod, ast.Pow, ast.USub, ast.UAdd, ast.Load, ast.Tuple, ast.List, ast.Dict}
SAFE_VARS = {"pi": 3.141592653589793, "e": 2.718281828459045}
OPS = {ast.Add: op.add, ast.Sub: op.sub, ast.Mult: op.mul, ast.Div: op.truediv, ast.FloorDiv: op.floordiv, ast.Mod: op.mod, ast.Pow: lambda a,b: a**b if (abs(a)<=1e6 and abs(b)<=8) else (_ for _ in ()).throw(ValueError("pow too big"))}
def _eval(n, env):
    if type(n) not in ALLOWED: raise ValueError(f'node not allowed: {type(n).__name__}')
    if isinstance(n, ast.Expression): return _eval(n.body, env)
    if isinstance(n, ast.Constant): 
        if isinstance(n.value, (int,float)): return n.value
        raise ValueError('const type not allowed')
    if isinstance(n, ast.Name): 
        if n.id in env: return env[n.id]
        raise ValueError('unknown name: '+n.id)
    if isinstance(n, ast.UnaryOp): 
        v=_eval(n.operand, env); return +v if isinstance(n.op, ast.UAdd) else -v
    if isinstance(n, ast.BinOp): return OPS[type(n.op)](_eval(n.left, env), _eval(n.right, env))
    if isinstance(n, (ast.Tuple, ast.List)): return [_eval(e, env) for e in n.elts]
    if isinstance(n, ast.Dict): return { _eval(k, env): _eval(v, env) for k,v in zip(n.keys, n.values) }
    raise ValueError('unsupported')
def safe_eval(expr:str, vars=None):
    env=dict(SAFE_VARS); 
    if vars: env.update({k: float(v) for k,v in vars.items()})
    return _eval(ast.parse(expr, mode='eval'), env)
