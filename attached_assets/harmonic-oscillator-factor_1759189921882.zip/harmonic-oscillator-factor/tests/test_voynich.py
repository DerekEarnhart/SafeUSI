from voynich.decoder import VoynichDecoder

def test_decoder_runs():
    text = "qokedy qokedy dal qokedy qokedy"
    d = VoynichDecoder().decode(text)
    assert "decoded" in d and "confidence" in d
    assert 0.0 <= d["confidence"] <= 1.0
