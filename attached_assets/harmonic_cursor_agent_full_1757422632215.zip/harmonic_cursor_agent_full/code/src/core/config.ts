import fs from 'fs';
import path from 'path';

export function loadConfig(configPath?: string): any {
  const defaultCfg = {
    model: 'gpt-4o-mini',
    temperature: 0.2,
    planning: { max_iterations: 4, retry_on_fail: 1 },
    policies: { allow_network: false, allow_shell: true, confirm_large_diff: true },
    memory: { dir: '.harmonic_agent', vector_store: 'local', kv_store: 'json' }
  };
  const p = configPath || path.resolve(process.cwd(), '../examples/agent.config.json');
  try {
    const raw = fs.readFileSync(p, 'utf8');
    return { ...defaultCfg, ...JSON.parse(raw) };
  } catch {
    return defaultCfg;
  }
}
