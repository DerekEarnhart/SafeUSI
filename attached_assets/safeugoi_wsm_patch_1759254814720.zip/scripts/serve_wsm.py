\
import argparse, torch
from fastapi import FastAPI
from pydantic import BaseModel
import uvicorn
from wsm.model import WSMForCausalLM
from wsm.tokenization import TokenizerWrapper

app = FastAPI()

class GenReq(BaseModel):
    prompt: str
    max_new_tokens: int = 128
    temperature: float = 1.0
    top_k: int = 0
    top_p: float = 1.0

class GenResp(BaseModel):
    text: str

state = {}

@app.on_event("startup")
def load_model():
    global state
    ckpt = torch.load(state["ckpt_path"], map_location=state["device"])
    tok = TokenizerWrapper(ckpt.get("tokenizer", "gpt2"))
    model_cfg = ckpt.get("config", {"d_model":512,"state_n":128,"layers":3})
    model = WSMForCausalLM(vocab_size=tok.vocab_size,
                           d_model=model_cfg["d_model"],
                           state_n=model_cfg["state_n"],
                           layers=model_cfg["layers"])
    model.load_state_dict(ckpt["model"], strict=True)
    model.to(state["device"]).eval()
    state["tok"] = tok
    state["model"] = model

@app.post("/generate", response_model=GenResp)
def generate(req: GenReq):
    tok = state["tok"]
    model = state["model"]
    device = state["device"]
    enc = tok.batch_encode([req.prompt], max_length=1024)
    input_ids = enc["input_ids"].to(device)
    out_ids = model.generate(input_ids,
                             max_new_tokens=req.max_new_tokens,
                             temperature=req.temperature,
                             top_k=req.top_k,
                             top_p=req.top_p)
    text = tok.decode(out_ids[0].tolist())
    return GenResp(text=text)

def main(ckpt_path: str, host: str = "0.0.0.0", port: int = 8000, device: str = None):
    device = device or ("cuda" if torch.cuda.is_available() else "cpu")
    state.update({"ckpt_path": ckpt_path, "device": device})
    uvicorn.run(app, host=host, port=port)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True, help="Path to WSM checkpoint (from train or distill)")
    ap.add_argument("--host", default="0.0.0.0")
    ap.add_argument("--port", type=int, default=8000)
    ap.add_argument("--device", default=None)
    args = ap.parse_args()
    main(args.ckpt, host=args.host, port=args.port, device=args.device)
