
from dataclasses import dataclass, asdict
from typing import List, Optional, Dict, Any

@dataclass
class LabelProvenance:
    type: str                 # "proven" | "heuristic" | "unknown"
    method: str               # e.g. "lefschetz_11" | "van_luijk" | "reduction_bound"
    assumptions: List[str]    # e.g. ["none"] or ["Tate","GRH"]
    confidence: float         # 0..1
    notes: Optional[str] = ""

    def to_json(self) -> Dict[str, Any]:
        return asdict(self)
