import time
from itertools import combinations

def verify_subset_sum(numbers, target_sum, proposed_subset):
    """
    Verifies if a proposed_subset of numbers sums up to the target_sum.
    This is the "easy" part of an NP problem.
    Time Complexity: O(k) where k is the size of the proposed_subset (linear in subset size).
    """
    print(f"  > Verifying proposed subset {proposed_subset} for target sum {target_sum} in {numbers}...")
    start_time = time.perf_counter()
    current_sum = sum(proposed_subset)
    end_time = time.perf_counter()
    is_correct = (current_sum == target_sum)

    print(f"  > Proposed subset sums to {current_sum}. Matches target: {is_correct}. Verification took {end_time - start_time:.6f} seconds.")
    return is_correct

def find_subset_sum_bruteforce(numbers, target_sum):
    """
    Attempts to find a subset that sums to the target_sum using a brute-force approach.
    This demonstrates why finding a solution for NP problems can be "hard" (exponential).
    Time Complexity: O(2^n * n) in the worst case (iterating through all 2^n subsets and summing them).
    """
    print(f"  > Attempting to FIND a subset for target sum {target_sum} in {numbers} (brute-force)...")
    start_time = time.perf_counter()
    n = len(numbers)
    # Iterate through all possible subset sizes
    for i in range(1, n + 1):
        # Iterate through all combinations of that size
        for subset_tuple in combinations(numbers, i):
            subset = list(subset_tuple)
            if sum(subset) == target_sum:
                end_time = time.perf_counter()
                print(f"  > Found a subset: {subset} in {end_time - start_time:.6f} seconds.")
                return subset
    end_time = time.perf_counter()
    print(f"  > No subset found matching target sum {target_sum} in {end_time - start_time:.6f} seconds.")
    return None

if __name__ == "__main__":
    print("--- NP-Problems Demonstration ---")
    my_numbers_np = [3, 34, 4, 12, 5, 2]
    my_target_np = 9

    # Demonstrate verification (easy)
    correct_subset = [3, 4, 2]
    incorrect_subset = [12, 5]
    verify_subset_sum(my_numbers_np, my_target_np, correct_subset)
    verify_subset_sum(my_numbers_np, my_target_np, incorrect_subset)

    print("-" * 30)

    # Demonstrate finding (hard via brute force)
    find_subset_sum_bruteforce(my_numbers_np, my_target_np)
    find_subset_sum_bruteforce(my_numbers_np, 100) # Should not find

    # A slightly larger example to highlight the finding difficulty
    large_numbers = list(range(1, 25)) # 24 numbers, 2^24 is large
    # Let's pick a target that makes it find one relatively quickly if it exists, but the search space is vast.
    target_large = sum(large_numbers[:5]) # Sum of first 5 numbers = 1+2+3+4+5 = 15
    print("\n--- Demonstrating Brute-Force difficulty with a larger set ---")
    # Commenting out for quick execution, but uncomment to see it run longer
    # find_subset_sum_bruteforce(large_numbers, target_large)
    # find_subset_sum_bruteforce(large_numbers, 999) # Very unlikely to find quickly
    print("  (Brute-force finding for larger sets can take a very long time!)")
    print("-" * 30)
