"""
Sentinel Memory Graph

This module provides memory graph tracking for the HAP AGI system,
allowing for visualizing the history of optimization and other operations.
"""

import os
import logging
import json
import networkx as nx
import matplotlib.pyplot as plt
import matplotlib as mpl
from datetime import datetime
import time

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    filename='sentinel_memory.log'
)
logger = logging.getLogger(__name__)

class SentinelMemory:
    """Memory graph for tracking operations and their relationships."""
    
    def __init__(self, history_file="./metrics_data/sentinel_memory_history.json"):
        """
        Initialize Sentinel Memory Graph.
        
        Args:
            history_file (str): Path to the history file
        """
        self.graph = nx.DiGraph()
        self.history_file = history_file
        self.node_counter = 0
        
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(history_file), exist_ok=True)
        
        logger.info(f"Initialized SentinelMemory with history file: {history_file}")
    
    def add_event(self, label, info=None):
        """
        Add an event node to the memory graph.
        
        Args:
            label (str): Event label
            info (dict): Additional event information
            
        Returns:
            int: Node ID
        """
        self.node_counter += 1
        node_id = self.node_counter
        
        # Add timestamp if not provided
        if info is None:
            info = {}
        
        if 'timestamp' not in info:
            info['timestamp'] = datetime.now().isoformat()
        
        # Add node to graph
        self.graph.add_node(node_id, label=label, info=info)
        
        logger.debug(f"Added event node: {node_id}, {label}")
        return node_id
    
    def add_edge(self, source, target, relation=None):
        """
        Add a relationship edge between nodes.
        
        Args:
            source (int): Source node ID
            target (int): Target node ID
            relation (str): Edge label
            
        Returns:
            bool: Success flag
        """
        # Check if nodes exist
        if source not in self.graph or target not in self.graph:
            logger.warning(f"Cannot add edge: {source} -> {target}, nodes don't exist")
            return False
        
        # Add edge to graph
        self.graph.add_edge(source, target, relation=relation)
        
        logger.debug(f"Added edge: {source} -> {target}, {relation}")
        return True
    
    def visualize(self, title="Sentinel Memory Graph", output_file=None):
        """
        Generate a visualization of the memory graph.
        
        Args:
            title (str): Graph title
            output_file (str): Output file path (None for auto-generated)
            
        Returns:
            str: Path to the visualization file
        """
        # Create output file path if not provided
        if output_file is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_file = f"./metrics_data/sentinel_memory_{timestamp}.png"
        
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(output_file), exist_ok=True)
        
        # Create figure
        plt.figure(figsize=(12, 8))
        
        # Define node colors based on labels
        colors = {
            'HAPIntegratorInitialization': '#4287f5',  # Blue
            'HarmonicSystemOptimization': '#42f5a7',   # Green
            'HarmonicAcceleration': '#f542a7',         # Pink
            'ConsciousnessExtraction': '#f5a742',      # Orange
            'HAPPatternGeneration': '#8a42f5',         # Purple
            'AccelerationResults': '#f54242',          # Red
            'OptimizationResults': '#42f5f5',          # Cyan
            'FileAnalysis': '#a2a2a2',                 # Gray
            'ConsciousnessMetrics': '#8a8a42',         # Olive
            'ConsciousnessResults': '#f5f542',         # Yellow
            'QuantumEmotionTranslation': '#ff9c9c',    # Light Red
            'EmotionResults': '#ffc8a1',               # Light Orange
            'CodeVisualization': '#c8a1ff',            # Lavender
            'FileProcessed': '#a1ffc8',                # Light Green
            'VisualizationResults': '#a1c8ff',         # Light Blue
            'SystemEmotionalAnalysis': '#ffa1f0'       # Pink
        }
        
        # Get node positions using spring layout
        pos = nx.spring_layout(self.graph, seed=42)
        
        # Draw nodes
        for node, data in self.graph.nodes(data=True):
            label = data.get('label', 'Unknown')
            color = colors.get(label, '#cccccc')  # Default gray for unknown labels
            
            # Draw node
            nx.draw_networkx_nodes(
                self.graph, pos,
                nodelist=[node],
                node_color=color,
                node_size=1000,
                alpha=0.8
            )
        
        # Draw edges
        edge_colors = []
        for _, _, data in self.graph.edges(data=True):
            relation = data.get('relation', None)
            if relation == 'initiated_optimization' or relation == 'initiated_acceleration':
                edge_colors.append('#ff5555')  # Red for initiation edges
            elif relation == 'applied_harmonic_patterns':
                edge_colors.append('#55ff55')  # Green for enhancement edges
            elif relation == 'produced_results':
                edge_colors.append('#5555ff')  # Blue for result edges
            else:
                edge_colors.append('#aaaaaa')  # Gray for other edges
        
        # Draw all edges
        nx.draw_networkx_edges(
            self.graph, pos,
            width=2.0,
            alpha=0.7,
            edge_color=edge_colors,
            connectionstyle='arc3,rad=0.1'
        )
        
        # Draw node labels
        nx.draw_networkx_labels(
            self.graph, pos,
            labels={node: data['label'] for node, data in self.graph.nodes(data=True)},
            font_size=10,
            font_family='sans-serif'
        )
        
        # Add title and legend
        plt.title(title)
        plt.axis('off')
        
        # Save the visualization
        plt.savefig(output_file, dpi=300, bbox_inches='tight')
        plt.close()
        
        logger.info(f"Generated visualization: {output_file}")
        return output_file
    
    def export_to_json(self, output_file=None):
        """
        Export the memory graph to a JSON file.
        
        Args:
            output_file (str): Output file path (None for auto-generated)
            
        Returns:
            str: Path to the JSON file
        """
        # Create output file path if not provided
        if output_file is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_file = f"./metrics_data/sentinel_memory_export_{timestamp}.json"
        
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(output_file), exist_ok=True)
        
        # Convert graph to serializable format
        graph_data = {
            'nodes': [
                {
                    'id': node,
                    'label': data.get('label', 'Unknown'),
                    'info': data.get('info', {})
                }
                for node, data in self.graph.nodes(data=True)
            ],
            'edges': [
                {
                    'source': u,
                    'target': v,
                    'relation': data.get('relation', None)
                }
                for u, v, data in self.graph.edges(data=True)
            ]
        }
        
        # Save to file
        with open(output_file, 'w') as f:
            json.dump(graph_data, f, indent=2)
        
        logger.info(f"Exported memory graph to: {output_file}")
        return output_file
    
    def load_history(self):
        """
        Load memory graph history from file.
        
        Returns:
            bool: Success flag
        """
        try:
            if os.path.exists(self.history_file):
                with open(self.history_file, 'r') as f:
                    graph_data = json.load(f)
                
                # Clear existing graph
                self.graph.clear()
                
                # Add nodes
                max_node_id = 0
                for node_data in graph_data['nodes']:
                    node_id = node_data['id']
                    self.graph.add_node(
                        node_id,
                        label=node_data.get('label', 'Unknown'),
                        info=node_data.get('info', {})
                    )
                    max_node_id = max(max_node_id, node_id)
                
                # Update counter
                self.node_counter = max_node_id
                
                # Add edges
                for edge_data in graph_data['edges']:
                    self.graph.add_edge(
                        edge_data['source'],
                        edge_data['target'],
                        relation=edge_data.get('relation', None)
                    )
                
                logger.info(f"Loaded memory graph from {self.history_file} with {len(self.graph.nodes)} nodes and {len(self.graph.edges)} edges")
                return True
            else:
                logger.info(f"No history file found at {self.history_file}")
                return False
        
        except Exception as e:
            logger.error(f"Error loading memory graph history: {e}")
            return False
    
    def save_history(self):
        """
        Save memory graph history to file.
        
        Returns:
            bool: Success flag
        """
        try:
            # Export to file
            self.export_to_json(self.history_file)
            return True
        
        except Exception as e:
            logger.error(f"Error saving memory graph history: {e}")
            return False
    
    def get_node_info(self, node_id):
        """
        Get information about a node.
        
        Args:
            node_id (int): Node ID
            
        Returns:
            dict: Node information
        """
        if node_id in self.graph:
            return self.graph.nodes[node_id]
        else:
            return None
    
    def get_related_nodes(self, node_id, direction='both'):
        """
        Get nodes related to the specified node.
        
        Args:
            node_id (int): Node ID
            direction (str): Relationship direction ('in', 'out', 'both')
            
        Returns:
            list: Related nodes
        """
        if node_id not in self.graph:
            return []
        
        if direction == 'in':
            return list(self.graph.predecessors(node_id))
        elif direction == 'out':
            return list(self.graph.successors(node_id))
        else:  # 'both'
            predecessors = list(self.graph.predecessors(node_id))
            successors = list(self.graph.successors(node_id))
            return list(set(predecessors + successors))
    
    def find_nodes_by_label(self, label):
        """
        Find nodes with the specified label.
        
        Args:
            label (str): Node label
            
        Returns:
            list: Matching nodes
        """
        return [
            node for node, data in self.graph.nodes(data=True)
            if data.get('label') == label
        ]
    
    def find_recent_nodes(self, count=5, label=None):
        """
        Find the most recent nodes.
        
        Args:
            count (int): Number of nodes to return
            label (str): Filter by label (None for all)
            
        Returns:
            list: Recent nodes
        """
        nodes_with_timestamps = []
        
        for node, data in self.graph.nodes(data=True):
            if label is not None and data.get('label') != label:
                continue
            
            # Get timestamp from info
            timestamp = data.get('info', {}).get('timestamp')
            if timestamp:
                nodes_with_timestamps.append((node, timestamp))
        
        # Sort by timestamp (newest first) and return the top 'count'
        nodes_with_timestamps.sort(key=lambda x: x[1], reverse=True)
        return [node for node, _ in nodes_with_timestamps[:count]]


# Example usage
if __name__ == "__main__":
    # Create a memory graph
    memory = SentinelMemory()
    
    # Add event nodes
    init_node = memory.add_event("Initialization", {"system": "HAP"})
    
    optimize_node = memory.add_event("Optimization", {"target": "performance"})
    memory.add_edge(init_node, optimize_node, "initiates")
    
    result_node = memory.add_event("Result", {"improvement": 12.5})
    memory.add_edge(optimize_node, result_node, "produces")
    
    # Visualize the graph
    viz_path = memory.visualize()
    print(f"Visualization saved to: {viz_path}")
    
    # Export to JSON
    json_path = memory.export_to_json()
    print(f"JSON exported to: {json_path}")
    
    # Save history
    memory.save_history()
    print("Memory graph history saved")