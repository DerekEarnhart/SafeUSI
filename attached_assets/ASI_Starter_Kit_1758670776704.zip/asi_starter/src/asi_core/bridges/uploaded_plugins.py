from __future__ import annotations
from typing import Dict, Any, List, Callable
from pathlib import Path
from ..orchestrator import Tool
from ..loader import discover_functions
import importlib, importlib.util, sys, inspect

def generate(search_paths: List[str], out_path: str) -> Dict[str, Tool]:
    root_paths = [Path(p) for p in search_paths]
    found = discover_functions(root_paths)
    tools: Dict[str, Tool] = {}

    for item in found:
        if item["type"] == "function":
            mod = importlib.import_module(item["module"])
            func = getattr(mod, item["callable_name"])
            tool_name = f"{Path(item['file']).stem}_{item['callable_name']}".lower()
            def make_call(f):
                def _call(payload: Dict[str, Any]) -> Dict[str, Any]:
                    x = payload.get("input")
                    out = f(x)
                    return {"output": out, "from": tool_name}
                return _call
            tools[tool_name] = Tool(name=tool_name, call=make_call(func), doc=f"Wrapped {item['module']}.{item['callable_name']}")

        elif item["type"] == "class":
            mod = importlib.import_module(item["module"])
            cls = getattr(mod, item["callable_name"])
            # pick first candidate method
            method_name = item.get("methods", ["run"])[0]
            tool_name = f"{Path(item['file']).stem}_{cls.__name__}_{method_name}".lower()
            def make_call(c, mname):
                def _call(payload: Dict[str, Any]) -> Dict[str, Any]:
                    x = payload.get("input")
                    inst = c()
                    m = getattr(inst, mname)
                    out = m(x)
                    return {"output": out, "from": tool_name}
                return _call
            tools[tool_name] = Tool(name=tool_name, call=make_call(cls, method_name), doc=f"Wrapped {item['module']}.{cls.__name__}.{method_name}")

    # Write generated registry
    lines = ["REGISTRY = {"]
    for k in sorted(tools.keys()):
        lines.append(f'    "{k}": None,')
    lines.append("}")
    Path(out_path).write_text("\n".join(lines), encoding="utf-8")
    return tools
