# Harmonic Project Architect (HPA) Demo

This project demonstrates a simplified Harmonic Project Architect (HPA) CLI interacting with a local Null-State Ingest Service. It showcases how a project specification (its 'harmonic fingerprint') can be logged and tracked using content-addressed identifiers (CIDs) before the actual project files are synthesized.

## Components

1. `nullstate_service.py`: A robust, standard-library-only HTTP server for ingesting 'null-state' descriptors, generating deterministic harmonic embeddings, and committing content-addressed ledger entries. This is the **patched version** provided.
2. `hpa_cli.py`: A command-line interface (CLI) for the Harmonic Project Architect. It takes a natural language project description, generates a structured specification, ingests it into the `nullstate_service`, and then simulates project synthesis and packaging.
3. `project_templates/micro_benchmark_template.py`: A basic template for a Python micro-benchmark, demonstrating how projects might be synthesized from a specification.
4. `metric_weights_normalized.json`: A dummy file representing the normalized weights for quality scoring, as described in the HPA framework.

## Quickstart

1. **Start the Null-State Ingest Service:**
 ```bash
 python nullstate_service.py --serve --port 8000
 ```
 *Leave this running in a separate terminal.*

2. **Run the HPA CLI:**
 ```bash
 python hpa_cli.py "Build a simple Python micro-benchmark for array sorting performance."
 ```

 This will:
 - Generate a structured `Spec` from your prompt.
 - Send this `Spec` to the `nullstate_service.py` to get a `CID` (Content-Addressed Identifier) for the project's intent.
 - Simulate the creation of a `micro_benchmark.py` file based on a template.
 - Package the generated files into a ZIP archive (`HPA_Project_<CID>.zip`).
 - Report the `CID` and the output ZIP file name.

3. **Inspect the Ledger (Optional):**
 You can retrieve the ingested `Spec` using the reported `CID` from the `nullstate_service`:
 ```bash
 curl -s http://127.0.0.1:8000/ledger/ | python -m json.tool
 ```

## HPA Concepts Demonstrated

* **Intent Harmonization**: Natural language description to structured `Spec`.
* **Safety Gates**: Conceptualized by the `nullstate_service`'s ingestion rules and deterministic embedding.
* **Capability Graph & Synthesis**: Simulated via template-based code generation.
* **Packaging**: Output as a downloadable ZIP.
* **Quality Scoring**: Placeholder `metric_weights_normalized.json` for future integration.
* **Content-Addressed Tracking**: Using `CID`s from the `nullstate_service` to uniquely identify and retrieve project specifications based on their content.
