
from setuptools import setup, find_packages

setup(
    name="hodge_toolkit",
    version="1.0.0",
    packages=find_packages(),
    install_requires=[
        "numpy",
        "matplotlib",
        "networkx",
    ],
    author="Your Name",
    author_email="your.email@example.com",
    description="A toolkit for analyzing Hodge theory in algebraic geometry",
    keywords="mathematics, algebraic geometry, hodge theory",
    python_requires=">=3.6",
    entry_points={{
        "console_scripts": [
            "hodge-toolkit=hodge_toolkit.main:main",
        ],
    }},
)
