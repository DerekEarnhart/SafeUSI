# ComparatorKit — A/B/N Model Comparator with Reproducible Seeds & Proof Artifacts

**What it is**
A tiny, portable harness to compare multiple model variants side‑by‑side with fixed seeds,
pinned synthetic tasks, multi‑metric selection, and a signed artifact log (hash‑linked).

**Highlights**
- A/B/N comparator with fixed **seeds** and dataset/version pins
- Multi‑metric selection: **accuracy** (higher), **robust_accuracy** (higher), **latency_ms** (lower)
- Output: console table + `artifacts/commit_*.json` (hash‑linked “HPC‑style” proof)
- Deterministic synthetic task: `synthetic_blobs_v1` (no internet/data files)
- Two built‑in variants: `baseline_lr` and `tuned_lr` (logistic regression)
- Pure Python + **numpy** only

Quick start:
1) `python -m pip install numpy`
2) `python comparator.py --config config_example.json`
