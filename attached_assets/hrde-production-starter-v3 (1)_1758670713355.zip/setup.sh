#!/usr/bin/env bash
set -euo pipefail
[ -f .env ] || cp .env.example .env
mkdir -p assets/external assets/samples hrde_workspace bench/reports
cd python && python3 -m venv .venv && source .venv/bin/activate && pip install -U pip && pip install -r requirements.txt && cd - >/dev/null
cd worker && npm config set optional true && npm install && cd - >/dev/null
echo Setup complete.
