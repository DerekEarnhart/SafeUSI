
# Hodge Toolkit

A toolkit for analyzing Hodge theory in algebraic geometry.

## Installation

```bash
pip install .
```

## Usage

### Python

```python
from hodge_toolkit import HodgeToolkit

toolkit = HodgeToolkit()
toolkit.visualizer.hodge_diamond("default")
```

### CLI

```bash
hodge-toolkit --visualize
```
