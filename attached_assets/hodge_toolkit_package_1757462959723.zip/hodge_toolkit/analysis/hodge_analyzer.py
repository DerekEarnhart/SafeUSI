
import numpy as np

class HodgeAnalyzer:
    def __init__(self, data):
        self.data = data

    def analyze_variety(self, key):
        if key not in self.data:
            raise KeyError(f"Variety '{key}' not found in data")
        variety = self.data[key]
        hodge_numbers = variety.get('hodge_numbers', [])
        return {
            'dimension': variety.get('dimension', len(hodge_numbers) - 1),
            'hodge_symmetry': self._check_hodge_symmetry(hodge_numbers),
            'pure': self._check_pure_type(hodge_numbers),
            'summary': self._generate_summary(hodge_numbers)
        }

    def _check_hodge_symmetry(self, hodge_numbers):
        n = len(hodge_numbers)
        for p in range(n):
            for q in range(n):
                if hodge_numbers[p][q] != hodge_numbers[q][p]:
                    return False
        return True

    def _check_pure_type(self, hodge_numbers):
        n = len(hodge_numbers)
        for p in range(n):
            for q in range(n):
                if p != q and hodge_numbers[p][q] != 0:
                    return False
        return True

    def _generate_summary(self, hodge_numbers):
        n = len(hodge_numbers) - 1
        summary = f"Complex {n}-dimensional variety with Hodge numbers:\n"
        for p in range(n + 1):
            for q in range(n + 1):
                if hodge_numbers[p][q] != 0:
                    summary += f"h^{{{p},{q}}} = {hodge_numbers[p][q]}, "
        return summary.rstrip(", ")

    def compare_varieties(self, key1, key2):
        if key1 not in self.data or key2 not in self.data:
            raise KeyError("One or both varieties not found in data")
        var1 = self.data[key1]
        var2 = self.data[key2]
        hodge1 = var1.get('hodge_numbers', [])
        hodge2 = var2.get('hodge_numbers', [])
        return {
            'same_dimension': var1.get('dimension') == var2.get('dimension'),
            'same_euler': var1.get('euler_characteristic') == var2.get('euler_characteristic'),
            'same_hodge': np.array_equal(hodge1, hodge2) if len(hodge1) == len(hodge2) else False,
            'notes': self._compare_notes(var1, var2)
        }

    def _compare_notes(self, var1, var2):
        notes = []
        if var1.get('dimension') != var2.get('dimension'):
            notes.append(f"Different dimensions: {var1.get('dimension')} vs {var2.get('dimension')}")
        return "\n".join(notes)
