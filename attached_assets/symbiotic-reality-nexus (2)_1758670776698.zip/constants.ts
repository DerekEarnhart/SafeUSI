import { BenchmarkMetrics } from './types';

export const initialBenchmarks: BenchmarkMetrics = {
  cgr: 0,
  pdc: 0,
  hcs: 0,
  bdr: 0,
  ni: 0,
  pir: 0,
  pci: 0,
};
