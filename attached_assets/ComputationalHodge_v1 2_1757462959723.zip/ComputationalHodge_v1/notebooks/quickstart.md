# Quickstart

1) Regenerate the seed dataset (synthetic, schema-correct):
```bash
python src/build_dataset.py
```

2) Train a baseline and inspect top features + a small rule tree:
```bash
python src/train_baseline.py
```

3) Replace the synthetic generator with real K3 computations:
- Implement `compute_real_k3_features(...)` in `src/features.py`
- Build rows that match the existing schema (`ALL_FEATURES` + label + provenance)
- Add a **label provenance** record for every row
- Re-run steps (1)-(2) and compare top features/rules

## Family-holdout split (recommended)
In production, split train/test by a **family key** (e.g., construction type or parameter bucket)
before dropping the `family_id` to avoid leakage and ensure cross-family generalization.
