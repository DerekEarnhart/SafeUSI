# WSM Patch (SafeUGoI) — v2
- Offline tokenizer (local path ok)
- Cayley fallback (set `mode: cayley` in config)

Quickstart:
1) `pip install -r requirements_wsm.txt`
2) Distill (offline if teacher is a local dir):
   `python scripts/distill_wsm.py --config configs/wsm_base.yaml --data_dir ./data --out ./wsm_ckpt.pt --teacher ./teacher_gpt2m`
3) Serve:
   `python scripts/serve_wsm.py --ckpt ./wsm_ckpt.pt --port 8080`
