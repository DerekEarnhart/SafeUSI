import os, argparse, yaml, torch
from torch.utils.data import Dataset, DataLoader
from wsmpro.model import WSMForCausalLM
from wsmpro.tokenization import TokenizerWrapper

class TextFolderDataset(Dataset):
    def __init__(self, folder, tok, max_len=512):
        self.tokens = []
        for r,_,fs in os.walk(folder):
            for f in fs:
                if f.lower().endswith(".txt"):
                    with open(os.path.join(r,f),"r",encoding="utf-8",errors="ignore") as fh:
                        self.tokens.extend(tok.encode(fh.read()))
        self.max_len = max_len
        eos = tok.tok.eos_token_id
        if len(self.tokens) < max_len+1:
            self.tokens += [eos]*(max_len+1-len(self.tokens))
    def __len__(self):
        return max(1, len(self.tokens)//self.max_len - 1)
    def __getitem__(self, idx):
        s = idx*self.max_len
        w = self.tokens[s:s+self.max_len+1]
        return torch.tensor(w[:-1]), torch.tensor(w[1:])

def main(cfg, data_dir, out, tokenizer):
    with open(cfg,"r") as fh:
        C = yaml.safe_load(fh)
    m, t = C["model"], C["train"]
    tok = TokenizerWrapper(tokenizer)
    model = WSMForCausalLM(tok.vocab_size, m["hidden"], m["state_n"], m["layers"], m.get("mode","expm"), m.get("non_gauss_scale",0.1))
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    model.to(dev)
    dl = DataLoader(TextFolderDataset(data_dir, tok, t["max_len"]), batch_size=t["batch_size"], shuffle=True, drop_last=True)
    opt = torch.optim.AdamW(model.parameters(), lr=t["lr"], weight_decay=t["weight_decay"])
    for epoch in range(t["epochs"]):
        for i,(x,y) in enumerate(dl,1):
            x,y = x.to(dev), y.to(dev)
            _, loss = model(x, labels=y)
            opt.zero_grad(set_to_none=True); loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), t["grad_clip"])
            opt.step()
            if i%50==0: print(f"epoch {epoch} step {i} loss {loss.item():.4f}")
    out = out or t["save_path"]
    torch.save({"model": model.state_dict(), "tokenizer": tokenizer, "config": m}, out)
    print("saved ->", out)

if __name__=="__main__":
    import yaml
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/pro_base.yaml")
    ap.add_argument("--data_dir", required=True)
    ap.add_argument("--out", default=None)
    ap.add_argument("--tokenizer", default="gpt2")
    a = ap.parse_args()
    main(a.config, a.data_dir, a.out, a.tokenizer)
