class APIGateway:
    """
    Provides external access to system capabilities.
    """
    def serve(self):
        pass
