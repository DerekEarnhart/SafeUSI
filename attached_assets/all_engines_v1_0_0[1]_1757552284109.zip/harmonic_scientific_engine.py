"""
Harmonic Scientific Engine

This module provides an engine for analyzing scientific literature and data
using harmonic algebraic probability principles.
"""

import os
import sys
import json
import logging
import numpy as np
import requests
from datetime import datetime
from typing import Dict, List, Any, Optional, Union, Tuple, Set
import re
import uuid

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from base_engine import BaseEngine

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class HarmonicScientificEngine(BaseEngine):
    """
    Engine for analyzing scientific literature and data using
    harmonic algebraic probability principles.
    """
    
    def __init__(self, 
                 pubmed_api_key: Optional[str] = None,
                 use_hap: bool = True,
                 harmonic_base: float = 1.618,
                 quantum_factor: float = 0.01):
        """
        Initialize the Harmonic Scientific Engine.
        
        Args:
            pubmed_api_key: API key for PubMed access (optional)
            use_hap: Whether to use Harmonic Algebraic Probability
            harmonic_base: Harmonic base parameter (default: phi)
            quantum_factor: Quantum influence factor (0.0 to 1.0)
        """
        super().__init__(
            name="Harmonic Scientific Engine",
            version="1.0.0",
            description="Engine for analyzing scientific literature and data using harmonic principles",
            use_hap=use_hap,
            harmonic_base=harmonic_base,
            quantum_factor=quantum_factor
        )
        
        self.pubmed_api_key = pubmed_api_key
        
        # Initialize data structures
        self.citation_graph = {}  # paper_id -> list of cited paper_ids
        self.research_topics = {}  # topic -> list of paper_ids
        self.analyzed_papers = {}  # paper_id -> analysis results
        
        # Scientific fields and their related concepts
        self.scientific_fields = {
            "physics": ["quantum", "relativity", "particle", "cosmology", "mechanics", "thermodynamics"],
            "biology": ["genetics", "cell", "evolution", "organism", "ecology", "molecular"],
            "chemistry": ["reaction", "molecule", "element", "compound", "organic", "inorganic"],
            "computer_science": ["algorithm", "computation", "data", "intelligence", "network", "software"],
            "mathematics": ["theorem", "proof", "geometry", "algebra", "analysis", "topology"],
            "medicine": ["clinical", "disease", "treatment", "diagnosis", "patient", "therapy"],
            "environmental_science": ["climate", "ecosystem", "pollution", "sustainability", "conservation"],
            "neuroscience": ["brain", "neural", "cognition", "behavior", "neuron", "psychology"]
        }
        
        # Domain-specific analysis methods
        self.domain_analyzers = {
            "physics": self._analyze_physics_paper,
            "biology": self._analyze_biology_paper,
            "chemistry": self._analyze_chemistry_paper,
            "computer_science": self._analyze_computer_science_paper,
            "mathematics": self._analyze_mathematics_paper,
            "medicine": self._analyze_medicine_paper,
            "environmental_science": self._analyze_environmental_paper,
            "neuroscience": self._analyze_neuroscience_paper
        }
        
        # Initialize storage directory
        self.storage_dir = os.path.join(os.getcwd(), 'scientific_data')
        os.makedirs(self.storage_dir, exist_ok=True)
        
        # Update metadata
        self.meta["capabilities"] = self.get_capabilities()
        self.meta["configuration"].update({
            "has_pubmed_api_key": pubmed_api_key is not None
        })
        
        logger.info(f"Initialized {self.name} (PubMed API: {'Yes' if pubmed_api_key else 'No'})")
    
    def get_capabilities(self) -> List[str]:
        """Get a list of capabilities provided by this engine."""
        capabilities = [
            "research_paper_analysis",
            "citation_graph_building",
            "trend_identification",
            "cross_domain_analysis",
            "significance_assessment"
        ]
        
        # Add domain-specific capabilities
        for field in self.scientific_fields:
            capabilities.append(f"{field}_analysis")
        
        return capabilities
    
    def analyze_research_paper(self, 
                              paper_text: str, 
                              metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Analyze a research paper for key findings, methods, and significance.
        
        Args:
            paper_text: Full text of the research paper
            metadata: Additional metadata (title, authors, journal, etc.)
            
        Returns:
            Dictionary with analysis results
        """
        if not paper_text:
            return {"status": "error", "message": "Empty paper text"}
        
        # Generate paper ID if not provided
        paper_id = metadata.get("id") if metadata else str(uuid.uuid4())
        
        # Extract basic metadata if not provided
        if not metadata:
            metadata = self._extract_paper_metadata(paper_text)
        
        # Determine scientific domain
        domain = self._determine_scientific_domain(paper_text, metadata)
        
        # Basic analysis common to all papers
        analysis = {
            "paper_id": paper_id,
            "metadata": metadata,
            "domain": domain,
            "timestamp": datetime.now().isoformat(),
            "structure_analysis": self._analyze_paper_structure(paper_text),
            "key_concepts": self._extract_key_concepts(paper_text, domain),
            "citation_analysis": self._extract_citations(paper_text),
            "statistical_analysis": self._analyze_statistics(paper_text)
        }
        
        # Apply domain-specific analysis if available
        if domain in self.domain_analyzers:
            domain_analysis = self.domain_analyzers[domain](paper_text, metadata)
            analysis["domain_analysis"] = domain_analysis
        
        # Apply HAP-based significance assessment
        if self.hap_processor:
            significance = self._assess_scientific_significance(paper_text, domain, analysis)
            analysis["significance_assessment"] = significance
        
        # Store analysis results
        self.analyzed_papers[paper_id] = analysis
        
        # Update citation graph
        if "references" in analysis["citation_analysis"]:
            self.citation_graph[paper_id] = analysis["citation_analysis"]["references"]
        
        # Update research topics
        topics = analysis["key_concepts"]["topics"]
        for topic in topics:
            if topic not in self.research_topics:
                self.research_topics[topic] = []
            
            if paper_id not in self.research_topics[topic]:
                self.research_topics[topic].append(paper_id)
        
        logger.info(f"Analyzed paper {paper_id} in domain {domain}")
        return analysis
    
    def identify_research_trends(self, 
                                topic: str, 
                                timeframe: str = "5years") -> Dict[str, Any]:
        """
        Identify research trends in a specific topic.
        
        Args:
            topic: Research topic to analyze
            timeframe: Timeframe for trend analysis (e.g., "5years", "decade")
            
        Returns:
            Dictionary with trend analysis results
        """
        # If we have the PubMed API key, fetch recent papers on the topic
        papers = []
        
        if self.pubmed_api_key:
            # Fetch papers from PubMed
            papers = self._fetch_pubmed_papers(topic, timeframe)
        
        # Check for papers in our local database
        local_papers = []
        if topic in self.research_topics:
            local_paper_ids = self.research_topics[topic]
            local_papers = [
                self.analyzed_papers[paper_id] 
                for paper_id in local_paper_ids
                if paper_id in self.analyzed_papers
            ]
        
        # Combine papers from both sources
        all_papers = papers + local_papers
        
        if not all_papers:
            return {
                "status": "warning",
                "message": f"No papers found for topic '{topic}'",
                "topic": topic,
                "timeframe": timeframe,
                "trends": []
            }
        
        # Analyze trends
        trends = self._analyze_research_trends(topic, all_papers, timeframe)
        
        return {
            "status": "success",
            "topic": topic,
            "timeframe": timeframe,
            "paper_count": len(all_papers),
            "trends": trends,
            "analysis_timestamp": datetime.now().isoformat()
        }
    
    def connect_research_findings(self, papers_list: List[str]) -> Dict[str, Any]:
        """
        Connect findings across multiple research papers.
        
        Args:
            papers_list: List of paper IDs to connect
            
        Returns:
            Dictionary with connection analysis
        """
        # Validate paper IDs
        valid_papers = [p for p in papers_list if p in self.analyzed_papers]
        
        if not valid_papers:
            return {
                "status": "error",
                "message": "No valid paper IDs provided",
                "connected_papers": []
            }
        
        # Extract paper analyses
        paper_analyses = [self.analyzed_papers[paper_id] for paper_id in valid_papers]
        
        # Extract key concepts from all papers
        all_concepts = {}
        for analysis in paper_analyses:
            for concept, weight in analysis["key_concepts"].get("concepts", {}).items():
                if concept not in all_concepts:
                    all_concepts[concept] = []
                
                all_concepts[concept].append({
                    "paper_id": analysis["paper_id"],
                    "weight": weight
                })
        
        # Find shared concepts (connections)
        shared_concepts = {
            concept: papers for concept, papers in all_concepts.items()
            if len(papers) > 1  # Concept appears in multiple papers
        }
        
        # Build connection graph
        connection_graph = {}
        for paper_id in valid_papers:
            connection_graph[paper_id] = []
        
        # Add connections based on shared concepts
        for concept, papers in shared_concepts.items():
            paper_ids = [p["paper_id"] for p in papers]
            for i in range(len(paper_ids)):
                for j in range(i + 1, len(paper_ids)):
                    paper1 = paper_ids[i]
                    paper2 = paper_ids[j]
                    
                    # Add connection in both directions
                    if paper2 not in connection_graph.get(paper1, []):
                        if paper1 not in connection_graph:
                            connection_graph[paper1] = []
                        connection_graph[paper1].append({
                            "paper_id": paper2,
                            "shared_concepts": [concept]
                        })
                    else:
                        # Add concept to existing connection
                        for conn in connection_graph[paper1]:
                            if conn["paper_id"] == paper2:
                                if concept not in conn["shared_concepts"]:
                                    conn["shared_concepts"].append(concept)
                    
                    # Add reverse connection
                    if paper1 not in connection_graph.get(paper2, []):
                        if paper2 not in connection_graph:
                            connection_graph[paper2] = []
                        connection_graph[paper2].append({
                            "paper_id": paper1,
                            "shared_concepts": [concept]
                        })
                    else:
                        # Add concept to existing connection
                        for conn in connection_graph[paper2]:
                            if conn["paper_id"] == paper1:
                                if concept not in conn["shared_concepts"]:
                                    conn["shared_concepts"].append(concept)
        
        # Calculate connection strengths
        for paper_id, connections in connection_graph.items():
            for connection in connections:
                # Calculate connection strength based on number of shared concepts
                connection["strength"] = len(connection["shared_concepts"]) / \
                                        len(all_concepts)
        
        # Identify key findings that relate across papers
        key_findings = []
        for analysis in paper_analyses:
            domain_analysis = analysis.get("domain_analysis", {})
            findings = domain_analysis.get("findings", [])
            
            for finding in findings:
                key_findings.append({
                    "paper_id": analysis["paper_id"],
                    "finding": finding
                })
        
        # Generate cross-paper insights
        cross_paper_insights = self._generate_cross_paper_insights(
            valid_papers, connection_graph, shared_concepts
        )
        
        result = {
            "status": "success",
            "papers_analyzed": len(valid_papers),
            "shared_concepts": shared_concepts,
            "connection_graph": connection_graph,
            "key_findings": key_findings,
            "cross_paper_insights": cross_paper_insights,
            "analysis_timestamp": datetime.now().isoformat()
        }
        
        logger.info(f"Connected findings across {len(valid_papers)} papers")
        return result
    
    def process(self, input_data: Dict[str, Any], **kwargs) -> Dict[str, Any]:
        """
        Process input data using the Harmonic Scientific Engine.
        
        Args:
            input_data: Dictionary containing input data
            **kwargs: Additional keyword arguments
            
        Returns:
            Dictionary with processed results
        """
        operation = input_data.get("operation", "analyze_paper")
        
        if operation == "analyze_paper":
            paper_text = input_data.get("paper_text", "")
            metadata = input_data.get("metadata", {})
            
            if not paper_text:
                return {"status": "error", "message": "No paper text provided"}
            
            analysis = self.analyze_research_paper(paper_text, metadata)
            return {
                "status": "success",
                "message": "Paper analyzed successfully",
                "results": analysis
            }
        
        elif operation == "identify_trends":
            topic = input_data.get("topic", "")
            timeframe = input_data.get("timeframe", "5years")
            
            if not topic:
                return {"status": "error", "message": "No topic provided"}
            
            trends = self.identify_research_trends(topic, timeframe)
            return {
                "status": "success",
                "message": f"Identified trends for topic '{topic}'",
                "results": trends
            }
        
        elif operation == "connect_findings":
            papers_list = input_data.get("papers_list", [])
            
            if not papers_list:
                return {"status": "error", "message": "No papers provided"}
            
            connections = self.connect_research_findings(papers_list)
            return {
                "status": "success",
                "message": "Connected findings across papers",
                "results": connections
            }
        
        else:
            return {"status": "error", "message": f"Unknown operation: {operation}"}
    
    def _extract_paper_metadata(self, paper_text: str) -> Dict[str, Any]:
        """Extract basic metadata from paper text."""
        metadata = {
            "title": "",
            "authors": [],
            "publication_date": "",
            "journal": "",
            "abstract": ""
        }
        
        # Extract title (usually at the beginning)
        title_match = re.search(r'^([^\n]+)', paper_text)
        if title_match:
            metadata["title"] = title_match.group(1).strip()
        
        # Extract abstract
        abstract_match = re.search(r'Abstract[.\s]+(.*?)(?:Introduction|$)', 
                                  paper_text, re.DOTALL | re.IGNORECASE)
        if abstract_match:
            metadata["abstract"] = abstract_match.group(1).strip()
        
        # Try to extract authors
        author_match = re.search(r'(?:^|\n)([^0-9]+?)\s*\d+(?:\s*,|\n|$)', paper_text)
        if author_match:
            authors_text = author_match.group(1).strip()
            authors = [a.strip() for a in authors_text.split(',')]
            metadata["authors"] = authors
        
        return metadata
    
    def _determine_scientific_domain(self, 
                                    paper_text: str, 
                                    metadata: Dict[str, Any]) -> str:
        """Determine the primary scientific domain of the paper."""
        # Combine title, abstract, and a sample of the body text
        text_to_analyze = (
            (metadata.get("title", "") + " ") +
            (metadata.get("abstract", "") + " ") +
            paper_text[:5000]  # Sample from the beginning
        ).lower()
        
        # Count keywords for each domain
        domain_scores = {}
        
        for domain, keywords in self.scientific_fields.items():
            score = 0
            for keyword in keywords:
                matches = re.findall(r'\b' + keyword + r'\b', text_to_analyze)
                score += len(matches)
            
            domain_scores[domain] = score
        
        # Find domain with highest score
        max_score = 0
        max_domain = "general"
        
        for domain, score in domain_scores.items():
            if score > max_score:
                max_score = score
                max_domain = domain
        
        return max_domain
    
    def _analyze_paper_structure(self, paper_text: str) -> Dict[str, Any]:
        """Analyze the structure of the paper."""
        # Identify sections
        sections = []
        section_pattern = r'(?:^|\n)(?:[0-9]+\.\s+)?([A-Z][A-Za-z\s]+)(?:\n|$)'
        
        for match in re.finditer(section_pattern, paper_text):
            section_title = match.group(1).strip()
            sections.append(section_title)
        
        # Count figures and tables
        figure_count = len(re.findall(r'(?:Figure|Fig\.)\s+\d+', paper_text, re.IGNORECASE))
        table_count = len(re.findall(r'Table\s+\d+', paper_text, re.IGNORECASE))
        
        # Analyze section distribution
        total_length = len(paper_text)
        section_proportions = {}
        
        if sections:
            prev_section_end = 0
            for i, section in enumerate(sections):
                section_start = paper_text.find(section, prev_section_end)
                
                if section_start == -1:
                    continue
                
                # Find next section start or end of text
                if i < len(sections) - 1:
                    next_section = sections[i + 1]
                    next_section_start = paper_text.find(next_section, section_start + len(section))
                    if next_section_start == -1:
                        next_section_start = total_length
                else:
                    next_section_start = total_length
                
                section_length = next_section_start - section_start
                section_proportion = section_length / total_length
                
                section_proportions[section] = section_proportion
                prev_section_end = next_section_start
        
        # Detect if paper appears to be a preprint or peer-reviewed
        has_peer_review_indicators = any(s.lower() in paper_text.lower() for s in 
                                       ["peer-reviewed", "journal of", "proceedings of"])
        
        return {
            "sections": sections,
            "section_proportions": section_proportions,
            "figure_count": figure_count,
            "table_count": table_count,
            "total_length": total_length,
            "appears_peer_reviewed": has_peer_review_indicators
        }
    
    def _extract_key_concepts(self, paper_text: str, domain: str) -> Dict[str, Any]:
        """Extract key concepts and topics from the paper."""
        # Extract domain-specific keywords
        domain_keywords = self.scientific_fields.get(domain, [])
        domain_keyword_counts = {}
        
        for keyword in domain_keywords:
            matches = re.findall(r'\b' + keyword + r'\b', paper_text.lower())
            if matches:
                domain_keyword_counts[keyword] = len(matches)
        
        # Identify additional key terms
        # This is a simplified approach - in a real implementation, we'd use NLP
        words = re.findall(r'\b[A-Za-z]{4,}\b', paper_text.lower())
        word_counts = {}
        
        for word in words:
            if word not in ["this", "that", "with", "from", "have", "were", "what"]:
                word_counts[word] = word_counts.get(word, 0) + 1
        
        # Filter to most frequent words
        sorted_words = sorted(word_counts.items(), key=lambda x: x[1], reverse=True)
        key_terms = {word: count for word, count in sorted_words[:20]}
        
        # Extract key phrases using simple patterns
        key_phrases = []
        
        # Look for phrases like "we propose", "we demonstrate", "our method", etc.
        phrase_patterns = [
            r'we propose ([^\.]+)',
            r'we demonstrate ([^\.]+)',
            r'our (?:method|approach|model|system) ([^\.]+)',
            r'results show ([^\.]+)',
            r'conclude that ([^\.]+)'
        ]
        
        for pattern in phrase_patterns:
            matches = re.finditer(pattern, paper_text.lower())
            for match in matches:
                key_phrases.append(match.group(1).strip())
        
        # Determine main topics
        topics = []
        for word, count in sorted_words[:5]:
            if len(word) > 4 and count > 5 and word not in topics:
                topics.append(word)
        
        # Add domain as a topic
        if domain not in topics:
            topics.append(domain)
        
        # Create weighted concept dictionary
        concepts = {}
        total_occurrences = sum(domain_keyword_counts.values()) + sum(key_terms.values())
        
        if total_occurrences > 0:
            # Add domain keywords with weights
            for keyword, count in domain_keyword_counts.items():
                concepts[keyword] = count / total_occurrences
            
            # Add other key terms with weights
            for term, count in key_terms.items():
                if term not in concepts:
                    concepts[term] = count / total_occurrences
        
        return {
            "domain_keywords": domain_keyword_counts,
            "key_terms": key_terms,
            "concepts": concepts,
            "key_phrases": key_phrases,
            "topics": topics
        }
    
    def _extract_citations(self, paper_text: str) -> Dict[str, Any]:
        """Extract and analyze citations."""
        # Look for citation patterns
        citation_patterns = [
            r'\[(\d+(?:,\s*\d+)*)\]',  # [1] or [1, 2, 3]
            r'\(([^)]+?(?:et al\.)?[^)]*?,\s*\d{4}[a-z]?(?:;\s*[^)]+?(?:et al\.)?[^)]*?,\s*\d{4}[a-z]?)*)\)'  # (Author et al., 2020) or (Author, 2020; Author2, 2019)
        ]
        
        citations = []
        for pattern in citation_patterns:
            matches = re.finditer(pattern, paper_text)
            for match in matches:
                citations.append(match.group(0))
        
        # Extract references list
        references = []
        references_section = re.search(r'(?:References|Bibliography)(?:\n|\s|$)(.*?)(?:\n\s*?(?:[A-Z][a-z]+ ){2,}|\Z)', 
                                      paper_text, re.DOTALL | re.IGNORECASE)
        
        if references_section:
            ref_text = references_section.group(1)
            # Split references by line or numbered entries
            ref_entries = re.split(r'\n\s*\n|\n\s*\[\d+\]|\n\s*\d+\.', ref_text)
            
            for entry in ref_entries:
                entry = entry.strip()
                if entry:
                    references.append(entry)
        
        # Analyze citation distribution
        total_citations = len(citations)
        citation_density = total_citations / (len(paper_text) / 1000)  # Citations per 1000 chars
        
        return {
            "citation_count": total_citations,
            "citation_density": citation_density,
            "references": references,
            "references_count": len(references)
        }
    
    def _analyze_statistics(self, paper_text: str) -> Dict[str, Any]:
        """Analyze statistical content in the paper."""
        # Look for common statistical indicators
        p_values = re.findall(r'p\s*(?:<|>|=)\s*0\.\d+', paper_text)
        t_stats = re.findall(r't\s*(?:<|>|=)\s*\d+\.\d+', paper_text)
        conf_intervals = re.findall(r'95%\s*CI\s*[:=]\s*\[?[-+]?\d+\.\d+\s*(?:,|to)\s*[-+]?\d+\.\d+\]?', paper_text)
        
        # Check for specific statistical tests
        tests = {
            "t_test": len(re.findall(r't-test', paper_text, re.IGNORECASE)),
            "chi_square": len(re.findall(r'chi[- ]square', paper_text, re.IGNORECASE)),
            "anova": len(re.findall(r'ANOVA', paper_text)),
            "regression": len(re.findall(r'regression', paper_text, re.IGNORECASE)),
            "bayes": len(re.findall(r'bayes(?:ian)?', paper_text, re.IGNORECASE)),
            "machine_learning": len(re.findall(r'machine learning|neural network|deep learning', paper_text, re.IGNORECASE))
        }
        
        # Extract numerical data
        numbers = re.findall(r'\b\d+\.\d+\b', paper_text)
        numerical_values = [float(n) for n in numbers]
        
        # Basic statistics on numerical values
        numerical_stats = {}
        if numerical_values:
            numerical_stats = {
                "count": len(numerical_values),
                "mean": np.mean(numerical_values),
                "median": np.median(numerical_values),
                "min": min(numerical_values),
                "max": max(numerical_values)
            }
        
        return {
            "statistical_tests": tests,
            "p_values_count": len(p_values),
            "t_statistics_count": len(t_stats),
            "confidence_intervals_count": len(conf_intervals),
            "numerical_statistics": numerical_stats,
            "has_significance_testing": len(p_values) > 0 or len(t_stats) > 0
        }
    
    def _assess_scientific_significance(self, 
                                       paper_text: str, 
                                       domain: str,
                                       analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Assess scientific significance using HAP principles."""
        # Extract key signals for significance assessment
        
        # 1. Novelty signal (based on phrases indicating new findings)
        novelty_phrases = ["novel", "first time", "new method", "previously unknown", "unexplored"]
        novelty_signal = sum(paper_text.lower().count(phrase) for phrase in novelty_phrases)
        
        # 2. Impact signal (based on phrases suggesting importance)
        impact_phrases = ["significant", "important", "breakthrough", "fundamental", "paradigm shift"]
        impact_signal = sum(paper_text.lower().count(phrase) for phrase in impact_phrases)
        
        # 3. Evidence signal (based on statistical content)
        statistical_analysis = analysis.get("statistical_analysis", {})
        evidence_signal = (
            statistical_analysis.get("p_values_count", 0) +
            statistical_analysis.get("t_statistics_count", 0) * 2 +
            statistical_analysis.get("confidence_intervals_count", 0) * 3
        )
        
        # 4. Methodology signal (based on methodology descriptions)
        methodology_phrases = ["methodology", "experiment", "procedure", "protocol", "analysis"]
        methodology_signal = sum(paper_text.lower().count(phrase) for phrase in methodology_phrases)
        
        # Normalize signals
        paper_length = len(paper_text)
        if paper_length > 0:
            length_factor = min(1.0, 10000 / paper_length)  # Normalize to typical paper
            
            novelty_signal = novelty_signal * length_factor
            impact_signal = impact_signal * length_factor
            evidence_signal = evidence_signal * length_factor
            methodology_signal = methodology_signal * length_factor
        
        # Apply harmonic principles to combine signals
        if self.hap_processor:
            # Map signals to harmonic space using golden ratio relationships
            phi = (1 + np.sqrt(5)) / 2
            
            harmonic_weights = {
                "novelty": 1.0,
                "impact": 1.0 / phi,
                "evidence": 1.0 / (phi ** 2),
                "methodology": 1.0 / (phi ** 3)
            }
            
            # Normalize weights
            weight_sum = sum(harmonic_weights.values())
            harmonic_weights = {k: v / weight_sum for k, v in harmonic_weights.items()}
            
            # Apply harmonic weights
            significance_score = (
                novelty_signal * harmonic_weights["novelty"] +
                impact_signal * harmonic_weights["impact"] +
                evidence_signal * harmonic_weights["evidence"] +
                methodology_signal * harmonic_weights["methodology"]
            )
            
            # Apply domain-specific modulation based on harmonic base
            domain_modulation = 0.5 + 0.5 * np.sin(self.harmonic_base * domain_weights.get(domain, 0.5))
            significance_score *= domain_modulation
            
            # Apply quantum factor for small variations
            quantum_adjustment = np.random.random() * self.quantum_factor
            significance_score = significance_score * (1 - self.quantum_factor) + quantum_adjustment
            
            # Normalize to [0, 1] range
            significance_score = min(1.0, significance_score / 10.0)  # Assume 10 is max reasonable score
        else:
            # Simple averaging
            signals = [novelty_signal, impact_signal, evidence_signal, methodology_signal]
            significance_score = sum(signals) / (len(signals) * 5.0)  # Assume 5 per signal is a strong paper
            significance_score = min(1.0, significance_score)
        
        # Generate significance assessment
        assessment = {
            "overall_score": float(significance_score),
            "component_scores": {
                "novelty": float(min(1.0, novelty_signal / 5.0)),
                "impact": float(min(1.0, impact_signal / 5.0)),
                "evidence": float(min(1.0, evidence_signal / 10.0)),
                "methodology": float(min(1.0, methodology_signal / 10.0))
            },
            "significance_category": self._get_significance_category(significance_score)
        }
        
        return assessment
    
    def _get_significance_category(self, score: float) -> str:
        """Map significance score to category."""
        if score >= 0.8:
            return "groundbreaking"
        elif score >= 0.6:
            return "significant"
        elif score >= 0.4:
            return "notable"
        elif score >= 0.2:
            return "incremental"
        else:
            return "minor"
    
    def _analyze_physics_paper(self, paper_text: str, metadata: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze a physics paper."""
        # Detect physics subfields
        subfields = {
            "quantum_physics": len(re.findall(r'quantum|qubit|superposition|entanglement', paper_text, re.IGNORECASE)),
            "relativity": len(re.findall(r'relativity|spacetime|gravity|graviton', paper_text, re.IGNORECASE)),
            "particle_physics": len(re.findall(r'particle|hadron|lepton|boson|fermion', paper_text, re.IGNORECASE)),
            "astrophysics": len(re.findall(r'star|galaxy|cosmos|universe|black hole', paper_text, re.IGNORECASE)),
            "condensed_matter": len(re.findall(r'solid state|phase transition|superconductor', paper_text, re.IGNORECASE))
        }
        
        # Find primary subfield
        primary_subfield = max(subfields.items(), key=lambda x: x[1])[0] if subfields else "general_physics"
        
        # Extract equations
        equations = re.findall(r'\\begin{equation}.*?\\end{equation}', paper_text, re.DOTALL)
        if not equations:
            # Try alternative pattern
            equations = re.findall(r'\$\$(.*?)\$\$', paper_text, re.DOTALL)
        
        # Extract key findings
        findings = self._extract_key_findings(paper_text, "physics")
        
        return {
            "subfield": primary_subfield,
            "subfield_scores": subfields,
            "equation_count": len(equations),
            "findings": findings
        }
    
    def _analyze_biology_paper(self, paper_text: str, metadata: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze a biology paper."""
        # Detect biology subfields
        subfields = {
            "molecular_biology": len(re.findall(r'molecular|dna|rna|protein|gene|genome', paper_text, re.IGNORECASE)),
            "ecology": len(re.findall(r'ecosystem|species|environment|habitat|population', paper_text, re.IGNORECASE)),
            "evolutionary_biology": len(re.findall(r'evolution|selection|adaptation|phylogeny', paper_text, re.IGNORECASE)),
            "microbiology": len(re.findall(r'microbe|bacteria|virus|fungus|pathogen', paper_text, re.IGNORECASE)),
            "neurobiology": len(re.findall(r'neuron|brain|neural|synapse|cognition', paper_text, re.IGNORECASE))
        }
        
        # Find primary subfield
        primary_subfield = max(subfields.items(), key=lambda x: x[1])[0] if subfields else "general_biology"
        
        # Check for experimental design
        has_experimental = len(re.findall(r'experiment|control group|sample|specimen', paper_text, re.IGNORECASE)) > 0
        
        # Extract key findings
        findings = self._extract_key_findings(paper_text, "biology")
        
        return {
            "subfield": primary_subfield,
            "subfield_scores": subfields,
            "has_experimental_design": has_experimental,
            "findings": findings
        }
    
    def _analyze_chemistry_paper(self, paper_text: str, metadata: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze a chemistry paper."""
        # Simple implementation
        return {"subfield": "general_chemistry", "findings": self._extract_key_findings(paper_text, "chemistry")}
    
    def _analyze_computer_science_paper(self, paper_text: str, metadata: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze a computer science paper."""
        # Simple implementation
        return {"subfield": "general_cs", "findings": self._extract_key_findings(paper_text, "computer_science")}
    
    def _analyze_mathematics_paper(self, paper_text: str, metadata: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze a mathematics paper."""
        # Simple implementation
        return {"subfield": "general_mathematics", "findings": self._extract_key_findings(paper_text, "mathematics")}
    
    def _analyze_medicine_paper(self, paper_text: str, metadata: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze a medicine paper."""
        # Simple implementation
        return {"subfield": "general_medicine", "findings": self._extract_key_findings(paper_text, "medicine")}
    
    def _analyze_environmental_paper(self, paper_text: str, metadata: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze an environmental science paper."""
        # Simple implementation
        return {"subfield": "general_environmental", "findings": self._extract_key_findings(paper_text, "environmental_science")}
    
    def _analyze_neuroscience_paper(self, paper_text: str, metadata: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze a neuroscience paper."""
        # Simple implementation
        return {"subfield": "general_neuroscience", "findings": self._extract_key_findings(paper_text, "neuroscience")}
    
    def _extract_key_findings(self, paper_text: str, domain: str) -> List[str]:
        """Extract key findings from the paper."""
        findings = []
        
        # Look for finding patterns
        finding_patterns = [
            r'we (?:found|discover(?:ed)?|observ(?:ed)?) that ([^\.]+)',
            r'results (?:show|indicate|demonstrate|suggest) that ([^\.]+)',
            r'(?:key|main|important) finding(?:s)? (?:is|are|was|were) that ([^\.]+)',
            r'we (?:show|demonstrate|prove) that ([^\.]+)',
            r'(?:conclusion|conclusions) [^\.]+? that ([^\.]+)'
        ]
        
        for pattern in finding_patterns:
            matches = re.finditer(pattern, paper_text, re.IGNORECASE)
            for match in matches:
                finding = match.group(1).strip()
                if finding and finding not in findings:
                    findings.append(finding)
        
        # If no findings found, extract from abstract
        if not findings:
            abstract_match = re.search(r'Abstract[.\s]+(.*?)(?:Introduction|$)', 
                                      paper_text, re.DOTALL | re.IGNORECASE)
            if abstract_match:
                abstract = abstract_match.group(1).strip()
                
                # Extract last sentence of abstract as finding
                sentences = abstract.split('.')
                if sentences and len(sentences) > 1:
                    last_sentence = sentences[-2].strip()  # -2 because the last element might be empty
                    if last_sentence:
                        findings.append(last_sentence)
        
        return findings[:5]  # Limit to top 5 findings
    
    def _fetch_pubmed_papers(self, topic: str, timeframe: str) -> List[Dict[str, Any]]:
        """Fetch papers from PubMed."""
        # This is a placeholder implementation
        # In a real implementation, we would use the PubMed API
        return []
    
    def _analyze_research_trends(self, 
                                topic: str, 
                                papers: List[Dict[str, Any]], 
                                timeframe: str) -> List[Dict[str, Any]]:
        """Analyze research trends from papers."""
        # This is a simplified implementation
        # In a real implementation, we would perform more sophisticated analysis
        
        # Extract key concepts across papers
        all_concepts = {}
        for paper in papers:
            if "key_concepts" in paper:
                for concept, weight in paper["key_concepts"].get("concepts", {}).items():
                    if concept not in all_concepts:
                        all_concepts[concept] = []
                    
                    all_concepts[concept].append({
                        "paper_id": paper.get("paper_id", ""),
                        "weight": weight
                    })
        
        # Find most common concepts
        concept_counts = {concept: len(papers) for concept, papers in all_concepts.items()}
        top_concepts = sorted(concept_counts.items(), key=lambda x: x[1], reverse=True)[:10]
        
        # Generate trend descriptions
        trends = []
        for concept, count in top_concepts:
            trends.append({
                "trend": f"Research on {concept}",
                "paper_count": count,
                "strength": count / len(papers)
            })
        
        return trends
    
    def _generate_cross_paper_insights(self, 
                                     papers: List[str], 
                                     connection_graph: Dict[str, List[Dict[str, Any]]],
                                     shared_concepts: Dict[str, List[Dict[str, Any]]]) -> List[str]:
        """Generate insights across papers."""
        insights = []
        
        # Check for strongly connected papers
        strong_connections = []
        for paper_id, connections in connection_graph.items():
            strong = [c for c in connections if c["strength"] > 0.3]
            if strong:
                strong_connections.append({
                    "paper_id": paper_id,
                    "strong_connections": len(strong)
                })
        
        # Generate insights based on connection patterns
        if strong_connections:
            most_connected = max(strong_connections, key=lambda x: x["strong_connections"])
            insights.append(
                f"Paper {most_connected['paper_id']} forms a central hub with "
                f"{most_connected['strong_connections']} strong connections to other papers."
            )
        
        # Generate insights based on shared concepts
        if shared_concepts:
            most_shared = max(shared_concepts.items(), key=lambda x: len(x[1]))
            insights.append(
                f"The concept '{most_shared[0]}' appears in {len(most_shared[1])} papers, "
                f"suggesting it's a central theme in this research area."
            )
        
        # Generic insight if nothing specific found
        if not insights:
            insights.append(
                f"These {len(papers)} papers share limited conceptual overlap, "
                f"suggesting they may represent diverse approaches within the field."
            )
        
        return insights

# Initialize domain weights
domain_weights = {
    "physics": 0.9,
    "biology": 0.7,
    "chemistry": 0.8,
    "computer_science": 0.75,
    "mathematics": 0.95,
    "medicine": 0.6,
    "environmental_science": 0.5,
    "neuroscience": 0.65
}