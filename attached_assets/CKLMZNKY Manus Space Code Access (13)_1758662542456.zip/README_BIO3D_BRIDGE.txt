README_BIO3D_BRIDGE.txt

BIO ↔ 3D Visualizer Bridge — Multi-Entity + Auth + Organs/Systems
==================================================================

What’s new in v0.2.0
--------------------
- **Multi-entity** out of the box (`bio1`, `bio2`, and you can add more).
- **Optional auth token**: set `BRIDGE_TOKEN` to require `Authorization: Bearer` on REST and `?token=` on WS.
- **Richer schema**: `metrics`, `systems` (cardio/immune/neural), `organs` array with relative positions.
- **Delete-missing** (client opt-in) to remove entities locally when they vanish from the server.

Quick run
---------
Backend:
```bash
export BRIDGE_TOKEN="test123"     # optional, for dev
pip install fastapi uvicorn[standard]
uvicorn bio_bridge_server:app --reload --host 0.0.0.0 --port 8000
```

Frontend (HU3DPE):
```html
<script src="https://unpkg.com/three@0.160.0/build/three.min.js"></script>
<script src="/path/to/hu3dpe_client_bridge.js"></script>
<script>
  const bridge = new HU3DPEBridge({
    wsUrl: "ws://localhost:8000/ws/state?token=test123", // or apiUrl: "http://localhost:8000/api/state"
    authToken: "test123",
    deleteMissing: false
  });
  bridge.attach(visualizerInstance);
</script>
```

API examples
------------
Create entity:
```bash
curl -H "Authorization: Bearer test123" -X POST localhost:8000/api/entity \
  -H "Content-Type: application/json" \
  -d '{"id":"bio3"}'
```

Tune neurotransmitters:
```bash
curl -H "Authorization: Bearer test123" -X POST \
  "localhost:8000/api/tune?id=bio3&dopamine=0.85&serotonin=0.8&cortisol=0.2"
```

Delete entity:
```bash
curl -H "Authorization: Bearer test123" -X DELETE "localhost:8000/api/entity?id=bio3"
```

Schema:
```bash
curl localhost:8000/api/schema
```

Notes
-----
- WebSocket auth is via query param: `ws://.../ws/state?token=YOUR_TOKEN` (browser WS can’t set headers).
- The client bridge will draw small **organ nodes** as child spheres; customize in `_upsertEntity` if desired.
- All units and behaviors are **simulated**. This is a **Simulation-Only** bridge; no device control or real-world instructions.

Safety
------
Use with your guardrail pipeline (input pre-filter, system prompt, output post-filter). Consider
adding a visible “Simulation-Only” badge and watermarking output panels.

License & attribution
---------------------
Use freely. Please keep headers and this README for attribution.
