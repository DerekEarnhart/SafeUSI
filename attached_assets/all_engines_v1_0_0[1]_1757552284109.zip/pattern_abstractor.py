"""
Pattern Abstractor for ARC Benchmark

This module provides specialized pattern abstraction capabilities for solving 
ARC (Abstraction and Reasoning Corpus) tasks. It leverages the HAP AGI system's
harmonic rings and quantum state representations to identify abstract patterns
and transformations in ARC grids.
"""

import numpy as np
import logging
import os
import json
from typing import Dict, List, Tuple, Any, Optional, Union
import time
import traceback

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    filename='pattern_abstractor.log'
)
logger = logging.getLogger(__name__)

# Import HAP system components if available
try:
    from harmonic_algebraic_probability import HarmonicAlgebraicProbability
    from harmonic_consciousness_engine import HarmonicConsciousnessEngine
    from sentinel_memory_graph import SentinelMemoryGraph
    from system_aggregator import SystemAggregator
    hap_available = True
except ImportError:
    logger.warning("HAP components not fully available. Running in limited mode.")
    hap_available = False


class GridPattern:
    """Class representing a pattern identified in an ARC grid."""
    
    def __init__(self, pattern_type: str, properties: Dict[str, Any]):
        """
        Initialize a grid pattern.
        
        Args:
            pattern_type: Type of pattern (e.g., 'shape', 'color_transform', 'symmetry')
            properties: Dictionary of pattern properties
        """
        self.pattern_type = pattern_type
        self.properties = properties
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert pattern to dictionary for serialization."""
        return {
            'pattern_type': self.pattern_type,
            'properties': self.properties
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'GridPattern':
        """Create a pattern from a dictionary."""
        return cls(data['pattern_type'], data['properties'])


class Transformation:
    """Class representing a transformation between input and output grids."""
    
    def __init__(self, 
                 transform_type: str,
                 properties: Dict[str, Any],
                 input_patterns: List[GridPattern] = None,
                 output_patterns: List[GridPattern] = None):
        """
        Initialize a transformation.
        
        Args:
            transform_type: Type of transformation
            properties: Dictionary of transformation properties
            input_patterns: Patterns identified in the input grid
            output_patterns: Patterns identified in the output grid
        """
        self.transform_type = transform_type
        self.properties = properties
        self.input_patterns = input_patterns or []
        self.output_patterns = output_patterns or []
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert transformation to dictionary for serialization."""
        return {
            'transform_type': self.transform_type,
            'properties': self.properties,
            'input_patterns': [p.to_dict() for p in self.input_patterns],
            'output_patterns': [p.to_dict() for p in self.output_patterns]
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Transformation':
        """Create a transformation from a dictionary."""
        input_patterns = [GridPattern.from_dict(p) for p in data.get('input_patterns', [])]
        output_patterns = [GridPattern.from_dict(p) for p in data.get('output_patterns', [])]
        
        return cls(
            data['transform_type'],
            data['properties'],
            input_patterns,
            output_patterns
        )


class Rule:
    """Class representing a rule that can be applied to an input grid."""
    
    def __init__(self, 
                 rule_type: str,
                 conditions: List[Dict[str, Any]],
                 actions: List[Dict[str, Any]],
                 confidence: float = 0.0):
        """
        Initialize a rule.
        
        Args:
            rule_type: Type of rule
            conditions: List of conditions that must be met for the rule to apply
            actions: List of actions to perform when the rule applies
            confidence: Confidence level in the rule (0.0 to 1.0)
        """
        self.rule_type = rule_type
        self.conditions = conditions
        self.actions = actions
        self.confidence = confidence
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert rule to dictionary for serialization."""
        return {
            'rule_type': self.rule_type,
            'conditions': self.conditions,
            'actions': self.actions,
            'confidence': self.confidence
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Rule':
        """Create a rule from a dictionary."""
        return cls(
            data['rule_type'],
            data['conditions'],
            data['actions'],
            data.get('confidence', 0.0)
        )
    
    def applies_to(self, grid: np.ndarray, metadata: Dict[str, Any] = None) -> bool:
        """
        Check if the rule applies to a given grid.
        
        Args:
            grid: Input grid
            metadata: Additional metadata about the grid
        
        Returns:
            True if the rule applies, False otherwise
        """
        # This would be implemented with the actual logic for checking conditions
        # For now, return a placeholder value
        return True
    
    def apply(self, grid: np.ndarray, metadata: Dict[str, Any] = None) -> np.ndarray:
        """
        Apply the rule to a grid.
        
        Args:
            grid: Input grid
            metadata: Additional metadata about the grid
        
        Returns:
            Transformed grid
        """
        # This would be implemented with the actual logic for applying actions
        # For now, return a copy of the input grid
        return grid.copy()


class PatternAbstractor:
    """
    Pattern Abstractor for ARC tasks.
    
    This class provides functionality for identifying abstract patterns in ARC grids
    and learning transformations between input and output examples.
    """
    
    def __init__(self, use_hap: bool = True, persistence_dir: str = './pattern_memory'):
        """
        Initialize the Pattern Abstractor.
        
        Args:
            use_hap: Whether to use HAP components if available
            persistence_dir: Directory for persisting learned patterns
        """
        self.use_hap = use_hap and hap_available
        self.persistence_dir = persistence_dir
        
        # Initialize HAP components if available and requested
        self.hap = None
        self.consciousness_engine = None
        self.memory_graph = None
        
        if self.use_hap:
            try:
                self.system_aggregator = SystemAggregator()
                self.hap = self.system_aggregator.get_component('hap')
                self.consciousness_engine = self.system_aggregator.get_component('consciousness')
                self.memory_graph = self.system_aggregator.get_component('memory')
                logger.info("HAP components initialized successfully")
            except Exception as e:
                logger.error(f"Failed to initialize HAP components: {str(e)}")
                logger.debug(traceback.format_exc())
                self.use_hap = False
        
        # Pattern library
        self.patterns = {}
        self.transformations = {}
        self.rules = {}
        
        # Create persistence directory if it doesn't exist
        os.makedirs(self.persistence_dir, exist_ok=True)
        
        # Load existing patterns
        self._load_patterns()
    
    def _load_patterns(self) -> None:
        """Load existing patterns from persistence directory."""
        try:
            # Load patterns
            patterns_file = os.path.join(self.persistence_dir, 'patterns.json')
            if os.path.exists(patterns_file):
                with open(patterns_file, 'r') as f:
                    patterns_data = json.load(f)
                
                for pattern_id, pattern_data in patterns_data.items():
                    self.patterns[pattern_id] = GridPattern.from_dict(pattern_data)
            
            # Load transformations
            transformations_file = os.path.join(self.persistence_dir, 'transformations.json')
            if os.path.exists(transformations_file):
                with open(transformations_file, 'r') as f:
                    transformations_data = json.load(f)
                
                for transform_id, transform_data in transformations_data.items():
                    self.transformations[transform_id] = Transformation.from_dict(transform_data)
            
            # Load rules
            rules_file = os.path.join(self.persistence_dir, 'rules.json')
            if os.path.exists(rules_file):
                with open(rules_file, 'r') as f:
                    rules_data = json.load(f)
                
                for rule_id, rule_data in rules_data.items():
                    self.rules[rule_id] = Rule.from_dict(rule_data)
            
            logger.info(f"Loaded {len(self.patterns)} patterns, {len(self.transformations)} transformations, and {len(self.rules)} rules")
        
        except Exception as e:
            logger.error(f"Failed to load patterns: {str(e)}")
            logger.debug(traceback.format_exc())
    
    def _save_patterns(self) -> None:
        """Save patterns to persistence directory."""
        try:
            # Save patterns
            patterns_data = {pattern_id: pattern.to_dict() for pattern_id, pattern in self.patterns.items()}
            patterns_file = os.path.join(self.persistence_dir, 'patterns.json')
            with open(patterns_file, 'w') as f:
                json.dump(patterns_data, f, indent=2)
            
            # Save transformations
            transformations_data = {transform_id: transform.to_dict() for transform_id, transform in self.transformations.items()}
            transformations_file = os.path.join(self.persistence_dir, 'transformations.json')
            with open(transformations_file, 'w') as f:
                json.dump(transformations_data, f, indent=2)
            
            # Save rules
            rules_data = {rule_id: rule.to_dict() for rule_id, rule in self.rules.items()}
            rules_file = os.path.join(self.persistence_dir, 'rules.json')
            with open(rules_file, 'w') as f:
                json.dump(rules_data, f, indent=2)
            
            logger.info(f"Saved {len(self.patterns)} patterns, {len(self.transformations)} transformations, and {len(self.rules)} rules")
        
        except Exception as e:
            logger.error(f"Failed to save patterns: {str(e)}")
            logger.debug(traceback.format_exc())
    
    def identify_patterns(self, grid: np.ndarray) -> List[GridPattern]:
        """
        Identify patterns in a grid.
        
        Args:
            grid: Input grid
        
        Returns:
            List of identified patterns
        """
        identified_patterns = []
        
        try:
            # Basic pattern detection
            patterns = self._detect_basic_patterns(grid)
            identified_patterns.extend(patterns)
            
            # Use HAP for advanced pattern detection if available
            if self.use_hap and self.hap is not None:
                hap_patterns = self._detect_hap_patterns(grid)
                identified_patterns.extend(hap_patterns)
            
            # Use consciousness engine for higher-level abstractions if available
            if self.use_hap and self.consciousness_engine is not None:
                consciousness_patterns = self._detect_consciousness_patterns(grid)
                identified_patterns.extend(consciousness_patterns)
            
            # Check memory for similar patterns if available
            if self.use_hap and self.memory_graph is not None:
                memory_patterns = self._retrieve_similar_patterns(grid)
                identified_patterns.extend(memory_patterns)
            
            logger.info(f"Identified {len(identified_patterns)} patterns in grid")
            
        except Exception as e:
            logger.error(f"Error identifying patterns: {str(e)}")
            logger.debug(traceback.format_exc())
        
        return identified_patterns
    
    def _detect_basic_patterns(self, grid: np.ndarray) -> List[GridPattern]:
        """
        Detect basic patterns in a grid.
        
        Args:
            grid: Input grid
        
        Returns:
            List of basic patterns
        """
        patterns = []
        
        # Check for shapes
        shapes = self._detect_shapes(grid)
        patterns.extend(shapes)
        
        # Check for symmetry
        symmetry = self._detect_symmetry(grid)
        if symmetry:
            patterns.append(symmetry)
        
        # Check for color patterns
        color_patterns = self._detect_color_patterns(grid)
        patterns.extend(color_patterns)
        
        return patterns
    
    def _detect_shapes(self, grid: np.ndarray) -> List[GridPattern]:
        """
        Detect shapes in a grid.
        
        Args:
            grid: Input grid
        
        Returns:
            List of shape patterns
        """
        shapes = []
        
        # This would be implemented with the actual logic for detecting shapes
        # For demonstration, we'll detect a simple rectangle pattern
        
        # Get unique values (ignoring background which is assumed to be 0)
        unique_values = np.unique(grid)
        for val in unique_values:
            if val == 0:  # Skip background
                continue
            
            # Create a binary mask for this value
            mask = (grid == val)
            
            # Check if it forms a rectangle
            if self._is_rectangle(mask):
                # Get the rectangle properties
                min_row, min_col, max_row, max_col = self._get_bounding_box(mask)
                width = max_col - min_col + 1
                height = max_row - min_row + 1
                
                pattern = GridPattern(
                    'shape_rectangle',
                    {
                        'value': int(val),
                        'position': (int(min_row), int(min_col)),
                        'width': int(width),
                        'height': int(height),
                        'area': int(width * height),
                        'filled': bool(np.all(grid[min_row:max_row+1, min_col:max_col+1] == val))
                    }
                )
                shapes.append(pattern)
        
        return shapes
    
    def _is_rectangle(self, mask: np.ndarray) -> bool:
        """
        Check if a binary mask forms a rectangle.
        
        Args:
            mask: Binary mask
        
        Returns:
            True if the mask forms a rectangle, False otherwise
        """
        if not np.any(mask):
            return False
        
        # Get the bounding box
        min_row, min_col, max_row, max_col = self._get_bounding_box(mask)
        
        # Check if all cells within the bounding box are True
        return np.all(mask[min_row:max_row+1, min_col:max_col+1])
    
    def _get_bounding_box(self, mask: np.ndarray) -> Tuple[int, int, int, int]:
        """
        Get the bounding box of a binary mask.
        
        Args:
            mask: Binary mask
        
        Returns:
            Tuple of (min_row, min_col, max_row, max_col)
        """
        rows = np.any(mask, axis=1)
        cols = np.any(mask, axis=0)
        
        min_row, max_row = np.where(rows)[0][[0, -1]]
        min_col, max_col = np.where(cols)[0][[0, -1]]
        
        return min_row, min_col, max_row, max_col
    
    def _detect_symmetry(self, grid: np.ndarray) -> Optional[GridPattern]:
        """
        Detect symmetry in a grid.
        
        Args:
            grid: Input grid
        
        Returns:
            Symmetry pattern if detected, None otherwise
        """
        # Check for horizontal symmetry
        horizontal_symmetry = True
        rows, cols = grid.shape
        for r in range(rows):
            for c in range(cols // 2):
                if grid[r, c] != grid[r, cols - 1 - c]:
                    horizontal_symmetry = False
                    break
            if not horizontal_symmetry:
                break
        
        # Check for vertical symmetry
        vertical_symmetry = True
        for c in range(cols):
            for r in range(rows // 2):
                if grid[r, c] != grid[rows - 1 - r, c]:
                    vertical_symmetry = False
                    break
            if not vertical_symmetry:
                break
        
        # Check for diagonal symmetry (top-left to bottom-right)
        diagonal_symmetry_1 = False
        if rows == cols:  # Must be square for diagonal symmetry
            diagonal_symmetry_1 = True
            for r in range(rows):
                for c in range(r + 1, cols):
                    if grid[r, c] != grid[c, r]:
                        diagonal_symmetry_1 = False
                        break
                if not diagonal_symmetry_1:
                    break
        
        # Check for diagonal symmetry (top-right to bottom-left)
        diagonal_symmetry_2 = False
        if rows == cols:  # Must be square for diagonal symmetry
            diagonal_symmetry_2 = True
            for r in range(rows):
                for c in range(cols):
                    if r + c != rows - 1:
                        continue
                    if grid[r, c] != grid[rows - 1 - c, cols - 1 - r]:
                        diagonal_symmetry_2 = False
                        break
                if not diagonal_symmetry_2:
                    break
        
        if horizontal_symmetry or vertical_symmetry or diagonal_symmetry_1 or diagonal_symmetry_2:
            return GridPattern(
                'symmetry',
                {
                    'horizontal': horizontal_symmetry,
                    'vertical': vertical_symmetry,
                    'diagonal_1': diagonal_symmetry_1,
                    'diagonal_2': diagonal_symmetry_2
                }
            )
        
        return None
    
    def _detect_color_patterns(self, grid: np.ndarray) -> List[GridPattern]:
        """
        Detect color patterns in a grid.
        
        Args:
            grid: Input grid
        
        Returns:
            List of color patterns
        """
        patterns = []
        
        # Get the unique values and their counts
        unique, counts = np.unique(grid, return_counts=True)
        
        # Add a pattern for each color's distribution
        for val, count in zip(unique, counts):
            pattern = GridPattern(
                'color_distribution',
                {
                    'value': int(val),
                    'count': int(count),
                    'frequency': float(count) / grid.size
                }
            )
            patterns.append(pattern)
        
        return patterns
    
    def _detect_hap_patterns(self, grid: np.ndarray) -> List[GridPattern]:
        """
        Detect patterns using HAP.
        
        Args:
            grid: Input grid
        
        Returns:
            List of HAP-detected patterns
        """
        patterns = []
        
        # This would be implemented with the actual logic for detecting patterns using HAP
        # For now, return an empty list
        
        return patterns
    
    def _detect_consciousness_patterns(self, grid: np.ndarray) -> List[GridPattern]:
        """
        Detect patterns using the consciousness engine.
        
        Args:
            grid: Input grid
        
        Returns:
            List of consciousness-detected patterns
        """
        patterns = []
        
        # This would be implemented with the actual logic for detecting patterns using the consciousness engine
        # For now, return an empty list
        
        return patterns
    
    def _retrieve_similar_patterns(self, grid: np.ndarray) -> List[GridPattern]:
        """
        Retrieve similar patterns from memory.
        
        Args:
            grid: Input grid
        
        Returns:
            List of similar patterns
        """
        patterns = []
        
        # This would be implemented with the actual logic for retrieving similar patterns from memory
        # For now, return an empty list
        
        return patterns
    
    def learn_transformation(self, 
                            input_grid: np.ndarray, 
                            output_grid: np.ndarray) -> Optional[Transformation]:
        """
        Learn a transformation between input and output grids.
        
        Args:
            input_grid: Input grid
            output_grid: Output grid
        
        Returns:
            Learned transformation if successful, None otherwise
        """
        try:
            # Identify patterns in input and output grids
            input_patterns = self.identify_patterns(input_grid)
            output_patterns = self.identify_patterns(output_grid)
            
            # Analyze the transformation
            transform = self._analyze_transformation(input_grid, output_grid, input_patterns, output_patterns)
            
            if transform:
                # Generate a unique ID for the transformation
                transform_id = f"transform_{len(self.transformations) + 1}"
                
                # Store the transformation
                self.transformations[transform_id] = transform
                
                # Save patterns to persistent storage
                self._save_patterns()
                
                logger.info(f"Learned transformation {transform_id}: {transform.transform_type}")
                
                return transform
            else:
                logger.warning("Failed to learn transformation")
                return None
            
        except Exception as e:
            logger.error(f"Error learning transformation: {str(e)}")
            logger.debug(traceback.format_exc())
            return None
    
    def _analyze_transformation(self, 
                               input_grid: np.ndarray, 
                               output_grid: np.ndarray,
                               input_patterns: List[GridPattern],
                               output_patterns: List[GridPattern]) -> Optional[Transformation]:
        """
        Analyze the transformation between input and output grids.
        
        Args:
            input_grid: Input grid
            output_grid: Output grid
            input_patterns: Patterns in the input grid
            output_patterns: Patterns in the output grid
        
        Returns:
            Analyzed transformation if successful, None otherwise
        """
        # Check for common transformations
        
        # Check for value mapping (e.g., 1 -> 2)
        value_mapping = self._detect_value_mapping(input_grid, output_grid)
        if value_mapping:
            return Transformation(
                'value_mapping',
                {'mapping': value_mapping},
                input_patterns,
                output_patterns
            )
        
        # Check for scaling
        scaling = self._detect_scaling(input_grid, output_grid)
        if scaling:
            return Transformation(
                'scaling',
                {'factor': scaling},
                input_patterns,
                output_patterns
            )
        
        # Check for rotation
        rotation = self._detect_rotation(input_grid, output_grid)
        if rotation:
            return Transformation(
                'rotation',
                {'angle': rotation},
                input_patterns,
                output_patterns
            )
        
        # Check for reflection
        reflection = self._detect_reflection(input_grid, output_grid)
        if reflection:
            return Transformation(
                'reflection',
                {'axis': reflection},
                input_patterns,
                output_patterns
            )
        
        # Use HAP for complex transformation analysis if available
        if self.use_hap and self.hap is not None:
            hap_transform = self._analyze_hap_transformation(input_grid, output_grid)
            if hap_transform:
                return Transformation(
                    'hap_transform',
                    hap_transform,
                    input_patterns,
                    output_patterns
                )
        
        # If we couldn't identify a specific transformation, store a generic one
        return Transformation(
            'unknown',
            {
                'input_shape': input_grid.shape,
                'output_shape': output_grid.shape
            },
            input_patterns,
            output_patterns
        )
    
    def _detect_value_mapping(self, input_grid: np.ndarray, output_grid: np.ndarray) -> Optional[Dict[int, int]]:
        """
        Detect value mapping between input and output grids.
        
        Args:
            input_grid: Input grid
            output_grid: Output grid
        
        Returns:
            Dictionary mapping input values to output values if detected, None otherwise
        """
        # Check if shapes match
        if input_grid.shape != output_grid.shape:
            return None
        
        # Try to determine a consistent value mapping
        mapping = {}
        for i in range(input_grid.shape[0]):
            for j in range(input_grid.shape[1]):
                in_val = int(input_grid[i, j])
                out_val = int(output_grid[i, j])
                
                if in_val in mapping and mapping[in_val] != out_val:
                    # Inconsistent mapping
                    return None
                
                mapping[in_val] = out_val
        
        # Check if at least one value changes
        if all(k == v for k, v in mapping.items()):
            return None
        
        return mapping
    
    def _detect_scaling(self, input_grid: np.ndarray, output_grid: np.ndarray) -> Optional[float]:
        """
        Detect scaling between input and output grids.
        
        Args:
            input_grid: Input grid
            output_grid: Output grid
        
        Returns:
            Scaling factor if detected, None otherwise
        """
        # Check if output is a scaled version of input
        in_rows, in_cols = input_grid.shape
        out_rows, out_cols = output_grid.shape
        
        # Check if dimensions are multiples of each other
        if out_rows % in_rows == 0 and out_cols % in_cols == 0:
            row_factor = out_rows // in_rows
            col_factor = out_cols // in_cols
            
            if row_factor == col_factor:
                # Check if the content is scaled properly
                for i in range(in_rows):
                    for j in range(in_cols):
                        val = input_grid[i, j]
                        block = output_grid[i*row_factor:(i+1)*row_factor, j*col_factor:(j+1)*col_factor]
                        
                        if not np.all(block == val):
                            return None
                
                return row_factor
        
        return None
    
    def _detect_rotation(self, input_grid: np.ndarray, output_grid: np.ndarray) -> Optional[int]:
        """
        Detect rotation between input and output grids.
        
        Args:
            input_grid: Input grid
            output_grid: Output grid
        
        Returns:
            Rotation angle in degrees if detected, None otherwise
        """
        # Check for 90-degree rotation
        rotated_90 = np.rot90(input_grid)
        if rotated_90.shape == output_grid.shape and np.array_equal(rotated_90, output_grid):
            return 90
        
        # Check for 180-degree rotation
        rotated_180 = np.rot90(input_grid, 2)
        if rotated_180.shape == output_grid.shape and np.array_equal(rotated_180, output_grid):
            return 180
        
        # Check for 270-degree rotation
        rotated_270 = np.rot90(input_grid, 3)
        if rotated_270.shape == output_grid.shape and np.array_equal(rotated_270, output_grid):
            return 270
        
        return None
    
    def _detect_reflection(self, input_grid: np.ndarray, output_grid: np.ndarray) -> Optional[str]:
        """
        Detect reflection between input and output grids.
        
        Args:
            input_grid: Input grid
            output_grid: Output grid
        
        Returns:
            Reflection axis if detected, None otherwise
        """
        # Check for horizontal reflection
        reflected_h = np.flipud(input_grid)
        if reflected_h.shape == output_grid.shape and np.array_equal(reflected_h, output_grid):
            return 'horizontal'
        
        # Check for vertical reflection
        reflected_v = np.fliplr(input_grid)
        if reflected_v.shape == output_grid.shape and np.array_equal(reflected_v, output_grid):
            return 'vertical'
        
        return None
    
    def _analyze_hap_transformation(self, input_grid: np.ndarray, output_grid: np.ndarray) -> Optional[Dict[str, Any]]:
        """
        Analyze transformation using HAP.
        
        Args:
            input_grid: Input grid
            output_grid: Output grid
        
        Returns:
            Dictionary of HAP transformation properties if detected, None otherwise
        """
        # This would be implemented with the actual logic for analyzing transformations using HAP
        # For now, return None
        
        return None
    
    def derive_rule(self, 
                   input_grids: List[np.ndarray],
                   output_grids: List[np.ndarray]) -> Optional[Rule]:
        """
        Derive a rule from multiple input/output examples.
        
        Args:
            input_grids: List of input grids
            output_grids: List of output grids
        
        Returns:
            Derived rule if successful, None otherwise
        """
        try:
            if len(input_grids) != len(output_grids) or len(input_grids) == 0:
                return None
            
            # Learn transformations for each example
            transformations = []
            for i in range(len(input_grids)):
                transform = self.learn_transformation(input_grids[i], output_grids[i])
                if transform:
                    transformations.append(transform)
            
            if not transformations:
                return None
            
            # Analyze transformations to derive a common rule
            rule = self._analyze_transformations(transformations)
            
            if rule:
                # Generate a unique ID for the rule
                rule_id = f"rule_{len(self.rules) + 1}"
                
                # Store the rule
                self.rules[rule_id] = rule
                
                # Save patterns to persistent storage
                self._save_patterns()
                
                logger.info(f"Derived rule {rule_id}: {rule.rule_type}")
                
                return rule
            else:
                logger.warning("Failed to derive rule")
                return None
            
        except Exception as e:
            logger.error(f"Error deriving rule: {str(e)}")
            logger.debug(traceback.format_exc())
            return None
    
    def _analyze_transformations(self, transformations: List[Transformation]) -> Optional[Rule]:
        """
        Analyze transformations to derive a common rule.
        
        Args:
            transformations: List of transformations
        
        Returns:
            Derived rule if successful, None otherwise
        """
        if not transformations:
            return None
        
        # Check if all transformations are of the same type
        transform_types = set(t.transform_type for t in transformations)
        if len(transform_types) == 1:
            transform_type = list(transform_types)[0]
            
            # Handle different transformation types
            if transform_type == 'value_mapping':
                return self._derive_value_mapping_rule(transformations)
            elif transform_type == 'scaling':
                return self._derive_scaling_rule(transformations)
            elif transform_type == 'rotation':
                return self._derive_rotation_rule(transformations)
            elif transform_type == 'reflection':
                return self._derive_reflection_rule(transformations)
            elif transform_type == 'hap_transform':
                return self._derive_hap_rule(transformations)
        
        # If we couldn't derive a specific rule, create a generic one
        return Rule(
            'generic',
            [{"type": "any"}],
            [{"type": "apply_best_matching_transform", "transformations": [t.to_dict() for t in transformations]}],
            0.5
        )
    
    def _derive_value_mapping_rule(self, transformations: List[Transformation]) -> Optional[Rule]:
        """
        Derive a rule from value mapping transformations.
        
        Args:
            transformations: List of value mapping transformations
        
        Returns:
            Derived rule if successful, None otherwise
        """
        # Check if all transformations have the same mapping
        mappings = [t.properties.get('mapping', {}) for t in transformations]
        if not mappings or not all(m == mappings[0] for m in mappings):
            return None
        
        mapping = mappings[0]
        
        return Rule(
            'value_mapping',
            [{"type": "always"}],
            [{"type": "map_values", "mapping": mapping}],
            1.0
        )
    
    def _derive_scaling_rule(self, transformations: List[Transformation]) -> Optional[Rule]:
        """
        Derive a rule from scaling transformations.
        
        Args:
            transformations: List of scaling transformations
        
        Returns:
            Derived rule if successful, None otherwise
        """
        # Check if all transformations have the same scaling factor
        factors = [t.properties.get('factor', 0) for t in transformations]
        if not factors or not all(f == factors[0] for f in factors):
            return None
        
        factor = factors[0]
        
        return Rule(
            'scaling',
            [{"type": "always"}],
            [{"type": "scale", "factor": factor}],
            1.0
        )
    
    def _derive_rotation_rule(self, transformations: List[Transformation]) -> Optional[Rule]:
        """
        Derive a rule from rotation transformations.
        
        Args:
            transformations: List of rotation transformations
        
        Returns:
            Derived rule if successful, None otherwise
        """
        # Check if all transformations have the same rotation angle
        angles = [t.properties.get('angle', 0) for t in transformations]
        if not angles or not all(a == angles[0] for a in angles):
            return None
        
        angle = angles[0]
        
        return Rule(
            'rotation',
            [{"type": "always"}],
            [{"type": "rotate", "angle": angle}],
            1.0
        )
    
    def _derive_reflection_rule(self, transformations: List[Transformation]) -> Optional[Rule]:
        """
        Derive a rule from reflection transformations.
        
        Args:
            transformations: List of reflection transformations
        
        Returns:
            Derived rule if successful, None otherwise
        """
        # Check if all transformations have the same reflection axis
        axes = [t.properties.get('axis', '') for t in transformations]
        if not axes or not all(a == axes[0] for a in axes):
            return None
        
        axis = axes[0]
        
        return Rule(
            'reflection',
            [{"type": "always"}],
            [{"type": "reflect", "axis": axis}],
            1.0
        )
    
    def _derive_hap_rule(self, transformations: List[Transformation]) -> Optional[Rule]:
        """
        Derive a rule from HAP transformations.
        
        Args:
            transformations: List of HAP transformations
        
        Returns:
            Derived rule if successful, None otherwise
        """
        # This would be implemented with the actual logic for deriving rules from HAP transformations
        # For now, return None
        
        return None
    
    def apply_rule(self, rule: Rule, grid: np.ndarray) -> np.ndarray:
        """
        Apply a rule to an input grid.
        
        Args:
            rule: Rule to apply
            grid: Input grid
        
        Returns:
            Transformed grid
        """
        try:
            # Check if the rule applies to the grid
            if not rule.applies_to(grid):
                logger.warning(f"Rule {rule.rule_type} does not apply to the grid")
                return grid.copy()
            
            # Apply the rule
            result = rule.apply(grid)
            
            logger.info(f"Applied rule {rule.rule_type} to grid")
            
            return result
            
        except Exception as e:
            logger.error(f"Error applying rule: {str(e)}")
            logger.debug(traceback.format_exc())
            return grid.copy()
    
    def solve_task(self, train_inputs: List[np.ndarray], train_outputs: List[np.ndarray], test_input: np.ndarray) -> np.ndarray:
        """
        Solve an ARC task.
        
        Args:
            train_inputs: List of training input grids
            train_outputs: List of training output grids
            test_input: Test input grid
        
        Returns:
            Predicted output grid for the test input
        """
        try:
            # Derive rule from training examples
            rule = self.derive_rule(train_inputs, train_outputs)
            
            if rule:
                # Apply the rule to the test input
                prediction = self.apply_rule(rule, test_input)
                
                logger.info(f"Solved task using rule {rule.rule_type}")
                
                return prediction
            else:
                # If we couldn't derive a rule, try to find the most similar training example
                most_similar_idx = self._find_most_similar_example(test_input, train_inputs)
                
                if most_similar_idx is not None:
                    # Learn transformation from the most similar example
                    transform = self.learn_transformation(train_inputs[most_similar_idx], train_outputs[most_similar_idx])
                    
                    if transform:
                        # Apply the transformation to the test input
                        prediction = self._apply_transformation(transform, test_input)
                        
                        logger.info(f"Solved task using transformation {transform.transform_type}")
                        
                        return prediction
                
                logger.warning("Failed to solve task")
                return test_input.copy()
            
        except Exception as e:
            logger.error(f"Error solving task: {str(e)}")
            logger.debug(traceback.format_exc())
            return test_input.copy()
    
    def _find_most_similar_example(self, grid: np.ndarray, examples: List[np.ndarray]) -> Optional[int]:
        """
        Find the most similar example to a grid.
        
        Args:
            grid: Input grid
            examples: List of example grids
        
        Returns:
            Index of the most similar example if found, None otherwise
        """
        if not examples:
            return None
        
        # This would be implemented with the actual logic for finding the most similar example
        # For now, return the first example
        
        return 0
    
    def _apply_transformation(self, transform: Transformation, grid: np.ndarray) -> np.ndarray:
        """
        Apply a transformation to a grid.
        
        Args:
            transform: Transformation to apply
            grid: Input grid
        
        Returns:
            Transformed grid
        """
        result = grid.copy()
        
        # Apply the transformation based on its type
        if transform.transform_type == 'value_mapping':
            mapping = transform.properties.get('mapping', {})
            for i in range(grid.shape[0]):
                for j in range(grid.shape[1]):
                    val = int(grid[i, j])
                    if val in mapping:
                        result[i, j] = mapping[val]
        
        elif transform.transform_type == 'scaling':
            factor = transform.properties.get('factor', 1)
            if factor > 1:
                rows, cols = grid.shape
                result = np.zeros((rows * factor, cols * factor), dtype=grid.dtype)
                
                for i in range(rows):
                    for j in range(cols):
                        result[i*factor:(i+1)*factor, j*factor:(j+1)*factor] = grid[i, j]
        
        elif transform.transform_type == 'rotation':
            angle = transform.properties.get('angle', 0)
            rotations = angle // 90
            result = np.rot90(grid, rotations)
        
        elif transform.transform_type == 'reflection':
            axis = transform.properties.get('axis', '')
            if axis == 'horizontal':
                result = np.flipud(grid)
            elif axis == 'vertical':
                result = np.fliplr(grid)
        
        elif transform.transform_type == 'hap_transform':
            # This would be implemented with the actual logic for applying HAP transformations
            pass
        
        return result


# Example usage
if __name__ == "__main__":
    # Simple grid for testing
    grid1 = np.array([
        [0, 0, 0, 0, 0],
        [0, 1, 1, 1, 0],
        [0, 1, 0, 1, 0],
        [0, 1, 1, 1, 0],
        [0, 0, 0, 0, 0]
    ])
    
    grid2 = np.array([
        [0, 0, 0, 0, 0],
        [0, 2, 2, 2, 0],
        [0, 2, 0, 2, 0],
        [0, 2, 2, 2, 0],
        [0, 0, 0, 0, 0]
    ])
    
    # Create and initialize pattern abstractor
    abstractor = PatternAbstractor(use_hap=False)  # Don't use HAP for this simple test
    
    # Identify patterns
    patterns = abstractor.identify_patterns(grid1)
    print(f"Identified {len(patterns)} patterns")
    
    # Learn transformation
    transform = abstractor.learn_transformation(grid1, grid2)
    if transform:
        print(f"Learned transformation: {transform.transform_type}")
        print(f"Properties: {transform.properties}")
    else:
        print("Failed to learn transformation")
    
    # Derive rule from examples
    rule = abstractor.derive_rule([grid1], [grid2])
    if rule:
        print(f"Derived rule: {rule.rule_type}")
        
        # Apply rule to a new input
        grid3 = np.array([
            [0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0],
            [0, 0, 1, 1, 1, 0, 0],
            [0, 0, 1, 0, 1, 0, 0],
            [0, 0, 1, 1, 1, 0, 0],
            [0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0]
        ])
        
        result = abstractor.apply_rule(rule, grid3)
        print(f"Applied rule to new input. Result shape: {result.shape}")
    else:
        print("Failed to derive rule")