import numpy as np
from numpy.fft import rfft, rfftfreq

class HarmonicSignalAnalyzer:
    """FFT/PSD, autocorrelation, and a coarse 'intelligence' heuristic."""
    def __init__(self, sample_rate: float = 1.0):
        self.fs = sample_rate

    def spectrum(self, x: np.ndarray):
        x = np.asarray(x, dtype=float)
        X = rfft(x - np.mean(x))
        P = (np.abs(X)**2) / max(len(x), 1)
        f = rfftfreq(len(x), d=1.0/self.fs)
        return f, P

    def autocorr(self, x: np.ndarray):
        x = np.asarray(x, dtype=float) - np.mean(x)
        ac = np.correlate(x, x, mode="full")
        ac = ac[ac.size//2:]
        return ac / (ac[0] if ac[0] else 1.0)

    def spectral_entropy(self, P: np.ndarray, eps: float = 1e-12):
        p = P / (np.sum(P) + eps)
        h = -np.sum(p * np.log2(p + eps))
        h_max = np.log2(len(P) + eps)
        return float(1.0 - h / (h_max + eps))  # 0=random, 1=peaky

    def intelligence_score(self, x: np.ndarray):
        f, P = self.spectrum(x)
        ent = self.spectral_entropy(P)
        ac = self.autocorr(x)
        ac_peaks = np.max(ac[1:10]) if len(ac) > 10 else (np.max(ac[1:]) if len(ac)>1 else 0.0)
        score = 0.6*ent + 0.4*float(ac_peaks)
        return float(np.clip(score, 0.0, 1.0)), {"entropy": ent, "ac_peak": float(ac_peaks)}
