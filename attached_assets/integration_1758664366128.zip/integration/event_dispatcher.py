class EventDispatcher:
    """
    Routes events between components.
    """
    def dispatch(self, event):
        pass
