import math

PHI = (1 + math.sqrt(5)) / 2


