
from typing import Union, Optional
import os

def load_tokenizer(tokenizer_path_or_id: str = "./assets/tokenizer"):
    """A simple wrapper to defer to Hugging Face if available, or a local dir.
    This function avoids hard import errors by importing transformers lazily.
    """
    if os.path.isdir(tokenizer_path_or_id):
        try:
            from transformers import PreTrainedTokenizerFast
            return PreTrainedTokenizerFast.from_pretrained(tokenizer_path_or_id)
        except Exception as e:
            raise RuntimeError(f"Failed to load local tokenizer at {tokenizer_path_or_id}: {e}")
    else:
        try:
            from transformers import AutoTokenizer
            return AutoTokenizer.from_pretrained(tokenizer_path_or_id, use_fast=True)
        except Exception as e:
            raise RuntimeError(f"Failed to load HF tokenizer {tokenizer_path_or_id}: {e}")
