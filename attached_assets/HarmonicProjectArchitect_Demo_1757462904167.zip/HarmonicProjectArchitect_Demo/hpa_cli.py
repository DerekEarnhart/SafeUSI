#!/usr/bin/env python3
"""
Harmonic Project Architect CLI (simplified demo)
- Takes a natural-language prompt and produces:
  1) A structured "Spec"
  2) Ingests it into the local nullstate_service to get a CID
  3) Synthesizes a micro_benchmark.py file from a template
  4) Writes metric weights
  5) Packages everything into HPA_Project_<CID>.zip
Standard library only.
"""
import argparse
import datetime as _dt
import json
import os
import pathlib
import re
import sys
import urllib.request
import zipfile

THIS_DIR = pathlib.Path(__file__).resolve().parent
TPL_DIR = THIS_DIR / "project_templates"

def slugify(text: str, maxlen=50):
    text = re.sub(r"[^a-zA-Z0-9_-]+", "-", text.strip().lower())
    text = re.sub(r"-+", "-", text).strip("-")
    return (text[:maxlen] or "project").strip("-")

def make_spec(nl_prompt: str) -> dict:
    now = _dt.datetime.utcnow().isoformat() + "Z"
    name = f"HPA_{slugify(nl_prompt, 32)}"
    spec = {
        "version": "0.1",
        "created_at": now,
        "name": name,
        "description": nl_prompt,
        "goals": [
            "Generate a Python micro-benchmark script for sorting performance",
            "Be reproducible and easy to run",
            "Report timing statistics across array sizes and algorithms"
        ],
        "constraints": [
            "Use Python standard library only",
            "CLI should run on CPython 3.9+",
            "Deterministic output files from this spec"
        ],
        "artifacts": [
            "micro_benchmark.py",
            "metric_weights_normalized.json",
            "spec.json",
            "README_RUN.md"
        ],
        "metrics": {
            "weights_file": "metric_weights_normalized.json",
            "notes": "Weights are placeholders for future quality scoring."
        }
    }
    return spec

def post_ingest(spec: dict, host: str, port: int) -> dict:
    url = f"http://{host}:{port}/ingest"
    data = json.dumps({"spec": spec}).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=10) as resp:
        return json.loads(resp.read().decode("utf-8"))

def read_template() -> str:
    # Load template contents; if not present, fallback to embedded minimal template
    tpl_path = TPL_DIR / "micro_benchmark_template.py"
    if tpl_path.exists():
        return tpl_path.read_text(encoding="utf-8")
    # Fallback tiny template
    return """#!/usr/bin/env python3
print('template missing – hello world')
"""

def write_micro_benchmark(out_dir: pathlib.Path, spec: dict):
    code = read_template()
    code = code.replace("{{SPEC_NAME}}", spec["name"])
    (out_dir / "micro_benchmark.py").write_text(code, encoding="utf-8")

def write_metric_weights(out_dir: pathlib.Path):
    weights = {
        "readability": 0.25,
        "performance": 0.25,
        "reliability": 0.20,
        "reproducibility": 0.15,
        "maintainability": 0.15
    }
    (out_dir / "metric_weights_normalized.json").write_text(json.dumps(weights, indent=2), encoding="utf-8")

def write_spec(out_dir: pathlib.Path, spec: dict, cid: str):
    spec2 = dict(spec)
    spec2["cid"] = cid
    (out_dir / "spec.json").write_text(json.dumps(spec2, indent=2), encoding="utf-8")

def write_readme_run(out_dir: pathlib.Path, cid: str):
    txt = f"""# HPA Run Instructions (CID: {cid})

## 1) Run the micro benchmark

```bash
python micro_benchmark.py --sizes 5000 10000 20000 --runs 3
```

## 2) View spec + weights

```bash
cat spec.json
cat metric_weights_normalized.json
```
"""
    (out_dir / "README_RUN.md").write_text(txt, encoding="utf-8")

def package_zip(out_dir: pathlib.Path, cid: str) -> pathlib.Path:
    zip_path = out_dir.parent / f"HPA_Project_{cid}.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for p in out_dir.rglob("*"):
            if p.is_file():
                z.write(p, p.relative_to(out_dir.parent))
    return zip_path

def main():
    ap = argparse.ArgumentParser(description="Harmonic Project Architect CLI (demo)")
    ap.add_argument("prompt", help="Natural-language project description")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8000)
    ap.add_argument("--out", default="build", help="Output directory for generated project")
    args = ap.parse_args()

    spec = make_spec(args.prompt)
    print("[hpa] spec built:", spec["name"])

    try:
        resp = post_ingest(spec, args.host, args.port)
    except Exception as e:
        print(f"[hpa] error contacting nullstate_service at {args.host}:{args.port} -> {e}", file=sys.stderr)
        print("[hpa] You can start it with: python nullstate_service.py --serve --port 8000", file=sys.stderr)
        sys.exit(2)

    cid = resp.get("cid", "unknown")
    print("[hpa] received CID:", cid)

    out_root = pathlib.Path(args.out).resolve()
    project_dir = out_root / f"HPA_Project_{cid}"
    project_dir.mkdir(parents=True, exist_ok=True)

    write_micro_benchmark(project_dir, spec)
    write_metric_weights(project_dir)
    write_spec(project_dir, spec, cid)
    write_readme_run(project_dir, cid)

    zip_path = package_zip(project_dir, cid)
    print("[hpa] packaged ->", zip_path)
    print("[hpa] done.")

if __name__ == "__main__":
    main()
