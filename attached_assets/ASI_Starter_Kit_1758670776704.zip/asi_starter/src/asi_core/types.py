from typing import Any, Dict, List, Optional, TypedDict

class Message(TypedDict):
    role: str
    content: str

class InvocationResult(TypedDict, total=False):
    output: Any
    logs: str
    usage: Dict[str, Any]
    error: Optional[str]
