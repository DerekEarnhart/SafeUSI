import React, { useState } from 'react';
import axios from 'axios';
import './App.css';
import AgenticPhysicsSandbox from './AgenticPhysicsSandbox.tsx';
import InfiniteWorld from './components/InfiniteWorld';
import Bio3DBridge from './components/Bio3DBridge';

function App() {
  const [message, setMessage] = useState('');
  const [apiKey, setApiKey] = useState('');
  const [chatHistory, setChatHistory] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const API_BASE_URL = 'http://localhost:8000';

  const sendMessage = async () => {
    if (!message.trim()) return;
    
    if (!apiKey.trim()) {
      setError('Please enter your OpenAI API key first');
      return;
    }

    setIsLoading(true);
    setError('');

    const userMessage = { role: 'user', content: message, timestamp: new Date() };
    setChatHistory(prev => [...prev, userMessage]);

    try {
      const response = await axios.post(`${API_BASE_URL}/chat`, {
        message: message,
        api_key: apiKey
      });

      const assistantMessage = { 
        role: 'assistant', 
        content: response.data.response, 
        timestamp: new Date() 
      };
      
      setChatHistory(prev => [...prev, assistantMessage]);
      setMessage('');
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to send message');
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const setupApiKey = async () => {
    if (!apiKey.trim()) {
      setError('Please enter your API key');
      return;
    }

    try {
      await axios.post(`${API_BASE_URL}/setup`, { api_key: apiKey });
      setError('');
    } catch (err) {
      setError('Failed to setup API key');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-gray-800 mb-2">ProactiveV02</h1>
            <p className="text-gray-600">AI Chat Interface with Flexible API Key Management</p>
          </div>

          {/* API Key Setup */}
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <h2 className="text-xl font-semibold mb-4">API Key Configuration</h2>
            <div className="flex gap-4">
              <input
                type="password"
                placeholder="Enter your OpenAI API key"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <button
                onClick={setupApiKey}
                className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                Setup Key
              </button>
            </div>
            <p className="text-sm text-gray-500 mt-2">
              Your API key is stored locally and sent with each request for security.
            </p>
          </div>

          {/* Agentic Physics Sandbox */}
          {/* <div style={{ width: '100%', height: '600px', position: 'relative' }}>
            <AgenticPhysicsSandbox />
          </div> */}

          {/* Infinite World */}
          <InfiniteWorld />

          {/* Bio3D Bridge */}
          <Bio3DBridge />

          {/* Error Display */}
          {error && (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
              {error}
            </div>
          )}

          {/* Chat Interface */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            {/* Chat History */}
            <div className="h-96 overflow-y-auto p-6 space-y-4">
              {chatHistory.length === 0 ? (
                <div className="text-center text-gray-500">
                  <p>Start a conversation by typing a message below</p>
                </div>
              ) : (
                chatHistory.map((msg, index) => (
                  <div
                    key={index}
                    className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                        msg.role === 'user'
                          ? 'bg-blue-600 text-white'
                          : 'bg-gray-200 text-gray-800'
                      }`}
                    >
                      <p className="whitespace-pre-wrap">{msg.content}</p>
                      <p className="text-xs opacity-70 mt-1">
                        {msg.timestamp.toLocaleTimeString()}
                      </p>
                    </div>
                  </div>
                ))
              )}
              {isLoading && (
                <div className="flex justify-start">
                  <div className="bg-gray-200 text-gray-800 px-4 py-2 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-600"></div>
                      <span>Thinking...</span>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Message Input */}
            <div className="border-t p-4">
              <div className="flex gap-4">
                <textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Type your message here..."
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                  rows="3"
                  disabled={isLoading}
                />
                <button
                  onClick={sendMessage}
                  disabled={isLoading || !message.trim()}
                  className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isLoading ? 'Sending...' : 'Send'}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
