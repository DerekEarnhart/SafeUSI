
from collections import defaultdict
import numpy as np

class PatternEngine:
    def __init__(self, data):
        self.data = data

    def extract_naming_patterns(self):
        patterns = defaultdict(list)
        for key in self.data:
            if key.startswith("CY"):
                patterns["Calabi-Yau"].append(key)
            elif key.startswith("K3"):
                patterns["K3 type"].append(key)
            elif "toric" in key.lower():
                patterns["Toric"].append(key)
            elif "elliptic" in key.lower():
                patterns["Elliptic"].append(key)
        return dict(patterns)

    def find_structural_patterns(self):
        patterns = []
        mirror_candidates = []
        keys = list(self.data.keys())
        for i, key1 in enumerate(keys):
            for key2 in keys[i+1:]:
                var1 = self.data[key1]
                var2 = self.data[key2]
                if var1.get('dimension') != var2.get('dimension'):
                    continue
                h1 = var1.get('hodge_numbers', [])
                h2 = var2.get('hodge_numbers', [])
                if len(h1) == len(h2):
                    n = len(h1) - 1
                    is_mirror = True
                    for p in range(n + 1):
                        for q in range(n + 1):
                            if h1[p][q] != h2[n-p][n-q]:
                                is_mirror = False
                                break
                    if is_mirror:
                        mirror_candidates.append((key1, key2))
        if mirror_candidates:
            patterns.append({"type": "mirror_symmetry", "pairs": mirror_candidates})
        return patterns

    def anomaly_detection(self):
        anomalies = []
        for key, var in self.data.items():
            hodge = var.get('hodge_numbers', [])
            if len(hodge) > 0 and hodge[0][0] != 1:
                anomalies.append({
                    "type": "unexpected_h00",
                    "variety": key,
                    "value": hodge[0][0],
                    "expected": 1
                })
            n = len(hodge) - 1 if hodge else 0
            for p in range(n + 1):
                for q in range(n + 1):
                    if p < len(hodge) and q < len(hodge[p]) and p != q:
                        if hodge[p][q] != hodge[q][p]:
                            anomalies.append({
                                "type": "symmetry_violation",
                                "variety": key,
                                "position": (p, q),
                                "values": (hodge[p][q], hodge[q][p])
                            })
        return anomalies
