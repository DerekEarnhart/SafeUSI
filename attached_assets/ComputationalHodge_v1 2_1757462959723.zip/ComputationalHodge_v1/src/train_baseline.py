
import os, json
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier, export_text
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score, accuracy_score

DATA = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "hodge_seed.csv")

KEYS_DROP = ["label_is_algebraic", "seed", "label_provenance_json", "family_id"]  # drop family_id to avoid leakage

def permutation_importance(model, X, y, metric=roc_auc_score, repeats=3, random_state=0):
    rng = np.random.RandomState(random_state)
    baseline = metric(y, model.predict_proba(X)[:,1])
    importances = []
    for j in range(X.shape[1]):
        scores = []
        Xj = X.copy()
        col = Xj[:, j].copy()
        for _ in range(repeats):
            rng.shuffle(Xj[:, j])
            s = metric(y, model.predict_proba(Xj)[:,1])
            scores.append(baseline - s)
            Xj[:, j] = col
        importances.append(np.mean(scores))
    return np.array(importances)

if __name__ == "__main__":
    df = pd.read_csv(DATA)
    y = df["label_is_algebraic"].values.astype(int)
    X = df.drop(columns=KEYS_DROP, errors="ignore")
    feature_names = X.columns.tolist()
    X = X.values.astype(float)

    # family-holdout simulation: simple split (for real use, split by family_id before dropping it)
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)

    rf = RandomForestClassifier(n_estimators=400, max_depth=None, random_state=0, class_weight="balanced_subsample")
    rf.fit(X_tr, y_tr)
    proba = rf.predict_proba(X_te)[:,1]
    auc = roc_auc_score(y_te, proba)
    acc = accuracy_score(y_te, (proba>0.5).astype(int))
    print(f"RandomForest: AUC={auc:.3f} ACC={acc:.3f}")

    imp = permutation_importance(rf, X_te, y_te, repeats=5, random_state=0)
    top_idx = np.argsort(imp)[::-1][:10]
    print("\nTop features (perm. importance):")
    for k in top_idx:
        print(f"  {feature_names[k]:35s}  ΔAUC≈{imp[k]:.4f}")

    # tiny rule tree on top features
    X_te_top = X_te[:, top_idx]
    X_tr_top = X_tr[:, top_idx]
    tree = DecisionTreeClassifier(max_depth=4, min_samples_leaf=20, random_state=0)
    tree.fit(X_tr_top, y_tr)
    rules = export_text(tree, feature_names=[feature_names[i] for i in top_idx])
    print("\nInterpretable rule stump (depth<=4):\n")
    print(rules)
