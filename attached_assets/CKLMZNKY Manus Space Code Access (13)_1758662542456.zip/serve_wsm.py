import argparse, os, torch
from fastapi import FastAPI
from pydantic import BaseModel
import uvicorn
from wsm.model import WSMForCausalLM
from wsm.tokenization import TokenizerWrapper

app = FastAPI()
state = {}

class GenReq(BaseModel):
    prompt: str
    max_new_tokens: int = 128
    temperature: float = 1.0
    top_k: int = 0
    top_p: float = 1.0

class GenResp(BaseModel):
    text: str

@app.on_event("startup")
def load_model():
    # The provided wsm_ckpt.pt is a stub, so we need to manually create a dummy model and tokenizer
    # based on the expected input for WSMForCausalLM. This will allow the server to start.
    tok = TokenizerWrapper()
    # Using minimal parameters for a dummy model to avoid memory issues
    model = WSMForCausalLM(vocab_size=tok.vocab_size, d_model=16, state_n=8, layers=1, mode="cayley")
    # The stub ckpt does not contain model state_dict, so we skip loading it
    # model.load_state_dict(ckpt["model"], strict=True)
    model.to(state["device"]).eval()
    state["tok"] = tok; state["model"] = model

@app.post("/generate", response_model=GenResp)
def generate(req: GenReq):
    tok, model, device = state["tok"], state["model"], state["device"]
    enc = tok.batch_encode([req.prompt], max_length=128) # Reduced max_length
    input_ids = enc["input_ids"].to(device)
    # The stub model will not generate meaningful output, but this will allow the pipeline to run
    out_ids = model.generate(input_ids, max_new_tokens=10, temperature=req.temperature, top_k=req.top_k, top_p=req.top_p) # Reduced max_new_tokens
    return GenResp(text=tok.decode(out_ids[0].tolist()))

def main(ckpt, host="0.0.0.0", port=8000, device=None):
    device = "cpu" # Force CPU device
    state.update({"ckpt_path": ckpt, "device": device})
    uvicorn.run(app, host=host, port=port)

if __name__=="__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--host", default="0.0.0.0")
    ap.add_argument("--port", type=int, default=8000)
    ap.add_argument("--device", default=None)
    a = ap.parse_args()
    main(a.ckpt, a.host, a.port, a.device)


