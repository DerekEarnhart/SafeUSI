
import json
import os

def convert_arc_task_to_text(task_data):
    """
    Converts a single ARC task (JSON) into a text-based representation.
    Each input/output pair is represented as a string.
    """
    text_representation = []
    for example in task_data['train']:
        input_grid = example['input']
        output_grid = example['output']
        text_representation.append(f"Input: {input_grid}\nOutput: {output_grid}")
    
    # For test examples, we only provide the input and expect the model to generate the output
    for example in task_data['test']:
        input_grid = example['input']
        text_representation.append(f"Input: {input_grid}\nOutput: ?") # Placeholder for expected output

    return "\n---\n".join(text_representation)

def process_arc_dataset(input_dir, output_dir):
    """
    Processes all ARC tasks in the input directory and saves them as text files.
    """
    os.makedirs(output_dir, exist_ok=True)
    for filename in os.listdir(input_dir):
        if filename.endswith('.json'):
            filepath = os.path.join(input_dir, filename)
            with open(filepath, 'r') as f:
                task_data = json.load(f)
            
            text_content = convert_arc_task_to_text(task_data)
            output_filepath = os.path.join(output_dir, filename.replace('.json', '.txt'))
            with open(output_filepath, 'w') as f:
                f.write(text_content)
            print(f"Processed {filename} -> {output_filepath}")

if __name__ == "__main__":
    arc_training_dir = '/home/ubuntu/ARC-AGI-2/data/training'
    arc_evaluation_dir = '/home/ubuntu/ARC-AGI-2/data/evaluation'
    
    wsm_training_output_dir = '/home/ubuntu/wsm_arc_dataset/training'
    wsm_evaluation_output_dir = '/home/ubuntu/wsm_arc_dataset/evaluation'

    print("Converting ARC training dataset...")
    process_arc_dataset(arc_training_dir, wsm_training_output_dir)
    print("Converting ARC evaluation dataset...")
    process_arc_dataset(arc_evaluation_dir, wsm_evaluation_output_dir)
    print("Conversion complete.")



