class PlanningSystem:
    """
    Generates and executes multi-step plans.
    """
    def __init__(self):
        # initialize planner
        pass

    def plan(self, goal):
        """Create a plan to achieve the given goal."""
        # TODO: implement planning
        return []
