# Harmonic Cursor Agent — Full Kit

This is the extended kit: production docs, LaTeX manuscript, robust agent scaffold, editor integrations,
eval harness, playbooks, and safety governance. Start with `../code/README.md` for the agent.
