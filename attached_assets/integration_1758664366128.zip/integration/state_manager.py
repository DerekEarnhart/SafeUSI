class StateManager:
    """
    Manages the overall system state.
    """
    def __init__(self):
        self.state = {}
