class VisualProgrammingInterface:
    """
    Allows programming through visual elements.
    """
    def connect(self, node_a, node_b):
        # TODO: implement connection
        pass
