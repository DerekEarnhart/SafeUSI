import simpleGit from 'simple-git';
export async function status(cwd='.') { return await simpleGit(cwd).status(); }
export async function branch(cwd='.') { return (await simpleGit(cwd).branch()).current; }
export async function checkout(name: string, cwd='.') { await simpleGit(cwd).checkout(name); return true; }
export async function createBranch(name: string, cwd='.') { await simpleGit(cwd).checkoutLocalBranch(name); return true; }
export async function commit(message: string, cwd='.') { await simpleGit(cwd).add('-A'); await simpleGit(cwd).commit(message); return true; }
export async function diff(cwd='.') { return await simpleGit(cwd).diff(); }
export async function apply(patch: string, cwd='.') { await simpleGit(cwd).raw(['apply', '-p0'], patch); return true; }
