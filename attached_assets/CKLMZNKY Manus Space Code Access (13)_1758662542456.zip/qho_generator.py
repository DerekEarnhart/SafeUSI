import numpy as np
import matplotlib.pyplot as plt
import math
import io
import base64

def hermite_phys(n, x):
    if n == 0:
        return np.ones_like(x)
    if n == 1:
        return 2*x
    Hn_2 = np.ones_like(x)
    Hn_1 = 2*x
    for k in range(1, n):
        Hn = 2*x*Hn_1 - 2*k*Hn_2
        Hn_2, Hn_1 = Hn_1, Hn
    return Hn_1

def psi_n(n, x):
    Hn = hermite_phys(n, x)
    norm = 1.0 / (math.sqrt((2**n) * math.factorial(n)) * (math.pi**0.25))
    return norm * np.exp(-x**2 / 2.0) * Hn

def generate_qho_plot(width_px=600, height_px=400, xlim=(-4,4), n_states=4, format='png'):
    dpi = 100
    fig_w = width_px / dpi
    fig_h = height_px / dpi
    x = np.linspace(xlim[0], xlim[1], 1200)
    V = 0.5 * x**2
    
    plt.figure(figsize=(fig_w, fig_h), dpi=dpi)
    plt.plot(x, V, label="Potential V(x)")
    for n in range(n_states):
        psi = psi_n(n, x)
        En = n + 0.5
        plt.plot(x, psi + En, label=f"ψ_{n}(x)")
    
    plt.title("Quantum Harmonic Oscillator: V(x) and ψ_n(x)")
    plt.xlabel("x"); plt.ylabel("Energy / Wavefunction (shifted)")
    plt.legend(); plt.grid(True, linewidth=0.5, alpha=0.3); plt.tight_layout()
    
    buf = io.BytesIO()
    plt.savefig(buf, format=format, bbox_inches="tight")
    plt.close()
    buf.seek(0)
    return base64.b64encode(buf.getvalue()).decode("utf-8")

if __name__ == "__main__":
    # Example usage
    base64_image = generate_qho_plot(width_px=800, height_px=600, n_states=5, format='png')
    print(f"Generated QHO plot (base64 encoded, first 100 chars): {base64_image[:100]}...")



