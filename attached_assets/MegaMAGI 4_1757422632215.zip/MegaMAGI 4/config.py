# config.py: Configuration settings for MegaMAGI
CONFIG = {
    "LOG_LEVEL": "DEBUG",
    "API_KEYS": {
        "openai": "YOUR_OPENAI_API_KEY",  # Replace with your actual OpenAI API key.
    },
    "MODEL_PARAMS": {
        "max_tokens": 2048,
    },
    # Add additional configuration parameters here
}

def get_config():
    return CONFIG