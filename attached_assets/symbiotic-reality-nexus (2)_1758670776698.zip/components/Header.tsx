import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="px-4 py-2 bg-gray-900/50 backdrop-blur-sm border-b border-cyan-500/20 shadow-lg shadow-cyan-500/5">
      <h1 className="text-xl font-bold text-cyan-400 tracking-wider">
        SYMBIOTIC REALITY NEXUS
      </h1>
    </header>
  );
};

export default Header;
