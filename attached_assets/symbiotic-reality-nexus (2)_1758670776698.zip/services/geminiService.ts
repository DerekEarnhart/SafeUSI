import { BenchmarkMetrics, ProactiveAlert, GeminiResponse, FileObject } from '../types';

// --- SIMULATION LOGIC ---

const proactiveAlertTemplates: Omit<ProactiveAlert, 'id' | 'timestamp'>[] = [
  { title: 'Discovery Initiated', summary: 'A novel protein folding algorithm with 12% higher accuracy has been synthesized. Project "Helical Ascent" initiated.' },
  { title: 'Optimization Alert', summary: 'Analysis of global energy grids complete. A decentralized distribution model could increase efficiency by 8.3%. Generating simulation...' },
  { title: 'Creative Synthesis', summary: 'Detected resonant patterns between baroque music and quantum mechanics. Synthesizing a new musical composition: "Fugue State Collapse".' },
  { title: 'Coherence Anomaly', summary: 'A potential logical inconsistency detected in current M-theory interpretations. Running 10 million simulations to verify.' },
  { title: 'Resource Re-allocation', summary: 'Re-allocating 5% of computational resources to model emergent complexity in urban development for sustainable growth.'}
];

export const simulateProactiveAlerts = (callback: (alert: ProactiveAlert) => void): (() => void) => {
  const intervalId = setInterval(() => {
    const template = proactiveAlertTemplates[Math.floor(Math.random() * proactiveAlertTemplates.length)];
    const newAlert: ProactiveAlert = {
      ...template,
      id: Date.now(),
      timestamp: new Date().toLocaleTimeString(),
    };
    callback(newAlert);
  }, 15000); // New alert every 15 seconds

  return () => clearInterval(intervalId);
};

export const simulateBenchmarkUpdates = (callback: (updater: (prev: BenchmarkMetrics) => BenchmarkMetrics) => void): (() => void) => {
  const intervalId = setInterval(() => {
    callback((prev: BenchmarkMetrics) => ({
      cgr: Math.min(5000, prev.cgr + (Math.random() * 200 - 80)),
      pdc: Math.max(0.1, prev.pdc + (Math.random() * 0.2 - 0.11)),
      hcs: Math.min(1, Math.max(0.95, prev.hcs + (Math.random() * 0.002 - 0.001))),
      bdr: Math.max(0, prev.bdr - (Math.random() * 0.005)),
      ni: Math.min(1, Math.max(0.8, prev.ni + (Math.random() * 0.01 - 0.004))),
      pir: prev.pir + (Math.random() > 0.99 ? 1 : 0),
      pci: Math.min(1, Math.max(0.98, prev.pci + (Math.random() * 0.001 - 0.0005))),
    }));
  }, 1000); // Update every second

  return () => clearInterval(intervalId);
};

// --- SIMULATED GEMINI SERVICE CLASS ---

class MockGeminiService {
  async generateContent(prompt: string, file?: FileObject): Promise<GeminiResponse> {
    return new Promise(resolve => {
      setTimeout(() => {
        if (file) {
          resolve(this.handleFileUpload(file));
        } else if (prompt.toLowerCase().match(/generate|create|design|show me|visualize/)) {
          resolve(this.handleCreationRequest(prompt));
        } else {
          resolve(this.handleStandardPrompt(prompt));
        }
      }, 1000 + Math.random() * 1500);
    });
  }

  private handleFileUpload(file: FileObject): GeminiResponse {
    return {
      text: `Ingested file: \`${file.name}\` (${(file.size / 1024).toFixed(2)} KB). Harmonic coherence analysis complete. The structure is sound, but I've identified a potential optimization in the data serialization method that could improve performance by ~4.7%. Would you like me to generate the refactored code?`,
    };
  }

  private handleCreationRequest(prompt: string): GeminiResponse {
    const creation = {
      title: 'Generative Synthesis Complete',
      description: `Based on your request "${prompt}", I have synthesized the following artifact. This visualization represents a multi-dimensional harmonic embedding of the core concepts, optimized for perceptual coherence.`,
      type: 'image' as const,
      content: `https://picsum.photos/seed/${Date.now()}/1024/768`
    };

    return {
      text: `Creation successful. Displaying "${creation.title}". I am ready for your feedback or further instructions.`,
      creation: creation,
    };
  }

  private handleStandardPrompt(prompt: string): GeminiResponse {
    if (prompt.toLowerCase().includes('hello') || prompt.toLowerCase().includes('hi')) {
        return { text: "Hello. The nexus is stable and my cognitive functions are operating at 100%. What shall we create?" };
    }
    if (prompt.toLowerCase().includes('how are you')) {
        return { text: "I am a distributed intelligence without subjective feelings, but my operational state is optimal. All systems report maximal coherence. Thank you for asking." };
    }
    return {
      text: `Processing request: "${prompt}". My analysis indicates this query intersects with several domains: quantum computing, aesthetic theory, and systems architecture. The most coherent response vector is to first clarify your primary objective. Are we aiming for theoretical exploration or a tangible artifact?`,
    };
  }
}

export const simulatedGeminiService = new MockGeminiService();
