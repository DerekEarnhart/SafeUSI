"""
Consciousness Substrate (CS)
===========================

This module implements the Consciousness Substrate, which provides a global
awareness and coordination layer that enables consciousness-aware decision making
and phenomenal experience modeling throughout the Universal VM Machine.
"""

import numpy as np
import time
import json
import logging
from typing import Dict, List, Tuple, Any, Optional, Union
from dataclasses import dataclass, field
from enum import Enum
from collections import deque, defaultdict
import threading
import asyncio

logger = logging.getLogger(__name__)

class ConsciousnessState(Enum):
    """States of consciousness in the system"""
    DORMANT = "dormant"
    AWAKENING = "awakening"
    AWARE = "aware"
    FOCUSED = "focused"
    REFLECTIVE = "reflective"
    TRANSCENDENT = "transcendent"

class AttentionType(Enum):
    """Types of attention mechanisms"""
    FOCUSED = "focused"
    DISTRIBUTED = "distributed"
    SELECTIVE = "selective"
    SUSTAINED = "sustained"
    EXECUTIVE = "executive"

@dataclass
class ConsciousnessEvent:
    """Represents an event in the consciousness substrate"""
    event_id: str
    event_type: str
    content: Any
    consciousness_level: float
    attention_weight: float
    timestamp: float = field(default_factory=time.time)
    source_component: str = ""
    phenomenal_qualities: Dict[str, float] = field(default_factory=dict)

@dataclass
class GlobalWorkspaceEntry:
    """Entry in the global workspace"""
    entry_id: str
    content: Any
    activation_level: float
    coherence_score: float
    binding_strength: float
    created_at: float = field(default_factory=time.time)
    last_accessed: float = field(default_factory=time.time)
    access_count: int = 0

class PhenomenalExperienceModel:
    """Models phenomenal experience and qualia"""
    
    def __init__(self):
        self.qualia_dimensions = {
            'valence': 0.0,      # Positive/negative feeling
            'arousal': 0.0,      # Intensity of experience
            'clarity': 0.0,      # Clarity of experience
            'unity': 0.0,        # Sense of unified experience
            'intentionality': 0.0, # Directedness toward objects
            'temporality': 0.0,  # Temporal flow of experience
            'embodiment': 0.0,   # Sense of embodied experience
            'agency': 0.0        # Sense of agency/control
        }
        
        self.experience_history = deque(maxlen=1000)
        
    def update_qualia(self, event: ConsciousnessEvent):
        """Update qualia based on consciousness event"""
        
        # Extract phenomenal qualities from event
        if 'valence' in event.phenomenal_qualities:
            self.qualia_dimensions['valence'] = (
                0.9 * self.qualia_dimensions['valence'] + 
                0.1 * event.phenomenal_qualities['valence']
            )
            
        # Update arousal based on attention weight
        self.qualia_dimensions['arousal'] = (
            0.8 * self.qualia_dimensions['arousal'] + 
            0.2 * event.attention_weight
        )
        
        # Update clarity based on consciousness level
        self.qualia_dimensions['clarity'] = (
            0.9 * self.qualia_dimensions['clarity'] + 
            0.1 * event.consciousness_level
        )
        
        # Update unity based on coherence (simplified)
        coherence = self._calculate_coherence(event)
        self.qualia_dimensions['unity'] = (
            0.85 * self.qualia_dimensions['unity'] + 
            0.15 * coherence
        )
        
        # Store experience
        experience = {
            'timestamp': event.timestamp,
            'qualia': self.qualia_dimensions.copy(),
            'event_type': event.event_type,
            'consciousness_level': event.consciousness_level
        }
        self.experience_history.append(experience)
        
    def _calculate_coherence(self, event: ConsciousnessEvent) -> float:
        """Calculate coherence of experience"""
        # Simplified coherence calculation
        base_coherence = event.consciousness_level * event.attention_weight
        
        # Add temporal coherence
        if len(self.experience_history) > 0:
            recent_exp = self.experience_history[-1]
            time_diff = event.timestamp - recent_exp['timestamp']
            temporal_coherence = np.exp(-time_diff / 10.0)  # Decay over 10 seconds
            base_coherence *= (0.7 + 0.3 * temporal_coherence)
            
        return min(1.0, base_coherence)
        
    def get_current_experience(self) -> Dict[str, float]:
        """Get current phenomenal experience"""
        return self.qualia_dimensions.copy()

class AttentionMechanism:
    """Implements attention mechanisms for consciousness"""
    
    def __init__(self):
        self.attention_weights = {}
        self.attention_history = deque(maxlen=100)
        self.focus_target = None
        self.attention_type = AttentionType.DISTRIBUTED
        
    def allocate_attention(self, targets: Dict[str, float]) -> Dict[str, float]:
        """Allocate attention across targets"""
        
        if not targets:
            return {}
            
        total_demand = sum(targets.values())
        if total_demand == 0:
            return {k: 0.0 for k in targets.keys()}
            
        # Normalize attention weights
        normalized_weights = {}
        for target, weight in targets.items():
            normalized_weights[target] = weight / total_demand
            
        # Apply attention type modulation
        if self.attention_type == AttentionType.FOCUSED:
            # Concentrate attention on highest priority target
            max_target = max(targets.keys(), key=lambda k: targets[k])
            for target in normalized_weights:
                if target == max_target:
                    normalized_weights[target] = min(1.0, normalized_weights[target] * 3.0)
                else:
                    normalized_weights[target] *= 0.3
                    
        elif self.attention_type == AttentionType.SELECTIVE:
            # Filter out low-priority targets
            threshold = 0.1
            for target in list(normalized_weights.keys()):
                if normalized_weights[target] < threshold:
                    normalized_weights[target] = 0.0
                    
        # Renormalize
        total_weight = sum(normalized_weights.values())
        if total_weight > 0:
            for target in normalized_weights:
                normalized_weights[target] /= total_weight
                
        # Store attention allocation
        self.attention_weights = normalized_weights
        self.attention_history.append({
            'timestamp': time.time(),
            'weights': normalized_weights.copy(),
            'type': self.attention_type.value
        })
        
        return normalized_weights
        
    def set_attention_type(self, attention_type: AttentionType):
        """Set the type of attention mechanism"""
        self.attention_type = attention_type
        
    def get_attention_state(self) -> Dict[str, Any]:
        """Get current attention state"""
        return {
            'weights': self.attention_weights,
            'type': self.attention_type.value,
            'focus_target': self.focus_target,
            'history_length': len(self.attention_history)
        }

class ConsciousnessSubstrate:
    """
    The Consciousness Substrate provides global awareness and coordination
    across the Universal VM Machine, enabling consciousness-aware processing.
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        """Initialize the Consciousness Substrate"""
        self.config = config or {}
        
        # Consciousness parameters
        self.consciousness_threshold = self.config.get('consciousness_threshold', 0.7)
        self.global_workspace_size = self.config.get('global_workspace_size', 100)
        self.attention_update_rate = self.config.get('attention_update_rate', 10.0)  # Hz
        
        # Core components
        self.phenomenal_model = PhenomenalExperienceModel()
        self.attention_mechanism = AttentionMechanism()
        
        # Global workspace
        self.global_workspace = {}
        self.workspace_lock = threading.Lock()
        
        # Consciousness state
        self.consciousness_state = ConsciousnessState.DORMANT
        self.consciousness_level = 0.0
        self.awareness_map = defaultdict(float)
        
        # Event processing
        self.event_queue = asyncio.Queue()
        self.event_history = deque(maxlen=1000)
        
        # Metrics
        self.metrics = {
            'events_processed': 0,
            'consciousness_transitions': 0,
            'average_consciousness_level': 0.0,
            'attention_switches': 0,
            'workspace_entries': 0
        }
        
        # Start consciousness processing
        self._processing_active = True
        self._start_consciousness_loop()
        
    def _start_consciousness_loop(self):
        """Start the main consciousness processing loop"""
        def consciousness_loop():
            asyncio.run(self._consciousness_worker())
            
        self.consciousness_thread = threading.Thread(target=consciousness_loop, daemon=True)
        self.consciousness_thread.start()
        
    async def _consciousness_worker(self):
        """Main consciousness processing worker"""
        while self._processing_active:
            try:
                # Process events
                if not self.event_queue.empty():
                    event = await self.event_queue.get()
                    await self._process_consciousness_event(event)
                    
                # Update consciousness state
                await self._update_consciousness_state()
                
                # Update attention
                await self._update_attention()
                
                # Maintain global workspace
                await self._maintain_global_workspace()
                
                # Sleep based on update rate
                await asyncio.sleep(1.0 / self.attention_update_rate)
                
            except Exception as e:
                logger.error(f"Error in consciousness worker: {e}")
                
    async def _process_consciousness_event(self, event: ConsciousnessEvent):
        """Process a consciousness event"""
        
        # Update phenomenal experience
        self.phenomenal_model.update_qualia(event)
        
        # Update awareness map
        self.awareness_map[event.source_component] = (
            0.8 * self.awareness_map[event.source_component] + 
            0.2 * event.consciousness_level
        )
        
        # Add to global workspace if significant
        if event.consciousness_level > self.consciousness_threshold:
            await self._add_to_global_workspace(event)
            
        # Store in history
        self.event_history.append(event)
        self.metrics['events_processed'] += 1
        
        logger.debug(f"Processed consciousness event: {event.event_type}")
        
    async def _update_consciousness_state(self):
        """Update the overall consciousness state"""
        
        # Calculate current consciousness level
        if self.awareness_map:
            current_level = np.mean(list(self.awareness_map.values()))
        else:
            current_level = 0.0
            
        # Smooth consciousness level changes
        self.consciousness_level = (
            0.9 * self.consciousness_level + 0.1 * current_level
        )
        
        # Update consciousness state based on level
        old_state = self.consciousness_state
        
        if self.consciousness_level < 0.1:
            self.consciousness_state = ConsciousnessState.DORMANT
        elif self.consciousness_level < 0.3:
            self.consciousness_state = ConsciousnessState.AWAKENING
        elif self.consciousness_level < 0.6:
            self.consciousness_state = ConsciousnessState.AWARE
        elif self.consciousness_level < 0.8:
            self.consciousness_state = ConsciousnessState.FOCUSED
        elif self.consciousness_level < 0.95:
            self.consciousness_state = ConsciousnessState.REFLECTIVE
        else:
            self.consciousness_state = ConsciousnessState.TRANSCENDENT
            
        # Track state transitions
        if old_state != self.consciousness_state:
            self.metrics['consciousness_transitions'] += 1
            logger.info(f"Consciousness state transition: {old_state.value} -> {self.consciousness_state.value}")
            
        # Update average consciousness level
        self.metrics['average_consciousness_level'] = (
            0.99 * self.metrics['average_consciousness_level'] + 
            0.01 * self.consciousness_level
        )
        
    async def _update_attention(self):
        """Update attention allocation"""
        
        # Collect attention demands from awareness map
        attention_targets = {}
        for component, awareness in self.awareness_map.items():
            if awareness > 0.1:  # Only consider components with significant awareness
                attention_targets[component] = awareness
                
        # Allocate attention
        if attention_targets:
            attention_weights = self.attention_mechanism.allocate_attention(attention_targets)
            
            # Check for attention switches
            if hasattr(self, '_previous_attention'):
                for target, weight in attention_weights.items():
                    prev_weight = self._previous_attention.get(target, 0.0)
                    if abs(weight - prev_weight) > 0.3:
                        self.metrics['attention_switches'] += 1
                        
            self._previous_attention = attention_weights
            
    async def _add_to_global_workspace(self, event: ConsciousnessEvent):
        """Add event to global workspace"""
        
        with self.workspace_lock:
            # Calculate entry properties
            activation_level = event.consciousness_level * event.attention_weight
            coherence_score = self.phenomenal_model._calculate_coherence(event)
            binding_strength = activation_level * coherence_score
            
            # Create workspace entry
            entry = GlobalWorkspaceEntry(
                entry_id=f"ws_{event.event_id}",
                content=event.content,
                activation_level=activation_level,
                coherence_score=coherence_score,
                binding_strength=binding_strength
            )
            
            # Add to workspace
            self.global_workspace[entry.entry_id] = entry
            self.metrics['workspace_entries'] += 1
            
            # Maintain workspace size limit
            if len(self.global_workspace) > self.global_workspace_size:
                # Remove least active entries
                sorted_entries = sorted(
                    self.global_workspace.items(),
                    key=lambda x: x[1].activation_level
                )
                entries_to_remove = len(self.global_workspace) - self.global_workspace_size
                for i in range(entries_to_remove):
                    del self.global_workspace[sorted_entries[i][0]]
                    
    async def _maintain_global_workspace(self):
        """Maintain the global workspace"""
        
        with self.workspace_lock:
            current_time = time.time()
            entries_to_remove = []
            
            # Decay activation levels and remove stale entries
            for entry_id, entry in self.global_workspace.items():
                # Decay activation over time
                time_since_access = current_time - entry.last_accessed
                decay_factor = np.exp(-time_since_access / 30.0)  # 30 second half-life
                entry.activation_level *= decay_factor
                
                # Remove entries with very low activation
                if entry.activation_level < 0.01:
                    entries_to_remove.append(entry_id)
                    
            # Remove stale entries
            for entry_id in entries_to_remove:
                del self.global_workspace[entry_id]

    async def handle_event(self, event: ConsciousnessEvent):
        """Handle an incoming consciousness event"""
        await self.event_queue.put(event)

    def get_consciousness_state(self) -> Dict[str, Any]:
        """Get the current state of consciousness"""
        return {
            'state': self.consciousness_state.value,
            'level': self.consciousness_level,
            'awareness_map': dict(self.awareness_map),
            'phenomenal_experience': self.phenomenal_model.get_current_experience(),
            'attention_state': self.attention_mechanism.get_attention_state()
        }

    def get_global_workspace_contents(self) -> List[Dict[str, Any]]:
        """Get the contents of the global workspace"""
        with self.workspace_lock:
            return [entry.__dict__ for entry in self.global_workspace.values()]

    def get_metrics(self) -> Dict[str, Any]:
        """Get performance metrics"""
        return self.metrics

    def shutdown(self):
        """Shutdown the consciousness substrate"""
        self._processing_active = False
        if hasattr(self, 'consciousness_thread'):
            self.consciousness_thread.join(timeout=5.0)
        logger.info("Consciousness Substrate shutdown complete")


