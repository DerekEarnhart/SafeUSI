# Quantum Geometry VM — Scaffold (Windows-friendly)

This folder gives you a minimal, runnable scaffold to **start a server** and **hit a couple endpoints**,
without needing the entire original stack to be perfect on day one.

## What you can do immediately
- Boot a Flask server that wires your existing `vm_api`.
- Submit a test task to prove the route works.
- If your full `UniversalTaskOrchestrator` imports cleanly, it will be used. Otherwise, a **stub** orchestrator kicks in so the demo still works.

## Quickstart (Windows)
1) Open **Command Prompt** in this folder.
2) Create a virtual environment and install deps:
   ```bat
   scripts\setup_venv.bat
   ```
3) Start the server:
   ```bat
   scripts\run_server.bat
   ```
4) In a second terminal, test the endpoints:
   ```bat
   scripts\test_endpoints.bat
   ```

## Quickstart (macOS/Linux)
```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -U pip
pip install -r requirements-min.txt
python app/mini_server.py
# in another terminal:
python test_endpoints.py
```

## Where your code lives
- Package: `qgvm2/`
- API blueprint: `qgvm2/vm_api.py` (exposes `/vm/status` and `/vm/task`)
- Minimal server: `app/mini_server.py` (registers the blueprint and provides a fallback orchestrator)
- Optional dependencies: `networkx` for real orchestrator; `torch` is heavy and optional.

## Optional: use your real orchestrator
If `qgvm2/universal_task_orchestrator.py` imports cleanly (i.e., all its deps like `networkx` are installed), it will be used automatically.
Otherwise, the stub orchestrator completes tasks instantly so you can prove out the API surface.

## Troubleshooting
- **Port already in use**: edit `.env.example` to a new port and set `PORT` env var before running.
- **Missing modules**: `pip install -r requirements-min.txt` again. Add any extra libs your code needs.
- **Firewall prompts**: allow Python on private network for local testing.
