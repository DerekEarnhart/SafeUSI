import React, { useEffect, useState, useRef } from 'react'

const DEMO_MANIFEST = {
  job: { name: "demo-analog-vs-gpu", objective: { minimize: "val_loss" } },
  fidelity: { deterministic_check_fraction: 0.05 },
  resources: [{ type: "analog_emulator", id: "emu0" }, { type: "gpu", id: "local_gpu" }],
  schedule: [
    { stage: "coarse_search", run_on: "emu0", epochs: 20 },
    { stage: "refine", run_on: "local_gpu", epochs: 5 }
  ],
  checkpoint: { cadence: "2m" }
}

function prettyJson(v:any){ return JSON.stringify(v, null, 2) }

export default function ComputePanel(){
  const [manifest, setManifest] = useState(() => prettyJson(DEMO_MANIFEST))
  const [jobId, setJobId] = useState<string | null>(null)
  const [events, setEvents] = useState<string[]>([])
  const esRef = useRef<EventSource | null>(null)

  useEffect(() => {
    return () => {
      if(esRef.current){ esRef.current.close(); esRef.current = null }
    }
  }, [])

  async function submit(){
    setEvents([])
    setJobId(null)
    try {
      const res = await fetch('http://127.0.0.1:7878/jobs', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: manifest
      })
      const data = await res.json()
      setJobId(data.job_id)
      listenEvents(data.job_id)
    } catch(e){
      setEvents(ev => [...ev, "ERROR: " + String(e)])
    }
  }

  function listenEvents(jobId:string){
    if(esRef.current){ esRef.current.close() }
    const es = new EventSource(`http://127.0.0.1:7878/jobs/${jobId}/events`)
    esRef.current = es
    es.onmessage = (ev) => {
      setEvents(events => [...events, ev.data])
    }
    es.onerror = () =>{
      setEvents(ev => [...ev, "[SSE] connection closed or errored"])
      es.close()
      esRef.current = null
    }
  }

  return (
    <div className="card">
      <h4>Compute Panel</h4>
      <div className="small">Submit a declarative manifest to the local agent and view live telemetry (SSE).</div>

      <div style={{marginTop:12}}>
        <textarea className="input" rows={12} value={manifest} onChange={e=>setManifest(e.target.value)} />
      </div>

      <div style={{marginTop:8}} className="flex">
        <button className="btn" onClick={submit}>Submit Manifest</button>
        <div className="small">Job ID: {jobId ?? "<none>"}</div>
      </div>

      <div style={{marginTop:12}}>
        <h5>Events</h5>
        <div style={{maxHeight:220, overflowY:'auto', background:'#071026', padding:8, borderRadius:6}}>
          {events.length===0 ? <div className="small">No events yet</div> : events.map((e,i)=> <div key={i} style={{fontFamily:'monospace', fontSize:12, padding:'6px 0'}}>{e}</div>)}
        </div>
      </div>

    </div>
  )
}
