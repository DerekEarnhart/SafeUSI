from flask import Blueprint, jsonify, request

vm_api = Blueprint("vm_api", __name__)
system_components = {}

@vm_api.route("/vm/status", methods=["GET"])
def get_vm_status():
    status = {"status": "running", "components": {}}
    for name, component in system_components.items():
        status["components"][name] = {"initialized": True, "status": "ok"}
    return jsonify(status)

@vm_api.route("/vm/task", methods=["POST"])
def submit_task():
    data = request.get_json()
    task_description = data.get("task_description")
    if not task_description:
        return jsonify({"error": "Task description is required"}), 400

    orchestrator = system_components.get("task_orchestrator")
    if not orchestrator:
        return jsonify({"error": "Task orchestrator not initialized"}), 500

    try:
        task_id = orchestrator.submit_task(task_description)
        return jsonify({"message": "Task submitted successfully", "task_id": task_id}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


