import os, httpx
async def infer(prompt: str, max_tokens: int = 256) -> str:
    base = os.getenv("EDGE_BASE","http://127.0.0.1:8787"); key = os.getenv("EDGE_KEY","devkey123")
    async with httpx.AsyncClient(timeout=60.0) as cx:
        r = await cx.post(f"{base}/v1/infer", headers={"X-API-Key": key}, json={"prompt": prompt, "max_tokens": max_tokens})
    r.raise_for_status(); j = r.json(); return j.get("text") or str(j)
