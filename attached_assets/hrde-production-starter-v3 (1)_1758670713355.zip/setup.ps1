Param()
if (-Not (Test-Path .env)) { Copy-Item .env.example .env }
New-Item -ItemType Directory -Force -Path assets/external,assets/samples,hrde_workspace,bench/reports | Out-Null
Push-Location python
py -3 -m venv .venv
. .\.venv\Scripts\Activate.ps1
python -m pip install -U pip
pip install -r requirements.txt
Pop-Location
Push-Location worker
npm config set optional true | Out-Null
npm install
Pop-Location
Write-Host "Setup complete."
