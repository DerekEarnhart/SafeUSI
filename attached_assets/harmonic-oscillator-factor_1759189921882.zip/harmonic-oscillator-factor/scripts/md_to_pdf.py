import sys, textwrap
from pathlib import Path
from reportlab.lib.pagesizes import LETTER
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch

def md_to_pdf(src_md: Path, out_pdf: Path):
    text = Path(src_md).read_text(encoding="utf-8", errors="ignore")
    c = canvas.Canvas(str(out_pdf), pagesize=LETTER)
    width, height = LETTER
    x = 1*inch
    y = height - 1*inch
    for line in text.splitlines():
        if not line.strip():
            y -= 0.25*inch
            continue
        # basic heading emphasis
        if line.startswith("#"):
            c.setFont("Helvetica-Bold", 12)
            content = line.lstrip("# ").strip()
        else:
            c.setFont("Helvetica", 10)
            content = line
        # wrap long lines
        for chunk in textwrap.wrap(content, width=90):
            c.drawString(x, y, chunk)
            y -= 0.2*inch
            if y < 1*inch:
                c.showPage()
                y = height - 1*inch
    c.save()

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("usage: md_to_pdf.py <src.md> <out.pdf>"); sys.exit(2)
    md_to_pdf(Path(sys.argv[1]), Path(sys.argv[2]))
