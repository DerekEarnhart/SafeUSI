\
import os, argparse, yaml, math
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from wsm.model import WSMForCausalLM
from wsm.tokenization import TokenizerWrapper

class TextFolderDataset(Dataset):
    """
    Reads all .txt files under a folder; returns (input_ids, labels) windows of max_len.
    """
    def __init__(self, folder: str, tokenizer: TokenizerWrapper, max_len: int = 512):
        self.tokens = []
        for root, _, files in os.walk(folder):
            for f in files:
                if f.lower().endswith(".txt"):
                    path = os.path.join(root, f)
                    with open(path, "r", encoding="utf-8", errors="ignore") as fh:
                        txt = fh.read()
                    self.tokens.extend(tokenizer.encode(txt))
        self.max_len = max_len
        if len(self.tokens) < max_len+1:
            # pad with EOS ids if too short
            eos = tokenizer.tok.eos_token_id
            self.tokens = self.tokens + [eos] * (max_len + 1 - len(self.tokens))

    def __len__(self):
        return max(1, len(self.tokens) // self.max_len - 1)

    def __getitem__(self, idx):
        start = idx * self.max_len
        end = start + self.max_len + 1
        window = self.tokens[start:end]
        x = torch.tensor(window[:-1], dtype=torch.long)
        y = torch.tensor(window[1:], dtype=torch.long)
        return x, y

def train(cfg_path: str, data_dir: str, out_path: str = None, tokenizer_name: str = "gpt2"):
    with open(cfg_path, "r") as fh:
        cfg = yaml.safe_load(fh)
    model_cfg = cfg["model"]
    train_cfg = cfg["train"]

    tok = TokenizerWrapper(tokenizer_name)
    model = WSMForCausalLM(vocab_size=tok.vocab_size,
                           d_model=model_cfg["d_model"],
                           state_n=model_cfg["state_n"],
                           layers=model_cfg["layers"])
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model.to(device)

    ds = TextFolderDataset(data_dir, tok, max_len=train_cfg["max_len"])
    dl = DataLoader(ds, batch_size=train_cfg["batch_size"], shuffle=True, drop_last=True)

    opt = torch.optim.AdamW(model.parameters(), lr=train_cfg["lr"], weight_decay=train_cfg["weight_decay"])
    scaler = torch.cuda.amp.GradScaler(enabled=torch.cuda.is_available())

    steps = 0
    model.train()
    for epoch in range(train_cfg["epochs"]):
        for x, y in dl:
            x = x.to(device)
            y = y.to(device)
            opt.zero_grad(set_to_none=True)
            with torch.cuda.amp.autocast(enabled=torch.cuda.is_available()):
                _, loss = model(x, labels=y)
            scaler.scale(loss).backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), train_cfg["grad_clip"])
            scaler.step(opt)
            scaler.update()
            steps += 1
            if steps % 50 == 0:
                print(f"step {steps} | loss {loss.item():.4f}")
    out = out_path or cfg["train"]["save_path"]
    torch.save({"model": model.state_dict(), "tokenizer": tokenizer_name, "config": model_cfg}, out)
    print(f"saved checkpoint -> {out}")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/wsm_base.yaml")
    ap.add_argument("--data_dir", required=True)
    ap.add_argument("--out", default=None)
    ap.add_argument("--tokenizer", default="gpt2")
    args = ap.parse_args()
    train(args.config, args.data_dir, args.out, args.tokenizer)
