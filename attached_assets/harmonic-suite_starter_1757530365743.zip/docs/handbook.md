# Handbook — TODO: HA/HAP/HRA/RUIS/HRDE definitions
