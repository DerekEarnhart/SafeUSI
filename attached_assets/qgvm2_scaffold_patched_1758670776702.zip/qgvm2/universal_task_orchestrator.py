"""
Universal Task Orchestrator (UTO)
=================================

This module implements the Universal Task Orchestrator, which is responsible for
decomposing complex tasks, synthesizing capabilities, and orchestrating the 
execution of workflows across the Universal VM Machine.
"""

import asyncio
import uuid
import time
import json
import logging
from typing import Dict, List, Tuple, Any, Optional, Union, Callable
from dataclasses import dataclass, field
from enum import Enum
import networkx as nx
import numpy as np
from collections import deque, defaultdict

from .harmonic_topological_engine import HarmonicTopologicalEngine, ComputationTask, ComputeMode

logger = logging.getLogger(__name__)

class TaskType(Enum):
    """Types of tasks the orchestrator can handle"""
    ANALYSIS = "analysis"
    SYNTHESIS = "synthesis"
    OPTIMIZATION = "optimization"
    SIMULATION = "simulation"
    REASONING = "reasoning"
    CREATIVE = "creative"
    RESEARCH = "research"
    COMPUTATION = "computation"
    COMMUNICATION = "communication"
    LEARNING = "learning"

class TaskStatus(Enum):
    """Status of tasks in the system"""
    PENDING = "pending"
    DECOMPOSING = "decomposing"
    EXECUTING = "executing"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

@dataclass
class Task:
    """Represents a task in the Universal VM Machine"""
    task_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    description: str = ""
    task_type: TaskType = TaskType.COMPUTATION
    input_data: Any = None
    parameters: Dict[str, Any] = field(default_factory=dict)
    priority: float = 1.0
    deadline: Optional[float] = None
    dependencies: List[str] = field(default_factory=list)
    status: TaskStatus = TaskStatus.PENDING
    created_at: float = field(default_factory=time.time)
    started_at: Optional[float] = None
    completed_at: Optional[float] = None
    result: Any = None
    error: Optional[str] = None
    subtasks: List[str] = field(default_factory=list)
    parent_task: Optional[str] = None
    consciousness_level: float = 0.5
    
@dataclass
class Capability:
    """Represents a capability that can be synthesized"""
    capability_id: str
    name: str
    description: str
    input_types: List[str]
    output_types: List[str]
    complexity: float
    reliability: float
    resource_requirements: Dict[str, float]
    implementation: Optional[Callable] = None

class CapabilitySynthesizer:
    """Synthesizes new capabilities by combining existing ones"""
    
    def __init__(self):
        self.base_capabilities = {}
        self.synthesized_capabilities = {}
        self._initialize_base_capabilities()
        
    def _initialize_base_capabilities(self):
        """Initialize base capabilities"""
        base_caps = [
            Capability(
                capability_id="text_analysis",
                name="Text Analysis",
                description="Analyze and extract information from text",
                input_types=["text"],
                output_types=["analysis"],
                complexity=0.3,
                reliability=0.9,
                resource_requirements={"cpu": 0.2, "memory": 0.1}
            ),
            Capability(
                capability_id="numerical_computation",
                name="Numerical Computation",
                description="Perform numerical calculations and simulations",
                input_types=["numbers", "equations"],
                output_types=["results", "plots"],
                complexity=0.5,
                reliability=0.95,
                resource_requirements={"cpu": 0.6, "memory": 0.3}
            ),
            Capability(
                capability_id="pattern_recognition",
                name="Pattern Recognition",
                description="Identify patterns in data",
                input_types=["data", "images", "signals"],
                output_types=["patterns", "classifications"],
                complexity=0.7,
                reliability=0.8,
                resource_requirements={"cpu": 0.8, "memory": 0.5}
            ),
            Capability(
                capability_id="logical_reasoning",
                name="Logical Reasoning",
                description="Apply logical reasoning to problems",
                input_types=["premises", "rules"],
                output_types=["conclusions", "proofs"],
                complexity=0.6,
                reliability=0.85,
                resource_requirements={"cpu": 0.4, "memory": 0.2}
            ),
            Capability(
                capability_id="creative_generation",
                name="Creative Generation",
                description="Generate creative content and solutions",
                input_types=["prompts", "constraints"],
                output_types=["content", "ideas"],
                complexity=0.8,
                reliability=0.7,
                resource_requirements={"cpu": 0.5, "memory": 0.4}
            )
        ]
        
        for cap in base_caps:
            self.base_capabilities[cap.capability_id] = cap
            
    def synthesize_capability(self, required_inputs: List[str], 
                            required_outputs: List[str],
                            max_complexity: float = 1.0) -> Optional[Capability]:
        """Synthesize a new capability from existing ones"""
        
        # Find compatible capabilities
        compatible_caps = []
        for cap in self.base_capabilities.values():
            input_match = any(inp in cap.output_types for inp in required_inputs)
            output_match = any(out in cap.output_types for out in required_outputs)
            if input_match or output_match:
                compatible_caps.append(cap)
                
        if not compatible_caps:
            return None
            
        # Create synthesized capability
        synth_id = f"synth_{len(self.synthesized_capabilities)}"
        combined_complexity = min(max_complexity, 
                                sum(cap.complexity for cap in compatible_caps) / len(compatible_caps))
        combined_reliability = np.prod([cap.reliability for cap in compatible_caps]) ** (1/len(compatible_caps))
        
        synthesized_cap = Capability(
            capability_id=synth_id,
            name=f"Synthesized Capability {synth_id}",
            description=f"Synthesized from {[cap.name for cap in compatible_caps]}",
            input_types=required_inputs,
            output_types=required_outputs,
            complexity=combined_complexity,
            reliability=combined_reliability,
            resource_requirements={
                "cpu": sum(cap.resource_requirements.get("cpu", 0) for cap in compatible_caps),
                "memory": sum(cap.resource_requirements.get("memory", 0) for cap in compatible_caps)
            }
        )
        
        self.synthesized_capabilities[synth_id] = synthesized_cap
        return synthesized_cap

class WorkflowGraph:
    """Represents a workflow as a directed graph"""
    
    def __init__(self):
        self.graph = nx.DiGraph()
        self.task_data = {}
        
    def add_task(self, task: Task):
        """Add a task to the workflow graph"""
        self.graph.add_node(task.task_id)
        self.task_data[task.task_id] = task
        
        # Add dependency edges
        for dep_id in task.dependencies:
            if dep_id in self.graph:
                self.graph.add_edge(dep_id, task.task_id)
                
    def get_executable_tasks(self) -> List[str]:
        """Get tasks that can be executed (no pending dependencies)"""
        executable = []
        for task_id in self.graph.nodes():
            task = self.task_data[task_id]
            if task.status == TaskStatus.PENDING:
                # Check if all dependencies are completed
                deps_completed = all(
                    self.task_data[dep_id].status == TaskStatus.COMPLETED
                    for dep_id in task.dependencies
                    if dep_id in self.task_data
                )
                if deps_completed:
                    executable.append(task_id)
        return executable
        
    def get_critical_path(self) -> List[str]:
        """Get the critical path through the workflow"""
        try:
            return nx.dag_longest_path(self.graph)
        except:
            return []

class UniversalTaskOrchestrator:
    """
    The Universal Task Orchestrator manages task decomposition, capability synthesis,
    and workflow orchestration across the Universal VM Machine.
    """
    
    def __init__(self, htce: HarmonicTopologicalEngine):
        """Initialize the Universal Task Orchestrator"""
        self.htce = htce
        self.capability_synthesizer = CapabilitySynthesizer()
        
        # Task management
        self.tasks = {}
        self.workflows = {}
        self.task_queue = asyncio.PriorityQueue()
        
        # Performance tracking
        self.metrics = {
            'tasks_processed': 0,
            'workflows_completed': 0,
            'average_decomposition_time': 0.0,
            'capability_synthesis_count': 0,
            'success_rate': 0.0
        }
        
        # Start orchestration loop
        self._orchestration_active = True
        self._start_orchestration_loop()
        
    def _start_orchestration_loop(self):
        """Start the main orchestration loop"""
        def orchestration_loop():
            asyncio.run(self._orchestration_worker())
            
        import threading
        self.orchestration_thread = threading.Thread(target=orchestration_loop, daemon=True)
        self.orchestration_thread.start()
        
    async def _orchestration_worker(self):
        """Main orchestration worker loop"""
        while self._orchestration_active:
            try:
                # Process task queue
                if not self.task_queue.empty():
                    priority, task_id = await self.task_queue.get()
                    await self._process_task(task_id)
                else:
                    await asyncio.sleep(0.1)
                    
            except Exception as e:
                logger.error(f"Error in orchestration worker: {e}")
                
    async def _process_task(self, task_id: str):
        """Process a single task"""
        if task_id not in self.tasks:
            logger.error(f"Task {task_id} not found")
            return
            
        task = self.tasks[task_id]
        
        try:
            # Update task status
            task.status = TaskStatus.EXECUTING
            task.started_at = time.time()
            
            # Check if task needs decomposition
            if self._needs_decomposition(task):
                await self._decompose_task(task)
            else:
                # Execute task directly
                await self._execute_task(task)
                
        except Exception as e:
            task.status = TaskStatus.FAILED
            task.error = str(e)
            logger.error(f"Error processing task {task_id}: {e}")
            
    def _needs_decomposition(self, task: Task) -> bool:
        """Determine if a task needs to be decomposed"""
        # Simple heuristic: decompose if task description is long or complex
        if len(task.description) > 200:
            return True
        if task.task_type in [TaskType.RESEARCH, TaskType.ANALYSIS, TaskType.SYNTHESIS]:
            return True
        return False
        
    async def _decompose_task(self, task: Task):
        """Decompose a complex task into subtasks"""
        decomposition_start = time.time()
        
        # Simple decomposition strategy based on task type
        subtasks = []
        
        if task.task_type == TaskType.RESEARCH:
            subtasks = [
                Task(
                    name=f"Literature Review - {task.name}",
                    description=f"Review existing literature for {task.description}",
                    task_type=TaskType.ANALYSIS,
                    input_data=task.input_data,
                    parent_task=task.task_id,
                    consciousness_level=task.consciousness_level * 0.8
                ),
                Task(
                    name=f"Data Collection - {task.name}",
                    description=f"Collect relevant data for {task.description}",
                    task_type=TaskType.COMPUTATION,
                    input_data=task.input_data,
                    parent_task=task.task_id,
                    consciousness_level=task.consciousness_level * 0.6
                ),
                Task(
                    name=f"Analysis - {task.name}",
                    description=f"Analyze collected data for {task.description}",
                    task_type=TaskType.ANALYSIS,
                    input_data=task.input_data,
                    dependencies=[],  # Will be set after subtasks are created
                    parent_task=task.task_id,
                    consciousness_level=task.consciousness_level
                )
            ]
        elif task.task_type == TaskType.SYNTHESIS:
            subtasks = [
                Task(
                    name=f"Component Analysis - {task.name}",
                    description=f"Analyze components for {task.description}",
                    task_type=TaskType.ANALYSIS,
                    input_data=task.input_data,
                    parent_task=task.task_id,
                    consciousness_level=task.consciousness_level * 0.7
                ),
                Task(
                    name=f"Integration - {task.name}",
                    description=f"Integrate components for {task.description}",
                    task_type=TaskType.COMPUTATION,
                    input_data=task.input_data,
                    parent_task=task.task_id,
                    consciousness_level=task.consciousness_level
                )
            ]
        else:
            # Default decomposition
            subtasks = [
                Task(
                    name=f"Subtask 1 - {task.name}",
                    description=f"First part of {task.description}",
                    task_type=task.task_type,
                    input_data=task.input_data,
                    parent_task=task.task_id,
                    consciousness_level=task.consciousness_level
                )
            ]
            
        # Set up dependencies between subtasks
        for i in range(1, len(subtasks)):
            subtasks[i].dependencies.append(subtasks[i-1].task_id)
            
        # Add subtasks to the system
        for subtask in subtasks:
            self.tasks[subtask.task_id] = subtask
            task.subtasks.append(subtask.task_id)
            await self.task_queue.put((-subtask.priority, subtask.task_id))
            
        # Update metrics
        decomposition_time = time.time() - decomposition_start
        self.metrics['average_decomposition_time'] = (
            (self.metrics['average_decomposition_time'] * self.metrics['tasks_processed'] + decomposition_time) /
            (self.metrics['tasks_processed'] + 1)
        )
        
        logger.info(f"Decomposed task {task.task_id} into {len(subtasks)} subtasks")
        
    async def _execute_task(self, task: Task):
        """Execute a task using the Harmonic-Topological Compute Engine"""
        
        # Determine compute mode based on task type and consciousness level
        if task.consciousness_level > 0.8:
            compute_mode = ComputeMode.CONSCIOUSNESS
        elif task.task_type in [TaskType.REASONING, TaskType.ANALYSIS]:
            compute_mode = ComputeMode.HARMONIC
        elif task.task_type in [TaskType.SIMULATION, TaskType.COMPUTATION]:
            compute_mode = ComputeMode.TOPOLOGICAL
        else:
            compute_mode = ComputeMode.HYBRID
            
        # Create computation task
        comp_task = ComputationTask(
            task_id=f"comp_{task.task_id}",
            task_type=task.task_type.value,
            input_data=task.input_data or task.description,
            parameters=task.parameters,
            priority=task.priority,
            compute_mode=compute_mode,
            consciousness_level=task.consciousness_level
        )
        
        # Submit to the HTCE
        htce_task_id = await self.htce.submit_task(comp_task)
        
        # Wait for HTCE task completion
        max_wait = task.deadline - time.time() if task.deadline else 300.0  # 5 minutes default
        start_time = time.time()
        
        while time.time() - start_time < max_wait:
            result = self.htce.get_task_result(htce_task_id)
            if result:
                task.result = result
                task.status = TaskStatus.COMPLETED
                task.completed_at = time.time()
                self.metrics["tasks_processed"] += 1
                logger.info(f"Task {task.task_id} completed by HTCE")
                return
            await asyncio.sleep(0.1)
            
        raise TimeoutError(f"Task {task.task_id} timed out after {max_wait} seconds")
        
    async def submit_task(self, task: Task) -> str:
        """Submit a new task to the orchestrator"""
        self.tasks[task.task_id] = task
        await self.task_queue.put((-task.priority, task.task_id))  # Priority queue
        logger.info(f"Task {task.task_id} submitted to orchestrator")
        return task.task_id
        
    def get_task_result(self, task_id: str) -> Optional[Any]:
        """Get the result of a task"""
        task = self.tasks.get(task_id)
        if task and task.status == TaskStatus.COMPLETED:
            return task.result
        return None
        
    def get_task_status(self, task_id: str) -> Optional[TaskStatus]:
        """Get the status of a task"""
        task = self.tasks.get(task_id)
        return task.status if task else None
        
    def get_metrics(self) -> Dict[str, Any]:
        """Get orchestrator performance metrics"""
        # Calculate success rate
        completed_tasks = [t for t in self.tasks.values() if t.status == TaskStatus.COMPLETED]
        failed_tasks = [t for t in self.tasks.values() if t.status == TaskStatus.FAILED]
        
        total_finished_tasks = len(completed_tasks) + len(failed_tasks)
        if total_finished_tasks > 0:
            self.metrics["success_rate"] = len(completed_tasks) / total_finished_tasks
        else:
            self.metrics["success_rate"] = 0.0
            
        return {
            **self.metrics,
            "total_tasks": len(self.tasks),
            "pending_tasks": self.task_queue.qsize(),
            "active_tasks": len([t for t in self.tasks.values() if t.status == TaskStatus.EXECUTING]),
            "htce_metrics": self.htce.get_metrics() if self.htce else {}
        }
        
    def shutdown(self):
        """Shutdown the orchestrator"""
        self._orchestration_active = False
        if hasattr(self, 'orchestration_thread'):
            self.orchestration_thread.join(timeout=5.0)
        logger.info("Universal Task Orchestrator shutdown complete")


