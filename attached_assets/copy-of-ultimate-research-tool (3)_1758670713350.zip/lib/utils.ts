
export function ts(ms: number): string {
  try {
    const d = new Date(ms);
    return isNaN(d.getTime()) ? String(ms) : d.toLocaleString();
  } catch {
    return String(ms);
  }
}

export function seedRand(seed: string): () => number {
  let h = 1779033703 ^ seed.length;
  for (let i = 0; i < seed.length; i++) {
    h = Math.imul(h ^ seed.charCodeAt(i), 3432918353);
    h = (h << 13) | (h >>> 19);
  }
  return () => {
    h = Math.imul(h ^ (h >>> 16), 2246822507);
    h = Math.imul(h ^ (h >>> 13), 3266489909);
    const t = (h ^= h >>> 16) >>> 0;
    return t / 4294967296;
  };
}

export function download(name: string, content: string): void {
  const blob = new Blob([content], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

export function speak(text: string): void {
  if (typeof window === "undefined") return;
  if (!("speechSynthesis" in window)) return;
  const u = new SpeechSynthesisUtterance(text);
  window.speechSynthesis.speak(u);
}

export function textToBigIntString(s: string): string {
  const enc = new TextEncoder().encode(s);
  let hex = "";
  for (const b of enc) hex += b.toString(16).padStart(2, "0");
  const big = BigInt("0x" + (hex || "00"));
  return big.toString(10);
}

function bigIntStringToText(n: string): string {
  let big = BigInt(n || "0");
  let hex = big.toString(16);
  if (hex.length % 2) hex = "0" + hex;
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < bytes.length; i++) {
    bytes[i] = parseInt(hex.slice(i * 2, i * 2 + 2), 16);
  }
  return new TextDecoder().decode(bytes);
}

function isIntegerString(s: string): boolean {
  return /^\s*-?\d+\s*$/.test(s);
}

function tryParseFloatArrayStrict(s: string): number[] | null {
  try {
    const v = JSON.parse(s);
    if (Array.isArray(v) && v.every((x) => typeof x === "number" && Number.isFinite(x))) return v as number[];
  } catch {}
  return null;
}

function tryExtractFloatsLoose(s: string): number[] | null {
  const matches = s.match(/-?\d*.?\d+(?:e[+-]?\d+)?/gi);
  if (!matches) return null;
  const nums = matches.map(Number).filter((x) => Number.isFinite(x));
  return nums.length >= 4 ? nums : null; // need at least a handful to call it embeddings
}

function arrayBufferToBase64(buffer: ArrayBuffer): string {
    let binary = "";
    const bytes = new Uint8Array(buffer);
    for (let i = 0; i < bytes.byteLength; i++) {
        binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
}

function floatsToPackedSummary(arr: number[]): string {
  const f32 = new Float32Array(arr);
  const b64f32 = arrayBufferToBase64(f32.buffer);
  const min = Math.min(...arr);
  const max = Math.max(...arr);
  const mean = arr.reduce((a, b) => a + b, 0) / arr.length;
  return [
    `Float array detected (len=${arr.length}).`,
    `min=${min.toFixed(4)}, max=${max.toFixed(4)}, mean=${mean.toFixed(4)}`,
    `Packed (copyable):`,
    `- Float32 (base64): ${b64f32}`,
    `Tip: Store embeddings as typed arrays (e.g., Float32Array).`,
  ].join("\n");
}

export function safeDecodeBigIntOrFloats(input: string): string {
  if (isIntegerString(input)) {
    try {
      return bigIntStringToText(input.trim());
    } catch (e: any) {
      return `Error: invalid BigInt string — ${e?.message || e}`;
    }
  }
  const strict = tryParseFloatArrayStrict(input);
  if (strict) return floatsToPackedSummary(strict);
  const loose = tryExtractFloatsLoose(input);
  if (loose) return floatsToPackedSummary(loose);
  return "Input not recognized. Provide a decimal integer string for BigInt→Text, or a JSON/multi-line array of floats for embeddings import.";
}

export function bellStateSimulation(theta: number): string {
  const cosT = Math.cos(theta);
  const sinT = Math.sin(theta);
  if (Number.isNaN(theta)) return "Error: invalid θ.";
  if (theta <= 0.01) return "θ≈0: perfect resonance (|Φ⁺⟩-like). Max correlation.";
  if (theta >= Math.PI - 0.01) return "θ≈π: perfect anti-resonance (|Ψ⁻⟩-like). Max anti-corr.";
  return `θ=${theta.toFixed(2)} → correlation ${(Math.abs(cosT) * 100).toFixed(1)}%, entanglement ${(Math.abs(sinT) * 100).toFixed(1)}%.`;
}

export function analyzeHarmonicSignature(text: string): string {
  if (!text) return "Awaiting input…";
  const L = text.length;
  const uniq = new Set(text).size;
  const complexity = L ? ((uniq / L) * 100).toFixed(2) : "0.00";
  const golden = (L * 1.618).toFixed(2);
  return `Signature — complexity ${complexity}%, conceptual f0 ${golden}`;
}

export function sha256Str(s: string): string {
    let h = 2166136261 >>> 0;
    for (let i = 0; i < s.length; i++) {
        h ^= s.charCodeAt(i);
        h = Math.imul(h, 16777619) >>> 0;
    }
    return `fnv1a32:${h.toString(16)}`;
}

export function hashish(s: string): string { return sha256Str(s); }

export function b64FromUtf8(s: string): string {
    return btoa(unescape(encodeURIComponent(s)));
}

export function mockRatio(arr: number[]): number {
    if (arr.length === 0) return 1;
    const max = Math.max(...arr);
    const avg = arr.reduce((a, b) => a + b, 0) / arr.length;
    const structure = Math.max(0, (max - avg) / Math.max(1, avg));
    return Number((1.00 + 1.2 * structure).toFixed(3));
}

export function tokensFromSeries(arr: number[]): string[] {
    return arr.map(v => `S${toBase36(Math.round(v))}`);
}

export function toBase36(n: number): string {
    if (n >= 0 && n <= 9) return String(n);
    if (n >= 10 && n <= 35) return String.fromCharCode(55 + n); // A-Z
    return "?";
}

export function deriveFeatures(arr: number[], binSec: number) {
    if (arr.length === 0) return { baseline: 0, peak: 0, areaSec: 0, fwhmSec: 0, durationSec: 0, muSec: 0 };
    const baseline = Math.min(arr[0] || 0, arr[arr.length - 1] || 0, 1);
    const peak = Math.max(...arr);
    const areaSec = arr.reduce((a, b) => a + b, 0) * binSec;
    const wsum = arr.reduce((a, b) => a + b, 0) || 1;
    const muIdx = arr.reduce((a, b, i) => a + b * i, 0) / wsum;
    const varIdx = arr.reduce((a, b, i) => a + b * Math.pow(i - muIdx, 2), 0) / wsum;
    const sigmaIdx = Math.sqrt(Math.max(varIdx, 1e-6));
    const fwhmSec = 2.35482 * sigmaIdx * binSec;
    const thr = baseline + 1;
    let longest = 0, run = 0;
    for (const v of arr) { run = (v > thr) ? run + 1 : 0; longest = Math.max(longest, run); }
    const durationSec = longest * binSec;
    return { baseline, peak, areaSec, fwhmSec, durationSec, muSec: muIdx * binSec };
}

export function fmtRatio(r: number | null | undefined): string {
    if (r === null || typeof r === 'undefined') return "—";
    if (r < 0.01) return r.toExponential(2);
    return r.toFixed(3);
}
