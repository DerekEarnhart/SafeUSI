# make_qho_plot.py
# Deterministic, dependency-light generator for Quantum Harmonic Oscillator plots.
# Author: Dereeeek (proof bundle)
import numpy as np
import matplotlib.pyplot as plt
import math

def hermite_phys(n, x):
    if n == 0:
        return np.ones_like(x)
    if n == 1:
        return 2*x
    Hn_2 = np.ones_like(x)
    Hn_1 = 2*x
    for k in range(1, n):
        Hn = 2*x*Hn_1 - 2*k*Hn_2
        Hn_2, Hn_1 = Hn_1, Hn
    return Hn_1

def psi_n(n, x):
    Hn = hermite_phys(n, x)
    norm = 1.0 / (math.sqrt((2**n) * math.factorial(n)) * (math.pi**0.25))
    return norm * np.exp(-x**2 / 2.0) * Hn

def make_plot(width_px, height_px, path_out, xlim=(-4,4), n_states=4):
    dpi = 200
    fig_w = width_px / dpi
    fig_h = height_px / dpi
    x = np.linspace(xlim[0], xlim[1], 1200)
    V = 0.5 * x**2
    plt.figure(figsize=(fig_w, fig_h), dpi=dpi)
    plt.plot(x, V, label="Potential V(x)")
    for n in range(n_states):
        psi = psi_n(n, x)
        En = n + 0.5
        plt.plot(x, psi + En, label=f"ψ_{n}(x)")
    plt.title("Quantum Harmonic Oscillator: V(x) and ψ_n(x)")
    plt.xlabel("x"); plt.ylabel("Energy / Wavefunction (shifted)")
    plt.legend(); plt.grid(True, linewidth=0.5, alpha=0.3); plt.tight_layout()
    plt.savefig(path_out, bbox_inches="tight"); plt.close()

if __name__ == "__main__":
    make_plot(1080, 1920, "qho_story_1080x1920.png")
    make_plot(1080, 1080, "qho_square_1080.png")
    print("Saved: qho_story_1080x1920.png, qho_square_1080.png")
