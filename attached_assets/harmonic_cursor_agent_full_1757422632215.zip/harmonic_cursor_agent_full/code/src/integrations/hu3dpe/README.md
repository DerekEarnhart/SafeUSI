# HU3DPE Integration

Drop `hu3dpe_client_bridge.js` into your browser UI to visualize agent state in 3D.
- Connect via WebSocket or poll an API.
- Shapes/aura color change with `consciousness` state: harmonic, stressed, low, neutral.
