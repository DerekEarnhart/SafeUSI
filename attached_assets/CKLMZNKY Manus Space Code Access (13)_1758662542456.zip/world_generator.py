import numpy as np
from opensimplex import OpenSimplex
from typing import Tuple, List

def generate_terrain_heightmap(width: int, height: int, scale: float, octaves: int, persistence: float, lacunarity: float, seed: int) -> List[List[float]]:
    simplex = OpenSimplex(seed=seed)
    heightmap = []
    for y in range(height):
        row = []
        for x in range(width):
            amplitude = 1.0
            frequency = 1.0
            noise_height = 0.0

            for _ in range(octaves):
                sample_x = x / scale * frequency
                sample_y = y / scale * frequency
                noise_height += simplex.noise2d(sample_x, sample_y) * amplitude

                amplitude *= persistence
                frequency *= lacunarity
            row.append(noise_height)
        heightmap.append(row)
    return heightmap

# Example usage (for testing purposes)
if __name__ == "__main__":
    # You would typically install opensimplex via pip: pip install opensimplex
    # For this example, we'll assume it's available.
    
    width = 100
    height = 100
    scale = 50.0
    octaves = 4
    persistence = 0.5
    lacunarity = 2.0
    seed = 12345

    heightmap = generate_terrain_heightmap(width, height, scale, octaves, persistence, lacunarity, seed)
    print(f"Generated heightmap of size {len(heightmap)}x{len(heightmap[0])}")
    # You can further process this heightmap to generate 3D mesh data or images.


