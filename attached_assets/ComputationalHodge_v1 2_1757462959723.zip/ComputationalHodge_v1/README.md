# Computational Hodge — v1 seed

This is a **minimal, runnable scaffold** for your plan:
- A **data schema** for Hodge-class rows (features + provenance + label).
- A **synthetic generator** so the ML pipeline runs immediately.
- Hooks so you can swap in **real K3 computations** (Sage/Magma/Macaulay2) later.

## Layout
```
ComputationalHodge_v1/
  src/
    features.py        # feature schema + synthetic features + (Sage) hooks
    provenance.py      # label provenance model
    build_dataset.py   # dataset builder script (runs synthetic now)
    train_baseline.py  # RF baseline + permutation importance + rule extraction
  data/
    hodge_seed.parquet # tiny seed dataset (synthetic, schema-correct)
  notebooks/
    quickstart.md      # step-by-step
```

## Quickstart (inside this folder)
```bash
python src/build_dataset.py   # regenerates data/hodge_seed.parquet
python src/train_baseline.py  # trains a baseline and prints top features/rules
```
Then iterate: replace synthetic stubs in `features.py` with your real K3/period/Picard machinery.
