
// hu3dpe_client_bridge.js
class HU3DPEBridge {
  constructor(opts = {}) {
    this.apiUrl = opts.apiUrl || null;
    this.wsUrl  = opts.wsUrl  || null;
    this.intervalMs = opts.intervalMs ?? 500;
    this.visualizer = null;
    this.timer = null;
    this.ws = null;
  }

  attach(visualizer) {
    this.visualizer = visualizer;
    if (this.wsUrl) this._connectWS();
    else if (this.apiUrl) this._startPolling();
    else console.warn("[HU3DPEBridge] No apiUrl or wsUrl provided.");
  }

  detach() {
    this.visualizer = null;
    if (this.timer) { clearInterval(this.timer); this.timer = null; }
    if (this.ws) { this.ws.close(); this.ws = null; }
  }

  _startPolling() {
    this.timer = setInterval(async () => {
      try {
        const res = await fetch(this.apiUrl, { cache: "no-store" });
        const data = await res.json();
        this._applyState(data);
      } catch (err) {
        console.error("[HU3DPEBridge] poll error:", err);
      }
    }, this.intervalMs);
  }

  _connectWS() {
    this.ws = new WebSocket(this.wsUrl);
    this.ws.addEventListener("open", () => console.log("[HU3DPEBridge] WS connected."));
    this.ws.addEventListener("close", () => {
      console.warn("[HU3DPEBridge] WS disconnected. Reconnecting in 1.5s...");
      setTimeout(() => this._connectWS(), 1500);
    });
    this.ws.addEventListener("message", (ev) => {
      try {
        const data = JSON.parse(ev.data);
        this._applyState(data);
      } catch (e) {
        console.error("[HU3DPEBridge] bad WS payload", e);
      }
    });
  }

  _applyState(s) {
    if (!this.visualizer) return;
    const id = s.entity_id || "BioBob";
    const pos = s.position || {x:0,y:0,z:0};
    const cons = s.consciousness || "neutral";
    const glucose = s.health_metrics?.blood_glucose;
    const hr = s.health_metrics?.heart_rate;

    const entity = this._getOrCreateEntity(id);
    entity.position.set(pos.x, pos.y, pos.z);
    this._applyConsciousnessVisual(entity, cons);

    const stats = document.querySelector("#stats");
    if (stats) {
      stats.textContent = `id=${id} | state=${cons} | glucose=${glucose?.toFixed?.(1)} mg/dL | HR=${hr?.toFixed?.(0)} bpm`;
    }
  }

  _getOrCreateEntity(id) {
    let obj = this.visualizer?.getEntity?.(id);
    if (!obj) {
      const geom = new THREE.SphereGeometry(0.6, 24, 24);
      const mat  = new THREE.MeshStandardMaterial({ color: 0x66ccff, metalness: 0.1, roughness: 0.7 });
      obj = new THREE.Mesh(geom, mat);
      obj.name = id;
      this.visualizer?.scene?.add?.(obj);
      const aura = new THREE.Mesh(
        new THREE.SphereGeometry(0.9, 16, 16),
        new THREE.MeshBasicMaterial({ color: 0x00ffff, transparent: true, opacity: 0.15 })
      );
      aura.name = "__aura";
      obj.add(aura);
      const light = new THREE.PointLight(0xffffff, 0.6, 5.0);
      light.name = "__light";
      obj.add(light);
    }
    return obj;
  }

  _applyConsciousnessVisual(obj, cons) {
    const aura = obj.getObjectByName("__aura");
    const setWireframe = (mesh, isWire) => {
      if (mesh && mesh.material) {
        mesh.material.wireframe = !!isWire;
        mesh.material.needsUpdate = true;
      }
    };

    switch (cons) {
      case "harmonic": {
        obj.geometry.dispose();
        obj.geometry = new THREE.OctahedronGeometry(0.7, 0);
        setWireframe(obj, true);
        if (aura?.material) { aura.material.color.set(0x00ffff); aura.material.opacity = 0.22; }
        break;
      }
      case "stressed": {
        obj.geometry.dispose();
        obj.geometry = new THREE.TetrahedronGeometry(0.7, 0);
        setWireframe(obj, false);
        if (aura?.material) { aura.material.color.set(0xff3344); aura.material.opacity = 0.25; }
        break;
      }
      case "low": {
        obj.geometry.dispose();
        obj.geometry = new THREE.SphereGeometry(0.6, 16, 16);
        setWireframe(obj, false);
        if (aura?.material) { aura.material.color.set(0x6699ff); aura.material.opacity = 0.12; }
        break;
      }
      default: {
        obj.geometry.dispose();
        obj.geometry = new THREE.SphereGeometry(0.6, 24, 24);
        setWireframe(obj, false);
        if (aura?.material) { aura.material.color.set(0x88eeaa); aura.material.opacity = 0.15; }
        break;
      }
    }
  }
}

window.HU3DPEBridge = HU3DPEBridge;
