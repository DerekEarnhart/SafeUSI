class EpisodicMemory:
    """
    Records experiences and interactions.
    """
    def __init__(self):
        self.episodes = []

    def add(self, episode):
        """Add an episodic record."""
        self.episodes.append(episode)
