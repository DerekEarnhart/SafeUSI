import React, { useEffect, useMemo, useState } from "react";

// Base Model Comparator — single-file React app
// - Add/edit multiple "base models" (your old prototypes)
// - Persist to localStorage
// - Pick any two and see a deep diff table
// - Start with your provided "Superhuman Prototype" prefilled
// - Clean, no external deps beyond Tailwind (canvas provides)

// ---------- Types ----------
const DEFAULT_MODEL = {
  name: "Unnamed Model",
  endpoint: "",
  streaming: false,
  reasoning: "optional", // hidden | optional | always
  personaSystem: "enum",
  proactivityPolicy: {
    idle_ms: 45000,
    cadence_ms: 20000,
    rng: 0.25,
    code_rng: 0.33,
    notes: "RNG-driven; triggers when idle>45s"
  },
  persistence: {
    store: "",
    schema: "",
    debounce_ms: 1500
  },
  securityPosture: {
    sanitize: false,
    csp: false,
    api_key_on_client: false
  },
  errorPolicy: {
    retries: 0,
    backoff: "none",
    onFail: "inline-chat-msg"
  },
  rendering: {
    markdownParser: "custom",
    codeFences: "naive backtick split",
    math: "KaTeX",
    notes: "dangerouslySetInnerHTML on unsanitized content"
  },
  extensibility: {
    tools: [],
    functionCalling: false,
    notes: ""
  },
  jsonContract: "strict {response, reasoning}",
  knownGotchas: [
    "XSS risk via dangerouslySetInnerHTML",
    "Strict JSON parse brittle",
    "No streaming → perceived latency",
    "Proactivity cadence feels random"
  ],
  extra: {}
};

// Prefill Model A (from your HTML base)
const PREFILL_SUPERHUMAN = {
  ...DEFAULT_MODEL,
  name: "Superhuman Prototype",
  endpoint: "Gemini 2.0 Flash / v1beta generateContent (JSON)",
  streaming: false,
  reasoning: "always",
  personaSystem: "select (hyper_analytical_oracle | phd_academic | simple_detailed | scientific)",
  proactivityPolicy: {
    idle_ms: 45000,
    cadence_ms: 20000,
    rng: 0.25,
    code_rng: 0.33,
    notes: "Idle watcher every 20s; if idle>45s and RNG passes, sends a proactive message; 33% chance of \"post-superhuman code report\" variant"
  },
  persistence: {
    store: "Firestore: artifacts/{appId}/users/{uid}/agi_state_superhuman/current",
    schema: "{conversationHistory: JSON, lastActiveTimestamp: number, settings: JSON}",
    debounce_ms: 1500
  },
  securityPosture: {
    sanitize: false,
    csp: false,
    api_key_on_client: false // (left blank in the snippet, good)
  },
  errorPolicy: {
    retries: 0,
    backoff: "none",
    onFail: "post error text into chat"
  },
  rendering: {
    markdownParser: "manual split on ```",
    codeFences: "basic",
    math: "KaTeX (integrity attr typo in snippet)",
    notes: "dangerouslySetInnerHTML + KaTeX renderMathInElement"
  },
  extensibility: {
    tools: [],
    functionCalling: false,
    notes: "Spontaneous messages use an internal prompt; no toolcalls"
  },
  jsonContract: "Strict JSON {response, reasoning}; parsed from model text → brittle if model adds prose",
  knownGotchas: [
    "XSS via unsanitized HTML",
    "No retries/backoff",
    "No streaming",
    "Non-deterministic proactivity cadence",
    "KaTeX integrity attr typo (xintegrity)"
  ],
  extra: {
    ui: "Tailwind, single-file UMD React",
    charts: "Chart.js included (unused in base)"
  }
};

// ---------- Utilities ----------
function deepClone(v) {
  return JSON.parse(JSON.stringify(v));
}

function saveModels(models) {
  localStorage.setItem("modelComparator.models", JSON.stringify(models));
}

function loadModels() {
  try {
    const raw = localStorage.getItem("modelComparator.models");
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

// Deep diff returning entries like { path: 'a.b.c', a: valA, b: valB }
function deepDiff(a, b, basePath = []) {
  const keys = new Set([...(a ? Object.keys(a) : []), ...(b ? Object.keys(b) : [])]);
  const out = [];
  for (const k of keys) {
    const pa = a ? a[k] : undefined;
    const pb = b ? b[k] : undefined;
    const path = [...basePath, k];

    const bothObjects =
      pa && pb && typeof pa === "object" && typeof pb === "object" && !Array.isArray(pa) && !Array.isArray(pb);

    if (bothObjects) {
      out.push(...deepDiff(pa, pb, path));
      continue;
    }

    const same = JSON.stringify(pa) === JSON.stringify(pb);
    if (!same) out.push({ path: path.join("."), a: pa, b: pb });
  }
  return out;
}

// Pretty value printer
function pretty(v) {
  if (v === undefined) return "—";
  if (typeof v === "string") return v;
  return "```\n" + JSON.stringify(v, null, 2) + "\n```";
}

// ---------- Components ----------
function Header() {
  return (
    <div className="w-full flex items-center justify-between p-4 bg-slate-900/80 border-b border-slate-800 rounded-t-2xl">
      <div>
        <h1 className="text-xl md:text-2xl font-bold tracking-tight">Base Model Comparator</h1>
        <p className="text-slate-400 text-sm">Line up your old bases and see what actually changed.</p>
      </div>
      <div className="text-xs text-slate-400">v1</div>
    </div>
  );
}

function ModelCard({ model, isActive, onClick }) {
  return (
    <button
      className={`w-full text-left p-3 rounded-xl border ${
        isActive ? "border-indigo-500 bg-indigo-500/10" : "border-slate-800 hover:border-slate-700"
      }`}
      onClick={onClick}
    >
      <div className="font-semibold">{model.name || "Unnamed"}</div>
      <div className="text-xs text-slate-400 line-clamp-2">{model.endpoint || "—"}</div>
    </button>
  );
}

function Field({ label, children }) {
  return (
    <label className="block">
      <div className="text-xs font-medium text-slate-300 mb-1">{label}</div>
      {children}
    </label>
  );
}

function TextInput({ value, onChange, placeholder }) {
  return (
    <input
      className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
    />
  );
}

function TextArea({ value, onChange, rows = 3, placeholder }) {
  return (
    <textarea
      rows={rows}
      className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
    />
  );
}

function Bool({ value, onChange }) {
  return (
    <button
      onClick={() => onChange(!value)}
      className={`px-3 py-2 rounded-lg border ${
        value ? "bg-emerald-600/20 border-emerald-500 text-emerald-200" : "bg-slate-900 border-slate-700 text-slate-300"
      }`}
    >
      {value ? "Enabled" : "Disabled"}
    </button>
  );
}

function KeyValueEditor({ object, onChange, title, hint }) {
  const [entries, setEntries] = useState(() => Object.entries(object || {}));

  useEffect(() => setEntries(Object.entries(object || {})), [object]);

  const update = (idx, key, val) => {
    const next = entries.map((e, i) => (i === idx ? [key, val] : e));
    setEntries(next);
    onChange(Object.fromEntries(next));
  };

  const addRow = () => {
    const next = [...entries, ["key", "value"]];
    setEntries(next);
    onChange(Object.fromEntries(next));
  };

  const remove = (idx) => {
    const next = entries.filter((_, i) => i !== idx);
    setEntries(next);
    onChange(Object.fromEntries(next));
  };

  return (
    <div className="space-y-2">
      <div className="text-sm font-semibold text-slate-200">{title}</div>
      {hint && <div className="text-xs text-slate-400 -mt-1">{hint}</div>}
      {entries.map(([k, v], i) => (
        <div key={i} className="grid grid-cols-2 gap-2">
          <input
            className="px-2 py-1 rounded bg-slate-900 border border-slate-800"
            value={k}
            onChange={(e) => update(i, e.target.value, v)}
          />
          <input
            className="px-2 py-1 rounded bg-slate-900 border border-slate-800"
            value={v}
            onChange={(e) => update(i, k, e.target.value)}
          />
          <button className="col-span-2 text-left text-xs text-rose-300" onClick={() => remove(i)}>
            remove
          </button>
        </div>
      ))}
      <button className="text-xs text-indigo-300" onClick={addRow}>
        + add
      </button>
    </div>
  );
}

function ArrayEditor({ items, onChange, title }) {
  const [arr, setArr] = useState(items || []);
  useEffect(() => setArr(items || []), [items]);
  const update = (idx, val) => {
    const next = arr.map((x, i) => (i === idx ? val : x));
    setArr(next);
    onChange(next);
  };
  const add = () => {
    const next = [...arr, "new item"];
    setArr(next);
    onChange(next);
  };
  const remove = (idx) => {
    const next = arr.filter((_, i) => i !== idx);
    setArr(next);
    onChange(next);
  };
  return (
    <div className="space-y-2">
      <div className="text-sm font-semibold text-slate-200">{title}</div>
      {arr.map((v, i) => (
        <div key={i} className="flex gap-2">
          <input
            className="flex-1 px-2 py-1 rounded bg-slate-900 border border-slate-800"
            value={v}
            onChange={(e) => update(i, e.target.value)}
          />
          <button className="text-xs text-rose-300" onClick={() => remove(i)}>
            remove
          </button>
        </div>
      ))}
      <button className="text-xs text-indigo-300" onClick={add}>
        + add
      </button>
    </div>
  );
}

function ModelEditor({ model, onChange }) {
  if (!model) return <div className="text-slate-400">Select a model to edit.</div>;
  return (
    <div className="space-y-4">
      <Field label="Name">
        <TextInput value={model.name} onChange={(v) => onChange({ ...model, name: v })} placeholder="Model name" />
      </Field>
      <Field label="Endpoint">
        <TextInput value={model.endpoint} onChange={(v) => onChange({ ...model, endpoint: v })} placeholder="e.g., Gemini 2.0 Flash / JSON" />
      </Field>

      <div className="grid grid-cols-2 gap-4">
        <Field label="Streaming">
          <Bool value={model.streaming} onChange={(v) => onChange({ ...model, streaming: v })} />
        </Field>
        <Field label="Reasoning surfaced">
          <select
            className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-800"
            value={model.reasoning}
            onChange={(e) => onChange({ ...model, reasoning: e.target.value })}
          >
            <option>hidden</option>
            <option>optional</option>
            <option>always</option>
          </select>
        </Field>
      </div>

      <Field label="Persona system">
        <TextInput value={model.personaSystem} onChange={(v) => onChange({ ...model, personaSystem: v })} placeholder="enum / free-text / weighted, etc." />
      </Field>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="space-y-3 p-3 rounded-xl border border-slate-800">
          <div className="text-sm font-semibold text-slate-200">Proactivity policy</div>
          <div className="grid grid-cols-2 gap-2">
            <Field label="Idle (ms)">
              <TextInput
                value={model.proactivityPolicy.idle_ms}
                onChange={(v) => onChange({ ...model, proactivityPolicy: { ...model.proactivityPolicy, idle_ms: Number(v) || 0 } })}
                placeholder="45000"
              />
            </Field>
            <Field label="Cadence (ms)">
              <TextInput
                value={model.proactivityPolicy.cadence_ms}
                onChange={(v) => onChange({ ...model, proactivityPolicy: { ...model.proactivityPolicy, cadence_ms: Number(v) || 0 } })}
                placeholder="20000"
              />
            </Field>
            <Field label="RNG">
              <TextInput
                value={model.proactivityPolicy.rng}
                onChange={(v) => onChange({ ...model, proactivityPolicy: { ...model.proactivityPolicy, rng: Number(v) || 0 } })}
                placeholder="0.25"
              />
            </Field>
            <Field label="Code RNG">
              <TextInput
                value={model.proactivityPolicy.code_rng}
                onChange={(v) => onChange({ ...model, proactivityPolicy: { ...model.proactivityPolicy, code_rng: Number(v) || 0 } })}
                placeholder="0.33"
              />
            </Field>
          </div>
          <Field label="Notes">
            <TextArea
              rows={2}
              value={model.proactivityPolicy.notes || ""}
              onChange={(v) => onChange({ ...model, proactivityPolicy: { ...model.proactivityPolicy, notes: v } })}
            />
          </Field>
        </div>

        <div className="space-y-3 p-3 rounded-xl border border-slate-800">
          <div className="text-sm font-semibold text-slate-200">Persistence</div>
          <Field label="Store">
            <TextInput
              value={model.persistence.store}
              onChange={(v) => onChange({ ...model, persistence: { ...model.persistence, store: v } })}
              placeholder="e.g., Firestore path"
            />
          </Field>
          <Field label="Schema">
            <TextArea
              rows={2}
              value={model.persistence.schema}
              onChange={(v) => onChange({ ...model, persistence: { ...model.persistence, schema: v } })}
            />
          </Field>
          <Field label="Debounce (ms)">
            <TextInput
              value={model.persistence.debounce_ms}
              onChange={(v) => onChange({ ...model, persistence: { ...model.persistence, debounce_ms: Number(v) || 0 } })}
              placeholder="1500"
            />
          </Field>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        <div className="space-y-3 p-3 rounded-xl border border-slate-800">
          <div className="text-sm font-semibold text-slate-200">Security posture</div>
          <div className="grid grid-cols-2 gap-2">
            <Field label="Sanitize">
              <Bool
                value={model.securityPosture.sanitize}
                onChange={(v) => onChange({ ...model, securityPosture: { ...model.securityPosture, sanitize: v } })}
              />
            </Field>
            <Field label="CSP">
              <Bool
                value={model.securityPosture.csp}
                onChange={(v) => onChange({ ...model, securityPosture: { ...model.securityPosture, csp: v } })}
              />
            </Field>
            <Field label="API key on client">
              <Bool
                value={model.securityPosture.api_key_on_client}
                onChange={(v) => onChange({ ...model, securityPosture: { ...model.securityPosture, api_key_on_client: v } })}
              />
            </Field>
          </div>
        </div>

        <div className="space-y-3 p-3 rounded-xl border border-slate-800">
          <div className="text-sm font-semibold text-slate-200">Error policy</div>
          <Field label="Retries">
            <TextInput
              value={model.errorPolicy.retries}
              onChange={(v) => onChange({ ...model, errorPolicy: { ...model.errorPolicy, retries: Number(v) || 0 } })}
              placeholder="0"
            />
          </Field>
          <Field label="Backoff">
            <TextInput
              value={model.errorPolicy.backoff}
              onChange={(v) => onChange({ ...model, errorPolicy: { ...model.errorPolicy, backoff: v } })}
              placeholder="none | jittered | exponential"
            />
          </Field>
          <Field label="On fail">
            <TextInput
              value={model.errorPolicy.onFail}
              onChange={(v) => onChange({ ...model, errorPolicy: { ...model.errorPolicy, onFail: v } })}
              placeholder="toast | inline-chat-msg | silent"
            />
          </Field>
        </div>

        <div className="space-y-3 p-3 rounded-xl border border-slate-800">
          <div className="text-sm font-semibold text-slate-200">Rendering</div>
          <Field label="Markdown parser">
            <TextInput
              value={model.rendering.markdownParser}
              onChange={(v) => onChange({ ...model, rendering: { ...model.rendering, markdownParser: v } })}
              placeholder="markdown-it, etc."
            />
          </Field>
          <Field label="Code fences">
            <TextInput
              value={model.rendering.codeFences}
              onChange={(v) => onChange({ ...model, rendering: { ...model.rendering, codeFences: v } })}
              placeholder="naive | fenced"
            />
          </Field>
          <Field label="Math">
            <TextInput
              value={model.rendering.math}
              onChange={(v) => onChange({ ...model, rendering: { ...model.rendering, math: v } })}
              placeholder="KaTeX / MathJax"
            />
          </Field>
          <Field label="Notes">
            <TextArea
              rows={2}
              value={model.rendering.notes}
              onChange={(v) => onChange({ ...model, rendering: { ...model.rendering, notes: v } })}
            />
          </Field>
        </div>
      </div>

      <Field label="Extensibility notes">
        <TextArea
          rows={2}
          value={model.extensibility.notes}
          onChange={(v) => onChange({ ...model, extensibility: { ...model.extensibility, notes: v } })}
        />
      </Field>

      <Field label="JSON Contract">
        <TextInput
          value={model.jsonContract}
          onChange={(v) => onChange({ ...model, jsonContract: v })}
          placeholder="strict {response, reasoning}"
        />
      </Field>

      <ArrayEditor
        title="Known gotchas"
        items={model.knownGotchas}
        onChange={(arr) => onChange({ ...model, knownGotchas: arr })}
      />

      <KeyValueEditor
        title="Extra key/values"
        hint="Freeform fields for anything unique to this model"
        object={model.extra}
        onChange={(obj) => onChange({ ...model, extra: obj })}
      />
    </div>
  );
}

function DiffTable({ a, b }) {
  const rows = useMemo(() => (a && b ? deepDiff(a, b) : []), [a, b]);
  if (!a || !b) return <div className="text-slate-400">Pick two models to compare.</div>;
  if (rows.length === 0)
    return (
      <div className="text-emerald-300">No differences found. These two are functionally identical in recorded traits.</div>
    );
  return (
    <div className="overflow-auto">
      <table className="min-w-full text-sm">
        <thead className="bg-slate-900/60 sticky top-0">
          <tr>
            <th className="text-left p-2 w-1/3">Field</th>
            <th className="text-left p-2 w-1/3">A: {a?.name || "—"}</th>
            <th className="text-left p-2 w-1/3">B: {b?.name || "—"}</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i} className="border-t border-slate-800 align-top">
              <td className="p-2 font-mono text-xs text-slate-400">{r.path}</td>
              <td className="p-2">
                <div className="whitespace-pre-wrap text-slate-200">{pretty(r.a)}</div>
              </td>
              <td className="p-2">
                <div className="whitespace-pre-wrap text-slate-200">{pretty(r.b)}</div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function Toolbar({ onAdd, onDuplicate, onDelete, onImport, onExport, canDuplicate, canDelete }) {
  return (
    <div className="flex flex-wrap gap-2 items-center">
      <button className="px-3 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500" onClick={onAdd}>
        + New model
      </button>
      <button
        className={`px-3 py-2 rounded-lg ${canDuplicate ? "bg-slate-700 hover:bg-slate-600" : "bg-slate-800 text-slate-500"}`}
        disabled={!canDuplicate}
        onClick={onDuplicate}
      >
        Duplicate
      </button>
      <button
        className={`px-3 py-2 rounded-lg ${canDelete ? "bg-rose-700/80 hover:bg-rose-600" : "bg-slate-800 text-slate-500"}`}
        disabled={!canDelete}
        onClick={onDelete}
      >
        Delete
      </button>
      <button className="px-3 py-2 rounded-lg bg-slate-700 hover:bg-slate-600" onClick={onExport}>
        Export JSON
      </button>
      <label className="px-3 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 cursor-pointer">
        Import JSON
        <input type="file" accept="application/json" className="hidden" onChange={onImport} />
      </label>
    </div>
  );
}

export default function App() {
  const [models, setModels] = useState(() => loadModels() || [PREFILL_SUPERHUMAN]);
  const [activeIdx, setActiveIdx] = useState(0);
  const [diffA, setDiffA] = useState(0);
  const [diffB, setDiffB] = useState(models.length > 1 ? 1 : 0);

  // Persist
  useEffect(() => {
    saveModels(models);
    // Adjust selection bounds if models changed
    if (activeIdx >= models.length) setActiveIdx(models.length - 1);
    if (diffA >= models.length) setDiffA(models.length - 1);
    if (diffB >= models.length) setDiffB(models.length - 1);
  }, [models]);

  const updateModel = (idx, next) => {
    setModels((m) => m.map((x, i) => (i === idx ? deepClone(next) : x)));
  };

  const addModel = () => {
    setModels((m) => [...m, deepClone(DEFAULT_MODEL)]);
    setActiveIdx(models.length);
  };

  const duplicateModel = () => {
    if (activeIdx == null) return;
    setModels((m) => {
      const cp = deepClone(m[activeIdx]);
      cp.name = cp.name + " (copy)";
      return [...m, cp];
    });
  };

  const deleteModel = () => {
    if (activeIdx == null) return;
    setModels((m) => m.filter((_, i) => i !== activeIdx));
    setActiveIdx(0);
  };

  const exportJSON = () => {
    const blob = new Blob([JSON.stringify(models, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "base-models.json";
    a.click();
    URL.revokeObjectURL(url);
  };

  const importJSON = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(reader.result);
        if (!Array.isArray(parsed)) throw new Error("Invalid JSON format: expected an array of models");
        setModels(parsed);
      } catch (err) {
        alert("Import failed: " + err.message);
      }
    };
    reader.readAsText(file);
  };

  const activeModel = models[activeIdx];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-4 md:p-8">
      <div className="max-w-7xl mx-auto border border-slate-800 rounded-2xl overflow-hidden shadow-2xl">
        <Header />
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-0">
          {/* Sidebar: model list */}
          <div className="lg:col-span-1 p-4 bg-slate-950 border-r border-slate-800 space-y-3">
            <Toolbar
              onAdd={addModel}
              onDuplicate={duplicateModel}
              onDelete={deleteModel}
              onExport={exportJSON}
              onImport={importJSON}
              canDuplicate={models.length > 0}
              canDelete={models.length > 0}
            />
            <div className="grid gap-2 mt-2">
              {models.map((m, i) => (
                <ModelCard key={i} model={m} isActive={i === activeIdx} onClick={() => setActiveIdx(i)} />
              ))}
            </div>
          </div>

          {/* Editor */}
          <div className="lg:col-span-2 p-4 bg-slate-950/60">
            <div className="text-sm font-semibold mb-3">Model editor</div>
            <ModelEditor model={activeModel} onChange={(v) => updateModel(activeIdx, v)} />
          </div>

          {/* Diff */}
          <div className="lg:col-span-1 p-4 bg-slate-950/60 border-l border-slate-800">
            <div className="text-sm font-semibold mb-3">Compare</div>
            <div className="flex gap-2 mb-3">
              <select
                className="flex-1 px-3 py-2 rounded-lg bg-slate-900 border border-slate-800"
                value={diffA}
                onChange={(e) => setDiffA(Number(e.target.value))}
              >
                {models.map((m, i) => (
                  <option key={i} value={i}>
                    A: {m.name}
                  </option>
                ))}
              </select>
              <select
                className="flex-1 px-3 py-2 rounded-lg bg-slate-900 border border-slate-800"
                value={diffB}
                onChange={(e) => setDiffB(Number(e.target.value))}
              >
                {models.map((m, i) => (
                  <option key={i} value={i}>
                    B: {m.name}
                  </option>
                ))}
              </select>
            </div>
            <div className="h-[55vh] rounded-xl border border-slate-800 p-2 bg-slate-950 overflow-auto">
              <DiffTable a={models[diffA]} b={models[diffB]} />
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto mt-6 grid lg:grid-cols-2 gap-4">
        <div className="p-4 rounded-2xl border border-slate-800 bg-slate-950/80">
          <div className="text-sm font-semibold">How to use</div>
          <ol className="text-sm text-slate-300 list-decimal ml-4 mt-2 space-y-1">
            <li>Click <span className="text-indigo-300">+ New model</span> to add each old base you want to compare.</li>
            <li>Paste traits into the editor (endpoint, streaming, reasoning, etc.).</li>
            <li>Use the <span className="text-indigo-300">Compare</span> pickers at right to view differences.</li>
            <li>Export/Import JSON to move this list between machines or save a snapshot.</li>
          </ol>
        </div>
        <div className="p-4 rounded-2xl border border-slate-800 bg-slate-950/80">
          <div className="text-sm font-semibold">Tips</div>
          <ul className="text-sm text-slate-300 list-disc ml-4 mt-2 space-y-1">
            <li>Keep <span className="text-slate-200">known gotchas</span> honest—surface them as blockers to merge-forward decisions.</li>
            <li>Use <span className="text-slate-200">extra</span> for anything quirky (UI libs, auth nuances, rate limits).</li>
            <li>When two models match, differences will collapse to none—nice signal that they're functionally identical by traits.</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
