from __future__ import annotations
from typing import List, Dict

def naive_plan(task: str) -> List[Dict]:
    # toy planner: split by punctuation and heuristics
    steps = []
    shards = [s.strip() for s in task.replace("->", ".").replace(";", ".").split(".") if s.strip()]
    for i, s in enumerate(shards, 1):
        tag = "analyze" if i == 1 else ("implement" if i == len(shards) else "research")
        steps.append({"id": i, "kind": tag, "text": s})
    if not steps:
        steps = [{"id": 1, "kind": "analyze", "text": task}]
    return steps
