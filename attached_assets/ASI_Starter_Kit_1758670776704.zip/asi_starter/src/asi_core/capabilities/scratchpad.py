from ..capability import Capability

class EchoCapability(Capability):
    def __init__(self):
        super().__init__(name="echo", description="Echo inputs for testing")

    def invoke(self, inputs, context=None):
        return {"echo": inputs}
