import os, json, httpx, sqlite3
from fastapi import FastAPI, Request, Response, HTTPException
from pydantic import BaseModel
from dotenv import load_dotenv
from utils import getenv
from hpqcc import compress as hp_compress, decompress as hp_decompress

load_dotenv(dotenv_path=os.path.join(os.path.dirname(__file__), "..", ".env"))
app = FastAPI(title="HRDE Upstream")

class InferIn(BaseModel):
    prompt: str
    max_tokens: int = 256

@app.post("/v1/infer")
async def infer(body: InferIn, request: Request):
    provider = os.getenv("MODEL_PROVIDER", "custom")
    base = getenv("MODEL_BASE_URL", "http://127.0.0.1:9999")
    key = os.getenv("MODEL_API_KEY", "")
    full_prompt = body.prompt + rag_hints(body.prompt)
    if provider in {"openai","openrouter"}:
        url = f"{base}/v1/chat/completions"
        headers = {"Authorization": f"Bearer {key}"} if key else {}
        payload = {"model": os.getenv("MODEL_NAME","gpt-4o-mini"), "messages":[{"role":"user","content": full_prompt}], "max_tokens": body.max_tokens, "temperature": float(os.getenv("TEMP","0.2"))}
    else:
        url = f"{base}/v1/infer"
        hdr = os.getenv("CUSTOM_AUTH_HEADER","Authorization"); pfx = os.getenv("CUSTOM_AUTH_PREFIX","Bearer")
        headers = {hdr: f"{pfx} {key}"} if key else {}
        payload = {"prompt": full_prompt, "max_tokens": body.max_tokens}
    async with httpx.AsyncClient(timeout=60.0) as cx: r = await cx.post(url, headers=headers, json=payload)
    if r.status_code >= 300: raise HTTPException(status_code=502, detail=r.text)
    try:
        j = r.json()
        txt = j["choices"][0]["message"]["content"] if provider in {"openai","openrouter"} else (j.get("text") or j.get("output") or json.dumps(j))
    except Exception:
        txt = r.text; j = {}
    return {"text": txt, "usage": j.get("usage") if isinstance(j, dict) else None}

@app.get("/v1/metrics")
async def metrics(): return {"ok": True, "provider": os.getenv("MODEL_PROVIDER","custom")}

@app.post("/v1/hpqcc/compress")
async def hpqcc_compress(request: Request):
    data = await request.body(); return Response(content=hp_compress(data), media_type="application/octet-stream")

@app.post("/v1/hpqcc/decompress")
async def hpqcc_decompress(request: Request):
    data = await request.body(); return Response(content=hp_decompress(data), media_type="application/octet-stream")

def rag_hints(prompt: str) -> str:
    if os.getenv("ENABLE_RAG","0") != "1": return ""
    db = os.getenv("KNOWLEDGE_DB")
    if not db or not os.path.exists(db): return ""
    try:
        conn = sqlite3.connect(db); cur = conn.cursor(); cur.execute("SELECT content FROM docs ORDER BY id DESC LIMIT 5"); rows = cur.fetchall(); conn.close()
        snippets = "\n\n".join(r[0][:400] for r in rows); return f"\n\n[HINTS]\n{snippets}\n[/HINTS]"
    except Exception: return ""
