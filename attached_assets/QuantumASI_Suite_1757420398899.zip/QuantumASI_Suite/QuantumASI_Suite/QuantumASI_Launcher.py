#!/usr/bin/env python3
"""
Quantum ASI Suite Launcher
==========================
Main entry point for the complete Quantum Manifold ASI system
"""

import tkinter as tk
from tkinter import messagebox
import sys
import os
from pathlib import Path

# Add paths for imports
current_dir = Path(__file__).parent
sys.path.insert(0, str(current_dir / 'core'))
sys.path.insert(0, str(current_dir / 'gui'))

try:
    from api_setup_dialog import APISetupDialog
    from quantum_unified_core import create_quantum_asi
except ImportError as e:
    messagebox.showerror("Import Error", f"Failed to import components: {e}")
    sys.exit(1)

def check_dependencies():
    """Check if required dependencies are installed"""
    missing = []
    
    try:
        import numpy
    except ImportError:
        missing.append("numpy")
    
    try:
        import requests
    except ImportError:
        missing.append("requests")
    
    if missing:
        messagebox.showwarning(
            "Missing Dependencies",
            f"Please install: {', '.join(missing)}\n\nRun: pip install {' '.join(missing)}"
        )
        return False
    
    return True

def main():
    """Main launcher function"""
    
    # Check dependencies first
    if not check_dependencies():
        return
    
    # Create initial window for API setup
    root = tk.Tk()
    root.withdraw()  # Hide main window initially
    
    # Show splash screen
    splash = tk.Toplevel()
    splash.title("Quantum ASI Suite")
    splash.geometry("400x300")
    splash.configure(bg='#0a0a0a')
    splash.resizable(False, False)
    
    # Center splash screen
    splash.update_idletasks()
    x = (splash.winfo_screenwidth() // 2) - (400 // 2)
    y = (splash.winfo_screenheight() // 2) - (300 // 2)
    splash.geometry(f"400x300+{x}+{y}")
    
    # Splash content
    splash_frame = tk.Frame(splash, bg='#0a0a0a')
    splash_frame.pack(expand=True, fill='both', padx=20, pady=20)
    
    title_label = tk.Label(splash_frame,
                          text="🌌 QUANTUM MANIFOLD ASI 🧠",
                          bg='#0a0a0a', fg='#00ffff',
                          font=('Consolas', 16, 'bold'))
    title_label.pack(pady=20)
    
    subtitle_label = tk.Label(splash_frame,
                             text="Harmonic Unified Framework\nwith Gemini 2.5 Flash Integration",
                             bg='#0a0a0a', fg='#ffffff',
                             font=('Consolas', 10),
                             justify=tk.CENTER)
    subtitle_label.pack(pady=10)
    
    author_label = tk.Label(splash_frame,
                           text="Author: Derek Zeller\nHolographic Studios Consulting",
                           bg='#0a0a0a', fg='#888888',
                           font=('Consolas', 9),
                           justify=tk.CENTER)
    author_label.pack(pady=20)
    
    # Loading message
    loading_label = tk.Label(splash_frame,
                            text="Initializing quantum consciousness...",
                            bg='#0a0a0a', fg='#ffff00',
                            font=('Consolas', 10))
    loading_label.pack(pady=10)
    
    # Start button
    def start_asi():
        splash.destroy()
        
        # Show API setup dialog
        api_dialog = APISetupDialog(root)
        config = api_dialog.show()
        
        if config:
            # Start main application
            try:
                from quantum_asi_gui import QuantumASIGUI
                
                # Configure the ASI with API settings
                root.deiconify()
                app = QuantumASIGUI(root)
                
                # Pass API configuration to the app
                if hasattr(app, 'set_api_config'):
                    app.set_api_config(config)
                
                root.mainloop()
                
            except Exception as e:
                messagebox.showerror("Launch Error", f"Failed to start ASI: {e}")
        else:
            # User cancelled
            root.destroy()
    
    start_button = tk.Button(splash_frame,
                            text="🚀 Launch Quantum ASI",
                            command=start_asi,
                            bg='#1a1a1a', fg='#00ffff',
                            font=('Consolas', 12, 'bold'),
                            padx=20, pady=10)
    start_button.pack(pady=30)
    
    root.mainloop()

if __name__ == "__main__":
    main()