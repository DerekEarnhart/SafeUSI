from __future__ import annotations
from typing import List, Dict, Any
import numpy as np
import hashlib

class InMemoryVectorStore:
    def __init__(self, top_k: int = 8):
        self.top_k = top_k
        self._store = []  # list of (vec, meta)

    def _embed(self, text: str) -> np.ndarray:
        # very lightweight deterministic pseudo-embedding using hashing buckets
        h = hashlib.sha256(text.encode("utf-8")).digest()
        arr = np.frombuffer(h, dtype=np.uint8).astype(np.float32)
        # pad/reshape to a fixed size
        vec = np.tile(arr, 8)[:512].astype(np.float32)
        # normalize
        norm = np.linalg.norm(vec) + 1e-8
        return vec / norm

    def add(self, text: str, meta: Dict[str, Any]):
        self._store.append((self._embed(text), meta))

    def search(self, query: str, top_k: int = None) -> List[Dict[str, Any]]:
        k = top_k or self.top_k
        q = self._embed(query)
        scored = []
        for vec, meta in self._store:
            score = float(np.dot(q, vec))
            scored.append((score, meta))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [ {"score": s, **m} for s, m in scored[:k] ]
