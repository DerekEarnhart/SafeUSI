class ConversationalInterface:
    """
    Text-based natural language interaction.
    """
    def send(self, text):
        # TODO: implement send logic
        pass
