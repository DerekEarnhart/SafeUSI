import argparse, json, time, threading, queue, httpx
def worker(tasks: queue.Queue, base: str, api_key: str, stats: dict):
    while True:
        item = tasks.get()
        if item is None: break
        t0 = time.time()
        try:
            r = httpx.post(f"{base}/v1/infer", headers={"X-API-Key": "devkey123", "Authorization": f"Bearer {api_key}"}, json={"prompt": item, "max_tokens": 64}, timeout=60.0)
            r.raise_for_status(); stats["lats"].append(time.time()-t0)
        except Exception:
            stats["errs"].append(time.time()-t0)
        finally:
            tasks.task_done()
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-url", required=True); ap.add_argument("--api-key", required=True); ap.add_argument("--dataset", required=True)
    ap.add_argument("--concurrency", type=int, default=8); ap.add_argument("--requests", type=int, default=100); ap.add_argument("--warmup", type=int, default=10)
    a = ap.parse_args()
    data = [json.loads(l)["prompt"] for l in open(a.dataset)]; tasks=queue.Queue(); stats={"lats":[], "errs":[]}
    for _ in range(a.warmup): tasks.put(data[_%len(data)])
    for _ in range(a.requests): tasks.put(data[_%len(data)])
    for _ in range(a.concurrency): tasks.put(None)
    threads=[threading.Thread(target=worker, args=(tasks,a.base_url,a.api_key,stats)) for _ in range(a.concurrency)]
    [t.start() for t in threads]; tasks.join()
    def pct(p,xs): xs=sorted(xs); i=max(0,int(len(xs)*p/100)-1); return xs[i] if xs else 0
    rep={"count":len(stats["lats"]), "errors":len(stats["errs"]), "p50":pct(50,stats["lats"]), "p90":pct(90,stats["lats"]), "p99":pct(99,stats["lats"]), "throughput": (len(stats["lats"])/max(1e-6,sum(stats["lats"])) if stats["lats"] else 0)}
    print(json.dumps(rep, indent=2))
if __name__ == "__main__": main()
