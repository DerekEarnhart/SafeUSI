# Harmonic Oscillator Factor + Voynich Research Toolkit

This repository bundles:
- **CCR/HO factor playground** (FastAPI service) – minimal Lindblad stepper.
- **Voynich analysis toolkit** – frequency-based decoder + harmonic signal analyzer.
- **Manuscript v1.2** – archived in `docs/` with a PDF export.

## Quick start (Python only)
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/Mac: source .venv/bin/activate
pip install -r requirements.txt

# run API (Lindblad playground)
PYTHONPATH=src uvicorn hofa.scripts.run_server:app --app-dir src --reload

# use Voynich CLI
PYTHONPATH=src python -m voynich.cli --file samples/voynich_snippet.txt
```

## Makefile shortcuts
```bash
make dev     # venv + install deps (posix style)
make test    # run pytest
make docs    # build docs/manuscript_v1.2.pdf (simple text rendering)
```

## Structure
```
src/
  hofa/             # CCR factor demo API
  voynich/          # Voynich tools and CLI
docs/
  manuscript_v1.2.md (and .pdf)
notebooks/
  03_voynich_decoder.ipynb  # demo
tests/
  test_seti.py
  test_voynich.py
```
