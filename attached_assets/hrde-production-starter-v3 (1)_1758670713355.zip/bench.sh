#!/usr/bin/env bash
set -euo pipefail
cd bench
python bench.py --base-url http://127.0.0.1:8787 --api-key "${MODEL_API_KEY:-changeme}" --dataset datasets/toy_qa.jsonl --concurrency 8 --requests 200 --warmup 20
