# ProactiveV02

A full-stack application with backend API and frontend interface for model interaction with flexible API key management.

## Features

- **Backend API**: FastAPI-based backend with OpenAI integration
- **Frontend Interface**: React-based modern UI
- **Flexible API Key Management**: Multiple ways to configure API keys
- **Real-time Chat**: Interactive model conversation
- **Responsive Design**: Works on desktop and mobile

## Project Structure

```
ProactiveV02/
├── backend/           # FastAPI backend
│   ├── main.py       # Main application
│   ├── requirements.txt
│   └── env.example
├── frontend/         # React frontend
│   ├── src/
│   ├── public/
│   └── package.json
└── README.md
```

## Setup Instructions

### Backend Setup

1. Navigate to the backend directory:
   ```bash
   cd backend
   ```

2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Configure API key (choose one method):
   - **Environment Variable**: Create `.env` file with `OPENAI_API_KEY=your_key_here`
   - **Runtime Setup**: Use the `/setup` endpoint after starting the server

4. Start the backend server:
   ```bash
   uvicorn main:app --reload
   ```

### Frontend Setup

1. Navigate to the frontend directory:
   ```bash
   cd frontend
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Start the development server:
   ```bash
   npm start
   ```

## API Endpoints

- `POST /chat` - Main chat endpoint for model interaction
- `POST /setup` - Configure API key at runtime
- `GET /health` - Health check endpoint

## API Key Management

The application supports three ways to manage your API key:

1. **Environment Variable**: Set `OPENAI_API_KEY` in backend `.env` file
2. **Runtime Setup**: Use `POST /setup` endpoint with `{"api_key": "your_key_here"}`
3. **Frontend Input**: Enter API key directly in the web interface

## Usage

1. Start both backend and frontend servers
2. Configure your API key using any of the methods above
3. Open the frontend in your browser (usually `http://localhost:3000`)
4. Start chatting with the model!

## Technologies Used

- **Backend**: FastAPI, Python, OpenAI API
- **Frontend**: React, Tailwind CSS, Axios
- **Development**: Git, GitHub

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## License

This project is open source and available under the MIT License.
