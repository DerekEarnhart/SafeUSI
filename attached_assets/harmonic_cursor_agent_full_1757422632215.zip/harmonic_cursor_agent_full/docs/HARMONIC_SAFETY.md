# Harmonic Safety & Operator S

- **Operator S (Safety-Preserving)**: Enforces allow/deny, resource caps, and human confirmations for high-impact actions.
- **SEE**: Secure Experimental Environments for risky migrations and schema changes.
- **Conservation Laws**: Keep invariants—tests green, licenses intact, secrets redacted, reproducible diffs.
