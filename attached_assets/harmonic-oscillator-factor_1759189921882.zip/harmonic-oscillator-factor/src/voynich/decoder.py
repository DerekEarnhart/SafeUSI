import re
from collections import Counter

ENGLISH_ORDER = "etaoinshrdlcumwfgypbvkjxqz"

class VoynichDecoder:
    """Simple frequency-based substitution stub for experimentation.
Not a real decryption—returns a naive mapping and confidence metric."""
    def __init__(self, n:int=2):
        self.n = n

    def preprocess(self, text: str) -> str:
        t = text.lower()
        t = re.sub(r"[^a-z\s]", " ", t)  # keep ASCII letters and spaces
        t = re.sub(r"\s+", " ", t).strip()
        return t

    def ngram_freq(self, text: str, n: int = None):
        n = n or self.n
        toks = text.split()
        grams = []
        for tok in toks:
            if len(tok) >= n:
                grams += [tok[i:i+n] for i in range(len(tok)-n+1)]
        return Counter(grams)

    def char_freq(self, text: str):
        return Counter([c for c in text if c.isalpha()])

    def build_mapping(self, text: str):
        cf = self.char_freq(text)
        if not cf:
            return {}
        # map most frequent glyphs to most frequent English letters
        src_sorted = [c for c,_ in cf.most_common()]
        tgt_sorted = list(ENGLISH_ORDER[:len(src_sorted)])
        return dict(zip(src_sorted, tgt_sorted))

    def decode(self, raw: str):
        t = self.preprocess(raw)
        if not t:
            return {"decoded": "", "mapping": {}, "confidence": 0.0}
        mapping = self.build_mapping(t)
        decoded = "".join(mapping.get(c, c) for c in t)
        # naive "confidence": overlap of bigram distributions pre/post
        grams = self.ngram_freq(t, 2)
        total = sum(grams.values()) or 1
        diversity = min(len(grams)/50.0, 1.0)  # cap at 1
        # lower confidence if mapping is very sparse
        sparsity = len(mapping) / (len(set([c for c in t if c.isalpha()])) or 1)
        confidence = max(0.05, 0.5*diversity * 0.5*sparsity)
        return {"decoded": decoded, "mapping": mapping, "confidence": round(confidence, 3)}
