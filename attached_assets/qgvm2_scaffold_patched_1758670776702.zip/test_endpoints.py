import requests
BASE="http://127.0.0.1:5001"
print("GET /vm/status"); r=requests.get(f"{BASE}/vm/status", timeout=5); print(r.status_code, r.text)
print("\nPOST /vm/task"); r=requests.post(f"{BASE}/vm/task", json={"task_description":"add two numbers"}, timeout=5); print(r.status_code, r.text)
