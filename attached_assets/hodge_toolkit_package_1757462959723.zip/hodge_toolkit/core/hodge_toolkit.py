
from ..analysis.hodge_analyzer import HodgeAnalyzer
from ..visualization.hodge_visualizer import HodgeVisualizer
from ..analysis.pattern_engine import PatternEngine
from .hodge_calculator import HodgeCalculator
from ..analysis.conjecture_tester import ConjectureTester
from ..advanced.advanced_features import AdvancedFeatures

class HodgeToolkit:
    def __init__(self, data_source=None):
        self.data = self._load_data(data_source)
        self.analyzer = HodgeAnalyzer(self.data)
        self.visualizer = HodgeVisualizer(self.data)
        self.pattern_engine = PatternEngine(self.data)
        self.calculator = HodgeCalculator()
        self.conjecture_tester = ConjectureTester(self.data)
        
    def _load_data(self, source):
        if source is None:
            return {
                'example_variety': {
                    'hodge_numbers': [[1, 0, 0], [0, 1, 0], [0, 0, 1]],
                    'dimension': 3,
                    'euler_characteristic': 0
                }
            }
        if isinstance(source, dict):
            return source
        try:
            import json
            with open(source, 'r') as f:
                return json.load(f)
        except Exception as e:
            print(f"Error loading data from {source}: {e}")
            return {}

    def get_advanced_features(self):
        return AdvancedFeatures(self)

    def save_data(self, output_path):
        import json
        with open(output_path, 'w') as f:
            json.dump(self.data, f, indent=2)
