import React from 'react'
import ComputePanel from './ComputePanel'

export default function App() {
  return (
    <div>
      <div className="header">
        <h3>AI Browser — Starter</h3>
      </div>
      <div className="container">
        <div className="card">
          <h4>Welcome</h4>
          <p className="small">This is a prototype UI. It talks to a local Rust agent (http://127.0.0.1:7878).</p>
        </div>

        <ComputePanel />
      </div>
    </div>
  )
}
