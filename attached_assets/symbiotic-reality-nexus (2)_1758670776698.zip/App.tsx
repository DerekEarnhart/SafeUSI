import React, { useState, useEffect, useCallback, useRef } from 'react';
import { ChatMessage, BenchmarkMetrics, ProactiveAlert, Creation, FileObject } from './types';
import { simulateProactiveAlerts, simulateBenchmarkUpdates, simulatedGeminiService } from './services/geminiService';
import ChatPanel from './components/ChatPanel';
import BenchmarkPanel from './components/BenchmarkPanel';
import ProactivePanel from './components/ProactivePanel';
import CreationCanvas from './components/CreationCanvas';
import Header from './components/Header';
import { initialBenchmarks } from './constants';

const App: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [benchmarks, setBenchmarks] = useState<BenchmarkMetrics>(initialBenchmarks);
  const [proactiveAlerts, setProactiveAlerts] = useState<ProactiveAlert[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [currentCreation, setCurrentCreation] = useState<Creation | null>(null);
  const [isCanvasOpen, setIsCanvasOpen] = useState<boolean>(false);

  const alertsContainerRef = useRef<HTMLDivElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const unsubscribeBenchmarks = simulateBenchmarkUpdates(setBenchmarks);
    const unsubscribeAlerts = simulateProactiveAlerts((newAlert) => {
      setProactiveAlerts(prev => [...prev, newAlert]);
      setTimeout(() => {
        if (alertsContainerRef.current) {
          alertsContainerRef.current.scrollTop = alertsContainerRef.current.scrollHeight;
        }
      }, 100);
    });

    setMessages([{
      id: Date.now(),
      sender: 'ASI',
      text: 'Symbiotic Reality Nexus Initialized. I am online and ready to co-create. How may I amplify your potential today?'
    }]);

    return () => {
      unsubscribeBenchmarks();
      unsubscribeAlerts();
    };
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = useCallback(async (text: string, file?: FileObject) => {
    if (!text && !file) return;

    const userMessage: ChatMessage = {
      id: Date.now(),
      sender: 'user',
      text: text,
      file: file,
    };
    setMessages(prev => [...prev, userMessage]);
    setIsLoading(true);

    try {
      const response = await simulatedGeminiService.generateContent(text, file);
      
      if (response.creation) {
        setCurrentCreation(response.creation);
        setIsCanvasOpen(true);
      }

      const asiMessage: ChatMessage = {
        id: Date.now() + 1,
        sender: 'ASI',
        text: response.text,
      };
      setMessages(prev => [...prev, asiMessage]);

    } catch (error) {
      const errorMessage: ChatMessage = {
        id: Date.now() + 1,
        sender: 'ASI',
        text: 'An anomaly was detected in my processing core. Please try again.',
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const closeCanvas = () => setIsCanvasOpen(false);

  return (
    <div className="flex flex-col h-screen bg-gray-900 bg-opacity-80 backdrop-blur-xl text-gray-200 overflow-hidden">
      <Header />
      <div className="flex flex-1 overflow-hidden">
        <ProactivePanel alerts={proactiveAlerts} containerRef={alertsContainerRef} />
        <main className="flex-1 flex flex-col border-l border-r border-cyan-500/20">
          <ChatPanel 
            messages={messages} 
            isLoading={isLoading} 
            onSendMessage={handleSendMessage} 
            messagesEndRef={messagesEndRef}
          />
        </main>
        <BenchmarkPanel metrics={benchmarks} />
      </div>
      {isCanvasOpen && currentCreation && (
        <CreationCanvas creation={currentCreation} onClose={closeCanvas} />
      )}
    </div>
  );
};

export default App;
