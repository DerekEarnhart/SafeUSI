# Minimal Flask app wiring up your vm_api + a fallback orchestrator
import os, time
from flask import Flask
from flask_cors import CORS

# Import blueprint and its shared system_components dict
try:
    from qgvm2.vm_api import vm_api, system_components
except Exception:
    # Fallback to local import if package path isn't set
    from vm_api import vm_api, system_components  # type: ignore

# Try to import your real orchestrator; if it fails (missing deps), use a stub
try:
    from qgvm2.universal_task_orchestrator import UniversalTaskOrchestrator  # type: ignore
    orchestrator = UniversalTaskOrchestrator()  # type: ignore[name-defined]
except Exception:
    class UniversalTaskOrchestrator:
        def __init__(self):
            self.tasks = {}
        def submit_task(self, task_description: str) -> str:
            tid = str(int(time.time() * 1e6))
            self.tasks[tid] = {"status": "completed", "result": f"stub:{task_description}"}
            return tid
    orchestrator = UniversalTaskOrchestrator()

# Expose orchestrator to the API module
system_components["task_orchestrator"] = orchestrator

app = Flask(__name__)
CORS(app)
app.register_blueprint(vm_api)

if __name__ == "__main__":
    port = int(os.getenv("PORT", "5001"))
    app.run(host="0.0.0.0", port=port, debug=False)
