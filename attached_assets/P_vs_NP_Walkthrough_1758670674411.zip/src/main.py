import time
from src.p_problems import linear_search, bubble_sort
from src.np_problems import verify_subset_sum, find_subset_sum_bruteforce

def clear_screen():
    """Simple function to simulate clearing the screen for better readability."""
    print("\n" * 2) # Print newlines to push previous content up

def main():
    print("==============================================")
    print("  P vs NP: An Educational Walkthrough")
    print("==============================================")
    print("\nWelcome to this interactive guide on one of the most profound unsolved problems")
    print("in theoretical computer science: P vs NP.")
    print("\nPress Enter to continue...")
    input()
    clear_screen()

    print("----------------------------------------------")
    print("1. Understanding 'Polynomial Time' (P)")
    print("----------------------------------------------")
    print("\nProblems in class P are those that can be SOLVED by a computer in polynomial time.")
    print("This means the time taken to solve the problem grows 'reasonably' with the size of the input.")
    print("Polynomial time complexities look like O(n), O(n^2), O(n^3), etc.")
    print("These are generally considered 'easy' or 'tractable' problems.")
    print("\nLet's look at some examples:")
    print("\nPress Enter to continue...")
    input()
    clear_screen()

    print("--- Example 1: Linear Search (O(n)) ---")
    sample_list_p1 = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
    target_p1_found = 70
    target_p1_not_found = 55
    print(f"Scenario: Searching for an item in a list. The time taken is proportional to the list size.")
    print(f"Input List: {sample_list_p1}")
    linear_search(sample_list_p1, target_p1_found)
    linear_search(sample_list_p1, target_p1_not_found)
    print("\nNote: Even for large lists, this operation remains relatively fast.")
    print("\nPress Enter to continue...")
    input()
    clear_screen()

    print("--- Example 2: Bubble Sort (O(n^2)) ---")
    sample_list_p2 = [9, 5, 2, 8, 1, 7, 3, 6, 4]
    print(f"Scenario: Sorting a list using Bubble Sort. Time grows quadratically with input size.")
    print(f"Input List: {sample_list_p2}")
    bubble_sort(list(sample_list_p2)) # Pass a copy to preserve original
    print("\nNote: While O(n^2) is slower than O(n), it's still polynomial and considered tractable.")
    print("For a list of 1000 items, n^2 is 1,000,000 operations, which is often manageable.")
    print("\nPress Enter to continue...")
    input()
    clear_screen()

    print("----------------------------------------------")
    print("2. Understanding 'Nondeterministic Polynomial Time' (NP)")
    print("----------------------------------------------")
    print("\nProblems in class NP are those for which a given solution can be VERIFIED in polynomial time.")
    print("This is the key distinction: 'verifying' is different from 'solving'.")
    print("Many hard problems we encounter daily are in NP.")
    print("\nLet's use the 'Subset Sum Problem' as our example for NP.")
    print("Problem: Given a set of integers and a target sum, is there a non-empty subset")
    print("         of the integers that sums exactly to the target sum?")
    print("\nPress Enter to continue...")
    input()
    clear_screen()

    print("--- Example 3: Subset Sum - The VERIFICATION Part (P-time) ---")
    sample_numbers_np = [3, 34, 4, 12, 5, 2]
    target_np = 9
    print(f"Given numbers: {sample_numbers_np}, Target sum: {target_np}")

    print("\nScenario A: We are given a PROPOSED SUBSET. Can we quickly check if it's correct?")
    proposed_correct_subset = [3, 4, 2]
    print(f"Proposed subset: {proposed_correct_subset}")
    verify_subset_sum(sample_numbers_np, target_np, proposed_correct_subset)

    print("\nScenario B: Another proposed subset.")
    proposed_incorrect_subset = [12, 5]
    print(f"Proposed subset: {proposed_incorrect_subset}")
    verify_subset_sum(sample_numbers_np, target_np, proposed_incorrect_subset)

    print("\nNote: Checking if a subset sums correctly is very fast (linear in the size of the subset).")
    print("This is why Subset Sum is in NP - its solutions are easy to verify.")
    print("\nPress Enter to continue...")
    input()
    clear_screen()

    print("--- Example 4: Subset Sum - The FINDING Part (Potentially Exponential Time) ---")
    print("\nNow, consider finding the subset from scratch. This is much harder.")
    print("The most straightforward way is to try every possible subset (brute-force).")
    print(f"For a set of 'n' numbers, there are 2^n possible subsets. This grows EXPONENTIALLY.")
    print(f"For {len(sample_numbers_np)} numbers ({sample_numbers_np}), there are 2^{len(sample_numbers_np)} = {2**len(sample_numbers_np)} subsets.")
    print("Even for a small 'n', 2^n becomes a very large number quickly!")

    print("\nLet's try to FIND a subset for target 9:")
    found_subset = find_subset_sum_bruteforce(sample_numbers_np, target_np)
    if found_subset:
        print(f"Brute-force finding was successful: {found_subset}")
    else:
        print("Brute-force finding failed to find a subset.")

    print("\nLet's try to FIND a subset for target 100 (which doesn't exist):")
    find_subset_sum_bruteforce(sample_numbers_np, 100)

    print("\nConsider a slightly larger set:")
    larger_set = list(range(1, 16)) # 15 numbers -> 2^15 = 32,768 subsets
    target_larger = 78 # sum of 1..12
    print(f"For {len(larger_set)} numbers, there are 2^{len(larger_set)} = {2**len(larger_set)} subsets.")
    print(f"Attempting to find subset for target {target_larger} in {larger_set[:5]}...[and so on up to 15]")
    # Commenting out for faster execution, but it would demonstrate the wait.
    # find_subset_sum_bruteforce(larger_set, target_larger)
    print("  (Running brute-force on 15 elements would take noticeable time.)")
    print("  (Imagine 50 elements: 2^50 is an astronomically large number!)")
    print("\nPress Enter to continue...")
    input()
    clear_screen()

    print("----------------------------------------------")
    print("3. The Core Question: Is P = NP?")
    print("----------------------------------------------")
    print("\nWe've seen that P problems are easy to solve.")
    print("We've seen that NP problems are easy to verify, but potentially hard to solve.")

    print("\nThe P vs NP question asks: Is every problem whose solution can be quickly verified (NP)")
    print("also a problem whose solution can be quickly found (P)?")

    print("\nIf P = NP:")
    print("  - It would mean that finding solutions is as easy as checking them.")
    print("  - Many currently 'hard' problems (like optimizing delivery routes for all packages,")
    print("    breaking modern encryption, designing optimal protein folding) could be solved efficiently.")
    print("  - This would revolutionize many fields, but also break current cryptographic security.")

    print("\nIf P != NP (the widely believed conjecture):")
    print("  - It means that there truly are problems where verifying a solution is easy, but finding")
    print("    one from scratch is inherently difficult, no matter how clever our algorithms get.")
    print("  - This aligns with our current intuition about 'hard' problems and underpins the security")
    print("    of most modern cryptographic systems.")

    print("\nNo one has proven P=NP or P!=NP. It remains one of the greatest unsolved problems in computer science.")

    print("\nPress Enter to continue...")
    input()
    clear_screen()

    print("==============================================")
    print("  Walkthrough Complete!")
    print("==============================================")
    print("\nThank you for exploring the P vs NP problem.")
    print("Hopefully, this walkthrough has provided a clearer understanding of P, NP,")
    print("polynomial time, and the profound implications of this fundamental question.")
    print("\nFor more information, research 'P vs NP problem' or 'Clay Mathematics Institute Millennium Problems'.")
    print("\nExiting...")
    time.sleep(2)

if __name__ == "__main__":
    main()
