import React, { useState } from 'react';

export default function App() {
  const [input, setInput] = useState('');
  const [history, setHistory] = useState([]);

  const send = async () => {
    const res = await fetch('/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: input })
    }).then(r => r.json());
    setHistory(h => [...h, {q: input, a: res.reply}]);
    setInput('');
  };

  return (
    <div className="p-4 max-w-xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Sovereign HA‑AGI</h1>
      <div className="space-y-2 mb-4">
        {history.map((m,i)=>(
          <div key={i} className="bg-gray-800 p-2 rounded">
            <p className="font-semibold text-blue-400">You: {m.q}</p>
            <p className="text-green-300">AGI: {m.a}</p>
          </div>
        ))}
      </div>
      <input className="w-full p-2 bg-gray-700 rounded" value={input} onChange={e=>setInput(e.target.value)} placeholder="Ask me anything..." />
      <button className="mt-2 px-4 py-2 bg-blue-600 rounded" onClick={send}>Send</button>
    </div>
  );
}
