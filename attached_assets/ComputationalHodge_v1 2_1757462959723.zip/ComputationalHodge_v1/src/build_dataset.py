
import os, json, random
import pandas as pd
from features import synthetic_k3_row, ALL_FEATURES
from provenance import LabelProvenance

OUT = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "hodge_seed.csv")

def build_synthetic(n=1000, pos_ratio=0.5):
    rows = []
    for i in range(n):
        algebraic = (random.random() < pos_ratio)
        seed = f"k3q4_{i}"
        row = synthetic_k3_row(seed, algebraic)
        # attach label provenance
        prov = LabelProvenance(
            type="synthetic",
            method="toy_generator",
            assumptions=["none"],
            confidence=1.0,
            notes="This is synthetic; replace with real provenance in production."
        ).to_json()
        row["label_provenance_json"] = json.dumps(prov)
        rows.append(row)
    return pd.DataFrame(rows)

if __name__ == "__main__":
    df = build_synthetic(n=800, pos_ratio=0.55)
    df.to_csv(OUT, index=False)
    print(f"Wrote {OUT} with {len(df)} rows and {len(df.columns)} columns.")
