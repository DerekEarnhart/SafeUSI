# MegaMAGI – The Mega AGI System

Welcome to MegaMAGI, a simplified full-scale AGI system.

## Installation

1.  Ensure you have Python 3.11.9 installed.
2.  Open a command prompt in the project directory.
3.  Run:
    ```bash
    pip install -r requirements.txt
    ```

## Running the Application

* To launch the application, simply double-click the `MegaMAGI_launcher.bat` file.
* Alternatively, run:
    ```bash
    python main.py
    ```

## Project Structure

* `config.py`: Configuration settings.
* `main.py`: Entry point for the system.
* `all_core_modules.py`: Contains all core functionality modules.
* `all_tests.py`: Contains all test files for various components.

Happy coding and exploring MegaMAGI!