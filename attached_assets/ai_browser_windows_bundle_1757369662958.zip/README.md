AI-First Browser Starter — Windows bundle

This bundle contains a minimal prototype scaffold:
- frontend/ — Vite + React (TypeScript) web UI with a 'Compute Panel' that submits declarative job manifests to a local agent.
- agent/ — Minimal Rust HTTP agent (Axum) that exposes a small API:
  - GET /resources — lists available (mock) resources
  - POST /jobs — accept a job manifest and return a job id
  - GET /jobs/:id/events — SSE telemetry stream (simulated)

Included Windows convenience scripts:
- install_prereqs.bat    : Checks for Node and Rust and prints links if missing.
- setup.bat              : Runs dependency installs (npm install in frontend) and builds the Rust agent.
- run_agent.bat          : Starts the Rust agent (runs `cargo run --release`).
- run_frontend.bat       : Installs frontend deps if needed and runs `npm run dev`.
- start_all.bat          : Opens two new windows: one for agent and one for frontend.

How to use (Windows)
1. Install prerequisites if you don't have them:
   - Node.js (v18+): https://nodejs.org/
   - Rust toolchain (cargo): https://rustup.rs/

   You can run `install_prereqs.bat` which checks for node and cargo and prints links.

2. Setup (one-time): double-click or run `setup.bat`. This will:
   - Install frontend npm deps.
   - Build the Rust agent with `cargo build --release`.

3. Start:
   - Double-click `start_all.bat` to open two windows (agent + frontend).
   - Or run `run_agent.bat` and `run_frontend.bat` separately.

Notes
- The frontend dev server (Vite) will normally run on http://localhost:5173.
- The Rust agent listens on http://127.0.0.1:7878.
- If Windows blocks script execution, run the batch files from an elevated cmd/powershell or adjust security settings.

If you'd like, I can also add a single-click PowerShell installer that will auto-install Node and Rust via their official installers (requires admin privileges). Say the word and I’ll add it.

