# Harmonic Suite — MVP (Cursor-ready)

Generated 2025-09-08T21:34:04.424949Z
See web/index.html, src/services/*, docs/PPA_outline.md.
