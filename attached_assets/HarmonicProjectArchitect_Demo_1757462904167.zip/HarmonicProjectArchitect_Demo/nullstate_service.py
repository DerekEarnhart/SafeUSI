#!/usr/bin/env python3
"""
Null-State Ingest Service (standard-library only)
- POST /ingest         : Ingest a structured 'spec' (JSON). Returns a CID + embedding.
- GET  /ledger/        : Get the entire ledger (CID -> entry).
- GET  /ledger/<cid>   : Get a single entry by CID.
- GET  /health         : Health check.
- CORS preflight (OPTIONS) supported.

Deterministic 'harmonic embedding' and CID are derived from the canonical JSON of the spec.
The CID is sha256(hex) of the canonical spec.
The embedding is a fixed-length list of floats in [-1, 1], derived from the hash bytes.
"""
import argparse
import datetime as _dt
import hashlib
import json
import os
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse

LEDGER_DEFAULT = "ledger.json"

def canonical_json(data) -> str:
    """Deterministically serialize JSON (sorted keys, compact separators)."""
    return json.dumps(data, sort_keys=True, separators=(',', ':'))

def cid_from_canonical(canon: str) -> str:
    return hashlib.sha256(canon.encode('utf-8')).hexdigest()

def embedding_from_digest(digest_hex: str, length: int = 16):
    """Map sha256 hex -> list[float] in [-1, 1] deterministically."""
    b = bytes.fromhex(digest_hex)
    # If we need more than 32 bytes, cycle; else slice.
    need = length
    out = []
    i = 0
    while len(out) < need:
        val = b[i % len(b)]
        # map 0..255 to [-1, 1]
        out.append((val / 127.5) - 1.0)
        i += 1
    return out

class NullStateHandler(BaseHTTPRequestHandler):
    server_version = "NullStateIngest/1.1"

    def _send(self, status=200, payload=None, content_type="application/json"):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()
        if payload is not None:
            if isinstance(payload, (dict, list)):
                payload = json.dumps(payload).encode("utf-8")
            elif isinstance(payload, str):
                payload = payload.encode("utf-8")
            self.wfile.write(payload)

    def do_OPTIONS(self):
        self._send(204, b"")

    def do_GET(self):
        parsed = urlparse(self.path)
        parts = [p for p in parsed.path.split('/') if p]
        try:
            if parsed.path == "/health":
                return self._send(200, {"ok": True, "service": "nullstate", "version": "1.1"})

            if len(parts) == 1 and parts[0] == "ledger":
                # return entire ledger
                return self._send(200, self.server.ledger)

            if len(parts) == 2 and parts[0] == "ledger":
                cid = parts[1]
                entry = self.server.ledger.get(cid)
                if not entry:
                    return self._send(404, {"error": "CID not found"})
                return self._send(200, entry)

            return self._send(404, {"error": "not found"})
        except Exception as e:
            return self._send(500, {"error": f"server error: {e}"})

    def do_POST(self):
        parsed = urlparse(self.path)
        length = int(self.headers.get("Content-Length", "0") or 0)
        raw = self.rfile.read(length) if length > 0 else b""
        try:
            if parsed.path == "/ingest":
                if not raw:
                    return self._send(400, {"error": "empty body"})
                try:
                    data = json.loads(raw.decode("utf-8"))
                except json.JSONDecodeError:
                    return self._send(400, {"error": "invalid JSON"})

                # Accept either {"spec": {...}} or a raw spec object.
                spec = data.get("spec", data if isinstance(data, dict) else None)
                if not isinstance(spec, dict):
                    return self._send(400, {"error": "spec must be a JSON object"})

                canon = canonical_json(spec)
                cid = cid_from_canonical(canon)
                emb = embedding_from_digest(cid, length=16)
                now = _dt.datetime.utcnow().isoformat() + "Z"

                entry = {
                    "cid": cid,
                    "received_at": now,
                    "embedding": emb,
                    "spec": spec,
                    "canonical": canon,
                }
                self.server.ledger[cid] = entry

                # Persist
                try:
                    with open(self.server.ledger_path, "w", encoding="utf-8") as f:
                        json.dump(self.server.ledger, f, ensure_ascii=False, indent=2)
                except Exception as e:
                    # Non-fatal, but include warning
                    entry["persist_warning"] = str(e)

                return self._send(200, {"cid": cid, "received_at": now, "embedding": emb})
            else:
                return self._send(404, {"error": "not found"})
        except Exception as e:
            return self._send(500, {"error": f"server error: {e}"})

def run_server(host: str, port: int, ledger_path: str):
    # Load existing ledger if present
    ledger = {}
    if os.path.exists(ledger_path):
        try:
            with open(ledger_path, "r", encoding="utf-8") as f:
                ledger = json.load(f)
        except Exception:
            ledger = {}

    class _Server(ThreadingHTTPServer):
        pass
    server = _Server((host, port), NullStateHandler)
    server.ledger = ledger
    server.ledger_path = ledger_path

    print(f"[nullstate] serving on http://{host}:{port}  ledger={ledger_path}  entries={len(ledger)}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        # Persist on shutdown
        try:
            with open(server.ledger_path, "w", encoding="utf-8") as f:
                json.dump(server.ledger, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"[nullstate] error persisting ledger: {e}")

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Null-State Ingest Service")
    ap.add_argument("--serve", action="store_true", help="Start HTTP server")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8000)
    ap.add_argument("--ledger", default=LEDGER_DEFAULT, help="Path to ledger JSON")
    args = ap.parse_args()

    if args.serve:
        run_server(args.host, args.port, args.ledger)
    else:
        print("Use --serve to run the HTTP server.")
