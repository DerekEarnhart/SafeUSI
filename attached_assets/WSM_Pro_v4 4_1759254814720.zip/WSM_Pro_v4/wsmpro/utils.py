
import torch
import torch.nn as nn

def build_omega(n: int, device=None, dtype=None):
    I = torch.eye(n, device=device, dtype=dtype)
    Z = torch.zeros_like(I)
    top = torch.cat([Z, I], dim=1)
    bot = torch.cat([-I, Z], dim=1)
    return torch.cat([top, bot], dim=0)

def symmetrize(H):
    return 0.5 * (H + H.transpose(-1, -2))

def cayley(A):
    # (I - A/2)^{-1} (I + A/2)
    I = torch.eye(A.shape[-1], device=A.device, dtype=A.dtype)
    return torch.linalg.solve(I - 0.5*A, I + 0.5*A)

def symplectic_regularizer(S, Omega, p=2):
    # Penalize deviation from S^T Ω S = Ω
    diff = S.transpose(-1, -2) @ Omega @ S - Omega
    return diff.norm(p=p)

def is_symplectic(S, Omega, tol=1e-3):
    with torch.no_grad():
        diff = S.transpose(-1, -2) @ Omega @ S - Omega
        return diff.abs().max().item() < tol
