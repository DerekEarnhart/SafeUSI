import os, sys, importlib, json
REQUIRED = ["flask", "flask_cors"]
OPTIONAL = ["numpy", "networkx", "requests"]

def check_pkg(name):
    try:
        importlib.import_module(name); return True
    except Exception: return False

def main():
    print("Python:", sys.version.split()[0])
    status = {"required":{}, "optional":{}, "import_qgvm2": None, "flask_blueprint": None}
    for k in REQUIRED:
        status["required"][k] = check_pkg(k); print(f"[req] {k}: {'OK' if status['required'][k] else 'MISSING'}")
    for k in OPTIONAL:
        status["optional"][k] = check_pkg(k); print(f"[opt] {k}: {'OK' if status['optional'][k] else 'MISSING'}")
    sys.path.insert(0, os.getcwd())
    try:
        import qgvm2; print("Imported package: qgvm2"); status["import_qgvm2"] = True
    except Exception as e:
        print("Failed to import package qgvm2:", e); status["import_qgvm2"] = False
    try:
        vm_api = importlib.import_module("qgvm2.vm_api")
    except Exception:
        try: vm_api = importlib.import_module("vm_api")
        except Exception as e: vm_api=None; print("vm_api import failed:", e)
    status["flask_blueprint"] = bool(vm_api and hasattr(vm_api, "vm_api"))
    print("\\n=== SUMMARY ==="); print(json.dumps(status, indent=2))

if __name__ == "__main__": main()
