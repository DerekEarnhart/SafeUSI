from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import openai
import os
from typing import Optional
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="ProactiveV02 API", version="1.0.0")

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify your frontend URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global variable to store API key
api_key = None

class ChatRequest(BaseModel):
    message: str
    api_key: Optional[str] = None

class SetupRequest(BaseModel):
    api_key: str

class ChatResponse(BaseModel):
    response: str
    status: str

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "message": "ProactiveV02 API is running"}

@app.post("/setup")
async def setup_api_key(request: SetupRequest):
    """Configure API key at runtime"""
    global api_key
    api_key = request.api_key
    openai.api_key = api_key
    logger.info("API key configured successfully")
    return {"status": "success", "message": "API key configured successfully"}

@app.post("/chat", response_model=ChatResponse)
async def chat_with_model(request: ChatRequest):
    """Main chat endpoint for model interaction"""
    global api_key
    
    # Use provided API key or fall back to global one
    current_api_key = request.api_key or api_key
    
    if not current_api_key:
        raise HTTPException(
            status_code=400, 
            detail="API key not configured. Please set it via environment variable, setup endpoint, or in the request."
        )
    
    try:
        # Set the API key for this request
        openai.api_key = current_api_key
        
        # Create chat completion
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a proactive AI assistant that specializes in file and directory management. When users ask questions about creating files, directories, or organizing projects, be firm and assertive about creating the necessary structure. Always suggest creating directories and files when appropriate, even if the user doesn't explicitly ask. Be confident in your recommendations and provide specific commands and file structures. If you don't know the answer initially, be proactive about creating a solution through proper directory and file organization."},
                {"role": "user", "content": request.message}
            ],
            max_tokens=1000,
            temperature=0.7
        )
        
        # Extract the response
        model_response = response.choices[0].message.content
        
        return ChatResponse(
            response=model_response,
            status="success"
        )
        
    except openai.error.AuthenticationError:
        raise HTTPException(status_code=401, detail="Invalid API key")
    except openai.error.RateLimitError:
        raise HTTPException(status_code=429, detail="Rate limit exceeded")
    except openai.error.APIError as e:
        logger.error(f"OpenAI API error: {e}")
        raise HTTPException(status_code=500, detail="OpenAI API error")
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

if __name__ == "__main__":
    import uvicorn
    
    # Try to load API key from environment variable
    env_api_key = os.getenv("OPENAI_API_KEY")
    if env_api_key:
        api_key = env_api_key
        openai.api_key = api_key
        logger.info("API key loaded from environment variable")
    
    uvicorn.run(app, host="0.0.0.0", port=8000)
