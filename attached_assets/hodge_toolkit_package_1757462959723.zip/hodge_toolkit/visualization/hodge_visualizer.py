
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
from matplotlib.collections import PatchCollection

class HodgeVisualizer:
    def __init__(self, data):
        self.data = data

    def hodge_diamond(self, pair_key):
        if pair_key not in self.data and pair_key != "default":
            raise KeyError(f"Variety '{pair_key}' not found in data")
        if pair_key == "default":
            pair_key = next(iter(self.data))
        variety = self.data[pair_key]
        hodge_numbers = variety.get('hodge_numbers', [])
        if not hodge_numbers:
            raise ValueError(f"No Hodge numbers for '{pair_key}'")
        n = len(hodge_numbers) - 1
        fig, ax = plt.subplots(figsize=(8, 8))
        ax.set_aspect('equal')
        ax.axis('off')
        patches, texts = [], []
        for p in range(n + 1):
            for q in range(n + 1):
                x = p - q
                y = n - (p + q)
                if hodge_numbers[p][q] > 0:
                    diamond = Polygon([
                        (x, y + 0.5), (x + 0.5, y),
                        (x, y - 0.5), (x - 0.5, y)
                    ], closed=True)
                    patches.append(diamond)
                    texts.append(((x, y), str(hodge_numbers[p][q]), f"({p},{q})"))
        ax.add_collection(PatchCollection(patches, alpha=0.7, facecolor='lightblue', edgecolor='black'))
        for (pos, value, label) in texts:
            ax.text(pos[0], pos[1], value, ha='center', va='center', fontsize=12)
            ax.text(pos[0], pos[1] - 0.8, label, ha='center', va='center', fontsize=8, color='gray')
        ax.set_xlim(-n-1, n+1)
        ax.set_ylim(-n-1, n+1)
        plt.title(f"Hodge Diamond for {pair_key}")
        plt.tight_layout()
        return fig
