def posterior_from_lr(prior: float, likelihood_ratio: float) -> float:
    """Posterior = (LR * prior) / (LR * prior + (1 - prior))."""
    num = likelihood_ratio * prior
    den = num + (1.0 - prior)
    return num / den if den else 0.0

def wow_posterior_default() -> float:
    """A parameterisation that yields ~0.72 posterior, per manuscript summary."""
    prior = 0.30
    lr = 8.0/3.0  # ≈ 2.6667
    return posterior_from_lr(prior, lr)
