# Playbook: Replace a Dependency Safely

1) Scan imports and lockfile → list affected modules.  
2) Add shim adapter to preserve API.  
3) Swap implementation; write unit tests for adapter.  
4) Run tests → fix breakages; regenerate typings.  
5) Search repo for edge APIs; provide fallbacks.  
6) Commit small diffs; open PR with migration notes.
