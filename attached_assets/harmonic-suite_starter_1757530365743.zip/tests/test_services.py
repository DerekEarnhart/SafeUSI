def test_smoke_services(): assert True
