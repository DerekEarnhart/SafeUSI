
import torch
import torch.nn as nn
import torch.nn.functional as F
from .utils import build_omega, symmetrize, cayley, symplectic_regularizer

class WSMCore(nn.Module):
    def __init__(self, state_n: int, hidden: int, mode: str = "cayley"):
        super().__init__()
        assert mode in ("cayley","expm")
        self.n = state_n
        self.d = 2*state_n
        self.mode = mode
        self.Omega = build_omega(self.n)
        # Small feature extractor for tokens -> control u_t
        self.embed = nn.Embedding(50257, hidden)  # HF GPT2-size vocab by default; replace as needed
        self.to_H = nn.Linear(hidden, self.d*self.d)  # produce symmetric H(u)
        self.residual = nn.Sequential(
            nn.Linear(self.d, 4*self.d),
            nn.GELU(),
            nn.Linear(4*self.d, self.d)
        )
        # Output head for logits (toy; replace with your head of choice)
        self.to_logits = nn.Linear(self.d, 50257, bias=False)

        # Initialize mu_0 as learnable
        self.mu0 = nn.Parameter(torch.zeros(self.d))

    def step(self, mu, token_ids):
        # token_ids: (B,) -> embed -> H(u)
        h = self.embed(token_ids)  # (B,hidden)
        H_flat = self.to_H(h)      # (B,d*d)
        H = H_flat.view(-1, self.d, self.d)
        H = symmetrize(H)
        Omega = self.Omega.to(H.device, H.dtype)

        A = torch.einsum("ij,bjk->bik", Omega, H)  # Ω H
        if self.mode == "expm":
            S = torch.matrix_exp(A)
        else:
            S = cayley(A)

        mu_next = torch.einsum("bij,bj->bi", S, mu)
        mu_next = mu_next + self.residual(mu_next)
        return mu_next, S, Omega

    def forward_core(self, input_ids):
        B, T = input_ids.shape
        mu = self.mu0.unsqueeze(0).expand(B, -1)
        symp_reg = 0.0
        for t in range(T):
            mu, S, Omega = self.step(mu, input_ids[:, t])
            symp_reg = symp_reg + symplectic_regularizer(S, Omega)
        logits = self.to_logits(mu)  # final-state logits (toy design)
        return logits, symp_reg / max(1, T)

class WSMForCausalLM(nn.Module):
    def __init__(self, state_n=64, hidden=256, mode="cayley", symp_weight=1e-4):
        super().__init__()
        self.core = WSMCore(state_n, hidden, mode)
        self.symp_weight = symp_weight

    def forward(self, input_ids, labels=None):
        logits, symp_reg = self.core.forward_core(input_ids)
        out = {"logits": logits}
        if labels is not None:
            # Simple CE on final-state logits predicting last token next
            loss = F.cross_entropy(logits, labels) + self.symp_weight * symp_reg
            out["loss"] = loss
        return out

    @torch.no_grad()
    def generate(self, input_ids, max_new_tokens=32, temperature=1.0, top_p=0.9):
        cur = input_ids
        for _ in range(max_new_tokens):
            logits, _ = self.core.forward_core(cur)
            logits = logits / max(1e-6, temperature)
            # top-p sampling
            probs = torch.softmax(logits, dim=-1)
            sorted_probs, sorted_idx = torch.sort(probs, descending=True, dim=-1)
            cum = torch.cumsum(sorted_probs, dim=-1)
            mask = cum <= top_p
            # ensure at least one token
            mask[..., 0] = True
            filtered = torch.where(mask, sorted_probs, torch.zeros_like(sorted_probs))
            filtered = filtered / filtered.sum(dim=-1, keepdim=True)
            next_tokens = torch.gather(sorted_idx, -1, torch.multinomial(filtered, 1))
            cur = torch.cat([cur, next_tokens], dim=-1)
        return cur
