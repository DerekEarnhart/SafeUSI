from voynich.seti import wow_posterior_default

def test_wow_default():
    p = wow_posterior_default()
    assert 0.70 <= p <= 0.74
