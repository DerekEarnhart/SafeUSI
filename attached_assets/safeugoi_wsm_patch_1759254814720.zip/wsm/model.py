\
import math
import torch
import torch.nn as nn
import torch.nn.functional as F

def top_p_top_k_softmax(logits: torch.Tensor, top_k: int = 0, top_p: float = 1.0) -> torch.Tensor:
    """Return probability distribution after optional top-k/top-p filtering."""
    probs = torch.softmax(logits, dim=-1)
    if top_k and top_k > 0:
        v, idx = torch.topk(probs, top_k, dim=-1)
        mask = torch.zeros_like(probs).scatter(-1, idx, 1.0)
        probs = probs * mask
        probs = probs / probs.clamp_min(1e-12).sum(dim=-1, keepdim=True)
    if top_p and top_p < 1.0:
        sorted_probs, sorted_idx = torch.sort(probs, descending=True, dim=-1)
        cum = torch.cumsum(sorted_probs, dim=-1)
        cutoff = cum > top_p
        # keep at least one
        cutoff[..., 0] = False
        keep_mask = torch.ones_like(probs).scatter(-1, sorted_idx, (~cutoff).float())
        probs = probs * keep_mask
        probs = probs / probs.clamp_min(1e-12).sum(dim=-1, keepdim=True)
    return probs

def make_omega(d: int) -> torch.Tensor:
    """Return the canonical symplectic form Omega of size d=2n."""
    assert d % 2 == 0, "State dimension must be even (2n)."
    n = d // 2
    O = torch.zeros(d, d)
    O[:n, n:] = torch.eye(n)
    O[n:, :n] = -torch.eye(n)
    return O

class SymplecticLayer(nn.Module):
    """A Gaussian unitary layer: S(u) = exp(Omega @ H(u)), xi(u) displacement."""
    def __init__(self, in_dim: int, d_state: int):
        super().__init__()
        self.d = d_state
        # Parameterize H(u) via a symmetric matrix built from a dense map
        # We keep it small and stable by tanh in the middle.
        self.H_net = nn.Sequential(
            nn.Linear(in_dim, d_state * d_state),
            nn.Tanh(),
            nn.Linear(d_state * d_state, d_state * d_state)
        )
        self.xi_net = nn.Sequential(
            nn.Linear(in_dim, d_state),
            nn.Tanh(),
            nn.Linear(d_state, d_state)
        )
        # Omega is a buffer (moved with the module to device)
        Om = make_omega(d_state)
        self.register_buffer("Omega", Om, persistent=False)

    def forward(self, u: torch.Tensor, mu: torch.Tensor) -> torch.Tensor:
        """
        u: (B, in_dim)
        mu: (B, d_state)
        Returns: mu_next (B, d_state)
        """
        B = u.shape[0]
        d = self.d
        # Build symmetric H
        H_raw = self.H_net(u).view(B, d, d)
        H = 0.5 * (H_raw + H_raw.transpose(-1, -2))
        # Hamiltonian generator A = Omega @ H
        Omega = self.Omega.expand(B, d, d)
        A = torch.matmul(Omega, H)
        # Matrix exponential (batched)
        S = torch.matrix_exp(A)  # (B, d, d)
        xi = self.xi_net(u)      # (B, d)
        muS = torch.matmul(S, mu.unsqueeze(-1)).squeeze(-1)
        mu_next = muS + xi
        return mu_next

class WSMCell(nn.Module):
    """One step of WSM with optional shallow non-Gaussian residual."""
    def __init__(self, in_dim: int, d_state: int, non_gauss: bool = True, non_gauss_scale: float = 0.1):
        super().__init__()
        self.gauss = SymplecticLayer(in_dim, d_state)
        self.non_gauss = non_gauss
        self.scale = non_gauss_scale
        if non_gauss:
            self.ng = nn.Sequential(nn.Linear(d_state, d_state), nn.Tanh(), nn.Linear(d_state, d_state))

    def forward(self, u: torch.Tensor, mu: torch.Tensor) -> torch.Tensor:
        mu = self.gauss(u, mu)
        if self.non_gauss:
            mu = mu + self.scale * self.ng(mu)
        return mu

class WSMForCausalLM(nn.Module):
    """
    Drop-in causal LM: same interface (forward returns (logits, loss)), generate() for sampling.
    State is a 2n vector (mean-only dynamics).
    """
    def __init__(self, vocab_size: int, d_model: int = 512, state_n: int = 128, layers: int = 3):
        super().__init__()
        self.vocab_size = vocab_size
        self.d_model = d_model
        self.state_dim = 2 * state_n
        self.embed = nn.Embedding(vocab_size, d_model)
        self.cells = nn.ModuleList([WSMCell(d_model, self.state_dim, non_gauss=True) for _ in range(layers)])
        self.readout = nn.Linear(self.state_dim, vocab_size)
        self.layers = layers

    def init_state(self, batch_size: int, device=None, dtype=None) -> torch.Tensor:
        return torch.zeros(batch_size, self.state_dim, device=device, dtype=dtype)

    def step(self, token_ids: torch.Tensor, mu: torch.Tensor) -> (torch.Tensor, torch.Tensor):
        """
        One timestep update given last token ids.
        token_ids: (B,)
        mu: (B, state_dim)
        Returns: (logits (B,V), mu_next (B,state_dim))
        """
        u = self.embed(token_ids)  # (B, d_model)
        for cell in self.cells:
            mu = cell(u, mu)
        logits = self.readout(mu)
        return logits, mu

    def forward(self, input_ids: torch.Tensor, labels: torch.Tensor = None):
        """
        input_ids: (B,T)
        labels: (B,T) optional; if provided, compute next-token loss.
        """
        B, T = input_ids.shape
        device = input_ids.device
        mu = self.init_state(B, device=device, dtype=self.embed.weight.dtype)
        logits_seq = []
        for t in range(T):
            logits, mu = self.step(input_ids[:, t], mu)
            logits_seq.append(logits)
        logits = torch.stack(logits_seq, dim=1)  # (B,T,V)
        loss = None
        if labels is not None:
            # next-token loss: predict token t+1 from state at t
            loss = F.cross_entropy(logits[:, :-1].reshape(-1, self.vocab_size),
                                   labels[:, 1:].reshape(-1))
        return logits, loss

    @torch.inference_mode()
    def generate(self, input_ids: torch.Tensor, max_new_tokens: int = 64,
                 temperature: float = 1.0, top_k: int = 0, top_p: float = 1.0):
        """
        Simple autoregressive sampling compatible with many LLM APIs.
        input_ids: (B,T)
        Returns: generated tokens (B, max_new_tokens)
        """
        device = input_ids.device
        B = input_ids.shape[0]
        mu = self.init_state(B, device=device, dtype=self.embed.weight.dtype)
        # Warm-up with the prompt
        for t in range(input_ids.shape[1]):
            _, mu = self.step(input_ids[:, t], mu)

        last = input_ids[:, -1]
        outs = []
        for _ in range(max_new_tokens):
            logits, mu = self.step(last, mu)
            logits = logits / max(1e-6, float(temperature))
            probs = top_p_top_k_softmax(logits, top_k=top_k, top_p=top_p)
            last = torch.multinomial(probs, num_samples=1).squeeze(-1)
            outs.append(last)
        return torch.stack(outs, dim=1)  # (B, max_new_tokens)
