# PPA Outline — Harmonic QA Guard

(See README for structure; fill claims, enablement, and figures.)
