
import numpy as np

class HodgeCalculator:
    def calculate_betti_numbers(self, hodge_numbers):
        n = len(hodge_numbers)
        betti = [0] * n
        for k in range(n):
            for p in range(n):
                for q in range(n):
                    if p + q == k:
                        betti[k] += hodge_numbers[p][q]
        return betti

    def calculate_euler_characteristic(self, hodge_numbers):
        n = len(hodge_numbers)
        euler = 0
        for p in range(n):
            for q in range(n):
                euler += (-1)**(p+q) * hodge_numbers[p][q]
        return euler

    def calculate_hodge_diamond_symmetry(self, hodge_numbers):
        n = len(hodge_numbers)
        for p in range(n):
            for q in range(n):
                if hodge_numbers[p][q] != hodge_numbers[q][p]:
                    return False
        for p in range(n):
            for q in range(n):
                if p + q < n and hodge_numbers[p][q] != hodge_numbers[n-p][n-q]:
                    return False
        return True

    def calculate_signature(self, hodge_numbers):
        n = len(hodge_numbers) - 1
        signature = 0
        for p in range(n+1):
            for q in range(n+1):
                if (p + q) % 2 == 0:
                    signature += hodge_numbers[p][q]
                else:
                    signature -= hodge_numbers[p][q]
        return signature
