"""
Harmonic RAG Engine

This module provides a Retrieval-Augmented Generation (RAG) engine using 
Harmonic Algebraic Probability principles to enhance factual accuracy
by retrieving information from a knowledge base.
"""

import os
import sys
import json
import logging
import numpy as np
from datetime import datetime
from typing import Dict, List, Any, Optional, Union, Tuple, Set
import uuid
import pickle

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from base_engine import BaseEngine

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class HarmonicRAGEngine(BaseEngine):
    """
    Retrieval-Augmented Generation engine using Harmonic Algebraic principles.
    Enhances LLM output with factual information from knowledge bases.
    """
    
    def __init__(self, 
                 knowledge_base_path: str = "./knowledge_base",
                 embedding_dimension: int = 1536, 
                 harmonic_resonance: float = 0.7,
                 use_hap: bool = True,
                 harmonic_base: float = 1.618,
                 quantum_factor: float = 0.01):
        """
        Initialize the Harmonic RAG Engine.
        
        Args:
            knowledge_base_path: Path to knowledge base directory
            embedding_dimension: Dimension of embeddings
            harmonic_resonance: Harmonic resonance factor (0.0 to 1.0)
            use_hap: Whether to use Harmonic Algebraic Probability
            harmonic_base: Harmonic base parameter (default: phi)
            quantum_factor: Quantum influence factor (0.0 to 1.0)
        """
        super().__init__(
            name="Harmonic RAG Engine",
            version="1.0.0",
            description="Retrieval-Augmented Generation engine using Harmonic Algebraic principles",
            use_hap=use_hap,
            harmonic_base=harmonic_base,
            quantum_factor=quantum_factor
        )
        
        self.knowledge_base_path = knowledge_base_path
        self.embedding_dimension = embedding_dimension
        self.harmonic_resonance = harmonic_resonance
        
        # Initialize document storage
        self.document_index = {}  # doc_id -> {embedding, text, metadata}
        self.document_embeddings = {}  # doc_id -> embedding vector
        
        # Initialize the knowledge base
        self.initialize_knowledge_base()
        
        # Update metadata
        self.meta["capabilities"] = self.get_capabilities()
        self.meta["configuration"].update({
            "knowledge_base_path": knowledge_base_path,
            "embedding_dimension": embedding_dimension,
            "harmonic_resonance": harmonic_resonance
        })
        
        logger.info(f"Initialized {self.name} with knowledge base at {knowledge_base_path}")
    
    def get_capabilities(self) -> List[str]:
        """Get a list of capabilities provided by this engine."""
        return [
            "document_retrieval",
            "knowledge_management",
            "context_augmentation",
            "factual_enhancement",
            "harmonic_ranking"
        ]
    
    def initialize_knowledge_base(self) -> None:
        """Initialize and index the knowledge base."""
        # Create knowledge base directory if it doesn't exist
        os.makedirs(self.knowledge_base_path, exist_ok=True)
        
        # Create embeddings directory if it doesn't exist
        embeddings_path = os.path.join(self.knowledge_base_path, "embeddings")
        os.makedirs(embeddings_path, exist_ok=True)
        
        # Create documents directory if it doesn't exist
        documents_path = os.path.join(self.knowledge_base_path, "documents")
        os.makedirs(documents_path, exist_ok=True)
        
        # Load index if it exists
        index_path = os.path.join(self.knowledge_base_path, "index.json")
        if os.path.exists(index_path):
            with open(index_path, 'r') as f:
                self.document_index = json.load(f)
            
            # Load embeddings
            for doc_id in self.document_index:
                embedding_path = os.path.join(embeddings_path, f"{doc_id}.npy")
                if os.path.exists(embedding_path):
                    self.document_embeddings[doc_id] = np.load(embedding_path)
        
        logger.info(f"Loaded {len(self.document_index)} documents from knowledge base")
    
    def add_document(self, document_text: str, metadata: Optional[Dict[str, Any]] = None) -> str:
        """
        Add a document to the knowledge base with embeddings.
        
        Args:
            document_text: Text content of the document
            metadata: Additional metadata for the document
            
        Returns:
            Document ID
        """
        # Generate document ID
        doc_id = str(uuid.uuid4())
        
        # Generate embedding
        embedding = self._generate_embedding(document_text)
        
        # Store document
        self.document_index[doc_id] = {
            "text": document_text,
            "metadata": metadata or {},
            "added": datetime.now().isoformat()
        }
        self.document_embeddings[doc_id] = embedding
        
        # Save document to file
        documents_path = os.path.join(self.knowledge_base_path, "documents")
        with open(os.path.join(documents_path, f"{doc_id}.txt"), 'w') as f:
            f.write(document_text)
        
        # Save metadata
        with open(os.path.join(documents_path, f"{doc_id}.json"), 'w') as f:
            json.dump(metadata or {}, f, indent=2)
        
        # Save embedding
        embeddings_path = os.path.join(self.knowledge_base_path, "embeddings")
        np.save(os.path.join(embeddings_path, f"{doc_id}.npy"), embedding)
        
        # Update index
        index_path = os.path.join(self.knowledge_base_path, "index.json")
        with open(index_path, 'w') as f:
            json.dump(self.document_index, f, indent=2)
        
        logger.info(f"Added document {doc_id} to knowledge base")
        return doc_id
    
    def retrieve_relevant_context(self, query: str, top_k: int = 5) -> List[Dict[str, Any]]:
        """
        Retrieve most relevant documents for a given query.
        
        Args:
            query: Query text
            top_k: Number of top documents to retrieve
            
        Returns:
            List of relevant documents with similarity scores
        """
        if not self.document_embeddings:
            logger.warning("No documents in knowledge base for retrieval")
            return []
        
        # Generate query embedding
        query_embedding = self._generate_embedding(query)
        
        # Calculate similarity scores
        scores = {}
        for doc_id, doc_embedding in self.document_embeddings.items():
            # Calculate similarity using harmonic resonance
            similarity = self._calculate_harmonic_similarity(query_embedding, doc_embedding)
            scores[doc_id] = similarity
        
        # Sort by similarity score
        sorted_docs = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        
        # Return top-k documents
        results = []
        for doc_id, score in sorted_docs[:top_k]:
            doc_info = self.document_index[doc_id].copy()
            doc_info["id"] = doc_id
            doc_info["similarity"] = float(score)  # Convert numpy float to Python float
            results.append(doc_info)
        
        logger.info(f"Retrieved {len(results)} relevant documents for query")
        return results
    
    def harmonically_augment_generation(self, user_query: str, model_response: str) -> Dict[str, Any]:
        """
        Augment model generation with retrieved knowledge.
        
        Args:
            user_query: User query or prompt
            model_response: Initial model response
            
        Returns:
            Dictionary with augmented response and metadata
        """
        # Retrieve relevant context
        relevant_docs = self.retrieve_relevant_context(user_query)
        
        if not relevant_docs:
            logger.info("No relevant documents found for augmentation")
            return {
                "augmented_response": model_response,
                "used_documents": [],
                "augmentation_applied": False
            }
        
        # Extract relevant text from documents
        context_texts = [doc["text"] for doc in relevant_docs]
        context_combined = "\n\n".join(context_texts)
        
        # Apply harmonic augmentation
        # This is a simplified implementation - in a real system, we would 
        # use a more sophisticated approach to combine the response and context
        augmented_response = self._combine_with_harmonic_principles(model_response, context_combined)
        
        result = {
            "augmented_response": augmented_response,
            "used_documents": [
                {"id": doc["id"], "similarity": doc["similarity"]} 
                for doc in relevant_docs
            ],
            "augmentation_applied": True
        }
        
        logger.info(f"Augmented response with {len(relevant_docs)} documents")
        return result
    
    def process(self, input_data: Dict[str, Any], **kwargs) -> Dict[str, Any]:
        """
        Process input data using the Harmonic RAG Engine.
        
        Args:
            input_data: Dictionary containing input data
            **kwargs: Additional keyword arguments
            
        Returns:
            Dictionary with processed results
        """
        operation = input_data.get("operation", "augment")
        
        if operation == "add_document":
            document_text = input_data.get("document_text", "")
            metadata = input_data.get("metadata", {})
            
            if not document_text:
                return {"status": "error", "message": "No document text provided"}
            
            doc_id = self.add_document(document_text, metadata)
            return {
                "status": "success", 
                "message": "Document added successfully",
                "document_id": doc_id
            }
        
        elif operation == "retrieve":
            query = input_data.get("query", "")
            top_k = input_data.get("top_k", 5)
            
            if not query:
                return {"status": "error", "message": "No query provided"}
            
            relevant_docs = self.retrieve_relevant_context(query, top_k)
            return {
                "status": "success",
                "message": f"Retrieved {len(relevant_docs)} documents",
                "results": relevant_docs
            }
        
        elif operation == "augment":
            user_query = input_data.get("user_query", "")
            model_response = input_data.get("model_response", "")
            
            if not user_query or not model_response:
                return {"status": "error", "message": "Query and response must be provided"}
            
            augmentation_result = self.harmonically_augment_generation(user_query, model_response)
            augmentation_result["status"] = "success"
            return augmentation_result
        
        else:
            return {"status": "error", "message": f"Unknown operation: {operation}"}
    
    def _generate_embedding(self, text: str) -> np.ndarray:
        """
        Generate an embedding for the given text.
        
        Args:
            text: Text to embed
            
        Returns:
            Embedding vector
        """
        # This is a simplified placeholder implementation
        # In a real implementation, we would use a proper embedding model
        
        # If we have the HAP processor, use it for harmonic embedding
        if self.hap_processor:
            # Use a hash-based approach modulated by harmonic principles
            hash_val = hash(text)
            rng = np.random.RandomState(hash_val)
            
            # Generate a random vector
            base_embedding = rng.rand(self.embedding_dimension) * 2 - 1
            
            # Apply harmonic modulation
            harmonic_factors = np.array([
                np.sin(i * self.harmonic_base) 
                for i in range(self.embedding_dimension)
            ])
            
            # Combine
            embedding = base_embedding * harmonic_factors
            
            # Normalize
            norm = np.linalg.norm(embedding)
            if norm > 0:
                embedding = embedding / norm
                
            return embedding
        
        # Fallback to a simple hash-based approach
        hash_val = hash(text)
        rng = np.random.RandomState(hash_val)
        embedding = rng.rand(self.embedding_dimension) * 2 - 1
        
        # Normalize
        norm = np.linalg.norm(embedding)
        if norm > 0:
            embedding = embedding / norm
            
        return embedding
    
    def _calculate_harmonic_similarity(self, embedding1: np.ndarray, embedding2: np.ndarray) -> float:
        """
        Calculate similarity between embeddings using harmonic principles.
        
        Args:
            embedding1: First embedding
            embedding2: Second embedding
            
        Returns:
            Similarity score
        """
        # Use cosine similarity as the base
        dot_product = np.dot(embedding1, embedding2)
        
        # Apply harmonic resonance factor
        if self.hap_processor:
            # Apply a resonance factor based on the harmonic base
            phi_factor = (1 + np.sqrt(5)) / 2  # Golden ratio
            resonance = (1 - self.harmonic_resonance) + self.harmonic_resonance * (
                np.sin(dot_product * self.harmonic_base) * 0.5 + 0.5
            )
            
            # Apply quantum effect for small variations
            quantum_noise = np.random.random() * self.quantum_factor
            
            return dot_product * resonance + quantum_noise
        
        # Fallback to standard cosine similarity
        return dot_product
    
    def _combine_with_harmonic_principles(self, response: str, context: str) -> str:
        """
        Combine model response with context using harmonic principles.
        
        Args:
            response: Model response
            context: Retrieved context
            
        Returns:
            Augmented response
        """
        # Simplified implementation - in a real system, we would use 
        # a more sophisticated approach for combining text
        
        # Extract key facts from context (simplified)
        context_sentences = context.split(". ")
        selected_facts = context_sentences[:min(3, len(context_sentences))]
        facts_text = ". ".join(selected_facts) + "." if selected_facts else ""
        
        # Check if response already contains the facts
        facts_already_included = all(
            fact.lower() in response.lower() for fact in selected_facts if fact
        )
        
        if facts_already_included:
            return response
        
        # Create augmented response
        if facts_text:
            # For this simple version, we'll just append the facts to the response
            augmented_response = f"{response}\n\nAdditional relevant information:\n{facts_text}"
            return augmented_response
        
        return response
    
    def reset(self) -> Dict[str, Any]:
        """
        Reset engine state while preserving the knowledge base.
        
        Returns:
            Status dictionary
        """
        super().reset()
        return {"status": "success", "message": "Engine reset successfully"}