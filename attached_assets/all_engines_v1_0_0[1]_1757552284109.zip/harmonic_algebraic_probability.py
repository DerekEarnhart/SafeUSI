"""
Harmonic Algebraic Probability (HAP) Framework

This module provides a computational framework for working with harmonic algebraic
probability principles, which combine concepts from quantum mechanics, wave theory,
and non-linear dynamics to create a probabilistic system that follows harmonic relationships.
"""

import os
import sys
import json
import logging
import math
from enum import Enum, auto
from typing import Dict, List, Any, Optional, Union, Tuple, Set

import numpy as np

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class DistributionType(Enum):
    """Types of probability distributions used in HAP."""
    QUANTUM_HARMONIC = auto()
    CLASSIC_NORMAL = auto()
    PROBABILITY_WAVE = auto()
    HARMONIC_RESONANCE = auto()
    FIBONACCI_WEIGHTED = auto()
    PHI_DISTRIBUTED = auto()

class HAPProcessor:
    """
    Core processor for Harmonic Algebraic Probability calculations.
    
    This class provides methods for transforming data using harmonic principles,
    calculating resonance patterns, and generating harmonic-weighted probabilities.
    """
    
    def __init__(self, harmonic_base: float = 1.618, dimension: int = 3, 
                quantum_factor: float = 0.01, resonance_threshold: float = 0.7):
        """
        Initialize the HAP Processor.
        
        Args:
            harmonic_base: Base harmonic constant (phi by default)
            dimension: Number of dimensions to process in
            quantum_factor: Quantum influence factor (0.0 to 1.0)
            resonance_threshold: Threshold for resonance detection
        """
        self.harmonic_base = harmonic_base
        self.dimension = dimension
        self.quantum_factor = quantum_factor
        self.resonance_threshold = resonance_threshold
        
        # Initialize state
        self.state = {
            "iteration_count": 0,
            "total_resonance": 0.0,
            "resonance_history": [],
            "probability_fields": {}
        }
        
        logger.info(f"Initialized HAP Processor (Base: {harmonic_base}, Dimension: {dimension})")
    
    def process_time_series(self, data: np.ndarray, time_index: Optional[np.ndarray] = None) -> Dict[str, np.ndarray]:
        """
        Process a time series using HAP principles.
        
        Args:
            data: Time series data
            time_index: Optional time index array
            
        Returns:
            Dictionary of processed results
        """
        if time_index is None:
            time_index = np.arange(len(data))
        
        # Update state
        self.state["iteration_count"] += 1
        
        # Normalize data
        norm_data = (data - np.mean(data)) / np.std(data) if np.std(data) > 0 else data
        
        # Generate harmonic resonance pattern
        resonance = self._calculate_harmonic_resonance(norm_data)
        self.state["total_resonance"] += np.sum(resonance)
        self.state["resonance_history"].append(np.mean(resonance))
        
        # Apply quantum transformation
        quantum_field = self._apply_quantum_transformation(norm_data)
        
        # Calculate wave coefficients
        wave_coeffs = self._calculate_wave_coefficients(norm_data, time_index)
        
        # Store results
        result = {
            "resonance": resonance,
            "quantum_field": quantum_field,
            "wave_coefficients": wave_coeffs,
            "harmonic_probability": self._harmonic_probability(norm_data, resonance)
        }
        
        return result
    
    def _calculate_harmonic_resonance(self, data: np.ndarray) -> np.ndarray:
        """
        Calculate harmonic resonance pattern for data.
        
        Args:
            data: Input data array
            
        Returns:
            Resonance values array
        """
        resonance = np.zeros_like(data)
        phi = self.harmonic_base
        
        for i in range(2, len(data)):
            # Calculate first differences
            d1 = data[i] - data[i-1]
            d2 = data[i-1] - data[i-2]
            
            if d2 != 0:
                # Calculate ratio between consecutive differences
                ratio = abs(d1 / d2)
                
                # Compare to harmonic ratios (phi, 1/phi, phi^2, etc.)
                ratios = [1/phi**2, 1/phi, 1.0, phi, phi**2]
                weights = [0.6, 0.8, 1.0, 0.8, 0.6]  # Centrally weighted
                
                # Calculate weighted resonance
                total_weight = 0
                weighted_res = 0
                
                for r, w in zip(ratios, weights):
                    res = math.exp(-((ratio - r) ** 2) / 0.05)  # Gaussian similarity
                    weighted_res += res * w
                    total_weight += w
                
                resonance[i] = weighted_res / total_weight if total_weight > 0 else 0
        
        return resonance
    
    def _apply_quantum_transformation(self, data: np.ndarray) -> np.ndarray:
        """
        Apply quantum transformation to data.
        
        Args:
            data: Input data array
            
        Returns:
            Transformed data array
        """
        # Generate phase based on data
        phase = np.cumsum(data) * 2 * np.pi / len(data)
        
        # Create quantum wave function
        psi = np.exp(1j * phase) * np.exp(-np.arange(len(data)) / len(data) * self.quantum_factor)
        
        # Calculate probability amplitude (Born rule)
        prob = np.abs(psi) ** 2
        
        # Normalize
        quantum_field = prob / np.max(prob) if np.max(prob) > 0 else prob
        
        return quantum_field
    
    def _calculate_wave_coefficients(self, data: np.ndarray, time_index: np.ndarray) -> np.ndarray:
        """
        Calculate wave coefficients for data.
        
        Args:
            data: Input data array
            time_index: Time index array
            
        Returns:
            Wave coefficients array
        """
        # Normalize time to [0, 2π]
        norm_time = time_index / np.max(time_index) * 2 * np.pi if np.max(time_index) > 0 else time_index
        
        # Calculate wave coefficients using harmonic base
        phi = self.harmonic_base
        coeffs = np.zeros_like(data)
        
        for i in range(len(data)):
            # Weight by phi-based factors
            harmonic_term = np.sin(norm_time[i]) + np.sin(phi * norm_time[i]) / phi
            coeffs[i] = data[i] * harmonic_term
        
        return coeffs
    
    def _harmonic_probability(self, data: np.ndarray, resonance: np.ndarray) -> np.ndarray:
        """
        Calculate harmonic-weighted probability distribution.
        
        Args:
            data: Input data array
            resonance: Resonance values array
            
        Returns:
            Probability distribution array
        """
        # Combine data and resonance to create probability distribution
        probability = (data + 1) / 2  # Scale to [0, 1] assuming normalized data
        
        # Apply resonance weighting
        weighted_prob = probability * resonance
        
        # Normalize
        total = np.sum(weighted_prob)
        norm_prob = weighted_prob / total if total > 0 else weighted_prob
        
        return norm_prob
    
    def calculate_resonance_pattern(self, data: np.ndarray, pattern_type: str = "fibonacci") -> Tuple[np.ndarray, float]:
        """
        Calculate resonance pattern for data.
        
        Args:
            data: Input data array
            pattern_type: Type of pattern to detect
            
        Returns:
            Tuple of (pattern matches, resonance score)
        """
        if pattern_type == "fibonacci":
            fib_ratios = [0.236, 0.382, 0.5, 0.618, 0.786, 1.0, 1.618, 2.618]
            
            pattern_matches = np.zeros_like(data)
            
            for i in range(3, len(data)):
                # Calculate retracements
                d1 = data[i] - data[i-1]
                d2 = data[i-1] - data[i-2]
                d3 = data[i-2] - data[i-3]
                
                if d2 != 0 and d3 != 0:
                    r1 = abs(d1 / d2)
                    r2 = abs(d2 / d3)
                    
                    # Check if ratios are close to Fibonacci ratios
                    matches1 = [math.exp(-((r1 - f) ** 2) / 0.01) for f in fib_ratios]
                    matches2 = [math.exp(-((r2 - f) ** 2) / 0.01) for f in fib_ratios]
                    
                    pattern_matches[i] = max(matches1) * max(matches2)
            
            resonance_score = np.mean(pattern_matches)
            
        elif pattern_type == "harmonic":
            # Harmonic pattern detection (e.g., ABCD patterns)
            pattern_matches = np.zeros_like(data)
            patterns = [
                (0.382, 0.618, 1.272),  # Gartley
                (0.447, 0.618, 1.618),  # Butterfly
                (0.382, 0.886, 1.618)   # Bat
            ]
            
            for i in range(4, len(data)):
                # Use 4 points: i, i-1, i-2, i-3
                d1 = abs(data[i] - data[i-1])
                d2 = abs(data[i-1] - data[i-2])
                d3 = abs(data[i-2] - data[i-3])
                
                if d1 > 0 and d2 > 0 and d3 > 0:
                    r1 = d1 / d3
                    r2 = d2 / d3
                    r3 = d1 / d2
                    
                    # Check pattern matches
                    for pattern in patterns:
                        dist1 = abs(r1 - pattern[0])
                        dist2 = abs(r2 - pattern[1])
                        dist3 = abs(r3 - pattern[2])
                        
                        # Calculate match quality
                        match_quality = math.exp(-(dist1 + dist2 + dist3) / 0.5)
                        pattern_matches[i] = max(pattern_matches[i], match_quality)
            
            resonance_score = np.mean(pattern_matches)
            
        else:
            # Default simple pattern
            pattern_matches = np.zeros_like(data)
            resonance_score = 0.0
        
        return pattern_matches, resonance_score
    
    def quantum_probability_transform(self, probabilities: np.ndarray, 
                                      distribution_type: DistributionType = DistributionType.QUANTUM_HARMONIC) -> np.ndarray:
        """
        Transform probabilities using quantum principles.
        
        Args:
            probabilities: Input probability distribution
            distribution_type: Type of probability distribution to use
            
        Returns:
            Transformed probability distribution
        """
        if distribution_type == DistributionType.QUANTUM_HARMONIC:
            # Apply quantum transformation with harmonic weighting
            transformed = np.zeros_like(probabilities)
            
            for i in range(len(probabilities)):
                phase = 2 * np.pi * i / len(probabilities)
                quantum_factor = np.abs(np.exp(1j * phase * self.harmonic_base) * probabilities[i])
                transformed[i] = quantum_factor
            
            # Normalize
            total = np.sum(transformed)
            return transformed / total if total > 0 else transformed
            
        elif distribution_type == DistributionType.CLASSIC_NORMAL:
            # Just return normalized probabilities
            total = np.sum(probabilities)
            return probabilities / total if total > 0 else probabilities
            
        elif distribution_type == DistributionType.PROBABILITY_WAVE:
            # Create a wave-like probability distribution
            wave = np.sin(np.arange(len(probabilities)) / len(probabilities) * 2 * np.pi * self.harmonic_base) + 1
            transformed = probabilities * wave
            
            # Normalize
            total = np.sum(transformed)
            return transformed / total if total > 0 else transformed
            
        elif distribution_type == DistributionType.FIBONACCI_WEIGHTED:
            # Weight by Fibonacci sequence
            fibonacci = [1, 1]
            while len(fibonacci) < len(probabilities):
                fibonacci.append(fibonacci[-1] + fibonacci[-2])
            
            weights = np.array(fibonacci[:len(probabilities)], dtype=float)
            weights = weights / np.max(weights) if np.max(weights) > 0 else weights
            
            transformed = probabilities * weights
            
            # Normalize
            total = np.sum(transformed)
            return transformed / total if total > 0 else transformed
            
        else:
            return probabilities
    
    def apply_harmonic_transform(self, data: np.ndarray, time_index: Optional[np.ndarray] = None) -> Dict[str, Any]:
        """
        Apply a comprehensive harmonic transformation to data.
        
        Args:
            data: Input data array
            time_index: Optional time index array
            
        Returns:
            Dictionary of transformation results
        """
        if time_index is None:
            time_index = np.arange(len(data))
        
        # Process time series
        processed = self.process_time_series(data, time_index)
        
        # Calculate resonance patterns
        pattern_matches, resonance_score = self.calculate_resonance_pattern(data)
        
        # Perform quantum probability transform
        quantum_prob = self.quantum_probability_transform(processed["harmonic_probability"])
        
        # Combine results
        result = {
            "original_data": data,
            "harmonic_resonance": processed["resonance"],
            "quantum_field": processed["quantum_field"],
            "wave_coefficients": processed["wave_coefficients"],
            "pattern_matches": pattern_matches,
            "resonance_score": resonance_score,
            "quantum_probability": quantum_prob,
            "harmonic_base": self.harmonic_base,
            "dimension": self.dimension
        }
        
        return result
    
    def analyze_signal(self, signal: np.ndarray, parameters: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Analyze a signal using HAP principles.
        
        Args:
            signal: Input signal array
            parameters: Optional analysis parameters
            
        Returns:
            Analysis results
        """
        if parameters is None:
            parameters = {}
        
        # Extract parameters with defaults
        window_size = parameters.get("window_size", 20)
        overlap = parameters.get("overlap", 0.5)
        
        # Create time index if not provided
        time_index = parameters.get("time_index", np.arange(len(signal)))
        
        # Apply transformation
        harmonic_transform = self.apply_harmonic_transform(signal, time_index)
        
        # Perform windowed analysis
        windows = []
        window_results = []
        
        step = int(window_size * (1 - overlap))
        for i in range(0, len(signal) - window_size + 1, max(1, step)):
            window = signal[i:i+window_size]
            window_time = time_index[i:i+window_size]
            
            # Process window
            window_transform = self.apply_harmonic_transform(window, window_time)
            
            # Store window results
            windows.append((i, i+window_size))
            window_results.append({
                "start_idx": i,
                "end_idx": i+window_size,
                "resonance_score": window_transform["resonance_score"],
                "quantum_field": window_transform["quantum_field"],
                "pattern_matches": window_transform["pattern_matches"]
            })
        
        # Find highest resonance windows
        if window_results:
            resonance_scores = [w["resonance_score"] for w in window_results]
            top_idx = np.argsort(resonance_scores)[-3:]  # Top 3 windows
            top_windows = [window_results[i] for i in top_idx]
        else:
            top_windows = []
        
        # Create analysis result
        analysis_result = {
            "signal_length": len(signal),
            "harmonic_transform": harmonic_transform,
            "window_count": len(windows),
            "window_results": window_results,
            "top_resonance_windows": top_windows,
            "overall_resonance": harmonic_transform["resonance_score"],
            "quantum_influence": np.mean(harmonic_transform["quantum_field"]),
            "parameters": {
                "harmonic_base": self.harmonic_base,
                "dimension": self.dimension,
                "quantum_factor": self.quantum_factor,
                "window_size": window_size,
                "overlap": overlap
            }
        }
        
        return analysis_result
    
    def generate_probabilistic_signal(self, length: int, signal_type: str = "harmonic", 
                                      parameters: Optional[Dict[str, Any]] = None) -> np.ndarray:
        """
        Generate a probabilistic signal using HAP principles.
        
        Args:
            length: Length of signal to generate
            signal_type: Type of signal to generate
            parameters: Optional generation parameters
            
        Returns:
            Generated signal array
        """
        if parameters is None:
            parameters = {}
        
        # Extract parameters with defaults
        amplitude = parameters.get("amplitude", 1.0)
        noise_level = parameters.get("noise_level", 0.1)
        trend = parameters.get("trend", 0.0)
        
        # Initialize signal
        signal = np.zeros(length)
        
        if signal_type == "harmonic":
            # Generate harmonic signal based on golden ratio (phi)
            phi = self.harmonic_base
            
            for i in range(length):
                t = i / length
                
                # Combine harmonic frequencies with phi-based relationships
                signal[i] = (
                    amplitude * np.sin(2 * np.pi * t) +
                    amplitude / phi * np.sin(2 * np.pi * phi * t) +
                    amplitude / (phi * phi) * np.sin(2 * np.pi * phi * phi * t)
                )
                
                # Add trend
                signal[i] += trend * i / length
        
        elif signal_type == "quantum":
            # Generate quantum-inspired signal
            phase = np.random.uniform(0, 2 * np.pi)
            
            for i in range(length):
                t = i / length
                
                # Quantum wave function with phi-based parameters
                psi = np.exp(1j * (2 * np.pi * t * self.harmonic_base + phase))
                
                # Convert to real signal (probability amplitude)
                signal[i] = amplitude * np.abs(psi) ** 2
                
                # Add trend
                signal[i] += trend * i / length
        
        elif signal_type == "fibonacci":
            # Generate Fibonacci pattern signal
            fib_sequence = [1, 1]
            while len(fib_sequence) < length:
                fib_sequence.append(fib_sequence[-1] + fib_sequence[-2])
            
            # Convert to signal with appropriate scaling
            max_fib = max(fib_sequence[:length])
            for i in range(min(length, len(fib_sequence))):
                signal[i] = amplitude * fib_sequence[i] / max_fib
                
                # Add trend
                signal[i] += trend * i / length
            
            # Fill remaining points if needed
            if length > len(fib_sequence):
                for i in range(len(fib_sequence), length):
                    signal[i] = signal[i-1]  # Hold last value
        
        else:
            # Default to random walk with harmonic perturbations
            signal[0] = 0
            
            for i in range(1, length):
                # Random step with harmonic influence
                step = np.random.normal(0, 0.1)
                
                # Add harmonic component
                t = i / length
                harmonic = amplitude * 0.1 * np.sin(2 * np.pi * t * self.harmonic_base)
                
                signal[i] = signal[i-1] + step + harmonic
                
                # Add trend
                signal[i] += trend / length
        
        # Add noise
        if noise_level > 0:
            noise = np.random.normal(0, noise_level, length)
            signal += noise
        
        return signal
    
    def resonance_optimization(self, data: np.ndarray, target_function: callable, 
                              iterations: int = 100, learning_rate: float = 0.01) -> Dict[str, Any]:
        """
        Optimize parameters to maximize resonance with target function.
        
        Args:
            data: Input data array
            target_function: Target function to optimize for
            iterations: Number of optimization iterations
            learning_rate: Learning rate for gradient descent
            
        Returns:
            Optimization results
        """
        # Initialize parameters
        current_harmonic_base = self.harmonic_base
        current_quantum_factor = self.quantum_factor
        
        best_score = -float('inf')
        best_params = {
            "harmonic_base": current_harmonic_base,
            "quantum_factor": current_quantum_factor
        }
        
        scores = []
        
        # Run optimization
        for i in range(iterations):
            # Calculate current score
            harmonic_transform = self.apply_harmonic_transform(data)
            current_score = target_function(harmonic_transform)
            scores.append(current_score)
            
            # Check if this is the best score
            if current_score > best_score:
                best_score = current_score
                best_params = {
                    "harmonic_base": current_harmonic_base,
                    "quantum_factor": current_quantum_factor
                }
            
            # Calculate gradients (approximate)
            delta = 0.01
            
            # Gradient for harmonic base
            self.harmonic_base = current_harmonic_base + delta
            harmonic_transform_p = self.apply_harmonic_transform(data)
            score_p = target_function(harmonic_transform_p)
            
            self.harmonic_base = current_harmonic_base - delta
            harmonic_transform_n = self.apply_harmonic_transform(data)
            score_n = target_function(harmonic_transform_n)
            
            grad_harmonic_base = (score_p - score_n) / (2 * delta)
            
            # Gradient for quantum factor
            self.harmonic_base = current_harmonic_base
            self.quantum_factor = current_quantum_factor + delta
            quantum_transform_p = self.apply_harmonic_transform(data)
            score_p = target_function(quantum_transform_p)
            
            self.quantum_factor = current_quantum_factor - delta
            quantum_transform_n = self.apply_harmonic_transform(data)
            score_n = target_function(quantum_transform_n)
            
            grad_quantum_factor = (score_p - score_n) / (2 * delta)
            
            # Update parameters
            current_harmonic_base += learning_rate * grad_harmonic_base
            current_quantum_factor += learning_rate * grad_quantum_factor
            
            # Apply constraints
            current_harmonic_base = max(1.1, min(2.0, current_harmonic_base))
            current_quantum_factor = max(0.001, min(0.1, current_quantum_factor))
            
            # Update processor parameters
            self.harmonic_base = current_harmonic_base
            self.quantum_factor = current_quantum_factor
        
        # Set to best parameters
        self.harmonic_base = best_params["harmonic_base"]
        self.quantum_factor = best_params["quantum_factor"]
        
        # Final evaluation
        final_transform = self.apply_harmonic_transform(data)
        final_score = target_function(final_transform)
        
        optimization_result = {
            "initial_score": scores[0] if scores else None,
            "final_score": final_score,
            "best_score": best_score,
            "best_params": best_params,
            "current_params": {
                "harmonic_base": self.harmonic_base,
                "quantum_factor": self.quantum_factor
            },
            "score_history": scores,
            "iterations": iterations
        }
        
        return optimization_result
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert processor state to dictionary."""
        return {
            "harmonic_base": self.harmonic_base,
            "dimension": self.dimension,
            "quantum_factor": self.quantum_factor,
            "resonance_threshold": self.resonance_threshold,
            "state": self.state
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'HAPProcessor':
        """Create processor from dictionary."""
        processor = cls(
            harmonic_base=data.get("harmonic_base", 1.618),
            dimension=data.get("dimension", 3),
            quantum_factor=data.get("quantum_factor", 0.01),
            resonance_threshold=data.get("resonance_threshold", 0.7)
        )
        
        if "state" in data:
            processor.state = data["state"]
        
        return processor

class HAPJSONEncoder(json.JSONEncoder):
    """JSON encoder for HAP objects."""
    
    def default(self, obj):
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, DistributionType):
            return obj.name
        elif isinstance(obj, HAPProcessor):
            return obj.to_dict()
        elif isinstance(obj, HarmonicAlgebraicProbability):
            return obj.to_dict()


class HarmonicAlgebraicProbability:
    """
    High-level interface for the Harmonic Algebraic Probability framework.
    
    This class provides a unified interface for working with HAP principles,
    including signal analysis, pattern detection, probability transformation,
    and harmonic resonance detection.
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize the Harmonic Algebraic Probability framework.
        
        Args:
            config: Optional configuration dictionary
        """
        self.config = config or {}
        self.initialized = False
        
        # Default configuration
        self.harmonic_base = self.config.get('harmonic_base', 1.618)
        self.dimension = self.config.get('dimension', 3)
        self.quantum_factor = self.config.get('quantum_factor', 0.01)
        self.resonance_threshold = self.config.get('resonance_threshold', 0.7)
        
        # Initialize processors
        try:
            # Main processor
            self.processor = HAPProcessor(
                harmonic_base=self.harmonic_base,
                dimension=self.dimension,
                quantum_factor=self.quantum_factor,
                resonance_threshold=self.resonance_threshold
            )
            
            # Distribution type mapping
            self.distribution_types = {
                'quantum': DistributionType.QUANTUM_HARMONIC,
                'classic': DistributionType.CLASSIC_NORMAL,
                'wave': DistributionType.PROBABILITY_WAVE,
                'resonance': DistributionType.HARMONIC_RESONANCE,
                'fibonacci': DistributionType.FIBONACCI_WEIGHTED,
                'phi': DistributionType.PHI_DISTRIBUTED
            }
            
            # Analysis results cache
            self.last_results = {}
            
            # Status tracking
            self.status = {
                'initialization_time': datetime.now().isoformat(),
                'last_analysis': None,
                'analysis_count': 0,
                'signal_types_analyzed': set(),
                'distribution_types_used': set()
            }
            
            self.initialized = True
            logger.info("Harmonic Algebraic Probability framework initialized successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize HAP framework: {e}")
            import traceback
            logger.debug(traceback.format_exc())
    
    def analyze_signal(self, signal: np.ndarray, parameters: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Analyze a signal using HAP principles.
        
        Args:
            signal: Input signal array
            parameters: Optional analysis parameters
            
        Returns:
            Analysis results
        """
        if not self.initialized:
            return {'status': 'error', 'message': 'Framework not initialized'}
        
        parameters = parameters or {}
        signal_type = parameters.get('signal_type', 'unknown')
        
        try:
            # Process the signal
            results = self.processor.analyze_signal(signal, parameters)
            
            # Update status
            self.status['last_analysis'] = datetime.now().isoformat()
            self.status['analysis_count'] += 1
            self.status['signal_types_analyzed'].add(signal_type)
            
            # Cache results
            self.last_results[signal_type] = {
                'timestamp': datetime.now().isoformat(),
                'parameters': parameters,
                'summary': {
                    'signal_length': len(signal),
                    'resonance_score': results.get('resonance_score', 0),
                    'harmonic_base': self.harmonic_base
                }
            }
            
            # Return full results
            return {
                'status': 'success',
                'signal_type': signal_type,
                'results': results
            }
            
        except Exception as e:
            logger.error(f"Error analyzing signal: {e}")
            import traceback
            logger.debug(traceback.format_exc())
            
            return {
                'status': 'error',
                'message': f"Failed to analyze signal: {str(e)}"
            }
    
    def transform_probability(self, probabilities: np.ndarray, distribution_type: str = 'quantum') -> Dict[str, Any]:
        """
        Transform a probability distribution using HAP principles.
        
        Args:
            probabilities: Input probability distribution
            distribution_type: Type of distribution to use
            
        Returns:
            Transformed distribution results
        """
        if not self.initialized:
            return {'status': 'error', 'message': 'Framework not initialized'}
        
        try:
            # Get distribution type
            dist_type = self.distribution_types.get(
                distribution_type, 
                DistributionType.QUANTUM_HARMONIC
            )
            
            # Transform probabilities
            transformed = self.processor.quantum_probability_transform(
                probabilities, 
                dist_type
            )
            
            # Update status
            self.status['distribution_types_used'].add(distribution_type)
            
            # Return results
            return {
                'status': 'success',
                'distribution_type': distribution_type,
                'original': probabilities.tolist(),
                'transformed': transformed.tolist(),
                'harmonic_base': self.harmonic_base
            }
            
        except Exception as e:
            logger.error(f"Error transforming probabilities: {e}")
            import traceback
            logger.debug(traceback.format_exc())
            
            return {
                'status': 'error',
                'message': f"Failed to transform probabilities: {str(e)}"
            }
    
    def detect_harmonic_patterns(self, data: np.ndarray, pattern_types: List[str] = None) -> Dict[str, Any]:
        """
        Detect harmonic patterns in data.
        
        Args:
            data: Input data array
            pattern_types: Types of patterns to detect
            
        Returns:
            Pattern detection results
        """
        if not self.initialized:
            return {'status': 'error', 'message': 'Framework not initialized'}
        
        pattern_types = pattern_types or ['fibonacci', 'harmonic']
        
        try:
            results = {}
            
            for pattern_type in pattern_types:
                pattern_matches, score = self.processor.calculate_resonance_pattern(
                    data, 
                    pattern_type
                )
                
                results[pattern_type] = {
                    'matches': pattern_matches.tolist(),
                    'score': score
                }
            
            # Return results
            return {
                'status': 'success',
                'pattern_types': pattern_types,
                'results': results,
                'strongest_pattern': max(results.items(), key=lambda x: x[1]['score'])[0]
            }
            
        except Exception as e:
            logger.error(f"Error detecting patterns: {e}")
            import traceback
            logger.debug(traceback.format_exc())
            
            return {
                'status': 'error',
                'message': f"Failed to detect patterns: {str(e)}"
            }
    
    def apply_harmonic_transform(self, data: np.ndarray, time_index: Optional[np.ndarray] = None) -> Dict[str, Any]:
        """
        Apply harmonic transformation to data.
        
        Args:
            data: Input data array
            time_index: Optional time index array
            
        Returns:
            Transformation results
        """
        if not self.initialized:
            return {'status': 'error', 'message': 'Framework not initialized'}
        
        try:
            # Apply transformation
            result = self.processor.apply_harmonic_transform(data, time_index)
            
            # Return results
            return {
                'status': 'success',
                'result': result
            }
            
        except Exception as e:
            logger.error(f"Error applying harmonic transform: {e}")
            import traceback
            logger.debug(traceback.format_exc())
            
            return {
                'status': 'error',
                'message': f"Failed to apply harmonic transform: {str(e)}"
            }
    
    def get_framework_status(self) -> Dict[str, Any]:
        """
        Get the current status of the HAP framework.
        
        Returns:
            Framework status information
        """
        if not self.initialized:
            return {'status': 'error', 'message': 'Framework not initialized'}
        
        # Convert sets to lists for JSON serialization
        status_copy = self.status.copy()
        status_copy['signal_types_analyzed'] = list(self.status['signal_types_analyzed'])
        status_copy['distribution_types_used'] = list(self.status['distribution_types_used'])
        
        return {
            'status': 'active',
            'framework_status': status_copy,
            'configuration': {
                'harmonic_base': self.harmonic_base,
                'dimension': self.dimension,
                'quantum_factor': self.quantum_factor,
                'resonance_threshold': self.resonance_threshold
            },
            'processor_state': self.processor.state,
            'timestamp': datetime.now().isoformat()
        }
    
    def update_configuration(self, new_config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Update framework configuration.
        
        Args:
            new_config: New configuration values
            
        Returns:
            Status dictionary
        """
        if not self.initialized:
            return {'status': 'error', 'message': 'Framework not initialized'}
        
        # Update configuration
        for key, value in new_config.items():
            self.config[key] = value
        
        # Update processor parameters
        update_processor = False
        
        if 'harmonic_base' in new_config:
            self.harmonic_base = new_config['harmonic_base']
            update_processor = True
        
        if 'dimension' in new_config:
            self.dimension = new_config['dimension']
            update_processor = True
        
        if 'quantum_factor' in new_config:
            self.quantum_factor = new_config['quantum_factor']
            update_processor = True
        
        if 'resonance_threshold' in new_config:
            self.resonance_threshold = new_config['resonance_threshold']
            update_processor = True
        
        # Create new processor with updated parameters if needed
        if update_processor:
            self.processor = HAPProcessor(
                harmonic_base=self.harmonic_base,
                dimension=self.dimension,
                quantum_factor=self.quantum_factor,
                resonance_threshold=self.resonance_threshold
            )
        
        logger.info(f"Updated HAP framework configuration: {new_config}")
        
        return {'status': 'success', 'configuration': self.config}
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            'harmonic_base': self.harmonic_base,
            'dimension': self.dimension,
            'quantum_factor': self.quantum_factor,
            'resonance_threshold': self.resonance_threshold,
            'initialized': self.initialized,
            'status': self.status,
            'processor': self.processor.to_dict() if self.initialized else None
        }
        return super().default(obj)