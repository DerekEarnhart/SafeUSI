use axum::{
    routing::{get, post},
    extract::{Path, State},
    response::{sse::{Sse, Event}, IntoResponse},
    Json, Router,
};
use serde::{Deserialize, Serialize};
use std::{net::SocketAddr, sync::{Arc, Mutex}, time::Duration};
use tokio::sync::broadcast;
use uuid::Uuid;
use tokio_stream::{wrappers::BroadcastStream, StreamExt};

#[derive(Clone)]
struct AppState {
    tx: broadcast::Sender<(String,String)>, // (job_id, payload)
}

#[derive(Deserialize)]
struct JobManifest(serde_json::Value);

#[derive(Serialize)]
struct JobResponse { job_id: String }

#[tokio::main]
async fn main() {
    tracing_subscriber::fmt::init();

    // small broadcast channel for event simulation
    let (tx, _rx) = broadcast::channel(100);
    let state = AppState { tx };

    let app = Router::new()
        .route("/resources", get(list_resources))
        .route("/jobs", post(submit_job))
        .route("/jobs/:id/events", get(job_events))
        .with_state(Arc::new(Mutex::new(state)));

    let addr = SocketAddr::from(([127,0,0,1], 7878));
    println!("Agent listening on http://{}", addr);
    axum::Server::bind(&addr)
        .serve(app.into_make_service())
        .await
        .unwrap();
}

async fn list_resources() -> impl IntoResponse {
    let resources = serde_json::json!([
        { "type":"analog_emulator", "id":"emu0", "fidelity":"1e-2" },
        { "type":"gpu", "id":"local_gpu", "memory_gb":16 }
    ]);
    Json(resources)
}

async fn submit_job(
    State(state): State<Arc<Mutex<AppState>>>,
    Json(manifest): Json<JobManifest>
) -> impl IntoResponse {
    // create a job id and spawn a simulated runner that emits SSE events
    let job_id = Uuid::new_v4().to_string();
    let json_preview = serde_json::to_string(&manifest.0).unwrap_or_else(|_| "{}".to_string());

    // send initial event(s) from a background task
    let tx = state.lock().unwrap().tx.clone();
    let jid = job_id.clone();
    tokio::spawn(async move {
        // Simulate telemetry
        let updates = vec![
            format!("job.started: {}", jid),
            format!("provenance: manifest_hash={}", sha256hex(&json_preview)),
            "stage:coarse_search started".to_string(),
        ];
        for (i,u) in updates.into_iter().enumerate() {
            let _ = tx.send((jid.clone(), u));
            tokio::time::sleep(Duration::from_millis(400 + (i as u64)*200)).await;
        }
        // periodic fake loss values
        for step in 0..12 {
            let loss = 0.8_f64.powf((step as f64)/2.0) * (1.0 + (step as f64)*0.002);
            let ev = format!("telemetry: step={} loss={:.6}", step, loss);
            let _ = tx.send((jid.clone(), ev));
            tokio::time::sleep(Duration::from_millis(350)).await;
        }
        let _ = tx.send((jid.clone(), "stage:coarse_search complete".to_string()));
        let _ = tx.send((jid.clone(), "verification: started (deterministic check)".to_string()));
        tokio::time::sleep(Duration::from_millis(600)).await;
        let _ = tx.send((jid.clone(), "job.finished: success".to_string()));
    });

    let resp = JobResponse { job_id };
    (axum::http::StatusCode::ACCEPTED, Json(resp))
}

async fn job_events(
    Path(id): Path<String>,
    State(state): State<Arc<Mutex<AppState>>>
) -> impl IntoResponse {
    // subscribe to broadcast channel and filter by job id
    let mut rx = state.lock().unwrap().tx.subscribe();
    let stream = BroadcastStream::new(rx).filter_map(move |res| {
        let id_clone = id.clone();
        async move {
            match res {
                Ok((jid, payload)) if jid == id_clone => Some(Ok(Event::default().data(payload))),
                _ => None
            }
        }
    });
    Sse::new(stream)
}

fn sha256hex(s: &str) -> String {
    use sha2::{Sha256, Digest};
    let mut hasher = Sha256::new();
    hasher.update(s.as_bytes());
    let res = hasher.finalize();
    hex::encode(res)
}
