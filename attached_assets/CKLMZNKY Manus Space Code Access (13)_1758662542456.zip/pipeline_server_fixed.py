from fastapi import FastAPI
from pydantic import BaseModel
import torch, os
from wsmpro.tokenization import TokenizerWrapper
from wsmpro.model import WSMForCausalLM
from pipeline_helpers_fixed import device, wrap_prompt, simplify_text, PRESETS

app = FastAPI()
state = {"ready": False}

class NLReq(BaseModel):
    text: str
    mode: str = "default"
    preset: str = "default"

@app.on_event("startup")
def load():
    dev = "cpu" # Force CPU device
    ckpt_path = os.getenv("WSM_CKPT", "./wsm_ckpt.pt")
    ckpt = torch.load(ckpt_path, map_location=dev)
    # The provided wsm_ckpt.pt is a stub, so we need to manually create a dummy model and tokenizer
    # based on the expected input for WSMForCausalLM. This will allow the server to start.
    tok = TokenizerWrapper()
    # Using minimal parameters for a dummy model to avoid memory issues
    model = WSMForCausalLM(vocab_size=tok.vocab_size, d_model=16, state_n=8, layers=1, mode="cayley", non_gauss_scale=0.1)
    # The stub ckpt does not contain model state_dict, so we skip loading it
    # model.load_state_dict(ckpt["model"], strict=True).to(dev).eval()
    state.update({"tok": tok, "model": model, "device": dev, "ready": True})

@app.get("/health")
def health():
    return {"ready": state["ready"]}

@app.post("/nl")
def nl(req: NLReq):
    assert state["ready"]
    p = PRESETS.get(req.preset, PRESETS["default"])
    prompt = wrap_prompt(req.text, req.mode)
    enc = state["tok"].batch_encode([prompt], max_length=128) # Reduced max_length
    ids = enc["input_ids"].to(state["device"])
    # The stub model will not generate meaningful output, but this will allow the pipeline to run
    out = state["model"].generate(ids, max_new_tokens=10, temperature=p["temperature"], top_k=0, top_p=p["top_p"]) # Reduced max_new_tokens
    text = state["tok"].decode(out[0].tolist())
    return {"text": simplify_text(text)}


