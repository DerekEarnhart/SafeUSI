# pipe JSON into this; it will POST to /ingest (fill later)
