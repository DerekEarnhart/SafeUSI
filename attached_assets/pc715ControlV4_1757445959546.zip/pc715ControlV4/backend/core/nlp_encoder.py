from sentence_transformers import SentenceTransformer
_model = SentenceTransformer('all-MiniLM-L6-v2')

def encode(text: str):
    """Return embedding vector for text."""
    return _model.encode(text)
