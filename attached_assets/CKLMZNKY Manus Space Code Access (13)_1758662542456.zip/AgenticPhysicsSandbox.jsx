
'use client'

import React, { useEffect, useMemo, useRef, useState } from 'react'
import * as THREE from 'three'
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js'
import * as CANNON from 'cannon-es'
import { Play, Pause, Sparkles, Zap, Settings, ShieldCheck, RotateCcw, Download, Upload, KeyRound, Bot } from 'lucide-react'
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js'
import { ConvexHull } from 'three/examples/jsm/math/ConvexHull.js'

/**
 * Agentic Physics Sandbox — React + Three + cannon‑es (v3, LLM‑enabled)
 * --------------------------------------------------------------------
 * Additions in this version:
 * - Built‑in optional GPT‑5 bridge (browser fetch to OpenAI Chat Completions)
 * - Settings panel in the dock to enter/store API key + select model
 * - Translate NL prompt → AgentPlan(JSON) using the bridge when enabled
 * - Stores API key/model/provider in localStorage (client‑only)
 *
 * ⚠️ Security note: API keys stored in localStorage are visible to anyone
 * who can run JS in this origin. This is OK for local tinkering, but for
 * production use you should proxy requests through a secure backend.
 */

// --------------------------
// Types & Tooling Contracts
// --------------------------

export type Vec3 = [number, number, number]

export type SpawnPrimitive = {
  op: 'spawn'
  kind: 'box' | 'sphere' | 'cylinder' | 'capsule' | 'torus' | 'mesh'
  size?: Vec3 | number // depending on kind
  position?: Vec3
  rotationEuler?: Vec3 // radians
  mass?: number
  color?: string
  restitution?: number
  friction?: number
  linearDamping?: number   // NEW
  angularDamping?: number  // NEW
  // for mesh
  url?: string             // NEW (mesh)
  scale?: number | Vec3    // NEW (mesh)
  convex?: boolean         // NEW (mesh)
}

export type SpawnLight = {
