"""
Harmonic Legal Analysis Engine

This module provides specialized legal document analysis using harmonic 
algebraic principles for contract analysis, precedent identification, 
and risk assessment.
"""

import os
import sys
import json
import logging
import numpy as np
from datetime import datetime
from typing import Dict, List, Any, Optional, Union, Tuple, Set
import uuid
import re

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from base_engine import BaseEngine

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class HarmonicLegalEngine(BaseEngine):
    """
    Specialized engine for legal document analysis using harmonic principles.
    Performs contract analysis, legal precedent identification, and risk assessment.
    """
    
    def __init__(self, 
                 legal_corpus_path: str = "./legal_corpus",
                 use_hap: bool = True,
                 harmonic_base: float = 1.618,
                 quantum_factor: float = 0.01):
        """
        Initialize the Harmonic Legal Analysis Engine.
        
        Args:
            legal_corpus_path: Path to legal corpus directory
            use_hap: Whether to use Harmonic Algebraic Probability
            harmonic_base: Harmonic base parameter (default: phi)
            quantum_factor: Quantum influence factor (0.0 to 1.0)
        """
        super().__init__(
            name="Harmonic Legal Analysis Engine",
            version="1.0.0",
            description="Specialized engine for legal document analysis using harmonic principles",
            use_hap=use_hap,
            harmonic_base=harmonic_base,
            quantum_factor=quantum_factor
        )
        
        self.legal_corpus_path = legal_corpus_path
        
        # Initialize legal term library
        self.legal_terms = {}  # term -> definition
        self.term_embeddings = {}  # term -> embedding
        
        # Initialize precedent database
        self.precedent_index = {}  # precedent_id -> precedent info
        self.precedent_embeddings = {}  # precedent_id -> embedding
        
        # Initialize clause templates
        self.clause_templates = {}  # template_id -> template info
        
        # Initialize corpus
        self.initialize_corpus()
        
        # Update metadata
        self.meta["capabilities"] = self.get_capabilities()
        self.meta["configuration"].update({
            "legal_corpus_path": legal_corpus_path
        })
        
        logger.info(f"Initialized {self.name} with corpus at {legal_corpus_path}")
    
    def get_capabilities(self) -> List[str]:
        """Get a list of capabilities provided by this engine."""
        return [
            "contract_analysis",
            "legal_risk_assessment",
            "precedent_identification",
            "clause_extraction",
            "term_definition"
        ]
    
    def initialize_corpus(self) -> None:
        """Initialize the legal corpus and indices."""
        # Create corpus directory if it doesn't exist
        os.makedirs(self.legal_corpus_path, exist_ok=True)
        
        # Create subdirectories
        terms_path = os.path.join(self.legal_corpus_path, "terms")
        precedents_path = os.path.join(self.legal_corpus_path, "precedents")
        clauses_path = os.path.join(self.legal_corpus_path, "clauses")
        
        os.makedirs(terms_path, exist_ok=True)
        os.makedirs(precedents_path, exist_ok=True)
        os.makedirs(clauses_path, exist_ok=True)
        
        # Load legal terms if available
        terms_index_path = os.path.join(terms_path, "index.json")
        if os.path.exists(terms_index_path):
            with open(terms_index_path, 'r') as f:
                self.legal_terms = json.load(f)
        else:
            # Initialize with some common legal terms
            self.legal_terms = self._initialize_common_legal_terms()
            with open(terms_index_path, 'w') as f:
                json.dump(self.legal_terms, f, indent=2)
        
        # Load precedents if available
        precedents_index_path = os.path.join(precedents_path, "index.json")
        if os.path.exists(precedents_index_path):
            with open(precedents_index_path, 'r') as f:
                self.precedent_index = json.load(f)
        
        # Load clause templates if available
        clauses_index_path = os.path.join(clauses_path, "index.json")
        if os.path.exists(clauses_index_path):
            with open(clauses_index_path, 'r') as f:
                self.clause_templates = json.load(f)
        
        logger.info(f"Loaded {len(self.legal_terms)} legal terms, {len(self.precedent_index)} precedents, and {len(self.clause_templates)} clause templates")
    
    def _initialize_common_legal_terms(self) -> Dict[str, str]:
        """Initialize a dictionary of common legal terms and definitions."""
        return {
            "force majeure": "Unforeseeable circumstances that prevent someone from fulfilling a contract",
            "habeas corpus": "A legal recourse that protects against unlawful detention",
            "tort": "A civil wrong that causes someone to suffer loss or harm",
            "negligence": "Failure to take proper care in doing something",
            "liability": "The state of being legally responsible for something",
            "jurisdiction": "The official power to make legal decisions and judgments",
            "plaintiff": "A person who brings a case against another in a court of law",
            "defendant": "An individual, company, or institution sued or accused in a court of law",
            "damages": "Monetary compensation for a loss, detriment, or injury to a person or property",
            "statute of limitations": "A law that sets the maximum time after an event within which legal proceedings may be initiated"
        }
    
    def analyze_contract(self, contract_text: str) -> Dict[str, Any]:
        """
        Analyze a contract for terms, obligations, and potential issues.
        
        Args:
            contract_text: Text of the contract
            
        Returns:
            Dictionary with analysis results
        """
        # Extract clauses
        clauses = self._extract_clauses(contract_text)
        
        # Extract defined terms
        defined_terms = self._extract_defined_terms(contract_text)
        
        # Identify parties
        parties = self._identify_parties(contract_text)
        
        # Identify obligations
        obligations = self._identify_obligations(contract_text)
        
        # Identify potential risks
        risks = self._identify_risks(contract_text)
        
        # Calculate risk score
        risk_score = self._calculate_risk_score(risks)
        
        # Identify missing clauses
        missing_clauses = self._identify_missing_clauses(clauses)
        
        analysis_results = {
            "clauses": clauses,
            "defined_terms": defined_terms,
            "parties": parties,
            "obligations": obligations,
            "risks": risks,
            "risk_score": risk_score,
            "missing_clauses": missing_clauses,
            "analysis_timestamp": datetime.now().isoformat()
        }
        
        logger.info(f"Analyzed contract with {len(clauses)} clauses and risk score {risk_score}")
        return analysis_results
    
    def identify_precedents(self, legal_situation: str) -> List[Dict[str, Any]]:
        """
        Identify relevant legal precedents for a given situation.
        
        Args:
            legal_situation: Description of the legal situation
            
        Returns:
            List of relevant precedents with similarity scores
        """
        if not self.precedent_index:
            logger.warning("No precedents available in the database")
            return []
        
        # Generate embedding for the situation
        situation_embedding = self._generate_legal_embedding(legal_situation)
        
        # Calculate similarity scores
        scores = {}
        for precedent_id, precedent_info in self.precedent_index.items():
            precedent_text = precedent_info.get("summary", "") + " " + precedent_info.get("ruling", "")
            precedent_embedding = self._generate_legal_embedding(precedent_text)
            
            # Calculate similarity
            similarity = self._calculate_harmonic_similarity(situation_embedding, precedent_embedding)
            scores[precedent_id] = similarity
        
        # Sort by similarity score
        sorted_precedents = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        
        # Return top precedents (limit to 5)
        results = []
        for precedent_id, score in sorted_precedents[:5]:
            precedent_info = self.precedent_index[precedent_id].copy()
            precedent_info["id"] = precedent_id
            precedent_info["relevance_score"] = float(score)  # Convert numpy float to Python float
            results.append(precedent_info)
        
        logger.info(f"Identified {len(results)} relevant precedents")
        return results
    
    def quantify_legal_risk(self, document_text: str) -> Dict[str, Any]:
        """
        Quantify legal risk in a document using harmonic probability.
        
        Args:
            document_text: Text of the document
            
        Returns:
            Dictionary with risk assessment results
        """
        # Identify risk factors
        risk_factors = self._identify_risks(document_text)
        
        # Calculate overall risk score
        risk_score = self._calculate_risk_score(risk_factors)
        
        # Generate risk heatmap for document sections
        sections = self._split_into_sections(document_text)
        section_risks = {}
        
        for section_name, section_text in sections.items():
            section_risk_factors = self._identify_risks(section_text)
            section_risk_score = self._calculate_risk_score(section_risk_factors)
            section_risks[section_name] = {
                "risk_score": section_risk_score,
                "risk_factors": section_risk_factors
            }
        
        # Generate recommendations
        recommendations = self._generate_risk_recommendations(risk_factors, section_risks)
        
        risk_assessment = {
            "overall_risk_score": risk_score,
            "risk_factors": risk_factors,
            "section_risks": section_risks,
            "recommendations": recommendations,
            "assessment_timestamp": datetime.now().isoformat()
        }
        
        logger.info(f"Quantified legal risk with score {risk_score}")
        return risk_assessment
    
    def process(self, input_data: Dict[str, Any], **kwargs) -> Dict[str, Any]:
        """
        Process input data using the Harmonic Legal Engine.
        
        Args:
            input_data: Dictionary containing input data
            **kwargs: Additional keyword arguments
            
        Returns:
            Dictionary with processed results
        """
        operation = input_data.get("operation", "analyze_contract")
        
        if operation == "analyze_contract":
            contract_text = input_data.get("document_text", "")
            
            if not contract_text:
                return {"status": "error", "message": "No contract text provided"}
            
            analysis_results = self.analyze_contract(contract_text)
            return {
                "status": "success", 
                "message": "Contract analyzed successfully",
                "results": analysis_results
            }
        
        elif operation == "identify_precedents":
            legal_situation = input_data.get("legal_situation", "")
            
            if not legal_situation:
                return {"status": "error", "message": "No legal situation provided"}
            
            precedents = self.identify_precedents(legal_situation)
            return {
                "status": "success",
                "message": f"Identified {len(precedents)} relevant precedents",
                "results": precedents
            }
        
        elif operation == "quantify_risk":
            document_text = input_data.get("document_text", "")
            
            if not document_text:
                return {"status": "error", "message": "No document text provided"}
            
            risk_assessment = self.quantify_legal_risk(document_text)
            return {
                "status": "success",
                "message": "Legal risk quantified successfully",
                "results": risk_assessment
            }
        
        else:
            return {"status": "error", "message": f"Unknown operation: {operation}"}
    
    def _extract_clauses(self, contract_text: str) -> List[Dict[str, Any]]:
        """Extract clauses from contract text."""
        clauses = []
        
        # Simple pattern for section/clause detection
        # In a real implementation, this would be much more sophisticated
        section_pattern = r'(?i)^\s*(\d+\.\s*|[A-Z]+\.\s*|SECTION \d+\.\s*)([^\n]+)'
        
        matches = re.finditer(section_pattern, contract_text, re.MULTILINE)
        
        last_pos = 0
        for match in matches:
            clause_num = match.group(1).strip()
            clause_title = match.group(2).strip()
            start_pos = match.start()
            
            # Find the content by looking for the next section or end of text
            content_start = match.end()
            content_end = len(contract_text)
            
            # Look for the next section
            next_match = re.search(section_pattern, contract_text[content_start:], re.MULTILINE)
            if next_match:
                content_end = content_start + next_match.start()
            
            clause_content = contract_text[content_start:content_end].strip()
            
            clauses.append({
                "number": clause_num,
                "title": clause_title,
                "content": clause_content,
                "position": {
                    "start": start_pos,
                    "end": content_end
                }
            })
            
            last_pos = content_end
        
        return clauses
    
    def _extract_defined_terms(self, contract_text: str) -> Dict[str, str]:
        """Extract defined terms from contract text."""
        defined_terms = {}
        
        # Simple pattern for defined terms
        # In a real implementation, this would be much more sophisticated
        term_pattern = r'(?i)"([^"]+)"\s+(?:shall )?(?:mean|refers to|is defined as)\s+([^\.]+)'
        
        matches = re.finditer(term_pattern, contract_text)
        
        for match in matches:
            term = match.group(1).strip()
            definition = match.group(2).strip()
            defined_terms[term] = definition
        
        return defined_terms
    
    def _identify_parties(self, contract_text: str) -> List[Dict[str, Any]]:
        """Identify parties in contract text."""
        parties = []
        
        # Simple pattern for party identification
        # In a real implementation, this would be much more sophisticated
        party_pattern = r'(?i)(?:This agreement is (?:made and )?entered into (?:by and )?between|BETWEEN|THIS AGREEMENT is made between)\s+([^\n,]+)(?:,\s*(?:a|an)\s+([^\n,]+))?(?:\s*,?\s*(?:and|AND))?\s+([^\n,]+)(?:,\s*(?:a|an)\s+([^\n,]+))?'
        
        match = re.search(party_pattern, contract_text)
        
        if match:
            party1_name = match.group(1).strip() if match.group(1) else ""
            party1_type = match.group(2).strip() if match.group(2) else ""
            party2_name = match.group(3).strip() if match.group(3) else ""
            party2_type = match.group(4).strip() if match.group(4) else ""
            
            if party1_name:
                parties.append({
                    "name": party1_name,
                    "type": party1_type,
                    "role": "first_party"
                })
            
            if party2_name:
                parties.append({
                    "name": party2_name,
                    "type": party2_type,
                    "role": "second_party"
                })
        
        return parties
    
    def _identify_obligations(self, contract_text: str) -> List[Dict[str, Any]]:
        """Identify obligations in contract text."""
        obligations = []
        
        # Simple patterns for obligation identification
        # In a real implementation, this would be much more sophisticated
        obligation_patterns = [
            r'(?i)([\w\s]+)\s+shall\s+([^\.\,]+)',
            r'(?i)([\w\s]+)\s+agrees\s+to\s+([^\.\,]+)',
            r'(?i)([\w\s]+)\s+must\s+([^\.\,]+)'
        ]
        
        for pattern in obligation_patterns:
            matches = re.finditer(pattern, contract_text)
            
            for match in matches:
                obligor = match.group(1).strip()
                action = match.group(2).strip()
                
                obligations.append({
                    "obligor": obligor,
                    "action": action,
                    "position": {
                        "start": match.start(),
                        "end": match.end()
                    }
                })
        
        return obligations
    
    def _identify_risks(self, document_text: str) -> List[Dict[str, Any]]:
        """Identify potential risks in document text."""
        risks = []
        
        # Risk patterns
        risk_patterns = [
            (r'(?i)terminat(?:e|ion|ing)', "Termination provisions may have significant consequences", 0.7),
            (r'(?i)indemnif(?:y|ication)', "Indemnification clauses need careful review", 0.8),
            (r'(?i)unlimited liability', "Unlimited liability poses high risk", 0.9),
            (r'(?i)warrant(?:y|ies)', "Warranty terms may create obligations", 0.6),
            (r'(?i)force majeure', "Force majeure clauses should be reviewed for scope", 0.5),
            (r'(?i)governing law', "Governing law affects interpretation", 0.4),
            (r'(?i)confidential(?:ity)?', "Confidentiality provisions should be assessed", 0.6),
            (r'(?i)dispute resolution', "Dispute resolution mechanisms affect rights", 0.5),
            (r'(?i)non-compete', "Non-compete clauses may be unenforceable", 0.7),
            (r'(?i)intellectual property', "IP provisions require careful review", 0.7)
        ]
        
        for pattern, description, risk_level in risk_patterns:
            matches = re.finditer(pattern, document_text)
            
            for match in matches:
                context_start = max(0, match.start() - 50)
                context_end = min(len(document_text), match.end() + 50)
                context = document_text[context_start:context_end]
                
                risks.append({
                    "type": pattern.replace('(?i)', '').replace('(?:', '').replace(')?', ''),
                    "description": description,
                    "risk_level": risk_level,
                    "context": context,
                    "position": {
                        "start": match.start(),
                        "end": match.end()
                    }
                })
        
        return risks
    
    def _calculate_risk_score(self, risk_factors: List[Dict[str, Any]]) -> float:
        """Calculate overall risk score based on risk factors."""
        if not risk_factors:
            return 0.0
        
        # Apply harmonic principles to risk calculation
        if self.hap_processor:
            # Use golden ratio-based weighting
            phi = (1 + np.sqrt(5)) / 2
            
            # Calculate base score as weighted average
            total_weight = 0
            weighted_sum = 0
            
            for i, risk in enumerate(risk_factors):
                # Weight decreases according to harmonic series
                weight = 1 / (i + 1)
                total_weight += weight
                weighted_sum += risk["risk_level"] * weight
            
            base_score = weighted_sum / total_weight if total_weight > 0 else 0
            
            # Apply quantum factor for small variations
            quantum_adjustment = np.random.random() * self.quantum_factor
            
            # Apply harmonic modulation
            harmonic_factor = 0.5 + 0.5 * np.sin(base_score * np.pi * self.harmonic_base)
            
            # Combine for final score
            risk_score = base_score * harmonic_factor + quantum_adjustment
            return min(1.0, max(0.0, risk_score))  # Clamp to [0, 1]
        
        # Simple averaging for fallback
        return sum(r["risk_level"] for r in risk_factors) / len(risk_factors)
    
    def _identify_missing_clauses(self, clauses: List[Dict[str, Any]]) -> List[str]:
        """Identify potentially missing important clauses."""
        important_clauses = [
            "termination",
            "indemnification",
            "liability",
            "warranty",
            "confidentiality",
            "governing law",
            "dispute resolution",
            "force majeure",
            "assignment",
            "entire agreement"
        ]
        
        # Extract titles and content
        clause_text = " ".join([
            clause.get("title", "") + " " + clause.get("content", "")
            for clause in clauses
        ]).lower()
        
        missing = []
        for clause in important_clauses:
            if clause not in clause_text:
                missing.append(clause)
        
        return missing
    
    def _split_into_sections(self, document_text: str) -> Dict[str, str]:
        """Split document into sections."""
        sections = {}
        
        # Extract clauses first
        clauses = self._extract_clauses(document_text)
        
        # If no clauses found, create a fallback section
        if not clauses:
            sections["Main Document"] = document_text
            return sections
        
        # Create sections from clauses
        for clause in clauses:
            section_name = clause.get("title", f"Section {clause.get('number', '')}")
            sections[section_name] = clause.get("content", "")
        
        return sections
    
    def _generate_risk_recommendations(self, 
                                      risk_factors: List[Dict[str, Any]], 
                                      section_risks: Dict[str, Dict[str, Any]]) -> List[str]:
        """Generate recommendations based on risk assessment."""
        recommendations = []
        
        # Overall risk-based recommendations
        high_risks = [r for r in risk_factors if r["risk_level"] >= 0.7]
        if high_risks:
            recommendations.append(
                f"Review {len(high_risks)} high-risk provisions identified in the document."
            )
        
        # Section-specific recommendations
        high_risk_sections = [
            section for section, data in section_risks.items() 
            if data["risk_score"] >= 0.7
        ]
        
        if high_risk_sections:
            sections_list = ", ".join(high_risk_sections[:3])
            if len(high_risk_sections) > 3:
                sections_list += f", and {len(high_risk_sections) - 3} others"
            
            recommendations.append(
                f"Focus review on high-risk sections: {sections_list}."
            )
        
        # Missing clause recommendations
        missing_clauses = []
        for section_data in section_risks.values():
            if "risk_factors" in section_data:
                section_risks = section_data["risk_factors"]
                for risk in section_risks:
                    if "missing" in risk["description"].lower():
                        missing_clauses.append(risk["type"])
        
        if missing_clauses:
            clauses_list = ", ".join(missing_clauses[:3])
            if len(missing_clauses) > 3:
                clauses_list += f", and {len(missing_clauses) - 3} others"
            
            recommendations.append(
                f"Consider adding missing clauses: {clauses_list}."
            )
        
        # Add generic recommendations if none specific
        if not recommendations:
            recommendations.append(
                "Review entire document for legal compliance and risk factors."
            )
        
        return recommendations
    
    def _generate_legal_embedding(self, text: str) -> np.ndarray:
        """
        Generate a specialized legal embedding for text.
        
        Args:
            text: Text to embed
            
        Returns:
            Embedding vector
        """
        # This is a simplified placeholder implementation
        # In a real implementation, we would use a legal-domain embedding model
        
        # Use hash-based approach for demo purposes
        hash_val = hash(text)
        rng = np.random.RandomState(hash_val)
        
        # Generate embedding vector (128-dimensional)
        embedding = rng.rand(128) * 2 - 1
        
        # Normalize
        norm = np.linalg.norm(embedding)
        if norm > 0:
            embedding = embedding / norm
        
        return embedding
    
    def _calculate_harmonic_similarity(self, embedding1: np.ndarray, embedding2: np.ndarray) -> float:
        """
        Calculate similarity between embeddings using harmonic principles.
        
        Args:
            embedding1: First embedding
            embedding2: Second embedding
            
        Returns:
            Similarity score
        """
        # Use cosine similarity as the base
        dot_product = np.dot(embedding1, embedding2)
        
        # Apply harmonic principles if HAP processor available
        if self.hap_processor:
            # Apply a resonance factor based on the harmonic base
            resonance = 0.5 + 0.5 * np.sin(dot_product * np.pi * self.harmonic_base)
            
            # Apply quantum effect for small variations
            quantum_noise = np.random.random() * self.quantum_factor
            
            return dot_product * resonance + quantum_noise
        
        # Fallback to standard cosine similarity
        return dot_product