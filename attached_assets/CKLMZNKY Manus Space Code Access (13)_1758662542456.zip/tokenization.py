from dataclasses import dataclass
import os
try:
    from transformers import AutoTokenizer
except Exception:
    AutoTokenizer = None

@dataclass
class TokenizerWrapper:
    name_or_path: str = "gpt2"
    def __post_init__(self):
        if AutoTokenizer is None:
            raise RuntimeError("Please `pip install transformers`")
        self.tok = AutoTokenizer.from_pretrained(self.name_or_path, local_files_only=os.path.isdir(self.name_or_path))
        if self.tok.pad_token is None:
            self.tok.pad_token = self.tok.eos_token
    @property
    def vocab_size(self):
        return self.tok.vocab_size
    def encode(self, text, add_special_tokens=False):
        return self.tok.encode(text, add_special_tokens=add_special_tokens)
    def batch_encode(self, texts, max_length=None, truncation=True):
        return self.tok(texts, return_tensors="pt", padding=True, truncation=truncation, max_length=max_length)
    def decode(self, ids):
        return self.tok.decode(ids, skip_special_tokens=True)
