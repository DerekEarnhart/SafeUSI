from hpqcc import compress, decompress
def test_roundtrip():
    s = b"hello-world\n" * 100
    out = compress(s)
    back = decompress(out)
    assert back == s
