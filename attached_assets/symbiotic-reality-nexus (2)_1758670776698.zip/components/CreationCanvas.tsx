import React from 'react';
import { Creation } from '../types';
import { CloseIcon } from './icons';

interface CreationCanvasProps {
  creation: Creation;
  onClose: () => void;
}

const CreationCanvas: React.FC<CreationCanvasProps> = ({ creation, onClose }) => {
  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-lg flex items-center justify-center z-50 animate-fade-in">
      <div className="w-full max-w-4xl h-full max-h-[90vh] bg-gray-900 border border-cyan-500/30 rounded-xl shadow-2xl shadow-cyan-500/10 flex flex-col p-4 relative pulse-glow-border">
        <button onClick={onClose} className="absolute top-3 right-3 text-gray-500 hover:text-cyan-400 transition-colors z-10">
          <CloseIcon className="w-6 h-6" />
        </button>
        <h2 className="text-xl font-bold text-cyan-400 mb-2">{creation.title}</h2>
        <p className="text-sm text-gray-400 mb-4 flex-shrink-0">{creation.description}</p>
        <div className="flex-1 bg-black/30 rounded-lg overflow-hidden flex items-center justify-center">
          {creation.type === 'image' && (
            <img src={creation.content} alt={creation.title} className="max-w-full max-h-full object-contain" />
          )}
          {/* Other creation types could be rendered here */}
        </div>
      </div>
    </div>
  );
};

export default CreationCanvas;
