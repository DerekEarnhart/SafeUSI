import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';

const Bio3DBridge = () => {
  const mountRef = useRef(null);
  const [entities, setEntities] = useState({});
  const [error, setError] = useState(null);

  useEffect(() => {
    // Scene setup
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    mountRef.current.appendChild(renderer.domElement);

    camera.position.z = 5;

    // Lighting
    const ambientLight = new THREE.AmbientLight(0x404040); // soft white light
    scene.add(ambientLight);
    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.5);
    directionalLight.position.set(1, 1, 1).normalize();
    scene.add(directionalLight);

    // Entity representation (simple spheres for now)
    const entityMeshes = {};

    // WebSocket connection
    const ws = new WebSocket("wss://8001-ihln5f57547tye82ivz1t-87ff3ae6.manusvm.computer/ws/state"); // Assuming bio_bridge_server runs on 8001

    ws.onopen = () => {
      console.log("WebSocket connected");
      setError(null);
    };

    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.entities) {
        setEntities(prevEntities => {
          const newEntities = { ...prevEntities };
          data.entities.forEach(entity => {
            newEntities[entity.id] = entity;

            // Update or create mesh
            if (!entityMeshes[entity.id]) {
              const geometry = new THREE.SphereGeometry(0.1, 32, 32);
              const material = new THREE.MeshPhongMaterial({ color: Math.random() * 0xffffff });
              entityMeshes[entity.id] = new THREE.Mesh(geometry, material);
              scene.add(entityMeshes[entity.id]);
            }
            // Update position
            entityMeshes[entity.id].position.set(entity.pos.x, entity.pos.y, entity.pos.z);
          });
          return newEntities;
        });
      }
    };

    ws.onerror = (err) => {
      console.error("WebSocket error:", err);
      setError("Failed to connect to Bio3D Bridge. Ensure the server is running on port 8001.");
    };

    ws.onclose = () => {
      console.log("WebSocket disconnected");
      setError("Disconnected from Bio3D Bridge. Attempting to reconnect...");
      // Simple reconnect logic
      setTimeout(() => {
        // For a more robust solution, consider a dedicated reconnect function
      }, 3000);
    };

    // Animation loop
    const animate = () => {
      requestAnimationFrame(animate);
      // Rotate entities for visual effect
      Object.values(entityMeshes).forEach(mesh => {
        mesh.rotation.x += 0.005;
        mesh.rotation.y += 0.005;
      });
      renderer.render(scene, camera);
    };
    animate();

    // Handle window resize
    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener('resize', handleResize);

    // Cleanup
    return () => {
      ws.close();
      window.removeEventListener('resize', handleResize);
      mountRef.current.removeChild(renderer.domElement);
      // Dispose of geometries and materials to prevent memory leaks
      Object.values(entityMeshes).forEach(mesh => {
        mesh.geometry.dispose();
        mesh.material.dispose();
        scene.remove(mesh);
      });
      renderer.dispose();
    };
  }, []);

  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-6">
      <h2 className="text-xl font-semibold mb-4">Bio3D Bridge Simulation</h2>
      {error && <p className="text-red-500">{error}</p>}
      <div ref={mountRef} style={{ width: '100%', height: '400px', overflow: 'hidden' }}></div>
      <div className="mt-4">
        <h3 className="text-lg font-semibold">Entities:</h3>
        {Object.keys(entities).length === 0 ? (
          <p>No entities received yet.</p>
        ) : (
          <ul>
            {Object.values(entities).map(entity => (
              <li key={entity.id}>
                <strong>{entity.id}</strong>: Consciousness - {entity.consciousness}, Pos - ({entity.pos.x.toFixed(2)}, {entity.pos.y.toFixed(2)}, {entity.pos.z.toFixed(2)})
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default Bio3DBridge;


