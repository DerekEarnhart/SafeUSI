"""
Workflow Engine
===============

This module implements the Workflow Engine for orchestrating complex,
multi-step workflows across the Universal VM Machine system.
"""

import asyncio
import time
import json
import logging
from typing import Dict, List, Tuple, Any, Optional, Union, Callable
from dataclasses import dataclass, field
from enum import Enum
import networkx as nx
import uuid
from collections import deque, defaultdict

logger = logging.getLogger(__name__)

class WorkflowStatus(Enum):
    """Status of workflows in the system"""
    CREATED = "created"
    PLANNING = "planning"
    EXECUTING = "executing"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

class StepType(Enum):
    """Types of workflow steps"""
    COMPUTATION = "computation"
    ANALYSIS = "analysis"
    SYNTHESIS = "synthesis"
    DECISION = "decision"
    PARALLEL = "parallel"
    SEQUENTIAL = "sequential"
    CONDITIONAL = "conditional"
    LOOP = "loop"
    HUMAN_INPUT = "human_input"
    EXTERNAL_API = "external_api"

@dataclass
class WorkflowStep:
    """Represents a single step in a workflow"""
    step_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    description: str = ""
    step_type: StepType = StepType.COMPUTATION
    input_data: Any = None
    output_data: Any = None
    parameters: Dict[str, Any] = field(default_factory=dict)
    dependencies: List[str] = field(default_factory=list)
    conditions: Dict[str, Any] = field(default_factory=dict)
    timeout: Optional[float] = None
    retry_count: int = 0
    max_retries: int = 3
    status: str = "pending"
    started_at: Optional[float] = None
    completed_at: Optional[float] = None
    error: Optional[str] = None
    consciousness_level: float = 0.5

@dataclass
class Workflow:
    """Represents a complete workflow"""
    workflow_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    description: str = ""
    steps: Dict[str, WorkflowStep] = field(default_factory=dict)
    execution_graph: nx.DiGraph = field(default_factory=nx.DiGraph)
    status: WorkflowStatus = WorkflowStatus.CREATED
    priority: float = 1.0
    created_at: float = field(default_factory=time.time)
    started_at: Optional[float] = None
    completed_at: Optional[float] = None
    result: Any = None
    error: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

class WorkflowPlanner:
    """Plans and optimizes workflow execution"""
    
    def __init__(self):
        self.planning_strategies = {
            'sequential': self._plan_sequential,
            'parallel': self._plan_parallel,
            'adaptive': self._plan_adaptive,
            'consciousness_aware': self._plan_consciousness_aware
        }
        
    def plan_workflow(self, workflow: Workflow, strategy: str = 'adaptive') -> bool:
        """Plan the execution of a workflow"""
        
        try:
            planner = self.planning_strategies.get(strategy, self._plan_adaptive)
            return planner(workflow)
        except Exception as e:
            logger.error(f"Error planning workflow {workflow.workflow_id}: {e}")
            return False
            
    def _plan_sequential(self, workflow: Workflow) -> bool:
        """Plan sequential execution"""
        
        # Create linear execution graph
        step_ids = list(workflow.steps.keys())
        
        for i in range(len(step_ids) - 1):
            workflow.execution_graph.add_edge(step_ids[i], step_ids[i + 1])
            
        return True
        
    def _plan_parallel(self, workflow: Workflow) -> bool:
        """Plan parallel execution where possible"""
        
        # Analyze dependencies and create parallel execution paths
        for step_id, step in workflow.steps.items():
            workflow.execution_graph.add_node(step_id)
            
            # Add dependency edges
            for dep_id in step.dependencies:
                if dep_id in workflow.steps:
                    workflow.execution_graph.add_edge(dep_id, step_id)
                    
        return True
        
    def _plan_adaptive(self, workflow: Workflow) -> bool:
        """Plan adaptive execution based on step characteristics"""
        
        # Start with parallel planning
        self._plan_parallel(workflow)
        
        # Optimize based on step types and resource requirements
        for step_id, step in workflow.steps.items():
            if step.step_type in [StepType.HUMAN_INPUT, StepType.EXTERNAL_API]:
                # These steps might need special handling
                step.timeout = step.timeout or 300.0  # 5 minutes default
                
            elif step.step_type == StepType.PARALLEL:
                # Ensure parallel steps don't have unnecessary dependencies
                self._optimize_parallel_step(workflow, step_id)
                
        return True
        
    def _plan_consciousness_aware(self, workflow: Workflow) -> bool:
        """Plan execution with consciousness awareness"""
        
        # Start with adaptive planning
        self._plan_adaptive(workflow)
        
        # Prioritize steps based on consciousness level
        consciousness_levels = {}
        for step_id, step in workflow.steps.items():
            consciousness_levels[step_id] = step.consciousness_level
            
        # Reorder execution to prioritize high-consciousness steps
        high_consciousness_steps = [
            step_id for step_id, level in consciousness_levels.items()
            if level > 0.7
        ]
        
        # Adjust execution graph to prioritize these steps
        for step_id in high_consciousness_steps:
            # Reduce dependencies where possible
            predecessors = list(workflow.execution_graph.predecessors(step_id))
            for pred in predecessors:
                if workflow.steps[pred].consciousness_level < 0.5:
                    # Consider removing this dependency if not critical
                    pass
                    
        return True
        
    def _optimize_parallel_step(self, workflow: Workflow, step_id: str):
        """Optimize a parallel step for better execution"""
        
        step = workflow.steps[step_id]
        
        # Remove unnecessary dependencies for parallel execution
        necessary_deps = []
        for dep_id in step.dependencies:
            dep_step = workflow.steps.get(dep_id)
            if dep_step and dep_step.step_type not in [StepType.PARALLEL]:
                necessary_deps.append(dep_id)
                
        step.dependencies = necessary_deps

class WorkflowExecutor:
    """Executes workflows using the Universal VM Machine components"""
    
    def __init__(self, system_components: Dict[str, Any]):
        self.system_components = system_components
        self.active_workflows = {}
        self.execution_history = deque(maxlen=1000)
        
    async def execute_workflow(self, workflow: Workflow) -> bool:
        """Execute a workflow"""
        
        try:
            workflow.status = WorkflowStatus.EXECUTING
            workflow.started_at = time.time()
            self.active_workflows[workflow.workflow_id] = workflow
            
            # Execute steps according to the execution graph
            await self._execute_workflow_steps(workflow)
            
            # Check if workflow completed successfully
            if all(step.status == "completed" for step in workflow.steps.values()):
                workflow.status = WorkflowStatus.COMPLETED
                workflow.completed_at = time.time()
                
                # Collect final result
                workflow.result = self._collect_workflow_result(workflow)
                
                logger.info(f"Workflow {workflow.workflow_id} completed successfully")
                return True
            else:
                workflow.status = WorkflowStatus.FAILED
                workflow.error = "Some steps failed to complete"
                logger.error(f"Workflow {workflow.workflow_id} failed")
                return False
                
        except Exception as e:
            workflow.status = WorkflowStatus.FAILED
            workflow.error = str(e)
            logger.error(f"Error executing workflow {workflow.workflow_id}: {e}")
            return False
        finally:
            # Move to history
            if workflow.workflow_id in self.active_workflows:
                del self.active_workflows[workflow.workflow_id]
            self.execution_history.append(workflow)
            
    async def _execute_workflow_steps(self, workflow: Workflow):
        """Execute workflow steps according to execution graph"""
        
        # Get topological order for execution
        try:
            execution_order = list(nx.topological_sort(workflow.execution_graph))
        except nx.NetworkXError:
            # Graph has cycles, use simple order
            execution_order = list(workflow.steps.keys())
            
        # Execute steps in order
        for step_id in execution_order:
            if step_id in workflow.steps:
                await self._execute_step(workflow, step_id)
                
    async def _execute_step(self, workflow: Workflow, step_id: str):
        """Execute a single workflow step"""
        
        step = workflow.steps[step_id]
        
        try:
            # Check dependencies
            if not self._check_step_dependencies(workflow, step_id):
                step.status = "waiting"
                return
                
            step.status = "executing"
            step.started_at = time.time()
            
            # Execute based on step type
            if step.step_type == StepType.COMPUTATION:
                await self._execute_computation_step(step)
            elif step.step_type == StepType.ANALYSIS:
                await self._execute_analysis_step(step)
            elif step.step_type == StepType.SYNTHESIS:
                await self._execute_synthesis_step(step)
            elif step.step_type == StepType.DECISION:
                await self._execute_decision_step(step)
            elif step.step_type == StepType.PARALLEL:
                await self._execute_parallel_step(workflow, step)
            elif step.step_type == StepType.CONDITIONAL:
                await self._execute_conditional_step(workflow, step)
            elif step.step_type == StepType.LOOP:
                await self._execute_loop_step(workflow, step)
            else:
                # Default execution
                await self._execute_default_step(step)
                
            step.status = "completed"
            step.completed_at = time.time()
            
        except Exception as e:
            step.status = "failed"
            step.error = str(e)
            step.retry_count += 1
            
            # Retry if possible
            if step.retry_count <= step.max_retries:
                logger.warning(f"Step {step_id} failed, retrying ({step.retry_count}/{step.max_retries})")
                await asyncio.sleep(1.0)  # Brief delay before retry
                await self._execute_step(workflow, step_id)
            else:
                logger.error(f"Step {step_id} failed permanently: {e}")
                
    def _check_step_dependencies(self, workflow: Workflow, step_id: str) -> bool:
        """Check if step dependencies are satisfied"""
        
        step = workflow.steps[step_id]
        
        for dep_id in step.dependencies:
            if dep_id in workflow.steps:
                dep_step = workflow.steps[dep_id]
                if dep_step.status != "completed":
                    return False
                    
        return True
        
    async def _execute_computation_step(self, step: WorkflowStep):
        """Execute a computation step"""
        
        # Use the Harmonic-Topological Compute Engine
        htce = self.system_components.get('harmonic_topological_engine')
        if not htce:
            raise RuntimeError("Harmonic-Topological Compute Engine not available")
            
        from src.core.harmonic_topological_engine import ComputationTask, ComputeMode
        
        # Create computation task
        comp_task = ComputationTask(
            task_id=f"workflow_{step.step_id}",
            task_type="computation",
            input_data=step.input_data,
            parameters=step.parameters,
            consciousness_level=step.consciousness_level,
            compute_mode=ComputeMode.HYBRID
        )
        
        # Submit and wait for result
        task_id = await htce.submit_task(comp_task)
        
        # Wait for completion
        max_wait = step.timeout or 60.0
        start_time = time.time()
        
        while time.time() - start_time < max_wait:
            result = htce.get_task_result(task_id)
            if result:
                step.output_data = result
                return
            await asyncio.sleep(0.1)
            
        raise TimeoutError(f"Computation step timed out after {max_wait} seconds")
        
    async def _execute_analysis_step(self, step: WorkflowStep):
        """Execute an analysis step"""
        
        # Use task orchestrator for analysis
        orchestrator = self.system_components.get('task_orchestrator')
        if not orchestrator:
            raise RuntimeError("Task orchestrator not available")
            
        from src.core.universal_task_orchestrator import Task, TaskType
        
        # Create analysis task
        task = Task(
            name=f"Analysis: {step.name}",
            description=step.description,
            task_type=TaskType.ANALYSIS,
            input_data=step.input_data,
            parameters=step.parameters,
            consciousness_level=step.consciousness_level
        )
        
        # Submit and wait
        task_id = await orchestrator.submit_task(task)
        
        # Wait for completion
        max_wait = step.timeout or 120.0
        start_time = time.time()
        
        while time.time() - start_time < max_wait:
            result = orchestrator.get_task_result(task_id)
            if result:
                step.output_data = result
                return
            await asyncio.sleep(0.1)
            
        raise TimeoutError(f"Analysis step timed out after {max_wait} seconds")
        
    async def _execute_synthesis_step(self, step: WorkflowStep):
        """Execute a synthesis step"""
        
        # Similar to analysis but with synthesis task type
        orchestrator = self.system_components.get('task_orchestrator')
        if not orchestrator:
            raise RuntimeError("Task orchestrator not available")
            
        from src.core.universal_task_orchestrator import Task, TaskType
        
        task = Task(
            name=f"Synthesis: {step.name}",
            description=step.description,
            task_type=TaskType.SYNTHESIS,
            input_data=step.input_data,
            parameters=step.parameters,
            consciousness_level=step.consciousness_level
        )
        
        task_id = await orchestrator.submit_task(task)
        
        max_wait = step.timeout or 180.0
        start_time = time.time()
        
        while time.time() - start_time < max_wait:
            result = orchestrator.get_task_result(task_id)
            if result:
                step.output_data = result
                return
            await asyncio.sleep(0.1)
            
        raise TimeoutError(f"Synthesis step timed out after {max_wait} seconds")
        
    async def _execute_decision_step(self, step: WorkflowStep):
        """Execute a decision step"""
        
        # Use consciousness substrate for decision making
        consciousness = self.system_components.get('consciousness_substrate')
        if not consciousness:
            raise RuntimeError("Consciousness substrate not available")
            
        from src.core.consciousness_substrate import ConsciousnessEvent
        
        # Create consciousness event for decision
        event = ConsciousnessEvent(
            event_id=f"decision_{step.step_id}",
            event_type="decision_request",
            content={
                'input_data': step.i
(Content truncated due to size limit. Use page ranges or line ranges to read remaining content)

                'parameters': step.parameters
            },
            consciousness_level=step.consciousness_level
        )
        
        decision = await consciousness.handle_event(event)
        step.output_data = decision

    async def _execute_parallel_step(self, workflow: Workflow, step: WorkflowStep):
        """Execute a parallel step"""
        
        child_step_ids = step.parameters.get('child_steps', [])
        
        child_steps = []
        for child_id in child_step_ids:
            if child_id in workflow.steps:
                child_steps.append(self._execute_step(workflow, child_id))
                
        if child_steps:
            await asyncio.gather(*child_steps)

    async def _execute_conditional_step(self, workflow: Workflow, step: WorkflowStep):
        """Execute a conditional step"""
        
        condition = step.conditions.get('if')
        true_step_id = step.parameters.get('then')
        false_step_id = step.parameters.get('else')
        
        # Evaluate condition
        if self._evaluate_condition(condition, workflow):
            if true_step_id in workflow.steps:
                await self._execute_step(workflow, true_step_id)
        else:
            if false_step_id in workflow.steps:
                await self._execute_step(workflow, false_step_id)

    async def _execute_loop_step(self, workflow: Workflow, step: WorkflowStep):
        """Execute a loop step"""
        
        loop_condition = step.conditions.get('while')
        loop_body_step_id = step.parameters.get('do')
        
        while self._evaluate_condition(loop_condition, workflow):
            if loop_body_step_id in workflow.steps:
                await self._execute_step(workflow, loop_body_step_id)
            else:
                break

    async def _execute_default_step(self, step: WorkflowStep):
        """Execute a default step"""
        
        logger.warning(f"No specific execution logic for step type {step.step_type}")
        step.output_data = step.input_data

    def _evaluate_condition(self, condition: Any, workflow: Workflow) -> bool:
        """Evaluate a condition"""
        
        # This is a simplified evaluator. A real implementation would need a proper expression language.
        if isinstance(condition, bool):
            return condition
        elif isinstance(condition, str):
            # Example: "{{step_id.output_data}} > 10"
            # This requires a template engine and a safe evaluation environment
            return True  # Placeholder
        return False

    def _collect_workflow_result(self, workflow: Workflow) -> Any:
        """Collect the final result of the workflow"""
        
        # Find terminal nodes in the execution graph
        terminal_nodes = [node for node, out_degree in workflow.execution_graph.out_degree() if out_degree == 0]
        
        if not terminal_nodes:
            return None
            
        # Collect output from all terminal nodes
        final_results = {}
        for node_id in terminal_nodes:
            if node_id in workflow.steps:
                final_results[node_id] = workflow.steps[node_id].output_data
                
        return final_results


