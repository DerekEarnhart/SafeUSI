# Bench Tasks

- Replace deprecated date lib with luxon.  
- Split a 500-line module into cohesive submodules.  
- Add unit tests around a pure function with edge cases.
