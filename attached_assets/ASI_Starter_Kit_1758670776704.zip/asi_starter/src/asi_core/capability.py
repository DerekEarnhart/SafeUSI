from __future__ import annotations
from typing import Any, Dict, Optional
from dataclasses import dataclass

@dataclass
class Capability:
    name: str
    description: str

    def invoke(self, inputs: Dict[str, Any], context: Optional[Dict[str, Any]]=None) -> Dict[str, Any]:
        raise NotImplementedError("invoke must be implemented by subclass")
