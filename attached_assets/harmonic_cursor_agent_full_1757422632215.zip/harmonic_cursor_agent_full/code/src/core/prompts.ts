export function planPrompt(task: string, context: string) {
  return `Task: ${task}
Context:
${context}

Plan in <=6 bullet points:
- `;
}
export function reflectPrompt(task: string, steps: string[], failure: any) {
  return `Task: ${task}
Steps tried: ${steps.join(' | ')}
Failure: ${JSON.stringify(failure).slice(0,500)}

Propose a new <=6-step repair plan:
- `;
}
