
import os
from typing import List, Dict, Any, Optional
from fastembed import TextEmbedding
from chromadb import Client
from chromadb.utils import embedding_functions

class DocumentLoader:
    """Loads documents from various sources."""
    
    def load_text_file(self, file_path: str) -> str:
        """Loads content from a text file."""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")
        with open(file_path, "r", encoding="utf-8") as f:
            return f.read()

class TextSplitter:
    """Splits text into smaller chunks."""
    
    def split_text(self, text: str, chunk_size: int = 1000, chunk_overlap: int = 200) -> List[str]:
        """Splits text into chunks of specified size with overlap."""
        chunks = []
        start = 0
        while start < len(text):
            end = start + chunk_size
            chunk = text[start:end]
            chunks.append(chunk)
            start += chunk_size - chunk_overlap
        return chunks

class EmbeddingModel:
    """Generates embeddings for text."""
    
    def __init__(self, model_name: str = "BAAI/bge-small-en-v1.5"):
        self.model = TextEmbedding(model_name)

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """Generates embeddings for a list of texts."""
        embeddings = self.model.embed(texts)
        return embeddings.tolist()

    def embed_query(self, text: str) -> List[float]:
        """Generates embedding for a single query text."""
        embedding = self.model.embed([text])
        return embedding[0].tolist()

class VectorStore:
    """Manages the vector database for storing and retrieving embeddings."""
    
    def __init__(self, collection_name: str = "knowledge_base"):
        self.client = Client()
        self.collection = self.client.get_or_create_collection(
            name=collection_name,
            embedding_function=embedding_functions.SentenceTransformerEmbeddingFunction(model_name="BAAI/bge-small-en-v1.5")
        )

    def add_documents(self, texts: List[str], metadatas: Optional[List[Dict[str, Any]]] = None) -> None:
        """Adds documents and their embeddings to the vector store."""
        ids = [f"doc_{i}" for i in range(len(texts))]
        self.collection.add(documents=texts, metadatas=metadatas, ids=ids)

    def query(self, query_text: str, n_results: int = 5) -> List[Dict[str, Any]]:
        """Queries the vector store for relevant documents."""
        results = self.collection.query(
            query_texts=[query_text],
            n_results=n_results,
            include=["documents", "distances", "metadatas"]
        )
        return results

class RAGSystem:
    """Orchestrates the RAG pipeline."""
    
    def __init__(self, knowledge_base_path: str = "./knowledge_base"):
        self.loader = DocumentLoader()
        self.splitter = TextSplitter()
        self.embedder = EmbeddingModel()
        self.vector_store = VectorStore()
        self.knowledge_base_path = knowledge_base_path
        self._initialize_knowledge_base()

    def _initialize_knowledge_base(self):
        """Loads and indexes documents from the knowledge base path."""
        print(f"Initializing knowledge base from {self.knowledge_base_path}")
        for root, _, files in os.walk(self.knowledge_base_path):
            for file in files:
                file_path = os.path.join(root, file)
                try:
                    text = self.loader.load_text_file(file_path)
                    chunks = self.splitter.split_text(text)
                    self.vector_store.add_documents(chunks, metadatas=[{"source": file_path}] * len(chunks))
                    print(f"Indexed {len(chunks)} chunks from {file_path}")
                except Exception as e:
                    print(f"Error processing {file_path}: {e}")

    def retrieve(self, query: str, n_results: int = 5) -> List[str]:
        """Retrieves relevant documents for a given query."""
        results = self.vector_store.query(query, n_results=n_results)
        retrieved_docs = [doc for sublist in results["documents"] for doc in sublist]
        return retrieved_docs

    def generate_augmented_prompt(self, query: str, retrieved_docs: List[str]) -> str:
        """Generates an augmented prompt for the language model."""
        context = "\n\n".join(retrieved_docs)
        augmented_prompt = f"Context: {context}\n\nQuestion: {query}\n\nAnswer:"
        return augmented_prompt

# Example Usage (for testing purposes)
if __name__ == "__main__":
    # Create a dummy knowledge base directory and files
    if not os.path.exists("knowledge_base"):
        os.makedirs("knowledge_base")
    with open("knowledge_base/doc1.txt", "w", encoding="utf-8") as f:
        f.write("The Harmonic Unification Stack (HUS) is a comprehensive framework.")
    with open("knowledge_base/doc2.txt", "w", encoding="utf-8") as f:
        f.write("The Hodge Diamond organizes Hodge numbers of a complex manifold.")

    rag_system = RAGSystem()
    
    query = "What is HUS?"
    retrieved_docs = rag_system.retrieve(query)
    augmented_prompt = rag_system.generate_augmented_prompt(query, retrieved_docs)
    
    print(f"\nAugmented Prompt: {augmented_prompt}")
    
    # Clean up dummy knowledge base
    os.remove("knowledge_base/doc1.txt")
    os.remove("knowledge_base/doc2.txt")
    os.rmdir("knowledge_base")
    print("\nDummy knowledge base cleaned up.")


