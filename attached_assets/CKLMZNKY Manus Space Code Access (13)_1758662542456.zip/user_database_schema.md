# User Information Database Schema Design

## Overview

This document outlines the database schema for storing user information in the ASI Mega Beast Complete Project. The database will support personalization, adaptive learning, and user preference tracking to enable the system to "revolutionize the world" by providing a highly personalized and intelligent user experience.

## Design Principles

1. **Privacy-First**: Minimize data collection and ensure user privacy is protected.
2. **Extensible**: Schema should be flexible to accommodate future features and data types.
3. **Performance**: Optimized for fast reads and writes to support real-time interactions.
4. **Security**: Implement proper access controls and data encryption.
5. **Compliance**: Adhere to data protection regulations (GDPR, CCPA, etc.).

## Core Tables

### 1. Users Table
```sql
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    preferences JSONB DEFAULT '{}',
    metadata JSONB DEFAULT '{}'
);
```

### 2. User Sessions Table
```sql
CREATE TABLE user_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    session_token VARCHAR(255) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP NOT NULL,
    ip_address INET,
    user_agent TEXT,
    is_active BOOLEAN DEFAULT TRUE
);
```

### 3. User Interactions Table
```sql
CREATE TABLE user_interactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    interaction_type VARCHAR(50) NOT NULL, -- 'chat', 'physics_simulation', 'compression', etc.
    interaction_data JSONB NOT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    session_id UUID REFERENCES user_sessions(id),
    response_time_ms INTEGER,
    success BOOLEAN DEFAULT TRUE,
    error_message TEXT
);
```

### 4. User Preferences Table
```sql
CREATE TABLE user_preferences (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    category VARCHAR(50) NOT NULL, -- 'ui', 'physics', 'ai_model', 'compression', etc.
    preference_key VARCHAR(100) NOT NULL,
    preference_value JSONB NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, category, preference_key)
);
```

### 5. User Learning Data Table
```sql
CREATE TABLE user_learning_data (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    learning_context VARCHAR(100) NOT NULL, -- 'wsm_adaptation', 'physics_preferences', etc.
    learning_data JSONB NOT NULL,
    confidence_score FLOAT CHECK (confidence_score >= 0 AND confidence_score <= 1),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE
);
```

### 6. User Projects Table
```sql
CREATE TABLE user_projects (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    project_name VARCHAR(255) NOT NULL,
    project_type VARCHAR(50) NOT NULL, -- 'physics_simulation', 'ai_model', 'compression_task', etc.
    project_data JSONB NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_public BOOLEAN DEFAULT FALSE,
    tags TEXT[]
);
```

### 7. User Feedback Table
```sql
CREATE TABLE user_feedback (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    feedback_type VARCHAR(50) NOT NULL, -- 'rating', 'comment', 'bug_report', etc.
    feedback_data JSONB NOT NULL,
    related_interaction_id UUID REFERENCES user_interactions(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    processed BOOLEAN DEFAULT FALSE
);
```

## Indexes for Performance

```sql
-- User table indexes
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_created_at ON users(created_at);

-- User sessions indexes
CREATE INDEX idx_user_sessions_user_id ON user_sessions(user_id);
CREATE INDEX idx_user_sessions_token ON user_sessions(session_token);
CREATE INDEX idx_user_sessions_expires_at ON user_sessions(expires_at);

-- User interactions indexes
CREATE INDEX idx_user_interactions_user_id ON user_interactions(user_id);
CREATE INDEX idx_user_interactions_timestamp ON user_interactions(timestamp);
CREATE INDEX idx_user_interactions_type ON user_interactions(interaction_type);
CREATE INDEX idx_user_interactions_session_id ON user_interactions(session_id);

-- User preferences indexes
CREATE INDEX idx_user_preferences_user_id ON user_preferences(user_id);
CREATE INDEX idx_user_preferences_category ON user_preferences(category);

-- User learning data indexes
CREATE INDEX idx_user_learning_data_user_id ON user_learning_data(user_id);
CREATE INDEX idx_user_learning_data_context ON user_learning_data(learning_context);
CREATE INDEX idx_user_learning_data_updated_at ON user_learning_data(updated_at);

-- User projects indexes
CREATE INDEX idx_user_projects_user_id ON user_projects(user_id);
CREATE INDEX idx_user_projects_type ON user_projects(project_type);
CREATE INDEX idx_user_projects_created_at ON user_projects(created_at);

-- User feedback indexes
CREATE INDEX idx_user_feedback_user_id ON user_feedback(user_id);
CREATE INDEX idx_user_feedback_type ON user_feedback(feedback_type);
CREATE INDEX idx_user_feedback_created_at ON user_feedback(created_at);
```

## Data Types and Usage

### User Preferences Categories
- `ui`: User interface preferences (theme, layout, accessibility settings)
- `physics`: Physics engine preferences (simulation quality, default parameters)
- `ai_model`: AI model preferences (response style, creativity level)
- `compression`: Compression preferences (algorithm choice, compression level)
- `wsm`: WSM-specific preferences (model parameters, response patterns)

### Interaction Types
- `chat`: Chat interactions with AI models
- `physics_simulation`: Physics engine interactions
- `compression`: Data compression/decompression operations
- `wsm_query`: WSM-specific queries
- `ui_action`: UI interactions and navigation
- `project_management`: Project creation, modification, deletion

### Learning Context Types
- `wsm_adaptation`: WSM model adaptation based on user interactions
- `physics_preferences`: Learning user's physics simulation preferences
- `ui_optimization`: Learning optimal UI configurations for the user
- `compression_patterns`: Learning user's compression usage patterns

## Security Considerations

1. **Password Security**: Passwords are hashed using bcrypt or similar strong hashing algorithms.
2. **Session Management**: Session tokens are cryptographically secure and have appropriate expiration times.
3. **Data Encryption**: Sensitive data in JSONB fields should be encrypted at rest.
4. **Access Control**: Implement row-level security (RLS) to ensure users can only access their own data.
5. **Audit Trail**: All data modifications are logged with timestamps and user information.

## Privacy Compliance

1. **Data Minimization**: Only collect data necessary for functionality.
2. **User Consent**: Explicit consent for data collection and processing.
3. **Right to Deletion**: Implement cascading deletes and data purging capabilities.
4. **Data Portability**: Provide mechanisms for users to export their data.
5. **Anonymization**: Support for anonymizing user data for analytics.

## Integration Points

### With WSM (Weyl State Machine)
- Store WSM interaction patterns and preferences
- Track WSM model adaptation data
- Log WSM performance metrics per user

### With Physics Engine
- Store physics simulation preferences and parameters
- Track user's physics interaction patterns
- Save custom physics scenarios and configurations

### With Compression System
- Store compression algorithm preferences
- Track compression usage patterns
- Log compression performance metrics

### With UI/UX System
- Store UI preferences and customizations
- Track user navigation patterns
- Learn optimal UI configurations per user

## Future Extensions

1. **Machine Learning Integration**: Tables for storing ML model states and training data
2. **Collaboration Features**: Tables for shared projects and user relationships
3. **Analytics**: Aggregated analytics tables for system-wide insights
4. **API Usage Tracking**: Detailed API usage and rate limiting data
5. **Content Management**: Tables for user-generated content and media

## Implementation Notes

- Use PostgreSQL for JSONB support and advanced indexing capabilities
- Implement database migrations for schema evolution
- Set up automated backups and point-in-time recovery
- Use connection pooling for performance optimization
- Implement database monitoring and alerting

