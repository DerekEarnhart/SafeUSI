# Quick bootstrap to run the CLI inside this environment without installing
import sys, runpy, yaml, json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent / "src"))
from asi_core.cli import run, list_capabilities

if __name__ == "__main__":
    # Example: list capabilities and run a sample task
    pass
