# Cursor Rules (Example)

- Prefer minimal diffs; keep public APIs stable.  
- Before big changes: propose plan and diff.  
- Always write/adjust tests for changed behavior.  
- Never write secrets to logs; never paste license-incompatible code.
