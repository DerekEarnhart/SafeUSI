from .minivm import MiniVM
import random
class ResonanceOS:
    def __init__(self, workspace: str): self.vm = MiniVM(workspace)
    def handle(self, intent: str, *args):
        if intent == "ls": return self.vm.ls()
        if intent == "read": return self.vm.read(args[0])
        if intent == "write": self.vm.write(args[0], " ".join(args[1:])); return "OK"
        if intent == "append": self.vm.append(args[0], " ".join(args[1:])); return "OK"
        if intent == "run":
            code,out,err = self.vm.run(" ".join(args)); return f"exit={code}\n{out}{('\nERR:\n'+err) if err else ''}"
        if intent == "rml-gen": return gen_ascii_heightmap(int(args[0]) if args else 65)
        return "Unknown intent"
def gen_ascii_heightmap(n=65):
    n = max(9, n|1); grid=[[0.0 for _ in range(n)] for _ in range(n)]
    grid[0][0]=grid[0][-1]=grid[-1][0]=grid[-1][-1]=0.5
    step=n-1; scale=0.6
    while step>1:
        half=step//2
        for y in range(half, n-1, step):
            for x in range(half, n-1, step):
                avg=(grid[y-half][x-half]+grid[y-half][x+half]+grid[y+half][x-half]+grid[y+half][x+half])/4
                grid[y][x]=min(1,max(0,avg+(random.random()-0.5)*scale))
        for y in range(0, n, half):
            for x in range((y+half)%step, n, step):
                s=0;c=0
                for dy,dx in ((-half,0),(half,0),(0,-half),(0,half)):
                    yy=y+dy; xx=x+dx
                    if 0<=yy<n and 0<=xx<n: s+=grid[yy][xx]; c+=1
                grid[y][x]=min(1,max(0,s/c+(random.random()-0.5)*scale))
        step//=2; scale*=0.5
    shades=" .:-=+*#%@"
    return "\n".join("".join(shades[int(h*(len(shades)-1))] for h in row) for row in grid)
