# Harmonic Cursor Agent — Code

## Install
```bash
npm install
```

## Run
```bash
npm run agent -- "Refactor utils/date.ts to use luxon"
```

## Configure
- Create `.env` from `.env.example` if using OpenAI or GitHub PR integration.
- Pass `--config ../examples/agent.config.json` to override defaults.

## Extend
- Add tools in `src/tools/*.ts` and route from `src/core/toolRouter.ts`.
- Adjust policy in `src/core/policy.ts` (allow domains, shell bins, confirmations).
