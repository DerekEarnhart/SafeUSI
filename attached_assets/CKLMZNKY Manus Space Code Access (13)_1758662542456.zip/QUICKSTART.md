# HUS / WSM Full Bundle — Quickstart
- Core model: `WSM_Pro_v4/`
- Pipeline server: `Pipeline/`
- Zenodo + Media: `Zenodo_Media/`
- IP disclosure: `NOTE_OF_PUBLICATION.md`
