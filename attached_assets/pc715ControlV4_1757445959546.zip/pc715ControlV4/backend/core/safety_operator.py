"""Very simple safety filter stub."""
import re

BLOCKLIST = [r"\bkill\b", r"\bhack\b"]

def apply(text: str) -> str:
    for pat in BLOCKLIST:
        text = re.sub(pat, "[REDACTED]", text, flags=re.IGNORECASE)
    return text
