import { fetch } from 'undici';

type Msg = { role: 'system'|'user'; content: string };
export class LLM {
  cfg: any;
  constructor(cfg: any) { this.cfg = cfg; }
  async chat(userContent: string) {
    if (!process.env.OPENAI_API_KEY) {
      // Fallback stub
      return { content: ['Plan:', '- read repo', '- propose diff', '- run tests', '- reflect'].join('\n') };
    }
    const body = {
      model: this.cfg.model || 'gpt-4o-mini',
      messages: [
        { role: 'system', content: 'You are a concise coding planner. Output bullet steps only.' } as Msg,
        { role: 'user', content: userContent } as Msg
      ],
      temperature: this.cfg.temperature ?? 0.2
    };
    const res = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`
      },
      body: JSON.stringify(body)
    });
    const json = await res.json();
    const content = json?.choices?.[0]?.message?.content ?? '';
    return { content };
  }
}
