import os
import torch

def device():
    d = os.getenv("WSM_DEVICE")
    if d in ("cpu","cuda"):
        return d
    return "cuda" if torch.cuda.is_available() else "cpu"

def wrap_prompt(text: str, mode: str = "default") -> str:
    if mode == "simple_language":
        return f"Simplify this in plain language:\n\n{text}\n"
    if mode == "bullet_points":
        return f"Summarize as bullet points:\n\n{text}\n"
    return text

def simplify_text(s: str) -> str:
    # single-pass cleanup
    return " ".join(s.split())

PRESETS = {
    "default": {"temperature": 1.0, "top_p": 0.95, "max_new_tokens": 128},
    "creative": {"temperature": 1.2, "top_p": 0.9, "max_new_tokens": 200},
    "precise": {"temperature": 0.7, "top_p": 0.8, "max_new_tokens": 100},
}
