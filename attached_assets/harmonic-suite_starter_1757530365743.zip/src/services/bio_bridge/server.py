from flask import Flask, request, jsonify
from flask_cors import CORS
import json, os, time
app = Flask(__name__); CORS(app)
STATE={"timestamp":"","coherence":0.9,"resonance":0.86,"entropy":0.41,"hap_index":0.79,"metrics":{},"composite":0.734}
def write_latest(payload):
    path=os.path.abspath(os.path.join(os.path.dirname(__file__), "..","..","..","web","metric_demo","latest.json"))
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path,"w",encoding="utf-8") as f: json.dump(payload,f,indent=2)
@app.get("/healthz")
def healthz(): return {"ok":True}
@app.get("/metrics")
def metrics(): return jsonify(STATE)
@app.post("/ingest")
def ingest():
    data=request.get_json(force=True); STATE.update(data)
    STATE["timestamp"]=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()); write_latest(STATE)
    return {"ok":True,"state":STATE}
if __name__=="__main__": app.run(host="127.0.0.1", port=5001, debug=True)
