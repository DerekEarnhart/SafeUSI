"""Loads user docs into a FAISS index for retrieval. Placeholder implementation."""
import os, faiss, glob, pathlib, pickle
from sentence_transformers import SentenceTransformer

EMBED_PATH = pathlib.Path("data/vector_db/index.pkl")
_model = SentenceTransformer('all-MiniLM-L6-v2')

def ensure_index():
    if EMBED_PATH.exists():
        return  # already built
    os.makedirs(EMBED_PATH.parent, exist_ok=True)
    docs = []
    for f in glob.glob("docs/**/*", recursive=True):
        if not os.path.isfile(f): continue
        try:
            txt = open(f, encoding='utf-8', errors='ignore').read()
            docs.append(txt[:1000])  # naive
        except:
            pass
    if not docs:
        return
    embeddings = _model.encode(docs)
    index = faiss.IndexFlatL2(embeddings.shape[1])
    index.add(embeddings)
    with open(EMBED_PATH, 'wb') as fh:
        pickle.dump(index, fh)
