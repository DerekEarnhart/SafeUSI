
import argparse, torch
from fastapi import FastAPI
from pydantic import BaseModel
import uvicorn
from adapters.safeugoi_adapter import load_wsm_model

class GenReq(BaseModel):
    prompt: str
    max_new_tokens: int = 64
    temperature: float = 1.0
    top_p: float = 0.9

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", type=str, default="./wsm_ckpt.pt")
    ap.add_argument("--port", type=int, default=8080)
    ap.add_argument("--tokenizer", type=str, default="./assets/tokenizer")
    args = ap.parse_args()

    tok, model = load_wsm_model(args.ckpt, tokenizer=args.tokenizer, device="cuda")
    app = FastAPI()

    @app.post("/generate")
    def generate(req: GenReq):
        ids = tok(req.prompt, return_tensors="pt")["input_ids"]
        out = model.generate(ids, max_new_tokens=req.max_new_tokens, temperature=req.temperature, top_p=req.top_p)
        text = tok.decode(out[0].tolist(), skip_special_tokens=True)
        return {"text": text}

    uvicorn.run(app, host="0.0.0.0", port=args.port)

if __name__ == "__main__":
    main()
