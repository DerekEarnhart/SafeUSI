$ErrorActionPreference = "Stop"
$base = "http://127.0.0.1:5001"
Invoke-WebRequest "$base/vm/status" -UseBasicParsing | Select-Object -ExpandProperty Content
Invoke-WebRequest "$base/vm/task" -Method Post -ContentType "application/json" -Body '{"task_description":"add two numbers"}' -UseBasicParsing | Select-Object -ExpandProperty Content
