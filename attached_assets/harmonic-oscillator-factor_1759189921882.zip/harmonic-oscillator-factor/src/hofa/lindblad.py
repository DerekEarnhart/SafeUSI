import numpy as np

def L_K(rho: np.ndarray, K: np.ndarray) -> np.ndarray:
    return K @ rho @ K - 0.5 * (K @ K @ rho + rho @ K @ K)

def step(rho: np.ndarray, H: np.ndarray, K: np.ndarray, dt: float) -> np.ndarray:
    """Single Trotter step of unitary + Lindbladian, keeps trace 1."""
    rho = rho - 1j * dt * (H @ rho - rho @ H)  # unitary part
    rho = rho + dt * L_K(rho, K)               # dissipative
    tr = np.trace(rho)
    if abs(tr) > 0:
        rho = rho / tr
    return rho
