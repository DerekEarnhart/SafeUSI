# Minimal Flask app with robust path handling
import os, sys, time
from pathlib import Path

# Ensure project root is on sys.path no matter where this file is run from
HERE = Path(__file__).resolve()
ROOT = HERE.parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

# Try imports from package first, then fallback to sibling
try:
    from qgvm2.vm_api import vm_api, system_components  # type: ignore
except Exception as e_pkg:
    try:
        from vm_api import vm_api, system_components  # type: ignore
    except Exception as e_local:
        raise ImportError(
            "Could not import vm_api. Make sure the folder structure is:\n"
            "  <project_root>/app/mini_server.py\n"
            "  <project_root>/qgvm2/vm_api.py\n"
            "Run from the project root:  python -m app.mini_server\n"
            f"Package error: {e_pkg}\nLocal error: {e_local}"
        )

# Try to import your real orchestrator; otherwise use a stub
try:
    from qgvm2.universal_task_orchestrator import UniversalTaskOrchestrator  # type: ignore
    orchestrator = UniversalTaskOrchestrator()  # type: ignore[name-defined]
except Exception:
    class UniversalTaskOrchestrator:
        def __init__(self): self.tasks = {}
        def submit_task(self, task_description: str) -> str:
            tid = str(int(time.time() * 1e6))
            self.tasks[tid] = {"status": "completed", "result": f"stub:{task_description}"}
            return tid
    orchestrator = UniversalTaskOrchestrator()

# Wire orchestrator into the blueprint's shared registry
system_components["task_orchestrator"] = orchestrator

from flask import Flask
from flask_cors import CORS

app = Flask(__name__)
CORS(app)
app.register_blueprint(vm_api)

if __name__ == "__main__":
    port = int(os.getenv("PORT", "5001"))
    app.run(host="0.0.0.0", port=port, debug=False)
