class ToolTemplates:
    """
    Pre-defined patterns for common tool types.
    """
    @staticmethod
    def get_template(template_name):
        # TODO: implement template retrieval
        return ""
