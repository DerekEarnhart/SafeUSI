class MultiModalInterface:
    """
    Coordinates between different interface types.
    """
    def render(self):
        # TODO: implement rendering
        pass
