import React, { useState, useRef } from 'react';
import { ChatMessage, FileObject } from '../types';
import { SendIcon, UploadIcon, CopyIcon, VideoIcon } from './icons';

interface ChatPanelProps {
  messages: ChatMessage[];
  isLoading: boolean;
  onSendMessage: (text: string, file?: FileObject) => void;
  messagesEndRef: React.RefObject<HTMLDivElement>;
}

const ChatMessageItem: React.FC<{ message: ChatMessage }> = ({ message }) => {
  const isASI = message.sender === 'ASI';
  return (
    <div className={`flex items-start gap-3 ${isASI ? '' : 'justify-end'}`}>
        {isASI && <div className="w-8 h-8 rounded-full bg-cyan-500/20 flex-shrink-0 border border-cyan-400/50 mt-1"></div>}
        <div className={`max-w-xl p-3 rounded-lg ${isASI ? 'bg-gray-800' : 'bg-blue-800/50'}`}>
            <p className="text-gray-200 whitespace-pre-wrap">{message.text}</p>
            {message.file && (
                <div className="mt-2 p-2 bg-gray-700/50 rounded-md text-xs">
                    <p className="font-mono text-cyan-300">File: {message.file.name}</p>
                    <p className="text-gray-400">{message.file.type} - {(message.file.size / 1024).toFixed(2)} KB</p>
                </div>
            )}
        </div>
    </div>
  );
};

const ChatPanel: React.FC<ChatPanelProps> = ({ messages, isLoading, onSendMessage, messagesEndRef }) => {
  const [text, setText] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSend = () => {
    const trimmedText = text.trim();
    if (!trimmedText && !file) return;

    let fileObject: FileObject | undefined;
    if (file) {
      fileObject = { name: file.name, type: file.type, size: file.size };
    }
    onSendMessage(trimmedText, fileObject);
    setText('');
    setFile(null);
    if(fileInputRef.current) fileInputRef.current.value = "";
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="flex-1 flex flex-col p-4 overflow-hidden">
      <div className="flex-1 overflow-y-auto pr-2 space-y-4">
        {messages.map(msg => <ChatMessageItem key={msg.id} message={msg} />)}
        {isLoading && (
            <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-cyan-500/20 flex-shrink-0 border border-cyan-400/50 mt-1 animate-pulse"></div>
                <div className="max-w-xl p-3 rounded-lg bg-gray-800">
                    <div className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse delay-0"></div>
                        <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse delay-200"></div>
                        <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse delay-400"></div>
                    </div>
                </div>
            </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="mt-4 border border-cyan-500/20 bg-gray-800/50 rounded-lg p-2 shadow-lg backdrop-blur-sm">
        {file && (
          <div className="px-2 pb-2 text-xs flex justify-between items-center">
            <span className="text-cyan-300 font-mono">Attached: {file.name}</span>
            <button onClick={() => {
              setFile(null);
              if(fileInputRef.current) fileInputRef.current.value = "";
            }} className="text-gray-500 hover:text-red-400">&times;</button>
          </div>
        )}
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Transmit your intent..."
          className="w-full bg-transparent resize-none focus:outline-none p-2"
          rows={2}
          disabled={isLoading}
        />
        <div className="flex justify-between items-center mt-1">
          <div className="flex items-center space-x-2">
             <button onClick={() => fileInputRef.current?.click()} className="text-gray-400 hover:text-cyan-400 transition-colors" title="Attach File">
               <UploadIcon className="w-5 h-5" />
             </button>
             <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" />
             <button onClick={() => alert("Video stream initializing...")} className="text-gray-400 hover:text-cyan-400 transition-colors" title="Initiate Video Stream">
                <VideoIcon className="w-5 h-5" />
             </button>
             <button onClick={() => navigator.clipboard.writeText(JSON.stringify(messages, null, 2))} className="text-gray-400 hover:text-cyan-400 transition-colors" title="Copy Chat History">
                <CopyIcon className="w-5 h-5" />
             </button>
          </div>
          <button onClick={handleSend} disabled={isLoading || (!text.trim() && !file)} className="bg-cyan-600 hover:bg-cyan-500 disabled:bg-gray-600 disabled:cursor-not-allowed text-white rounded-md p-2 transition-colors">
            <SendIcon className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChatPanel;
