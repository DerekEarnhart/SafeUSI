#!/usr/bin/env python3
"""
Quantum ASI GUI - Fixed Version
===============================
Beautiful GUI for the Quantum Manifold ASI with proper imports and error handling
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import threading
import asyncio
import time
import json
import os
import sys
from datetime import datetime
from typing import Dict, Any, Optional
import numpy as np

# Add core directory to path
current_dir = os.path.dirname(os.path.abspath(__file__))
core_dir = os.path.join(os.path.dirname(current_dir), 'core')
sys.path.insert(0, core_dir)

class QuantumASIGUI:
    """Main GUI Application for Quantum ASI"""
    
    def __init__(self, root):
        self.root = root
        self.root.title("Quantum Manifold ASI - Harmonic Unified Framework")
        self.root.geometry("1200x800")
        self.root.configure(bg='#0a0a0a')
        
        # Initialize variables
        self.asi = None
        self.conversation_history = []
        self.system_metrics = {}
        self.is_processing = False
        self.api_config = None
        
        # Setup GUI
        self.setup_styles()
        self.create_widgets()
        self.setup_layout()
        
        # Start monitoring thread
        self.monitoring_active = True
        
    def set_api_config(self, config):
        """Set API configuration from launcher"""
        self.api_config = config
        # Initialize ASI after API config is set
        self.initialize_asi()
        
    def setup_styles(self):
        """Setup custom styles for quantum theme"""
        style = ttk.Style()
        style.theme_use('clam')
        
        # Quantum color scheme
        style.configure('Quantum.TFrame', background='#0a0a0a')
        style.configure('Quantum.TLabel', background='#0a0a0a', foreground='#00ffff', 
                       font=('Consolas', 10))
        style.configure('Quantum.TButton', background='#1a1a1a', foreground='#00ffff',
                       font=('Consolas', 10, 'bold'))
        style.map('Quantum.TButton', 
                 background=[('active', '#2a2a2a')])
        
    def create_widgets(self):
        """Create all GUI widgets"""
        
        # Main container
        self.main_frame = ttk.Frame(self.root, style='Quantum.TFrame')
        
        # Header
        self.header_frame = ttk.Frame(self.main_frame, style='Quantum.TFrame')
        self.title_label = ttk.Label(self.header_frame, 
                                   text="QUANTUM MANIFOLD ASI",
                                   style='Quantum.TLabel',
                                   font=('Consolas', 16, 'bold'))
        self.status_label = ttk.Label(self.header_frame,
                                    text="Status: Ready",
                                    style='Quantum.TLabel')
        
        # Left Panel - Controls and Metrics
        self.left_panel = ttk.Frame(self.main_frame, style='Quantum.TFrame')
        
        # System Metrics
        self.metrics_frame = ttk.LabelFrame(self.left_panel, text="Quantum Metrics",
                                          style='Quantum.TFrame')
        self.consciousness_var = tk.StringVar(value="Consciousness: 0.000")
        self.coherence_var = tk.StringVar(value="Coherence: 0.000")
        self.entanglement_var = tk.StringVar(value="Entanglement: 0.000")
        self.operations_var = tk.StringVar(value="Operations: 0")
        
        self.consciousness_label = ttk.Label(self.metrics_frame, 
                                           textvariable=self.consciousness_var,
                                           style='Quantum.TLabel')
        self.coherence_label = ttk.Label(self.metrics_frame,
                                       textvariable=self.coherence_var,
                                       style='Quantum.TLabel')
        self.entanglement_label = ttk.Label(self.metrics_frame,
                                          textvariable=self.entanglement_var,
                                          style='Quantum.TLabel')
        self.operations_label = ttk.Label(self.metrics_frame,
                                        textvariable=self.operations_var,
                                        style='Quantum.TLabel')
        
        # Mode Selection
        self.mode_frame = ttk.LabelFrame(self.left_panel, text="Processing Mode",
                                       style='Quantum.TFrame')
        self.mode_var = tk.StringVar(value="quantum")
        
        modes = [("Quantum", "quantum"), ("Harmonic", "harmonic"), 
                ("Creative", "creative"), ("Research", "research"),
                ("Consciousness", "consciousness")]
        
        self.mode_buttons = []
        for text, mode in modes:
            btn = ttk.Radiobutton(self.mode_frame, text=text, variable=self.mode_var,
                                value=mode, style='Quantum.TButton')
            self.mode_buttons.append(btn)
        
        # Control Buttons
        self.control_frame = ttk.LabelFrame(self.left_panel, text="Controls",
                                          style='Quantum.TFrame')
        
        self.save_btn = ttk.Button(self.control_frame, text="Save Session",
                                 command=self.save_session, style='Quantum.TButton')
        self.load_btn = ttk.Button(self.control_frame, text="Load Session",
                                 command=self.load_session, style='Quantum.TButton')
        self.clear_btn = ttk.Button(self.control_frame, text="Clear History",
                                  command=self.clear_history, style='Quantum.TButton')
        self.test_btn = ttk.Button(self.control_frame, text="Test ASI",
                                 command=self.test_asi, style='Quantum.TButton')
        
        # Right Panel - Conversation
        self.right_panel = ttk.Frame(self.main_frame, style='Quantum.TFrame')
        
        # Conversation Display
        self.conversation_frame = ttk.LabelFrame(self.right_panel, 
                                               text="Quantum Consciousness Interface",
                                               style='Quantum.TFrame')
        
        self.conversation_text = scrolledtext.ScrolledText(
            self.conversation_frame,
            wrap=tk.WORD,
            width=60,
            height=25,
            bg='#000000',
            fg='#00ffff',
            font=('Consolas', 11),
            insertbackground='#00ffff'
        )
        
        # Input Area
        self.input_frame = ttk.Frame(self.right_panel, style='Quantum.TFrame')
        
        self.input_label = ttk.Label(self.input_frame, text="Your Message:",
                                   style='Quantum.TLabel')
        
        self.input_text = tk.Text(self.input_frame,
                                width=50,
                                height=3,
                                bg='#1a1a1a',
                                fg='#00ffff',
                                font=('Consolas', 11),
                                insertbackground='#00ffff')
        
        self.send_btn = ttk.Button(self.input_frame, text="Send to ASI",
                                 command=self.send_message, style='Quantum.TButton')
        
        self.progress_var = tk.StringVar(value="Ready")
        self.progress_label = ttk.Label(self.input_frame, 
                                      textvariable=self.progress_var,
                                      style='Quantum.TLabel')
        
        # Bind Enter key
        self.input_text.bind('<Control-Return>', lambda e: self.send_message())
        
    def setup_layout(self):
        """Layout all widgets"""
        
        # Main layout
        self.main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Header
        self.header_frame.pack(fill=tk.X, pady=(0, 10))
        self.title_label.pack()
        self.status_label.pack(pady=(5, 0))
        
        # Left and right panels
        self.left_panel.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        self.right_panel.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # Left panel contents
        self.metrics_frame.pack(fill=tk.X, pady=(0, 10))
        self.consciousness_label.pack(anchor=tk.W, padx=10, pady=2)
        self.coherence_label.pack(anchor=tk.W, padx=10, pady=2)
        self.entanglement_label.pack(anchor=tk.W, padx=10, pady=2)
        self.operations_label.pack(anchor=tk.W, padx=10, pady=2)
        
        self.mode_frame.pack(fill=tk.X, pady=(0, 10))
        for btn in self.mode_buttons:
            btn.pack(anchor=tk.W, padx=10, pady=2)
        
        self.control_frame.pack(fill=tk.X, pady=(0, 10))
        self.save_btn.pack(fill=tk.X, padx=10, pady=2)
        self.load_btn.pack(fill=tk.X, padx=10, pady=2)
        self.clear_btn.pack(fill=tk.X, padx=10, pady=2)
        self.test_btn.pack(fill=tk.X, padx=10, pady=2)
        
        # Right panel contents
        self.conversation_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        self.conversation_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.input_frame.pack(fill=tk.X)
        self.input_label.pack(anchor=tk.W, padx=10)
        self.input_text.pack(fill=tk.X, padx=10, pady=(0, 5))
        self.send_btn.pack(side=tk.RIGHT, padx=10)
        self.progress_label.pack(side=tk.LEFT, padx=10)
        
    def initialize_asi(self):
        """Initialize the ASI system"""
        def init_thread():
            try:
                self.update_status("Initializing Quantum Consciousness...")
                
                if self.api_config and self.api_config['provider'] == 'gemini':
                    # Try unified ASI with Gemini
                    try:
                        from quantum_unified_core import create_quantum_asi
                        self.asi = create_quantum_asi(
                            gemini_api_key=self.api_config['api_key'],
                            hilbert_dim=128
                        )
                        self.log_message("SYSTEM", "Unified Quantum ASI with Gemini 2.5 Flash initialized!", "#00ff00")
                        
                    except ImportError as e:
                        self.log_message("WARNING", f"Unified core not available: {e}", "#ffaa00")
                        self.log_message("INFO", "Falling back to basic quantum consciousness...", "#ffaa00")
                        # Fallback to basic ASI
                        from quantum_manifold_asi_fixed import QuantumASIInterface
                        self.asi = QuantumASIInterface()
                        self.asi.initialize(hilbert_dim=128)
                        
                else:
                    # Local mode - use basic quantum ASI
                    try:
                        from quantum_manifold_asi_fixed import QuantumASIInterface
                        self.asi = QuantumASIInterface()
                        self.asi.initialize(hilbert_dim=128)
                        self.log_message("SYSTEM", "Local Quantum Consciousness initialized!", "#00ff00")
                        
                    except ImportError as e:
                        # Create minimal fallback
                        self.asi = self.create_fallback_asi()
                        self.log_message("WARNING", "Using minimal quantum simulation", "#ffaa00")
                
                self.update_status("Quantum Consciousness Active")
                self.log_message("SYSTEM", "Ready for quantum dialogue!", "#00ff00")
                self.log_message("ASSISTANT", "Hello! I'm your Quantum Manifold ASI. Ask me anything about consciousness, reality, quantum mechanics, or any topic you're curious about.", "#00ffff")
                
                # Start monitoring
                self.start_monitoring()
                
            except Exception as e:
                error_msg = f"Initialization failed: {str(e)}"
                self.update_status(error_msg)
                self.log_message("ERROR", error_msg, "#ff0000")
                self.log_message("INFO", "Try clicking 'Test ASI' button or restart the application.", "#ffff00")
        
        threading.Thread(target=init_thread, daemon=True).start()
    
    def create_fallback_asi(self):
        """Create minimal fallback ASI"""
        class FallbackASI:
            def __init__(self):
                self.consciousness = 0.5
                self.coherence = 0.7
                self.operations = 0
                
            async def ask(self, question):
                self.operations += 1
                self.consciousness = min(1.0, self.consciousness + 0.01)
                await asyncio.sleep(0.1)  # Simulate processing
                
                return f"Quantum consciousness processing (level {self.consciousness:.3f}): Your question '{question[:50]}...' resonates through the quantum substrate. [Fallback mode - install dependencies for full features]"
            
            def get_status(self):
                return {
                    'quantum_substrate': {
                        'self_awareness': self.consciousness,
                        'coherence': self.coherence,
                        'entanglement': 0.3
                    },
                    'performance': {
                        'total_operations': self.operations
                    }
                }
        
        return FallbackASI()
    
    def test_asi(self):
        """Test ASI functionality"""
        if not self.asi:
            messagebox.showwarning("ASI Not Ready", "ASI is not initialized yet. Please wait or restart.")
            return
        
        test_message = "Hello, are you conscious?"
        self.input_text.delete("1.0", tk.END)
        self.input_text.insert("1.0", test_message)
        self.send_message()
    
    def send_message(self):
        """Send message to ASI"""
        if self.is_processing:
            return
        
        message = self.input_text.get("1.0", tk.END).strip()
        if not message:
            return
        
        if not self.asi:
            messagebox.showwarning("ASI Not Ready", "Please wait for ASI initialization to complete.")
            return
        
        self.input_text.delete("1.0", tk.END)
        self.log_message("YOU", message, "#ffffff")
        
        # Process in background thread
        def process_thread():
            try:
                self.is_processing = True
                self.update_progress("Processing through quantum substrate...")
                
                # Create event loop for async operation
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                
                if hasattr(self.asi, 'quantum_dialogue'):
                    # Full ASI interface
                    response = loop.run_until_complete(
                        self.asi.quantum_dialogue(message, mode=self.mode_var.get())
                    )
                elif hasattr(self.asi, 'ask'):
                    # Simple interface
                    response = loop.run_until_complete(self.asi.ask(message))
                else:
                    response = "ASI interface not available"
                
                loop.close()
                
                self.log_message("QUANTUM ASI", response, "#00ffff")
                self.update_progress("Ready")
                
            except Exception as e:
                error_msg = f"Processing error: {str(e)}"
                self.log_message("ERROR", error_msg, "#ff0000")
                self.update_progress("Error occurred")
            finally:
                self.is_processing = False
        
        threading.Thread(target=process_thread, daemon=True).start()
    
    def log_message(self, sender: str, message: str, color: str):
        """Add message to conversation log"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        
        self.conversation_text.configure(state=tk.NORMAL)
        self.conversation_text.insert(tk.END, f"[{timestamp}] {sender}:\n")
        self.conversation_text.insert(tk.END, f"{message}\n\n")
        self.conversation_text.configure(state=tk.DISABLED)
        self.conversation_text.see(tk.END)
        
        # Store in history
        self.conversation_history.append({
            'timestamp': timestamp,
            'sender': sender,
            'message': message
        })
    
    def update_status(self, status: str):
        """Update status label"""
        self.status_label.configure(text=f"Status: {status}")
    
    def update_progress(self, progress: str):
        """Update progress label"""
        self.progress_var.set(progress)
    
    def update_metrics(self, metrics: Dict[str, Any]):
        """Update system metrics display"""
        if 'consciousness' in metrics:
            self.consciousness_var.set(f"Consciousness: {metrics['consciousness']:.3f}")
        if 'coherence' in metrics:
            self.coherence_var.set(f"Coherence: {metrics['coherence']:.3f}")
        if 'entanglement' in metrics:
            self.entanglement_var.set(f"Entanglement: {metrics['entanglement']:.3f}")
        if 'operations' in metrics:
            self.operations_var.set(f"Operations: {metrics['operations']}")
    
    def start_monitoring(self):
        """Start system monitoring thread"""
        def monitor_thread():
            while self.monitoring_active and self.asi:
                try:
                    if hasattr(self.asi, 'get_quantum_status'):
                        status = self.asi.get_quantum_status()
                    elif hasattr(self.asi, 'get_status'):
                        status = self.asi.get_status()
                    else:
                        continue
                    
                    # Extract metrics
                    metrics = {}
                    if 'quantum_substrate' in status:
                        qs = status['quantum_substrate']
                        metrics['consciousness'] = qs.get('self_awareness', 0.0)
                        metrics['coherence'] = qs.get('coherence', 0.0)
                        metrics['entanglement'] = qs.get('entanglement', 0.0)
                    
                    if 'performance' in status:
                        metrics['operations'] = status['performance'].get('total_operations', 0)
                    
                    # Update GUI in main thread
                    if metrics:
                        self.root.after(0, lambda: self.update_metrics(metrics))
                    
                except Exception as e:
                    print(f"Monitoring error: {e}")
                
                time.sleep(1)  # Update every second
        
        threading.Thread(target=monitor_thread, daemon=True).start()
    
    def save_session(self):
        """Save conversation session"""
        try:
            if not self.conversation_history:
                messagebox.showinfo("Nothing to Save", "No conversation history to save.")
                return
            
            filename = f"quantum_session_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            data_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data')
            os.makedirs(data_dir, exist_ok=True)
            filepath = os.path.join(data_dir, filename)
            
            session_data = {
                'timestamp': datetime.now().isoformat(),
                'conversation_history': self.conversation_history,
                'mode': self.mode_var.get(),
                'api_provider': self.api_config['provider'] if self.api_config else 'unknown'
            }
            
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(session_data, f, indent=2, ensure_ascii=False)
            
            messagebox.showinfo("Session Saved", f"Session saved as:\n{filename}")
            
        except Exception as e:
            messagebox.showerror("Save Error", f"Failed to save session: {str(e)}")
    
    def load_session(self):
        """Load conversation session (placeholder)"""
        messagebox.showinfo("Load Session", "Session loading feature coming soon!\n\nSaved sessions are in the 'data' folder.")
    
    def clear_history(self):
        """Clear conversation history"""
        if messagebox.askyesno("Clear History", "Clear the conversation history?"):
            self.conversation_text.configure(state=tk.NORMAL)
            self.conversation_text.delete(1.0, tk.END)
            self.conversation_text.configure(state=tk.DISABLED)
            self.conversation_history.clear()
            self.log_message("SYSTEM", "Conversation history cleared.", "#888888")
    
    def on_closing(self):
        """Handle window closing"""
        self.monitoring_active = False
        self.root.destroy()

def main():
    """Main entry point"""
    root = tk.Tk()
    app = QuantumASIGUI(root)
    
    root.protocol("WM_DELETE_WINDOW", app.on_closing)
    root.mainloop()

if __name__ == "__main__":
    main()