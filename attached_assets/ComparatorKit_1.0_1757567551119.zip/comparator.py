#!/usr/bin/env python3
import os, json, time, math, hashlib, argparse, datetime, statistics, pathlib
from typing import Dict, Any, List, Tuple
try:
    import numpy as np
except ImportError:
    raise SystemExit("This tool requires numpy. Install with:  python -m pip install numpy")

ARTIFACT_DIR = "artifacts"
DATASET_ID = "synthetic_blobs_v1"
DATASET_VERSION = "1.0"

def set_seed(seed: int):
    np.random.seed(seed)

def sha256_bytes(b: bytes) -> str:
    return "sha256:" + hashlib.sha256(b).hexdigest()

def sha256_file(path: str) -> str:
    with open(path, "rb") as f:
        return sha256_bytes(f.read())

def merkle_root(leaves: List[str]) -> str:
    if not leaves:
        return ""
    layer = [bytes.fromhex(h.split(":")[1]) if h.startswith("sha256:") else bytes.fromhex(h) for h in leaves]
    while len(layer) > 1:
        nxt = []
        for i in range(0, len(layer), 2):
            a = layer[i]
            b = layer[i+1] if i+1 < len(layer) else a
            nxt.append(hashlib.sha256(a + b).digest())
        layer = nxt
    return "sha256:" + layer[0].hex()

def make_blobs(n: int, separation: float = 2.0, std: float = 1.0) -> Tuple["np.ndarray","np.ndarray"]:
    mean0 = np.array([-separation/2, 0.0])
    mean1 = np.array([ separation/2, 0.0])
    cov = np.array([[std, 0.0],[0.0, std]])
    x0 = np.random.multivariate_normal(mean0, cov, size=n//2)
    x1 = np.random.multivariate_normal(mean1, cov, size=n - n//2)
    X = np.vstack([x0, x1])
    y = np.array([0]*(n//2) + [1]*(n - n//2))
    idx = np.random.permutation(n)
    return X[idx], y[idx]

def split_train_test(X, y, test_ratio=0.3):
    n = len(X)
    t = int(n*(1-test_ratio))
    return (X[:t], y[:t]), (X[t:], y[t:])

def sigmoid(z):
    return 1.0 / (1.0 + np.exp(-z))

def logistic_train(X, y, lr=0.1, epochs=200, l2=0.0):
    Xb = np.hstack([X, np.ones((X.shape[0], 1))])
    w = np.zeros(Xb.shape[1])
    for _ in range(epochs):
        z = Xb @ w
        p = sigmoid(z)
        grad = Xb.T @ (p - y) / len(y) + l2 * np.r_[w[:-1], 0.0]
        w -= lr * grad
    return w

def logistic_pred(X, w):
    Xb = np.hstack([X, np.ones((X.shape[0], 1))])
    p = sigmoid(Xb @ w)
    return (p >= 0.5).astype(int)

def run_variant_baseline_lr(Xtr, ytr, Xte, yte, params):
    start = time.perf_counter()
    w = logistic_train(Xtr, ytr, lr=params.get("lr", 0.1), epochs=params.get("epochs", 200), l2=params.get("l2", 0.0))
    train_time = (time.perf_counter() - start) * 1000.0
    yhat = logistic_pred(Xte, w)
    acc = (yhat == yte).mean()
    Xte_rob = Xte + np.random.normal(0, params.get("rob_noise", 0.05), size=Xte.shape)
    yhat_rob = logistic_pred(Xte_rob, w)
    acc_rob = (yhat_rob == yte).mean()
    return {"accuracy": float(acc), "robust_accuracy": float(acc_rob), "latency_ms": float(train_time)}

def run_variant_tuned_lr(Xtr, ytr, Xte, yte, params):
    start = time.perf_counter()
    w = logistic_train(Xtr, ytr, lr=params.get("lr", 0.08), epochs=params.get("epochs", 300), l2=params.get("l2", 0.01))
    train_time = (time.perf_counter() - start) * 1000.0
    yhat = logistic_pred(Xte, w)
    acc = (yhat == yte).mean()
    Xte_rob = Xte + np.random.normal(0, params.get("rob_noise", 0.05), size=Xte.shape)
    yhat_rob = logistic_pred(Xte_rob, w)
    acc_rob = (yhat_rob == yte).mean()
    return {"accuracy": float(acc), "robust_accuracy": float(acc_rob), "latency_ms": float(train_time)}

VARIANT_FUNCS = {
    "baseline_lr": run_variant_baseline_lr,
    "tuned_lr": run_variant_tuned_lr,
}

def evaluate_variant_over_seeds(variant_name: str, params, seeds, suite):
    metrics = {"accuracy": [], "robust_accuracy": [], "latency_ms": []}
    for seed in seeds:
        np.random.seed(seed)
        X, y = make_blobs(n=suite.get("n_samples", 1000),
                          separation=suite.get("separation", 2.0),
                          std=suite.get("std", 1.0))
        (Xtr, ytr), (Xte, yte) = split_train_test(X, y, test_ratio=suite.get("test_ratio", 0.3))
        res = VARIANT_FUNCS[variant_name](Xtr, ytr, Xte, yte, params)
        for k in metrics:
            metrics[k].append(res[k])
    return {k: float(sum(v)/len(v)) for k, v in metrics.items()}

def select_dominant(results):
    def keyfn(item):
        name, m = item
        return (m["accuracy"], m["robust_accuracy"], -m["latency_ms"])
    return max(results.items(), key=keyfn)[0]

def print_table(results, winner):
    names = list(results.keys())
    header = f"{'Variant':<18} {'Accuracy':>9} {'RobustAcc':>10} {'Latency(ms)':>12}"
    print(header); print("-"*len(header))
    for n in names:
        m = results[n]
        star = "  *WIN*" if n == winner else ""
        print(f"{n:<18} {m['accuracy']*100:9.2f} {m['robust_accuracy']*100:10.2f} {m['latency_ms']:12.2f}{star}")

def write_commit(config_path, results, seeds, winner, parent_hash):
    os.makedirs(ARTIFACT_DIR, exist_ok=True)
    ts = datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"
    def sha256_bytes(b: bytes) -> str:
        return "sha256:" + hashlib.sha256(b).hexdigest()
    with open(config_path,"rb") as f: inputs_hash = "sha256:" + hashlib.sha256(f.read()).hexdigest()
    with open(__file__,"rb") as f: code_hash = "sha256:" + hashlib.sha256(f.read()).hexdigest()
    leaves = [sha256_bytes(json.dumps({"name":k, "metrics":v}, sort_keys=True).encode()) for k,v in sorted(results.items())]
    # simple merkle
    def mroot(leaves):
        import binascii, hashlib
        if not leaves: return ""
        layer = [bytes.fromhex(h.split(":")[1]) for h in leaves]
        while len(layer) > 1:
            nxt = []
            for i in range(0, len(layer), 2):
                a = layer[i]; b = layer[i+1] if i+1 < len(layer) else a
                nxt.append(hashlib.sha256(a+b).digest())
            layer = nxt
        return "sha256:" + layer[0].hex()
    root = mroot(leaves)
    commit = {
        "id": f"commit_{int(time.time())}",
        "parent": parent_hash or "",
        "timestamp": ts,
        "dataset_id": DATASET_ID,
        "dataset_version": DATASET_VERSION,
        "seeds": seeds,
        "metrics": results,
        "winner": winner,
        "inputs_hash": inputs_hash,
        "code_hash": code_hash,
        "merkle_root": root,
        "signer": "local",
        "signature": ""
    }
    out_path = os.path.join(ARTIFACT_DIR, f"{commit['id']}.json")
    with open(out_path,"w",encoding="utf-8") as f:
        json.dump(commit, f, indent=2)
    with open(out_path,"rb") as f:
        art_hash = "sha256:" + hashlib.sha256(f.read()).hexdigest()
    return out_path, art_hash

def last_commit_hash():
    if not os.path.isdir(ARTIFACT_DIR): return ""
    files = [f for f in os.listdir(ARTIFACT_DIR) if f.endswith(".json")]
    if not files: return ""
    latest = max(files, key=lambda x: os.path.getmtime(os.path.join(ARTIFACT_DIR, x)))
    with open(os.path.join(ARTIFACT_DIR, latest),"rb") as f:
        return "sha256:" + hashlib.sha256(f.read()).hexdigest()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True, help="Path to config JSON")
    args = ap.parse_args()
    with open(args.config,"r",encoding="utf-8") as f:
        cfg = json.load(f)
    seeds = cfg.get("seeds",[101,202,303])
    suite = cfg.get("suite",{"n_samples":1000,"separation":2.0,"std":1.0,"test_ratio":0.3})
    variants = cfg.get("variants",[])
    for v in variants:
        if v["name"] not in {"baseline_lr","tuned_lr"}:
            raise SystemExit(f"Unknown variant '{v['name']}'. Available: baseline_lr, tuned_lr")
    results = {}
    for v in variants:
        name = v["name"]; params = v.get("params",{})
        results[name] = evaluate_variant_over_seeds(name, params, seeds, suite)
    winner = select_dominant(results)
    print_table(results, winner)
    parent = last_commit_hash()
    out_path, art_hash = write_commit(args.config, results, seeds, winner, parent)
    print(f"\nSaved proof artifact: {out_path}")
    print(f"Artifact hash: {art_hash}")

if __name__ == "__main__":
    main()
