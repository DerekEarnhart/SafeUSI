import argparse, sys, json, numpy as np
from voynich.decoder import VoynichDecoder
from voynich.signal import HarmonicSignalAnalyzer

def main():
    ap = argparse.ArgumentParser(description="Voynich CLI – decode & analyze text / sequences")
    ap.add_argument("--file", type=str, required=True, help="Path to a text file")
    ap.add_argument("--as-numbers", action="store_true", help="Treat file lines as numbers for harmonic analysis")
    ap.add_argument("--json", action="store_true", help="Emit JSON")
    args = ap.parse_args()

    with open(args.file, "r", encoding="utf-8", errors="ignore") as f:
        content = f.read()

    out = {}
    if args.as_numbers:
        try:
            x = np.array([float(s) for s in content.replace(",", " ").split() if s.strip()])
        except Exception as e:
            print(f"[error] could not parse numbers: {e}", file=sys.stderr)
            sys.exit(2)
        H = HarmonicSignalAnalyzer()
        score, parts = H.intelligence_score(x)
        out["harmonic"] = {"score": score, **parts}
    else:
        dec = VoynichDecoder()
        out["decode"] = dec.decode(content)

    if args.json:
        print(json.dumps(out, ensure_ascii=False, indent=2))
    else:
        if "decode" in out:
            d = out["decode"]
            print(f"[decoded] conf={d['confidence']}\n{d['decoded']}\n[mapping] {d['mapping']}")
        if "harmonic" in out:
            h = out["harmonic"]
            print(f"[harmonic] score={h['score']:.3f} (entropy={h['entropy']:.3f}, ac_peak={h['ac_peak']:.3f})")

if __name__ == "__main__":
    main()
