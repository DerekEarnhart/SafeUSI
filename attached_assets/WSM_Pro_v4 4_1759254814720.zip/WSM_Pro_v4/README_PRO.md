
# WSM Pro v4 — Proprietary-Ready Skeleton

## Quickstart
```bash
pip install torch transformers fastapi uvicorn pytest pyyaml
python scripts/train.py --out ./wsm_ckpt.pt
python scripts/serve.py --ckpt ./wsm_ckpt.pt --port 8080
```

In your app:
```python
from adapters.safeugoi_adapter import load_wsm_model
tok, model = load_wsm_model("./wsm_ckpt.pt", device="cuda")
out = model.generate(tok("Hello", return_tensors="pt")["input_ids"])
```

## Notes
- Symplectic updates via Cayley or matrix exponential keep stability.
- Replace vocab size and heads as you integrate.
- Distillation script is a placeholder—wire your local teacher for KL.
