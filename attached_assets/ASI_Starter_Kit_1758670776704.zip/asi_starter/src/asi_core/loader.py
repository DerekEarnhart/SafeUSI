from __future__ import annotations
from typing import List, Dict, Callable, Any
from pathlib import Path
import importlib.util
import inspect
import sys, types

CANDIDATE_NAMES = {"infer", "predict", "generate", "run", "process", "execute", "forward", "call"}

def _import_from_path(py_path: Path):
    mod_name = "plugin_" + py_path.stem
    spec = importlib.util.spec_from_file_location(mod_name, str(py_path))
    if spec and spec.loader:
        mod = importlib.util.module_from_spec(spec)
        sys.modules[mod_name] = mod
        spec.loader.exec_module(mod)
        return mod
    return None

def discover_functions(root_paths: List[Path]) -> List[Dict[str, Any]]:
    found = []
    for root in root_paths:
        if not root.exists():
            continue
        for p in root.rglob("*.py"):
            # skip our own package files
            if "asi_core" in str(p):
                continue
            try:
                mod = _import_from_path(p)
            except Exception:
                continue
            if not mod:
                continue
            for name, obj in inspect.getmembers(mod):
                if inspect.isfunction(obj) and name.lower() in CANDIDATE_NAMES:
                    found.append({
                        "type": "function",
                        "file": str(p),
                        "module": mod.__name__,
                        "callable_name": name,
                    })
                if inspect.isclass(obj):
                    methods = {m for m, f in inspect.getmembers(obj, inspect.isfunction) if m.lower() in CANDIDATE_NAMES}
                    if methods:
                        found.append({
                            "type": "class",
                            "file": str(p),
                            "module": mod.__name__,
                            "callable_name": obj.__name__,
                            "methods": sorted(list(methods))
                        })
    return found
