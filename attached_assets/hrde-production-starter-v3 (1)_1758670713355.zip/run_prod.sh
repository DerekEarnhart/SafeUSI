#!/usr/bin/env bash
set -euo pipefail
( cd docker && docker compose -p hrde up --build )
