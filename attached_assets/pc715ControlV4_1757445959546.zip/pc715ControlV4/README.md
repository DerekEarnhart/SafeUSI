# Sovereign HA‑AGI Scaffold

This is a **scaffold** (starter kit) for the Harmonic‑Algebra AGI you requested.  
It installs locally on Windows with a single `setup.bat` and launches with `run.bat`.

> **Note**: All heavy maths / AGI internals are stubbed (`TODO:` markers). Fill them in as you iterate.
