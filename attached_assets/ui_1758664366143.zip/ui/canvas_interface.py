class CanvasInterface:
    """
    Provides access to the canvas system.
    """
    def open(self):
        pass
