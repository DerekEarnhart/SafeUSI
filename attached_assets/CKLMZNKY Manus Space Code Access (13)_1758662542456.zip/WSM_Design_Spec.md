
# WSM Design Spec (Pro v4)

## Core math
- Weyl operator: \(W(\xi)=\exp\!\big(i(\xi_Q Q+\xi_P P)/\hbar\big)\)
- Shifts: \(e^A Q e^{-A}=Q+\xi_P\), \(e^A P e^{-A}=P-\xi_Q\)
- Composition: \(W(\xi)W(\zeta)=e^{-\tfrac{i}{2\hbar}\sigma(\xi,\zeta)}W(\xi+\zeta)\), \(\sigma(\xi,\zeta)=\xi_Q\zeta_P-\xi_P\zeta_Q\)

## Model
- State \(\mu_t\in\mathbb{R}^{2n}\). Update per token: \(\mu_{t+1}=S(u_t)\mu_t + r(\mu_t)\) with symplectic \(S\in Sp(2n)\) via Cayley or matrix exponential of \(\Omega H(u)\).

## Practical notes
- `cayley` avoids matrix_exp for embedded/CPU.
- `symplectic_regularizer` keeps \(S^T \Omega S\approx\Omega\).
- Small MLP residual adds non-Gaussian expressivity.
