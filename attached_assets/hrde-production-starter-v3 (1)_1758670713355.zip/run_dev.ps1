Param()
Start-Process -NoNewWindow powershell -ArgumentList 'cd python; . .\.venv\Scripts\Activate.ps1; uvicorn api_server:app --host 0.0.0.0 --port 8000 --reload'
Start-Process -NoNewWindow powershell -ArgumentList 'cd worker; npx wrangler dev --local --port 8787'
Start-Process -NoNewWindow powershell -ArgumentList 'cd python; . .\.venv\Scripts\Activate.ps1; $env:HRDE_WORKSPACE="..\hrde_workspace"; python -m hrde.h_cli'
