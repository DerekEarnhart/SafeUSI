from dataclasses import dataclass
from threading import Thread
import time, uuid
from .safe_eval import safe_eval
@dataclass
class Tool: name:str; schema:dict; handler:callable
TOOLS, JOBS = {}, {}
def register(t:Tool): TOOLS[t.name]=t
def list_tools(): return [{"name":t.name,"schema":t.schema} for t in TOOLS.values()]
def _run(jid,name,args):
    try:
        res = TOOLS[name].handler(**(args or {}))
        JOBS[jid].update({"status":"done","result":res})
    except Exception as e:
        JOBS[jid].update({"status":"error","error":str(e)})
def run_tool_job(name,args=None):
    jid=str(uuid.uuid4()); JOBS[jid]={"status":"running","name":name,"args":args or {}, "created_at":time.time()}
    Thread(target=_run, args=(jid,name,args), daemon=True).start(); return jid
def sandbox(code:str, vars:dict=None): return {"value": safe_eval(code, vars or {})}
def geometric_prover(): return {"theorem":"Eq(2*M, A + B)", "proof":"By midpoint definition: 2M=A+B."}
def image_gen(prompt:str): return {"url": f"/static/placeholder.png?prompt={prompt}"}
register(Tool("sandbox", {"type":"object","properties":{"code":{"type":"string"},"vars":{"type":"object"}}}, sandbox))
register(Tool("geometric_prover", {"type":"object","properties":{}}, geometric_prover))
register(Tool("image_gen", {"type":"object","properties":{"prompt":{"type":"string"}}}, image_gen))
