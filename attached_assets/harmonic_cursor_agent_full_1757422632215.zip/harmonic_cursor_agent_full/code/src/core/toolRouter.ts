import * as fsTool from '../tools/fs.js';
import * as shellTool from '../tools/shell.js';
import * as gitTool from '../tools/git.js';
import * as testTool from '../tools/testRunner.js';
import fg from 'fast-glob';

export class ToolRouter {
  cfg: any;
  constructor(cfg: any){ this.cfg = cfg; }
  async execute(step: string) {
    const s = step.toLowerCase();
    try {
      if (s.startsWith('run tests')) return { ok: true, data: await testTool.run() };
      if (s.includes('list files')) return { ok: true, data: await fg(['**/*', '!node_modules/**', '!dist/**']) };
      if (s.startsWith('read ')) return { ok: true, data: await fsTool.read(step.slice(5).trim()) };
      if (s.startsWith('write ')) {
        const [_, p, ...rest] = step.split(' ');
        await fsTool.write(p, rest.join(' '));
        return { ok: true, data: 'written' };
      }
      // Placeholder for smarter routing
      return { ok: true, data: 'noop' };
    } catch (e:any) {
      return { ok: false, error: e?.message || String(e) };
    }
  }
}
