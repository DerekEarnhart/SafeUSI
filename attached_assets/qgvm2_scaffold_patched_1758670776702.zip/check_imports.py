import sys, os, pathlib
root = pathlib.Path(__file__).resolve().parent
print("CWD:", os.getcwd())
print("Project root:", root)
sys.path.insert(0, str(root))
try:
    import qgvm2, qgvm2.vm_api
    print("Imported qgvm2 and qgvm2.vm_api successfully")
except Exception as e:
    print("qgvm2 import failed:", e)
try:
    import vm_api
    print("Imported vm_api from root successfully")
except Exception as e:
    print("vm_api import failed:", e)
