# Gemini‑style CLI powered by Sovereign HA‑AGI

A tiny, offline‑capable command‑line tool that wraps the same **Harmonic Algebra AGI** core used in the Sovereign suite.

**Why?**
* Use your AGI from any terminal session (good for quick scripts, SSH boxes, VS Code tasks).
* No API keys needed by default – runs on local Llama‑3 via `llama‑cpp‑python`.
* Drop‑in replacement for Google’s `gemini-cli` sample: same UX (`>>>` prompt, /system, /multi‑line).

---

## Quick Start (Windows)

```bat
setup_cli.bat
run_cli.bat           :: opens an interactive shell
```

## Quick Start (POSIX)

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python cli.py
```

Type `help` inside the shell for commands.

## Features

* `/file path.txt`     – inject a local file into context.
* `/loadkb`            – force‑reload vector DB from `../docs`.
* `/sys text`          – set system prompt.
* History arrow‑keys, Ctrl‑C to abort generation.

