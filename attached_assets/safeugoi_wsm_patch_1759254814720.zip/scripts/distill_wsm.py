\
import os, argparse, yaml, math
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from transformers import AutoModelForCausalLM, AutoTokenizer
from wsm.model import WSMForCausalLM
from wsm.tokenization import TokenizerWrapper

class TextFolderDataset(Dataset):
    def __init__(self, folder: str, tokenizer, max_len: int = 512):
        self.tok = tokenizer
        self.max_len = max_len
        self.samples = []
        # collect lines across files as separate samples to increase diversity
        for root, _, files in os.walk(folder):
            for f in files:
                if f.lower().endswith(".txt"):
                    path = os.path.join(root, f)
                    with open(path, "r", encoding="utf-8", errors="ignore") as fh:
                        for line in fh:
                            line = line.strip()
                            if line:
                                self.samples.append(line)
        if not self.samples:
            self.samples = ["Hello world."]

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        enc = self.tok([self.samples[idx]], return_tensors="pt", padding=True, truncation=True, max_length=self.max_len)
        input_ids = enc["input_ids"].squeeze(0)  # (T)
        return input_ids[:-1], input_ids[1:]

def distill(cfg_path: str, data_dir: str, out_path: str = None):
    with open(cfg_path, "r") as fh:
        cfg = yaml.safe_load(fh)
    model_cfg = cfg["model"]
    train_cfg = cfg["train"]
    dist_cfg = cfg["distill"]

    # Teacher
    teacher_name = dist_cfg["teacher"]
    teacher_tok = AutoTokenizer.from_pretrained(teacher_name)
    if teacher_tok.pad_token is None:
        teacher_tok.pad_token = teacher_tok.eos_token
    teacher = AutoModelForCausalLM.from_pretrained(teacher_name)
    teacher.eval()

    # Student tokenizer: we reuse teacher tokenizer for easy alignment
    tok_wrap = TokenizerWrapper(teacher_name)
    student = WSMForCausalLM(vocab_size=tok_wrap.vocab_size,
                             d_model=model_cfg["d_model"],
                             state_n=model_cfg["state_n"],
                             layers=model_cfg["layers"])

    device = "cuda" if torch.cuda.is_available() else "cpu"
    student.to(device); teacher.to(device)

    ds = TextFolderDataset(data_dir, teacher_tok, max_len=train_cfg["max_len"])
    dl = DataLoader(ds, batch_size=train_cfg["batch_size"], shuffle=True, drop_last=True)

    opt = torch.optim.AdamW(student.parameters(), lr=train_cfg["lr"], weight_decay=train_cfg["weight_decay"])
    kl = nn.KLDivLoss(reduction="batchmean")
    temp = float(dist_cfg["temperature"])
    kl_scale = float(dist_cfg["kl_scale"])

    steps = 0
    student.train()
    for epoch in range(train_cfg["epochs"]):
        for x, y in dl:
            x = x.to(device); y = y.to(device)
            with torch.no_grad():
                out = teacher(input_ids=x, labels=y)
                teacher_logits = out.logits  # (B,T,V)
            # Student forward
            logits, loss_ce = student(x, labels=y)
            # Align distributions with temperature
            t_logits = teacher_logits / temp
            s_logits = logits / temp
            t_log_probs = torch.log_softmax(t_logits, dim=-1)
            s_log_probs = torch.log_softmax(s_logits, dim=-1)
            distill_loss = kl(s_log_probs, t_log_probs) * (temp * temp)
            loss = loss_ce + kl_scale * distill_loss

            opt.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(student.parameters(), train_cfg["grad_clip"])
            opt.step()

            steps += 1
            if steps % 50 == 0:
                print(f"step {steps} | loss {loss.item():.4f} | ce {loss_ce.item():.4f} | kl {distill_loss.item():.4f}")

    out = out_path or cfg["train"]["save_path"]
    torch.save({"model": student.state_dict(), "tokenizer": tok_wrap.name_or_path, "config": model_cfg}, out)
    print(f"saved distilled WSM -> {out}")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/wsm_base.yaml")
    ap.add_argument("--data_dir", required=True)
    ap.add_argument("--out", default=None)
    args = ap.parse_args()
    distill(args.config, args.data_dir, args.out)
