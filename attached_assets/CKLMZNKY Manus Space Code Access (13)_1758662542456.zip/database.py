"""
Database integration module for ASI Mega Beast Complete Project.
Handles user information storage, retrieval, and management.
"""

import os
import uuid
from datetime import datetime, timedelta
from typing import Optional, Dict, List, Any
import json
import logging

from sqlalchemy import create_engine, Column, String, DateTime, Boolean, Integer, Float, Text, ARRAY
from sqlalchemy.orm import declarative_base, sessionmaker, Session, relationship
from sqlalchemy.dialects.postgresql import UUID, JSONB, INET
from sqlalchemy import Index, ForeignKey
import bcrypt

# Configure logging
logger = logging.getLogger(__name__)

# Database configuration
DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://asi_user:asi_password@localhost/asi_mega_beast")

# Create engine and session
engine = create_engine(DATABASE_URL, echo=False)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# Database Models

class User(Base):
    __tablename__ = "users"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    username = Column(String(50), unique=True, nullable=False, index=True)
    email = Column(String(255), unique=True, nullable=True, index=True)
    password_hash = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_login = Column(DateTime, nullable=True)
    is_active = Column(Boolean, default=True)
    preferences = Column(JSONB, default=dict)
    user_metadata = Column(JSONB, default=dict)  # Renamed from 'metadata' to avoid conflict
    
    # Relationships
    sessions = relationship("UserSession", back_populates="user", cascade="all, delete-orphan")
    interactions = relationship("UserInteraction", back_populates="user", cascade="all, delete-orphan")
    preferences_rel = relationship("UserPreference", back_populates="user", cascade="all, delete-orphan")
    learning_data = relationship("UserLearningData", back_populates="user", cascade="all, delete-orphan")
    projects = relationship("UserProject", back_populates="user", cascade="all, delete-orphan")
    feedback = relationship("UserFeedback", back_populates="user", cascade="all, delete-orphan")

class UserSession(Base):
    __tablename__ = "user_sessions"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    session_token = Column(String(255), unique=True, nullable=False, index=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime, nullable=False, index=True)
    ip_address = Column(INET, nullable=True)
    user_agent = Column(Text, nullable=True)
    is_active = Column(Boolean, default=True)
    
    # Relationships
    user = relationship("User", back_populates="sessions")
    interactions = relationship("UserInteraction", back_populates="session")

class UserInteraction(Base):
    __tablename__ = "user_interactions"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    interaction_type = Column(String(50), nullable=False, index=True)
    interaction_data = Column(JSONB, nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    session_id = Column(UUID(as_uuid=True), ForeignKey("user_sessions.id"), nullable=True, index=True)
    response_time_ms = Column(Integer, nullable=True)
    success = Column(Boolean, default=True)
    error_message = Column(Text, nullable=True)
    
    # Relationships
    user = relationship("User", back_populates="interactions")
    session = relationship("UserSession", back_populates="interactions")

class UserPreference(Base):
    __tablename__ = "user_preferences"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    category = Column(String(50), nullable=False, index=True)
    preference_key = Column(String(100), nullable=False)
    preference_value = Column(JSONB, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    user = relationship("User", back_populates="preferences_rel")
    
    # Unique constraint
    __table_args__ = (
        Index('idx_user_preferences_unique', 'user_id', 'category', 'preference_key', unique=True),
    )

class UserLearningData(Base):
    __tablename__ = "user_learning_data"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    learning_context = Column(String(100), nullable=False, index=True)
    learning_data = Column(JSONB, nullable=False)
    confidence_score = Column(Float, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, index=True)
    is_active = Column(Boolean, default=True)
    
    # Relationships
    user = relationship("User", back_populates="learning_data")

class UserProject(Base):
    __tablename__ = "user_projects"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    project_name = Column(String(255), nullable=False)
    project_type = Column(String(50), nullable=False, index=True)
    project_data = Column(JSONB, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    is_public = Column(Boolean, default=False)
    tags = Column(ARRAY(Text), nullable=True)
    
    # Relationships
    user = relationship("User", back_populates="projects")

class UserFeedback(Base):
    __tablename__ = "user_feedback"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    feedback_type = Column(String(50), nullable=False, index=True)
    feedback_data = Column(JSONB, nullable=False)
    related_interaction_id = Column(UUID(as_uuid=True), ForeignKey("user_interactions.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    processed = Column(Boolean, default=False)
    
    # Relationships
    user = relationship("User", back_populates="feedback")

# Database utility functions

def get_db() -> Session:
    """Get database session."""
    db = SessionLocal()
    try:
        return db
    finally:
        pass  # Session will be closed by the caller

def init_database():
    """Initialize database tables."""
    try:
        Base.metadata.create_all(bind=engine)
        logger.info("Database tables created successfully")
    except Exception as e:
        logger.error(f"Error creating database tables: {e}")
        raise

def hash_password(password: str) -> str:
    """Hash password using bcrypt."""
    salt = bcrypt.gensalt()
    hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed.decode('utf-8')

def verify_password(password: str, hashed: str) -> bool:
    """Verify password against hash."""
    return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))

def generate_session_token() -> str:
    """Generate secure session token."""
    return str(uuid.uuid4())

# User management functions

class UserManager:
    """User management class with CRUD operations."""
    
    def __init__(self, db: Session):
        self.db = db
    
    def create_user(self, username: str, password: str, email: Optional[str] = None) -> User:
        """Create a new user."""
        # Check if username already exists
        existing_user = self.db.query(User).filter(User.username == username).first()
        if existing_user:
            raise ValueError("Username already exists")
        
        # Check if email already exists (if provided)
        if email:
            existing_email = self.db.query(User).filter(User.email == email).first()
            if existing_email:
                raise ValueError("Email already exists")
        
        # Create new user
        user = User(
            username=username,
            email=email,
            password_hash=hash_password(password)
        )
        
        self.db.add(user)
        self.db.commit()
        self.db.refresh(user)
        
        logger.info(f"Created new user: {username}")
        return user
    
    def authenticate_user(self, username: str, password: str) -> Optional[User]:
        """Authenticate user with username and password."""
        user = self.db.query(User).filter(User.username == username, User.is_active == True).first()
        if user and verify_password(password, user.password_hash):
            # Update last login
            user.last_login = datetime.utcnow()
            self.db.commit()
            return user
        return None
    
    def create_session(self, user: User, ip_address: Optional[str] = None, user_agent: Optional[str] = None) -> UserSession:
        """Create a new user session."""
        session = UserSession(
            user_id=user.id,
            session_token=generate_session_token(),
            expires_at=datetime.utcnow() + timedelta(days=30),  # 30 days expiry
            ip_address=ip_address,
            user_agent=user_agent
        )
        
        self.db.add(session)
        self.db.commit()
        self.db.refresh(session)
        
        return session
    
    def get_user_by_session_token(self, session_token: str) -> Optional[User]:
        """Get user by session token."""
        session = self.db.query(UserSession).filter(
            UserSession.session_token == session_token,
            UserSession.is_active == True,
            UserSession.expires_at > datetime.utcnow()
        ).first()
        
        if session:
            return session.user
        return None
    
    def log_interaction(self, user: User, interaction_type: str, interaction_data: Dict[str, Any], 
                       session_id: Optional[uuid.UUID] = None, response_time_ms: Optional[int] = None,
                       success: bool = True, error_message: Optional[str] = None) -> UserInteraction:
        """Log user interaction."""
        interaction = UserInteraction(
            user_id=user.id,
            interaction_type=interaction_type,
            interaction_data=interaction_data,
            session_id=session_id,
            response_time_ms=response_time_ms,
            success=success,
            error_message=error_message
        )
        
        self.db.add(interaction)
        self.db.commit()
        self.db.refresh(interaction)
        
        return interaction
    
    def set_user_preference(self, user: User, category: str, preference_key: str, preference_value: Any):
        """Set user preference."""
        # Check if preference already exists
        existing_pref = self.db.query(UserPreference).filter(
            UserPreference.user_id == user.id,
            UserPreference.category == category,
            UserPreference.preference_key == preference_key
        ).first()
        
        if existing_pref:
            existing_pref.preference_value = preference_value
            existing_pref.updated_at = datetime.utcnow()
        else:
            pref = UserPreference(
                user_id=user.id,
                category=category,
                preference_key=preference_key,
                preference_value=preference_value
            )
            self.db.add(pref)
        
        self.db.commit()
    
    def get_user_preferences(self, user: User, category: Optional[str] = None) -> Dict[str, Any]:
        """Get user preferences."""
        query = self.db.query(UserPreference).filter(UserPreference.user_id == user.id)
        
        if category:
            query = query.filter(UserPreference.category == category)
        
        preferences = query.all()
        
        result = {}
        for pref in preferences:
            if pref.category not in result:
                result[pref.category] = {}
            result[pref.category][pref.preference_key] = pref.preference_value
        
        return result
    
    def save_user_project(self, user: User, project_name: str, project_type: str, 
                         project_data: Dict[str, Any], tags: Optional[List[str]] = None,
                         is_public: bool = False) -> UserProject:
        """Save user project."""
        project = UserProject(
            user_id=user.id,
            project_name=project_name,
            project_type=project_type,
            project_data=project_data,
            tags=tags,
            is_public=is_public
        )
        
        self.db.add(project)
        self.db.commit()
        self.db.refresh(project)
        
        return project
    
    def get_user_projects(self, user: User, project_type: Optional[str] = None) -> List[UserProject]:
        """Get user projects."""
        query = self.db.query(UserProject).filter(UserProject.user_id == user.id)
        
        if project_type:
            query = query.filter(UserProject.project_type == project_type)
        
        return query.order_by(UserProject.created_at.desc()).all()

# Initialize database on module import
if __name__ == "__main__":
    init_database()
    print("Database initialized successfully!")

