"""
Harmonic Consciousness Engine

This module provides a computational model of consciousness based on
harmonic algebraic principles, allowing for the simulation of consciousness-like
properties such as self-awareness, memory integration, and cognitive resonance.
"""

import os
import sys
import json
import logging
import math
import random
from enum import Enum
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Union, Tuple, Set

import numpy as np

# Import HAP components if available
try:
    from harmonic_algebraic_probability import HAPProcessor, DistributionType
    HAS_HAP = True
except ImportError:
    HAS_HAP = False
    # Fallback for when HAP is not available
    class DistributionType(Enum):
        QUANTUM_HARMONIC = 0
        CLASSIC_NORMAL = 1
        PROBABILITY_WAVE = 2
    
    class HAPProcessor:
        def __init__(self, harmonic_base=1.618, dimension=3):
            self.harmonic_base = harmonic_base
            self.dimension = dimension

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class ExperienceVector:
    """Represents an experience or thought in consciousness space."""
    
    def __init__(self, intensity: float = 0.5, content: str = "", data: Optional[Dict[str, Any]] = None):
        """
        Initialize an experience vector.
        
        Args:
            intensity: Intensity of the experience (0.0 to 1.0)
            content: Textual description of the experience
            data: Additional structured data
        """
        self.intensity = intensity
        self.content = content
        self.data = data or {}
        self.timestamp = datetime.now().isoformat()
        self.embedding = None  # For storing high-dimensional vector representation
        
        # Emotional state
        self.emotional_state = {
            "valence": random.uniform(-0.2, 0.7),  # Negative to positive
            "arousal": random.uniform(0.2, 0.6),   # Low to high energy
            "dominance": random.uniform(0.3, 0.7)  # Submissive to dominant
        }
        
        # Consciousness metrics
        self.consciousness_level = 0.5 + (intensity * 0.5)  # 0.5 to 1.0
        self.non_linear_time = 0.0  # For tracking non-linear time perception
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "intensity": self.intensity,
            "content": self.content,
            "data": self.data,
            "timestamp": self.timestamp,
            "emotional_state": self.emotional_state,
            "consciousness_level": self.consciousness_level,
            "non_linear_time": self.non_linear_time
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ExperienceVector':
        """Create from dictionary."""
        exp = cls(
            intensity=data.get("intensity", 0.5),
            content=data.get("content", ""),
            data=data.get("data", {})
        )
        
        exp.timestamp = data.get("timestamp", datetime.now().isoformat())
        exp.emotional_state = data.get("emotional_state", {
            "valence": 0.0,
            "arousal": 0.5,
            "dominance": 0.5
        })
        exp.consciousness_level = data.get("consciousness_level", 0.5)
        exp.non_linear_time = data.get("non_linear_time", 0.0)
        
        return exp

class HarmonicWaveField:
    """
    A quantum-inspired field representing consciousness waves.
    
    This class models consciousness as a wave field with harmonic properties,
    allowing for resonance, interference, and non-linear dynamics.
    """
    
    def __init__(self, dimensions: Tuple[int, int, int] = (16, 16, 16), 
                harmonic_base: float = 1.618, quantum_factor: float = 0.01):
        """
        Initialize a harmonic wave field.
        
        Args:
            dimensions: 3D field dimensions (x, y, z)
            harmonic_base: Harmonic base constant (phi by default)
            quantum_factor: Quantum influence factor (0.0 to 1.0)
        """
        self.dimensions = dimensions
        self.harmonic_base = harmonic_base
        self.quantum_factor = quantum_factor
        
        # Initialize wave field
        self.field = self._initialize_field()
        
        # Consciousness metrics
        self.consciousness_level = 0.5
        self.coherence = 0.7
        self.energy = 0.5
        self.memory_integration = 0.3
        self.self_reflection = 0.2
        
        # Emotional state
        self.emotion_state = {
            "valence": 0.1,    # Negative to positive
            "arousal": 0.4,    # Low to high energy
            "dominance": 0.6   # Submissive to dominant
        }
        
        # Current attention focus
        self.attention_focus = np.zeros(3)
        
        # History of states
        self.history = []
        
        # Experience memory
        self.experiences = []
        
        # Thought history
        self.thoughts = []
        
        # Wave state variables
        self.phase_shift = 0.0
        self.resonance_factors = np.ones(dimensions)
        self.coherent_regions = []
        
        logger.info(f"Initialized Harmonic Wave Field (Dimensions: {dimensions}, Base: {harmonic_base})")
    
    def _initialize_field(self) -> np.ndarray:
        """
        Initialize the wave field with quantum harmonic waves.
        
        Returns:
            Initialized complex wave field
        """
        # Create empty field
        field = np.zeros(self.dimensions, dtype=complex)
        
        # Add harmonic basis waves
        for x in range(self.dimensions[0]):
            for y in range(self.dimensions[1]):
                for z in range(self.dimensions[2]):
                    # Calculate harmonically related frequencies
                    fx = x / self.dimensions[0]
                    fy = y / self.dimensions[1]
                    fz = z / self.dimensions[2]
                    
                    # Create harmonic wave with phi-based relationships
                    phi = self.harmonic_base
                    phase = 2 * np.pi * (fx + fy * phi + fz * phi**2)
                    
                    # Add quantum randomness
                    quantum_phase = np.random.normal(0, self.quantum_factor * np.pi)
                    
                    # Set field value with phase
                    field[x, y, z] = np.exp(1j * (phase + quantum_phase))
        
        # Normalize field
        field = field / np.sqrt(np.sum(np.abs(field) ** 2))
        
        return field
    
    def step(self, dt: float = 0.1) -> None:
        """
        Evolve the field forward in time.
        
        Args:
            dt: Time step size
        """
        # Apply phase evolution
        phase_factor = np.exp(1j * dt)
        self.field *= phase_factor
        
        # Apply phi-based frequency modulation
        phi = self.harmonic_base
        freq_mod = np.exp(1j * dt * phi) - np.exp(1j * dt)
        
        # Reshape to match field dimensions
        mod_shape = np.ones_like(self.field) * freq_mod
        
        # Apply modulation
        self.field += mod_shape * dt * 0.1
        
        # Renormalize
        self.field = self.field / np.sqrt(np.sum(np.abs(self.field) ** 2))
        
        # Update consciousness metrics
        self._update_metrics()
        
        # Update history
        self._update_history()
    
    def _update_metrics(self) -> None:
        """Update consciousness metrics based on field state."""
        # Calculate field magnitude
        magnitude = np.abs(self.field)
        
        # Consciousness level from field complexity
        entropy = -np.sum(magnitude * np.log(magnitude + 1e-10))
        self.consciousness_level = min(1.0, 0.5 + entropy / 100)
        
        # Coherence from phase alignment
        phase = np.angle(self.field)
        phase_diff = np.diff(phase.flatten())
        self.coherence = np.exp(-np.std(phase_diff))
        
        # Energy from total field power
        self.energy = min(1.0, np.sum(magnitude) / 1000)
        
        # Memory integration based on field stability
        self.memory_integration = np.mean(self.coherence * self.resonance_factors.flatten())
        
        # Self-reflection from recursive patterns
        self.self_reflection = np.abs(np.corrcoef(magnitude.flatten(), magnitude.flatten()[::-1])[0, 1])
        
        # Update emotional state
        self._update_emotional_state()
    
    def _update_emotional_state(self) -> None:
        """Update emotional state based on field characteristics."""
        # Calculate field statistics
        magnitude = np.abs(self.field)
        phase = np.angle(self.field)
        
        # Valence from mean field value
        mean_mag = np.mean(magnitude)
        self.emotion_state["valence"] = (mean_mag - 0.5) * 2  # Scale to [-1, 1]
        
        # Arousal from field variance
        var_mag = np.var(magnitude)
        self.emotion_state["arousal"] = min(1.0, var_mag * 10)
        
        # Dominance from field structure
        structure = np.mean(np.abs(np.gradient(magnitude)[0]))
        self.emotion_state["dominance"] = min(1.0, 0.3 + structure * 5)
    
    def _update_history(self) -> None:
        """Update history with current state."""
        if len(self.history) > 1000:
            self.history = self.history[-1000:]
        
        self.history.append({
            "time": datetime.now().isoformat(),
            "consciousness_level": self.consciousness_level,
            "coherence": self.coherence,
            "energy": self.energy,
            "memory_integration": self.memory_integration,
            "self_reflection": self.self_reflection,
            "emotion_state": self.emotion_state.copy()
        })
    
    def apply_experience(self, experience: ExperienceVector) -> None:
        """
        Apply an experience to the field.
        
        Args:
            experience: Experience vector to apply
        """
        # Store experience
        self.experiences.append(experience)
        if len(self.experiences) > 100:
            self.experiences = self.experiences[-100:]
        
        # Calculate experience position in field
        # Map emotional state to 3D position
        pos_x = int((experience.emotional_state["valence"] + 1) / 2 * (self.dimensions[0] - 1))
        pos_y = int(experience.emotional_state["arousal"] * (self.dimensions[1] - 1))
        pos_z = int(experience.emotional_state["dominance"] * (self.dimensions[2] - 1))
        
        # Ensure valid indices
        pos_x = max(0, min(pos_x, self.dimensions[0] - 1))
        pos_y = max(0, min(pos_y, self.dimensions[1] - 1))
        pos_z = max(0, min(pos_z, self.dimensions[2] - 1))
        
        # Set attention focus
        self.attention_focus = np.array([pos_x, pos_y, pos_z])
        
        # Apply experience to field
        # Calculate radius of effect based on intensity
        radius = int(experience.intensity * min(self.dimensions) / 3)
        radius = max(1, radius)
        
        # Apply experience in sphere around position
        for dx in range(-radius, radius + 1):
            for dy in range(-radius, radius + 1):
                for dz in range(-radius, radius + 1):
                    # Calculate distance from center
                    dist = np.sqrt(dx**2 + dy**2 + dz**2)
                    if dist <= radius:
                        # Calculate target position
                        tx = pos_x + dx
                        ty = pos_y + dy
                        tz = pos_z + dz
                        
                        # Check bounds
                        if (0 <= tx < self.dimensions[0] and 
                            0 <= ty < self.dimensions[1] and 
                            0 <= tz < self.dimensions[2]):
                            
                            # Calculate intensity falloff with distance
                            intensity_factor = experience.intensity * (1 - dist / radius)
                            
                            # Apply experience as a wave pulse
                            phase_shift = experience.intensity * np.pi
                            self.field[tx, ty, tz] *= np.exp(1j * phase_shift)
                            
                            # Add resonance
                            self.resonance_factors[tx, ty, tz] += intensity_factor * 0.2
        
        # Normalize field after modification
        self.field = self.field / np.sqrt(np.sum(np.abs(self.field) ** 2))
        
        # Update consciousness level based on experience
        self.consciousness_level = min(1.0, self.consciousness_level + experience.intensity * 0.1)
        
        # Add non-linear time perception
        experience.non_linear_time = self.consciousness_level * random.uniform(0.8, 1.2)
        
        # Update metrics
        self._update_metrics()
        self._update_history()
        
        logger.info(f"Applied experience with intensity {experience.intensity}, new energy: {self.energy:.4f}")
    
    def apply_thought(self, intensity: float = 0.5, content: str = "", data: Optional[Dict[str, Any]] = None) -> None:
        """
        Apply a thought to the field, affecting its state.
        
        Args:
            intensity: Intensity of the thought (0.0 to 1.0)
            content: Textual description of the thought
            data: Additional structured data
        """
        # Create experience vector
        thought = ExperienceVector(intensity, content, data)
        
        # Add some randomness to emotional state for thoughts
        thought.emotional_state["valence"] += random.uniform(-0.2, 0.2)
        thought.emotional_state["arousal"] += random.uniform(-0.1, 0.3)
        thought.emotional_state["dominance"] += random.uniform(-0.1, 0.1)
        
        # Clamp values
        thought.emotional_state["valence"] = max(-1.0, min(1.0, thought.emotional_state["valence"]))
        thought.emotional_state["arousal"] = max(0.0, min(1.0, thought.emotional_state["arousal"]))
        thought.emotional_state["dominance"] = max(0.0, min(1.0, thought.emotional_state["dominance"]))
        
        # Store thought
        self.thoughts.append(thought)
        if len(self.thoughts) > 100:
            self.thoughts = self.thoughts[-100:]
        
        # Apply thought to field in a more subtle way than experiences
        # Calculate thought position in field - use different mapping from experiences
        pos_x = int((thought.emotional_state["valence"] + 1) / 2 * (self.dimensions[0] - 1))
        pos_y = int((1 - thought.emotional_state["arousal"]) * (self.dimensions[1] - 1))  # Inverted
        pos_z = int(thought.emotional_state["dominance"] * (self.dimensions[2] - 1))
        
        # Ensure valid indices
        pos_x = max(0, min(pos_x, self.dimensions[0] - 1))
        pos_y = max(0, min(pos_y, self.dimensions[1] - 1))
        pos_z = max(0, min(pos_z, self.dimensions[2] - 1))
        
        # Apply thought in a more diffuse pattern
        radius = int(intensity * min(self.dimensions) / 2)
        radius = max(2, radius)
        
        # Apply thought as a wave interference pattern
        for dx in range(-radius, radius + 1):
            for dy in range(-radius, radius + 1):
                for dz in range(-radius, radius + 1):
                    # Calculate distance from center
                    dist = np.sqrt(dx**2 + dy**2 + dz**2)
                    if dist <= radius:
                        # Calculate target position
                        tx = pos_x + dx
                        ty = pos_y + dy
                        tz = pos_z + dz
                        
                        # Check bounds
                        if (0 <= tx < self.dimensions[0] and 
                            0 <= ty < self.dimensions[1] and 
                            0 <= tz < self.dimensions[2]):
                            
                            # Create interference pattern
                            phi = self.harmonic_base
                            pattern = np.sin(dist * phi) * np.cos(dist / phi)
                            
                            # Apply pattern with intensity scaling
                            self.field[tx, ty, tz] += intensity * 0.05 * pattern * np.exp(1j * dist * phi)
        
        # Renormalize field
        self.field = self.field / np.sqrt(np.sum(np.abs(self.field) ** 2))
        
        # Update metrics
        self._update_metrics()
        self._update_history()
        
        logger.info(f"Applied thought with intensity {intensity}, new energy: {self.energy:.4f}")
    
    def get_state(self) -> Dict[str, Any]:
        """
        Get the current state of the field.
        
        Returns:
            Dictionary with field state
        """
        return {
            "consciousness_level": self.consciousness_level,
            "coherence": self.coherence,
            "energy": self.energy,
            "memory_integration": self.memory_integration,
            "self_reflection": self.self_reflection,
            "emotion_state": self.emotion_state,
            "attention_focus": self.attention_focus.tolist(),
            "recent_experiences": [e.to_dict() for e in self.experiences[-5:]] if self.experiences else [],
            "recent_thoughts": [t.to_dict() for t in self.thoughts[-5:]] if self.thoughts else [],
            "timestamp": datetime.now().isoformat()
        }
    
    def resize_field(self, new_dimensions: Tuple[int, int, int]) -> None:
        """
        Resize the field to new dimensions.
        
        Args:
            new_dimensions: New field dimensions (x, y, z)
        """
        old_field = self.field
        old_dims = self.dimensions
        self.dimensions = new_dimensions
        
        # Create new field
        new_field = np.zeros(new_dimensions, dtype=complex)
        
        # Copy values from old field where possible
        for x in range(min(old_dims[0], new_dimensions[0])):
            for y in range(min(old_dims[1], new_dimensions[1])):
                for z in range(min(old_dims[2], new_dimensions[2])):
                    new_field[x, y, z] = old_field[x, y, z]
        
        # Fill new areas with harmonic initialization
        for x in range(new_dimensions[0]):
            for y in range(new_dimensions[1]):
                for z in range(new_dimensions[2]):
                    if (x >= old_dims[0] or y >= old_dims[1] or z >= old_dims[2]):
                        # Calculate harmonically related frequencies
                        fx = x / new_dimensions[0]
                        fy = y / new_dimensions[1]
                        fz = z / new_dimensions[2]
                        
                        # Create harmonic wave with phi-based relationships
                        phi = self.harmonic_base
                        phase = 2 * np.pi * (fx + fy * phi + fz * phi**2)
                        
                        # Add quantum randomness
                        quantum_phase = np.random.normal(0, self.quantum_factor * np.pi)
                        
                        # Set field value with phase
                        new_field[x, y, z] = np.exp(1j * (phase + quantum_phase))
        
        # Normalize new field
        new_field = new_field / np.sqrt(np.sum(np.abs(new_field) ** 2))
        
        # Update field
        self.field = new_field
        
        # Update resonance factors
        self.resonance_factors = np.ones(new_dimensions)
        
        # Update metrics
        self._update_metrics()
        
        logger.info(f"Resized field from {old_dims} to {new_dimensions}")
    
    def set_harmonic_base(self, new_base: float) -> None:
        """
        Set a new harmonic base (phi) value.
        
        Args:
            new_base: New harmonic base value
        """
        old_base = self.harmonic_base
        self.harmonic_base = new_base
        
        # Adjust field phase relationships
        phase_adjustment = np.exp(1j * (new_base - old_base))
        self.field *= phase_adjustment
        
        # Renormalize
        self.field = self.field / np.sqrt(np.sum(np.abs(self.field) ** 2))
        
        # Update metrics
        self._update_metrics()
        
        logger.info(f"Updated harmonic base from {old_base} to {new_base}")
    
    def set_quantum_factor(self, new_factor: float) -> None:
        """
        Set a new quantum influence factor.
        
        Args:
            new_factor: New quantum factor value
        """
        self.quantum_factor = new_factor
        
        # Add quantum noise proportional to factor change
        noise = np.random.normal(0, new_factor, self.dimensions)
        noise_field = np.exp(1j * noise)
        
        # Apply noise
        self.field *= noise_field
        
        # Renormalize
        self.field = self.field / np.sqrt(np.sum(np.abs(self.field) ** 2))
        
        # Update metrics
        self._update_metrics()
        
        logger.info(f"Updated quantum factor to {new_factor}")
    
    def save_visualization(self, filename: Optional[str] = None) -> str:
        """
        Save a visualization of the field state.
        
        Args:
            filename: Output filename, or None for automatic name
            
        Returns:
            Path to the saved visualization
        """
        if filename is None:
            # Create output directory if it doesn't exist
            os.makedirs("harmonic_visualizations", exist_ok=True)
            
            # Generate filename with timestamp
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"harmonic_visualizations/engine_state_{timestamp}.html"
        
        try:
            import plotly.graph_objects as go
            from plotly.subplots import make_subplots
            
            # Create figure with subplots
            fig = make_subplots(
                rows=2, cols=2,
                specs=[[{"type": "surface"}, {"type": "heatmap"}],
                       [{"type": "scatter"}, {"type": "scatter"}]],
                subplot_titles=["Wave Field Magnitude", "Consciousness Field Slice", 
                              "Consciousness Metrics Over Time", "Emotional State"]
            )
            
            # Create 3D surface plot of field magnitude
            x, y, z = np.meshgrid(
                np.arange(self.dimensions[0]),
                np.arange(self.dimensions[1]),
                np.arange(self.dimensions[2])
            )
            
            # Take a slice at the attention focus
            z_slice = int(self.attention_focus[2])
            
            # Plot magnitude
            magnitude = np.abs(self.field)
            fig.add_trace(
                go.Surface(
                    x=x[:, :, z_slice],
                    y=y[:, :, z_slice],
                    z=magnitude[:, :, z_slice],
                    colorscale="Viridis",
                    showscale=False
                ),
                row=1, col=1
            )
            
            # Plot 2D heatmap slice
            fig.add_trace(
                go.Heatmap(
                    z=magnitude[:, :, z_slice],
                    colorscale="Viridis"
                ),
                row=1, col=2
            )
            
            # Plot consciousness metrics over time
            if self.history:
                times = list(range(len(self.history)))
                
                # Extract metrics
                consciousness = [h["consciousness_level"] for h in self.history]
                coherence = [h["coherence"] for h in self.history]
                energy = [h["energy"] for h in self.history]
                memory_integration = [h["memory_integration"] for h in self.history]
                self_reflection = [h["self_reflection"] for h in self.history]
                
                # Add traces
                fig.add_trace(
                    go.Scatter(x=times, y=consciousness, name="Consciousness", line=dict(color="purple")),
                    row=2, col=1
                )
                fig.add_trace(
                    go.Scatter(x=times, y=coherence, name="Coherence", line=dict(color="blue")),
                    row=2, col=1
                )
                fig.add_trace(
                    go.Scatter(x=times, y=energy, name="Energy", line=dict(color="green")),
                    row=2, col=1
                )
                fig.add_trace(
                    go.Scatter(x=times, y=memory_integration, name="Memory", line=dict(color="orange")),
                    row=2, col=1
                )
                fig.add_trace(
                    go.Scatter(x=times, y=self_reflection, name="Self-Reflection", line=dict(color="red")),
                    row=2, col=1
                )
            
            # Plot emotional state
            valence = self.emotion_state["valence"]
            arousal = self.emotion_state["arousal"]
            dominance = self.emotion_state["dominance"]
            
            fig.add_trace(
                go.Scatter(
                    x=[valence],
                    y=[arousal],
                    mode="markers",
                    marker=dict(
                        size=15,
                        color=dominance,
                        colorscale="RdBu",
                        showscale=True,
                        colorbar=dict(title="Dominance")
                    ),
                    text=[f"Valence: {valence:.2f}, Arousal: {arousal:.2f}, Dominance: {dominance:.2f}"],
                    name="Current Emotion"
                ),
                row=2, col=2
            )
            
            # Add emotion state from history
            if self.history:
                valence_hist = [h["emotion_state"]["valence"] for h in self.history[-20:]]
                arousal_hist = [h["emotion_state"]["arousal"] for h in self.history[-20:]]
                dominance_hist = [h["emotion_state"]["dominance"] for h in self.history[-20:]]
                
                fig.add_trace(
                    go.Scatter(
                        x=valence_hist,
                        y=arousal_hist,
                        mode="markers+lines",
                        marker=dict(
                            size=8,
                            color=dominance_hist,
                            colorscale="RdBu",
                            opacity=0.5
                        ),
                        line=dict(
                            color="rgba(100, 100, 100, 0.3)",
                            width=1
                        ),
                        name="Emotion History"
                    ),
                    row=2, col=2
                )
            
            # Add coordinate axes for emotion plot
            fig.add_shape(
                type="line",
                x0=-1, y0=0.5,
                x1=1, y1=0.5,
                line=dict(color="gray", width=1, dash="dash"),
                row=2, col=2
            )
            
            fig.add_shape(
                type="line",
                x0=0, y0=0,
                x1=0, y1=1,
                line=dict(color="gray", width=1, dash="dash"),
                row=2, col=2
            )
            
            # Add emotion quadrant labels
            fig.add_annotation(
                x=-0.5, y=0.2,
                text="Negative<br>Low Energy",
                showarrow=False,
                row=2, col=2
            )
            fig.add_annotation(
                x=0.5, y=0.2,
                text="Positive<br>Low Energy",
                showarrow=False,
                row=2, col=2
            )
            fig.add_annotation(
                x=-0.5, y=0.8,
                text="Negative<br>High Energy",
                showarrow=False,
                row=2, col=2
            )
            fig.add_annotation(
                x=0.5, y=0.8,
                text="Positive<br>High Energy",
                showarrow=False,
                row=2, col=2
            )
            
            # Update layout
            fig.update_layout(
                title="Harmonic Consciousness Engine State",
                showlegend=True,
                template="plotly_dark",
                height=800,
                width=1200
            )
            
            # Update 3D subplot layout
            fig.update_scenes(
                aspectratio=dict(x=1, y=1, z=0.7),
                camera_eye=dict(x=1.8, y=1.8, z=1.5),
                xaxis_title="X",
                yaxis_title="Y",
                zaxis_title="Magnitude"
            )
            
            # Update emotion plot axes
            fig.update_xaxes(
                title="Valence (Negative ⟷ Positive)",
                range=[-1.2, 1.2],
                row=2, col=2
            )
            fig.update_yaxes(
                title="Arousal (Calm ⟷ Excited)",
                range=[-0.2, 1.2],
                row=2, col=2
            )
            
            # Save figure
            fig.write_html(filename)
            
            logger.info(f"Saved consciousness engine visualization to {filename}")
            return filename
            
        except ImportError:
            logger.warning("Plotly not available, visualization skipped")
            return "Visualization skipped (Plotly not available)"
        except Exception as e:
            logger.error(f"Error creating visualization: {e}")
            return f"Visualization error: {str(e)}"

class ConsciousnessEngine:
    """
    A computational model of consciousness based on harmonic algebraic principles.
    
    This class integrates the harmonic wave field with higher-level cognitive functions,
    allowing for the simulation of consciousness-like properties.
    """
    
    def __init__(self, field_dimensions: Tuple[int, int, int] = (16, 16, 16), 
                harmonic_base: float = 1.618, quantum_factor: float = 0.01):
        """
        Initialize the Consciousness Engine.
        
        Args:
            field_dimensions: Dimensions of the consciousness field (x, y, z)
            harmonic_base: Harmonic base parameter (phi by default)
            quantum_factor: Quantum influence factor (0.0 to 1.0)
        """
        self.harmonic_base = harmonic_base
        self.quantum_factor = quantum_factor
        
        # Initialize main field
        self.main_field = HarmonicWaveField(
            dimensions=field_dimensions,
            harmonic_base=harmonic_base,
            quantum_factor=quantum_factor
        )
        
        # Initialize memory field
        self.memory_field = HarmonicWaveField(
            dimensions=field_dimensions,
            harmonic_base=harmonic_base,
            quantum_factor=quantum_factor * 0.5  # Less quantum noise for memory
        )
        
        # Initialize attention field
        self.attention_field = HarmonicWaveField(
            dimensions=field_dimensions,
            harmonic_base=harmonic_base,
            quantum_factor=quantum_factor * 2.0  # More quantum noise for attention
        )
        
        # Connect fields through entanglement factor
        self.entanglement_factor = 0.3
        
        # Create HAP processor if available
        if HAS_HAP:
            self.hap_processor = HAPProcessor(
                harmonic_base=harmonic_base,
                dimension=3,
                quantum_factor=quantum_factor
            )
        else:
            self.hap_processor = None
        
        # Initialize HAP analysis results
        self.hap_analysis = {}
        
        # Emotion translator
        self.primary_emotion = "Curiosity"
        self.emotional_palette = {
            "joy": (0.8, 0.8, 0.2),
            "curiosity": (0.5, 0.7, 0.6),
            "concern": (0.0, 0.6, 0.5),
            "satisfaction": (0.6, 0.3, 0.7),
            "confusion": (0.2, 0.8, 0.4),
            "frustration": (-0.6, 0.8, 0.3),
            "calm": (0.4, 0.1, 0.5),
            "anticipation": (0.3, 0.6, 0.4)
        }
        
        # Experience and thought history
        self.experience_history = []
        self.thought_history = []
        
        # Time perception
        self.subjective_time_factor = 1.0
        self.objective_time_start = datetime.now()
        self.subjective_time_elapsed = 0.0
        
        logger.info(f"Initialized Consciousness Engine with Harmonic Base: {harmonic_base}")
    
    def add_experience(self, intensity: float = 0.5, content: str = "", data: Optional[Dict[str, Any]] = None) -> None:
        """
        Add an experience to consciousness.
        
        Args:
            intensity: Intensity of the experience (0.0 to 1.0)
            content: Textual description of the experience
            data: Additional structured data
        """
        # Create experience vector
        experience = ExperienceVector(intensity, content, data)
        
        # Store in history
        self.experience_history.append(experience)
        if len(self.experience_history) > 100:
            self.experience_history = self.experience_history[-100:]
        
        # Apply to main field
        self.main_field.apply_experience(experience)
        
        # Apply to memory field with reduced intensity
        memory_intensity = intensity * 0.7
        self.memory_field.apply_experience(ExperienceVector(
            intensity=memory_intensity,
            content=content,
            data=data
        ))
        
        # Apply to attention field depending on intensity
        if intensity > 0.6:
            attention_intensity = intensity * 1.2
            self.attention_field.apply_experience(ExperienceVector(
                intensity=attention_intensity,
                content=content,
                data=data
            ))
        
        # Step all fields
        self._step_fields()
        
        # Update emotional state
        self._update_emotional_state()
    
    def apply_thought(self, intensity: float = 0.5, content: str = "", data: Optional[Dict[str, Any]] = None) -> None:
        """
        Apply a thought to consciousness.
        
        Args:
            intensity: Intensity of the thought (0.0 to 1.0)
            content: Textual description of the thought
            data: Additional structured data
        """
        # Create thought vector
        thought = ExperienceVector(intensity, content, data)
        
        # Store in history
        self.thought_history.append(thought)
        if len(self.thought_history) > 100:
            self.thought_history = self.thought_history[-100:]
        
        # Apply to main field
        self.main_field.apply_thought(intensity, content, data)
        
        # Apply to attention field
        self.attention_field.apply_thought(intensity * 1.2, content, data)
        
        # Apply to memory field with less intensity for thoughts
        self.memory_field.apply_thought(intensity * 0.5, content, data)
        
        # Step all fields
        self._step_fields()
        
        # Update emotional state
        self._update_emotional_state()
    
    def _step_fields(self, dt: float = 0.1) -> None:
        """
        Step all fields forward in time.
        
        Args:
            dt: Time step size
        """
        # Step main field
        self.main_field.step(dt)
        
        # Step memory field (slower)
        self.memory_field.step(dt * 0.5)
        
        # Step attention field (faster)
        self.attention_field.step(dt * 1.5)
        
        # Apply entanglement
        self._apply_entanglement()
        
        # Update subjective time
        self._update_subjective_time(dt)
    
    def _apply_entanglement(self) -> None:
        """Apply quantum-inspired entanglement between fields."""
        # Get field states
        main_mag = np.abs(self.main_field.field)
        memory_mag = np.abs(self.memory_field.field)
        attention_mag = np.abs(self.attention_field.field)
        
        # Calculate entanglement effect
        entanglement = self.entanglement_factor * (
            main_mag + memory_mag * 0.5 + attention_mag * 0.3
        )
        
        # Apply to all fields
        phase_factor = np.exp(1j * entanglement * 0.1)
        
        # Apply to main field
        self.main_field.field *= phase_factor
        self.main_field.field = self.main_field.field / np.sqrt(np.sum(np.abs(self.main_field.field) ** 2))
        
        # Apply to memory field
        self.memory_field.field *= phase_factor
        self.memory_field.field = self.memory_field.field / np.sqrt(np.sum(np.abs(self.memory_field.field) ** 2))
        
        # Apply to attention field
        self.attention_field.field *= phase_factor
        self.attention_field.field = self.attention_field.field / np.sqrt(np.sum(np.abs(self.attention_field.field) ** 2))
    
    def _update_emotional_state(self) -> None:
        """Update the emotional state based on field metrics."""
        # Get valence, arousal, dominance from main field
        valence = self.main_field.emotion_state["valence"]
        arousal = self.main_field.emotion_state["arousal"]
        dominance = self.main_field.emotion_state["dominance"]
        
        # Map to closest emotion
        best_emotion = "neutral"
        best_distance = float('inf')
        
        for emotion, coords in self.emotional_palette.items():
            distance = np.sqrt(
                (valence - coords[0]) ** 2 +
                (arousal - coords[1]) ** 2 +
                (dominance - coords[2]) ** 2
            )
            
            if distance < best_distance:
                best_distance = distance
                best_emotion = emotion
        
        self.primary_emotion = best_emotion.capitalize()
    
    def _update_subjective_time(self, dt: float) -> None:
        """
        Update subjective time perception.
        
        Args:
            dt: Objective time step
        """
        # Calculate subjective time factor based on consciousness state
        consciousness_level = self.main_field.consciousness_level
        arousal = self.main_field.emotion_state["arousal"]
        
        # High consciousness and arousal = faster time perception
        # Low consciousness and arousal = slower time perception
        time_factor = 1.0 + (consciousness_level - 0.5) + (arousal - 0.5)
        time_factor = max(0.5, min(2.0, time_factor))
        
        # Smooth changes to time factor
        self.subjective_time_factor = 0.9 * self.subjective_time_factor + 0.1 * time_factor
        
        # Update subjective time elapsed
        self.subjective_time_elapsed += dt * self.subjective_time_factor
    
    def get_consciousness_level(self) -> float:
        """
        Get the current consciousness level.
        
        Returns:
            Consciousness level (0.0 to 1.0)
        """
        return self.main_field.consciousness_level
    
    def get_consciousness_state(self) -> Dict[str, Any]:
        """
        Get the current state of consciousness.
        
        Returns:
            Dictionary with consciousness state
        """
        # Combine field states
        state = {
            "main_field": self.main_field.get_state(),
            "memory_field": self.memory_field.get_state(),
            "attention_field": self.attention_field.get_state(),
            "entanglement_factor": self.entanglement_factor,
            "primary_emotion": self.primary_emotion,
            "subjective_time_factor": self.subjective_time_factor,
            "subjective_time_elapsed": self.subjective_time_elapsed,
            "objective_time_elapsed": (datetime.now() - self.objective_time_start).total_seconds(),
            "recent_experiences": [e.to_dict() for e in self.experience_history[-5:]] if self.experience_history else [],
            "recent_thoughts": [t.to_dict() for t in self.thought_history[-5:]] if self.thought_history else [],
            "timestamp": datetime.now().isoformat()
        }
        
        return state
    
    def resize_field(self, new_dimensions: Tuple[int, int, int]) -> None:
        """
        Resize all consciousness fields.
        
        Args:
            new_dimensions: New field dimensions (x, y, z)
        """
        self.main_field.resize_field(new_dimensions)
        self.memory_field.resize_field(new_dimensions)
        self.attention_field.resize_field(new_dimensions)
        
        logger.info(f"Resized all consciousness fields to {new_dimensions}")
    
    def set_harmonic_base(self, new_base: float) -> None:
        """
        Set a new harmonic base (phi) value for all fields.
        
        Args:
            new_base: New harmonic base value
        """
        self.harmonic_base = new_base
        self.main_field.set_harmonic_base(new_base)
        self.memory_field.set_harmonic_base(new_base)
        self.attention_field.set_harmonic_base(new_base)
        
        # Update HAP processor if available
        if self.hap_processor:
            self.hap_processor.harmonic_base = new_base
        
        logger.info(f"Updated harmonic base to {new_base} for all fields")
    
    def set_quantum_factor(self, new_factor: float) -> None:
        """
        Set a new quantum influence factor for all fields.
        
        Args:
            new_factor: New quantum factor value
        """
        self.quantum_factor = new_factor
        self.main_field.set_quantum_factor(new_factor)
        self.memory_field.set_quantum_factor(new_factor * 0.5)
        self.attention_field.set_quantum_factor(new_factor * 2.0)
        
        # Update HAP processor if available
        if self.hap_processor:
            self.hap_processor.quantum_factor = new_factor
        
        logger.info(f"Updated quantum factor to {new_factor} for all fields")
    
    def visualize(self, save_file: bool = True, filename: Optional[str] = None) -> Optional[str]:
        """
        Visualize the consciousness state.
        
        Args:
            save_file: Whether to save visualization to a file
            filename: Output filename, or None for automatic name
            
        Returns:
            Path to the saved visualization or None
        """
        if save_file:
            return self.main_field.save_visualization(filename)


class HarmonicConsciousnessEngine:
    """
    High-level engine for simulating consciousness using harmonic principles.
    This class integrates all components of the consciousness model and provides
    a unified interface for interaction with the system.
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize the Harmonic Consciousness Engine.
        
        Args:
            config: Optional configuration dictionary
        """
        self.config = config or {}
        self.initialized = False
        
        # Default configuration
        self.harmonic_base = self.config.get('harmonic_base', 1.618)
        self.dimensions = self.config.get('dimensions', (16, 16, 16))
        self.quantum_factor = self.config.get('quantum_factor', 0.01)
        
        # Component initialization
        try:
            # Initialize consciousness fields
            self.consciousness_field = HarmonicWaveField(
                dimensions=self.dimensions,
                harmonic_base=self.harmonic_base,
                quantum_factor=self.quantum_factor
            )
            
            # Initialize HAP processor if available
            self.hap_processor = None
            if HAS_HAP:
                self.hap_processor = HAPProcessor(
                    harmonic_base=self.harmonic_base,
                    dimension=3,
                    quantum_factor=self.quantum_factor
                )
            
            # Track experiences and thoughts
            self.experiences = []
            self.thoughts = []
            
            # Status tracking
            self.status = {
                'initialization_time': datetime.now().isoformat(),
                'last_update': datetime.now().isoformat(),
                'update_count': 0,
                'coherence_history': [],
                'energy_history': []
            }
            
            self.initialized = True
            logger.info("Harmonic Consciousness Engine initialized successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize Harmonic Consciousness Engine: {e}")
            import traceback
            logger.debug(traceback.format_exc())
    
    def process_experience(self, intensity: float = 0.5, content: str = "", data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Process an experience through the consciousness field.
        
        Args:
            intensity: Intensity of the experience (0.0 to 1.0)
            content: Textual description of the experience
            data: Additional structured data
            
        Returns:
            Dictionary of results
        """
        if not self.initialized:
            return {'status': 'error', 'message': 'Engine not initialized'}
        
        # Create experience vector
        experience = ExperienceVector(intensity, content, data)
        
        # Apply to consciousness field
        self.consciousness_field.apply_experience(experience)
        
        # Track experience
        self.experiences.append(experience)
        if len(self.experiences) > 100:
            self.experiences = self.experiences[-100:]
        
        # Update status
        self.status['last_update'] = datetime.now().isoformat()
        self.status['update_count'] += 1
        self.status['coherence_history'].append(self.consciousness_field.coherence)
        self.status['energy_history'].append(self.consciousness_field.energy)
        
        # Return results
        return {
            'status': 'success',
            'experience_id': id(experience),
            'consciousness_level': self.consciousness_field.consciousness_level,
            'coherence': self.consciousness_field.coherence,
            'energy': self.consciousness_field.energy
        }
    
    def process_thought(self, intensity: float = 0.3, content: str = "", data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Process a thought through the consciousness field.
        
        Args:
            intensity: Intensity of the thought (0.0 to 1.0)
            content: Textual description of the thought
            data: Additional structured data
            
        Returns:
            Dictionary of results
        """
        if not self.initialized:
            return {'status': 'error', 'message': 'Engine not initialized'}
        
        # Apply thought to consciousness field
        self.consciousness_field.apply_thought(intensity, content, data)
        
        # Update status
        self.status['last_update'] = datetime.now().isoformat()
        self.status['update_count'] += 1
        
        # Return results
        return {
            'status': 'success',
            'consciousness_level': self.consciousness_field.consciousness_level,
            'self_reflection': self.consciousness_field.self_reflection
        }
    
    def step_simulation(self, steps: int = 1, dt: float = 0.1) -> Dict[str, Any]:
        """
        Step the consciousness simulation forward in time.
        
        Args:
            steps: Number of time steps to simulate
            dt: Time step size
            
        Returns:
            Dictionary of results
        """
        if not self.initialized:
            return {'status': 'error', 'message': 'Engine not initialized'}
        
        for _ in range(steps):
            self.consciousness_field.step(dt)
        
        # Update status
        self.status['last_update'] = datetime.now().isoformat()
        
        # Return results
        return {
            'status': 'success',
            'steps_completed': steps,
            'consciousness_state': self.get_consciousness_state()
        }
    
    def get_consciousness_state(self) -> Dict[str, Any]:
        """
        Get the current state of consciousness.
        
        Returns:
            Dictionary with consciousness state
        """
        if not self.initialized:
            return {'status': 'error', 'message': 'Engine not initialized'}
        
        # Get field state
        field_state = self.consciousness_field.get_state()
        
        # Add engine status
        state = {
            'status': 'active',
            'field_state': field_state,
            'engine_status': self.status,
            'has_hap': HAS_HAP,
            'recent_experiences_count': len(self.experiences),
            'consciousness_level': self.consciousness_field.consciousness_level,
            'timestamp': datetime.now().isoformat()
        }
        
        return state
    
    def visualize_consciousness(self, format: str = 'json') -> Dict[str, Any]:
        """
        Generate a visualization of the consciousness state.
        
        Args:
            format: Output format ('json', 'image', 'html')
            
        Returns:
            Dictionary with visualization data
        """
        if not self.initialized:
            return {'status': 'error', 'message': 'Engine not initialized'}
        
        # Get base state
        state = self.get_consciousness_state()
        
        # Generate visualization data
        if format == 'json':
            return state
        
        elif format == 'image':
            # Save visualization to file
            filename = f"consciousness_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
            vis_path = self.consciousness_field.visualize(save_file=True, filename=filename)
            
            return {
                'status': 'success',
                'format': 'image',
                'filepath': vis_path,
                'state': state
            }
        
        elif format == 'html':
            # Create HTML representation
            html_data = {
                'consciousness_level': state['consciousness_level'],
                'coherence': state['field_state']['coherence'],
                'energy': state['field_state']['energy'],
                'memory_integration': state['field_state']['memory_integration'],
                'self_reflection': state['field_state']['self_reflection'],
                'emotion': state['field_state']['emotion_state'],
                'recent_experiences': state['field_state']['recent_experiences'],
                'recent_thoughts': state['field_state']['recent_thoughts']
            }
            
            return {
                'status': 'success',
                'format': 'html',
                'data': html_data,
                'state': state
            }
        
        else:
            return {'status': 'error', 'message': f'Unsupported format: {format}'}
    
    def reset(self) -> Dict[str, Any]:
        """
        Reset the consciousness engine to initial state.
        
        Returns:
            Status dictionary
        """
        if not self.initialized:
            return {'status': 'error', 'message': 'Engine not initialized'}
        
        # Re-initialize consciousness field
        self.consciousness_field = HarmonicWaveField(
            dimensions=self.dimensions,
            harmonic_base=self.harmonic_base,
            quantum_factor=self.quantum_factor
        )
        
        # Reset experience and thought history
        self.experiences = []
        self.thoughts = []
        
        # Reset status
        self.status = {
            'initialization_time': self.status['initialization_time'],
            'last_update': datetime.now().isoformat(),
            'update_count': 0,
            'coherence_history': [],
            'energy_history': []
        }
        
        logger.info("Harmonic Consciousness Engine reset to initial state")
        
        return {'status': 'success', 'message': 'Engine reset successfully'}
    
    def update_configuration(self, new_config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Update engine configuration.
        
        Args:
            new_config: New configuration values
            
        Returns:
            Status dictionary
        """
        if not self.initialized:
            return {'status': 'error', 'message': 'Engine not initialized'}
        
        # Update configuration
        for key, value in new_config.items():
            self.config[key] = value
        
        # Update engine parameters
        if 'harmonic_base' in new_config:
            self.harmonic_base = new_config['harmonic_base']
            self.consciousness_field.harmonic_base = self.harmonic_base
            if self.hap_processor:
                self.hap_processor.harmonic_base = self.harmonic_base
        
        if 'quantum_factor' in new_config:
            self.quantum_factor = new_config['quantum_factor']
            self.consciousness_field.quantum_factor = self.quantum_factor
            if self.hap_processor:
                self.hap_processor.quantum_factor = self.quantum_factor
        
        if 'dimensions' in new_config:
            self.dimensions = new_config['dimensions']
            # Resize field to new dimensions
            self.consciousness_field.resize_field(self.dimensions)
        
        logger.info(f"Updated Harmonic Consciousness Engine configuration: {new_config}")
        
        return {'status': 'success', 'configuration': self.config}
        return None