#!/usr/bin/env python3
"""
Quantum Geometry VM – Smoke Test
Run: python smoke_test.py
"""
import os, sys, importlib, json

REQUIRED = ["flask", "flask_cors"]
OPTIONAL = ["numpy", "networkx", "torch"]

def check_pkg(name):
    try:
        importlib.import_module(name)
        return True
    except Exception:
        return False

def main():
    print("Python:", sys.version.split()[0])
    status = {"required":{}, "optional":{}, "import_qgvm2": None, "flask_blueprint": None}

    for k in REQUIRED:
        ok = check_pkg(k)
        status["required"][k] = ok
        print(f"[req] {k}: {'OK' if ok else 'MISSING'}")
    for k in OPTIONAL:
        ok = check_pkg(k)
        status["optional"][k] = ok
        print(f"[opt] {k}: {'OK' if ok else 'MISSING'}")

    # Make project importable if run from repo root
    sys.path.insert(0, os.getcwd())

    # Try importing package and blueprint
    try:
        pkg = importlib.import_module("qgvm2")
        print("Imported package: qgvm2")
        status["import_qgvm2"] = True
    except Exception as e:
        print("Failed to import package qgvm2:", e)
        status["import_qgvm2"] = False

    vm_api = None
    for modname in ["qgvm2.vm_api", "vm_api"]:
        try:
            vm_api = importlib.import_module(modname)
            break
        except Exception:
            pass

    if vm_api and hasattr(vm_api, "vm_api"):
        print("Found Flask blueprint: vm_api")
        status["flask_blueprint"] = True
    else:
        print("Flask blueprint missing or could not be imported")
        status["flask_blueprint"] = False

    print("\n=== SUMMARY ===")
    print(json.dumps(status, indent=2))

if __name__ == "__main__":
    main()
