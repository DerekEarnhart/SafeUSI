import React from 'react';
import { ProactiveAlert } from '../types';

interface ProactivePanelProps {
  alerts: ProactiveAlert[];
  containerRef: React.RefObject<HTMLDivElement>;
}

const ProactivePanel: React.FC<ProactivePanelProps> = ({ alerts, containerRef }) => {
  return (
    <aside className="w-72 bg-gray-900/30 p-3 flex flex-col">
      <h2 className="text-sm font-semibold text-cyan-400 uppercase tracking-widest mb-3 text-center">PROACTIVE INITIATIVES</h2>
      <div ref={containerRef} className="flex-1 overflow-y-auto space-y-3 pr-2">
        {alerts.map(alert => (
          <div key={alert.id} className="bg-cyan-900/20 border border-cyan-700/30 rounded-lg p-2 text-xs transition-all duration-500 animate-fade-in">
            <div className="flex justify-between items-center mb-1">
              <span className="font-bold text-cyan-400">{alert.title}</span>
              <span className="text-gray-500 font-mono">{alert.timestamp}</span>
            </div>
            <p className="text-gray-300">{alert.summary}</p>
          </div>
        ))}
      </div>
    </aside>
  );
};

export default ProactivePanel;
