#!/usr/bin/env python3
import argparse, pathlib, hashlib, subprocess, time, csv, shlex, sys

def sha(p):
    h=hashlib.sha256(); 
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1<<20), b''): h.update(b)
    return h.hexdigest()

def run(cmd):
    t0=time.time()
    p=subprocess.run(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return p.returncode, time.time()-t0, p.stdout, p.stderr

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--tool', required=True)
    ap.add_argument('--detool', required=True)
    ap.add_argument('--data', required=True)
    ap.add_argument('--outcsv', default='bench_results.csv')
    a=ap.parse_args()
    files=[]
    p=pathlib.Path(a.data)
    files=[p] if p.is_file() else [f for f in p.rglob('*') if f.is_file()]
    rows=[]
    outdir=pathlib.Path('bench_out'); outdir.mkdir(exist_ok=True)
    for f in files:
        try:
            s_in=f.stat().st_size; h0=sha(f)
            c=outdir/(f.name+'.cmp'); d=outdir/(f.name+'.orig')
            r,tc,_,e=run(a.tool.format(inp=shlex.quote(str(f)), out=shlex.quote(str(c))))
            if r!=0: raise RuntimeError(e.decode('utf-8','ignore')[:160])
            s_out=c.stat().st_size
            r,td,_,e=run(a.detool.format(inp=shlex.quote(str(c)), out=shlex.quote(str(d))))
            if r!=0: raise RuntimeError(e.decode('utf-8','ignore')[:160])
            ok=(h0==sha(d))
            rows.append({'file':str(f),'size_in':s_in,'size_out':s_out,'ratio':s_in/max(1,s_out),'t_comp_s':tc,'t_decomp_s':td,'integrity_ok':ok})
            d.unlink(missing_ok=True)
        except Exception as ex:
            rows.append({'file':str(f),'error':str(ex),'size_in':0,'size_out':0,'ratio':0,'t_comp_s':0,'t_decomp_s':0,'integrity_ok':False})
    with open(a.outcsv,'w',newline='') as csvf:
        w=csv.DictWriter(csvf, fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
    print('Wrote', a.outcsv, '• files', len(rows))
if __name__=='__main__': main()
