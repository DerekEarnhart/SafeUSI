from flask import Flask, jsonify, request
from flask_cors import CORS
from .registry import list_tools, run_tool_job, JOBS
app = Flask(__name__); CORS(app)
METRICS={"timestamp":"","coherence":0.9,"resonance":0.86,"entropy":0.41,"hap_index":0.79,"metrics":{"structural_complexity":0.73},"composite":0.734}
@app.get("/healthz")
def healthz(): return {"ok":True}
@app.get("/v1/tools")
def tools(): return jsonify(list_tools())
@app.post("/v1/jobs")
def jobs_run():
    data = request.get_json(force=True)
    return {"job_id": run_tool_job(data.get("name"), data.get("args"))}
@app.get("/v1/jobs/<jid>")
def jobs_get(jid): return jsonify(JOBS.get(jid, {"error":"not found"}))
@app.get("/metrics")
def metrics(): return jsonify(METRICS)
if __name__=="__main__": app.run(host="127.0.0.1", port=5000, debug=True)
