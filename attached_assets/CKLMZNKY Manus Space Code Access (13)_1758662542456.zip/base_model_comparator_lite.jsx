import React, { useEffect, useMemo, useState } from "react";

// Base Model Comparator — Lite
// Goal: keep only the handful of traits that actually drive behavior so you can compare fast.
// - Minimal fields
// - LocalStorage persistence
// - Two-model diff
// - Prefilled with your Superhuman Prototype

// ---------- Shape ----------
const DEFAULT_MODEL = {
  name: "Unnamed Model",
  endpoint: "",
  streaming: false,
  reasoning: "optional", // hidden | optional | always
  proactivity: { enabled: true, idle_ms: 45000 },
  persistenceStore: "",
  sanitize: false,
  retries: 0,
  backoff: "none", // none | jittered | exponential
  markdownParser: "custom",
  knownGotchas: [],
  extra: {}
};

const PREFILL_SUPERHUMAN = {
  ...DEFAULT_MODEL,
  name: "Superhuman Prototype",
  endpoint: "Gemini 2.0 Flash / v1beta generateContent (JSON)",
  streaming: false,
  reasoning: "always",
  proactivity: { enabled: true, idle_ms: 45000 },
  persistenceStore: "Firestore: artifacts/{appId}/users/{uid}/agi_state_superhuman/current",
  sanitize: false,
  retries: 0,
  backoff: "none",
  markdownParser: "manual split on ```",
  knownGotchas: [
    "XSS via unsanitized HTML",
    "Strict JSON parse brittle",
    "No streaming",
    "Non-deterministic proactivity cadence"
  ],
  extra: { ui: "Tailwind single-file UMD" }
};

// ---------- Utils ----------
const KEY = "modelComparatorLite.models";
const clone = (v) => JSON.parse(JSON.stringify(v));
const save = (models) => localStorage.setItem(KEY, JSON.stringify(models));
const load = () => {
  try { const raw = localStorage.getItem(KEY); return raw ? JSON.parse(raw) : null; } catch { return null; }
};

// Deep diff -> [{path, a, b}]
function deepDiff(a, b, base = []) {
  const keys = new Set([...(a ? Object.keys(a) : []), ...(b ? Object.keys(b) : [])]);
  const out = [];
  for (const k of keys) {
    const va = a?.[k];
    const vb = b?.[k];
    const path = [...base, k];
    const bothObj =
      va && vb && typeof va === "object" && typeof vb === "object" && !Array.isArray(va) && !Array.isArray(vb);
    if (bothObj) { out.push(...deepDiff(va, vb, path)); continue; }
    if (JSON.stringify(va) !== JSON.stringify(vb)) out.push({ path: path.join("."), a: va, b: vb });
  }
  return out;
}

const pretty = (v) => (v === undefined ? "—" : typeof v === "string" ? v : "```\n" + JSON.stringify(v, null, 2) + "\n```");

// ---------- Tiny UI bits ----------
const Label = ({children}) => <div className="text-[11px] font-medium text-slate-400 mb-1">{children}</div>;
const Input = (p) => <input {...p} className={`w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 ${p.className||""}`} />;
const TextArea = (p) => <textarea {...p} className={`w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 ${p.className||""}`} />;
const Toggle = ({value, onChange}) => (
  <button onClick={() => onChange(!value)} className={`px-3 py-2 rounded-lg border ${value?"bg-emerald-600/20 border-emerald-500 text-emerald-200":"bg-slate-900 border-slate-700 text-slate-300"}`}>{value?"Enabled":"Disabled"}</button>
);

function Header({ onOpenHints }){
  return (
    <div className="w-full flex items-center justify-between p-4 bg-slate-900/80 border-b border-slate-800 rounded-t-2xl">
      <div>
        <h1 className="text-xl md:text-2xl font-bold tracking-tight">Base Model Comparator — Lite</h1>
        <p className="text-slate-400 text-sm">Only the knobs that matter, none of the yak.</p>
      </div>
      <div className="flex items-center gap-2">
        <button
          onClick={onOpenHints}
          className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs"
          title="Hints & quick lessons"
        >
          Hints
        </button>
        <div className="text-xs text-slate-400">v1-lite</div>
      </div>
    </div>
  );
}

function ModelCard({m, active, onClick}){
  return (
    <button onClick={onClick} className={`w-full text-left p-3 rounded-xl border ${active?"border-indigo-500 bg-indigo-500/10":"border-slate-800 hover:border-slate-700"}`}>
      <div className="font-semibold">{m.name || "Unnamed"}</div>
      <div className="text-xs text-slate-400 line-clamp-1">{m.endpoint || "—"}</div>
    </button>
  );
}

function ModelEditor({model, onChange}){
  if(!model) return <div className="text-slate-400">Pick a model.</div>;
  return (
    <div className="space-y-4">
      <div>
        <Label>Name</Label>
        <Input value={model.name} onChange={(e)=>onChange({...model, name:e.target.value})} placeholder="Model name"/>
      </div>
      <div>
        <Label>Endpoint</Label>
        <Input value={model.endpoint} onChange={(e)=>onChange({...model, endpoint:e.target.value})} placeholder="e.g., Gemini 2.0 Flash / JSON"/>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label>Streaming</Label>
          <Toggle value={model.streaming} onChange={(v)=>onChange({...model, streaming:v})}/>
        </div>
        <div>
          <Label>Reasoning surfaced</Label>
          <select className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-800" value={model.reasoning} onChange={(e)=>onChange({...model, reasoning:e.target.value})}>
            <option>hidden</option>
            <option>optional</option>
            <option>always</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label>Proactivity</Label>
          <Toggle value={model.proactivity.enabled} onChange={(v)=>onChange({...model, proactivity:{...model.proactivity, enabled:v}})}/>
        </div>
        <div>
          <Label>Idle (ms)</Label>
          <Input value={model.proactivity.idle_ms} onChange={(e)=>onChange({...model, proactivity:{...model.proactivity, idle_ms:Number(e.target.value)||0}})} placeholder="45000"/>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div>
          <Label>Sanitize</Label>
          <Toggle value={model.sanitize} onChange={(v)=>onChange({...model, sanitize:v})}/>
        </div>
        <div>
          <Label>Retries</Label>
          <Input value={model.retries} onChange={(e)=>onChange({...model, retries:Number(e.target.value)||0})} placeholder="0"/>
        </div>
        <div>
          <Label>Backoff</Label>
          <Input value={model.backoff} onChange={(e)=>onChange({...model, backoff:e.target.value})} placeholder="none | jittered | exponential"/>
        </div>
      </div>

      <div>
        <Label>Persistence Store</Label>
        <Input value={model.persistenceStore} onChange={(e)=>onChange({...model, persistenceStore:e.target.value})} placeholder="e.g., Firestore path"/>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label>Markdown Parser</Label>
          <Input value={model.markdownParser} onChange={(e)=>onChange({...model, markdownParser:e.target.value})} placeholder="custom | markdown-it"/>
        </div>
        <div>
          <Label>Known gotchas (comma separated)</Label>
          <Input value={model.knownGotchas.join(", ")} onChange={(e)=>onChange({...model, knownGotchas:e.target.value.split(",").map(s=>s.trim()).filter(Boolean)})} placeholder="XSS, no streaming, ..."/>
        </div>
      </div>

      <div>
        <Label>Extra (JSON)</Label>
        <TextArea rows={3} value={JSON.stringify(model.extra||{}, null, 2)} onChange={(e)=>{
          try { const obj = JSON.parse(e.target.value||"{}"); onChange({...model, extra: obj}); } catch {} }} />
      </div>
    </div>
  );
}

function DiffTable({a,b}){
  const rows = useMemo(()=> (a&&b? deepDiff(a,b):[]), [a,b]);
  if(!a||!b) return <div className="text-slate-400">Pick two models.</div>;
  if(rows.length===0) return <div className="text-emerald-300">No differences. These two are identical on recorded traits.</div>;
  return (
    <div className="overflow-auto">
      <table className="min-w-full text-sm">
        <thead className="bg-slate-900/60 sticky top-0">
          <tr>
            <th className="text-left p-2 w-1/3">Field</th>
            <th className="text-left p-2 w-1/3">A: {a?.name||"—"}</th>
            <th className="text-left p-2 w-1/3">B: {b?.name||"—"}</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r,i)=> (
            <tr key={i} className="border-t border-slate-800 align-top">
              <td className="p-2 font-mono text-xs text-slate-400">{r.path}</td>
              <td className="p-2"><div className="whitespace-pre-wrap text-slate-200">{pretty(r.a)}</div></td>
              <td className="p-2"><div className="whitespace-pre-wrap text-slate-200">{pretty(r.b)}</div></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function Toolbar({ onAdd, onDuplicate, onDelete, onExport, onImport, canDup, canDel, onQuickPaste }){
  return (
    <div className="flex flex-wrap gap-2 items-center">
      <button className="px-3 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500" onClick={onAdd}>+ New</button>
      <button className={`px-3 py-2 rounded-lg ${canDup?"bg-slate-700 hover:bg-slate-600":"bg-slate-800 text-slate-500"}`} disabled={!canDup} onClick={onDuplicate}>Duplicate</button>
      <button className={`px-3 py-2 rounded-lg ${canDel?"bg-rose-700/80 hover:bg-rose-600":"bg-slate-800 text-slate-500"}`} disabled={!canDel} onClick={onDelete}>Delete</button>
      <button className="px-3 py-2 rounded-lg bg-slate-700 hover:bg-slate-600" onClick={onExport}>Export JSON</button>
      <label className="px-3 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 cursor-pointer">Import JSON<input type="file" accept="application/json" className="hidden" onChange={onImport}/></label>
      <button className="px-3 py-2 rounded-lg bg-slate-700 hover:bg-slate-600" onClick={onQuickPaste}>Quick paste</button>
    </div>
  );
}

// --- Hints / Quick Lesson Modal ---
function QuickLessonModal({ open, onClose }) {
  const PHI = 1.61803398875;
  const C = 299792.458; // km/s
  const [fieldStrength, setFieldStrength] = React.useState(50);
  const [harmonicOrder, setHarmonicOrder] = React.useState(3);
  const [goldenFactor, setGoldenFactor] = React.useState(1.618);
  const [phaseSync, setPhaseSync] = React.useState(0);
  const [powerAlloc, setPowerAlloc] = React.useState(50); // %
  const [dampening, setDampening] = React.useState(80); // %

  const metrics = React.useMemo(() => {
    const gf = goldenFactor;
    const goldenAlignment = 1 + Math.exp(-Math.abs(gf - PHI) * 10);
    const basePower = Math.pow(fieldStrength, 2) * harmonicOrder;
    const rawPower = basePower * goldenAlignment * 0.01; // GW
    const phaseFactor = Math.cos((phaseSync * Math.PI) / 180);
    const resonanceMatch = Math.exp(-Math.abs(gf - PHI) * 5);
    const stability = (dampening / 100) * resonanceMatch * Math.abs(phaseFactor) * 100; // %
    const pOut = rawPower * (powerAlloc / 100);
    const thrust = pOut * (stability / 100);
    let warp = 0;
    if (stability > 75 && thrust > 10) warp = Math.pow(thrust, 1 / 3);
    if (warp > 9.9) warp = 9.9 + Math.log10(thrust - Math.pow(9.9, 3) + 1) * 0.1;
    warp = Math.min(warp, 10);
    const efficiency = stability > 50 ? (goldenAlignment - 1) * 50 * Math.abs(phaseFactor) : 0;
    const coreTemp = 273 + pOut * 50 + (100 - stability);
    const velocity = warp < 1 ? warp * C : Math.pow(warp, 10 / 3) * C; // km/s
    return { stability, pOut, thrust, warp, efficiency, coreTemp, velocity };
  }, [fieldStrength, harmonicOrder, goldenFactor, phaseSync, powerAlloc, dampening]);

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50">
      <div className="absolute inset-0 bg-black/60" onClick={onClose} />
      <div className="absolute inset-0 flex items-center justify-center p-4">
        <div className="w-full max-w-4xl max-h-[85vh] overflow-auto rounded-2xl border border-slate-800 bg-slate-950 shadow-2xl">
          <div className="flex items-center justify-between p-4 border-b border-slate-800">
            <div>
              <div className="text-lg font-semibold">Hints & Quick Lessons</div>
              <div className="text-xs text-slate-400">Quantum Harmonic Drive concepts mapped to model-comparison intuition.</div>
            </div>
            <button onClick={onClose} className="px-3 py-1.5 text-xs rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700">Close</button>
          </div>

          <div className="grid md:grid-cols-2 gap-4 p-4">
            <div className="space-y-3">
              <div className="text-sm font-semibold">Mini‑sim (play with the knobs)</div>
              <RangeRow label="Field Strength" value={fieldStrength} setValue={setFieldStrength} min={1} max={100} step={1} suffix=" V/m" />
              <RangeRow label="Harmonic Order" value={harmonicOrder} setValue={setHarmonicOrder} min={1} max={10} step={1} />
              <RangeRow label="Golden Ratio Factor" value={goldenFactor} setValue={setGoldenFactor} min={1.0} max={2.5} step={0.001} />
              <RangeRow label="Phase Sync" value={phaseSync} setValue={setPhaseSync} min={-90} max={90} step={1} suffix="°" />
              <RangeRow label="Power Allocation" value={powerAlloc} setValue={setPowerAlloc} min={0} max={100} step={1} suffix="%" />
              <RangeRow label="Inertial Dampening" value={dampening} setValue={setDampening} min={0} max={100} step={1} suffix="%" />
              <div className="flex gap-2 pt-1">
                <button
                  onClick={() => { setGoldenFactor(PHI); setPhaseSync(0); setDampening(95); }}
                  className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-xs"
                >Auto‑tune</button>
                <button
                  onClick={() => { setFieldStrength(50); setHarmonicOrder(3); setGoldenFactor(1.618); setPhaseSync(0); setPowerAlloc(50); setDampening(80); }}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs"
                >Reset</button>
              </div>
            </div>

            <div className="space-y-3">
              <div className="text-sm font-semibold">Outputs</div>
              <MetricRow k="Warp Factor" v={metrics.warp.toFixed(2)} />
              <MetricRow k="Field Stability" v={`${metrics.stability.toFixed(1)}%`} />
              <MetricRow k="Velocity" v={`${metrics.velocity.toLocaleString('en-US', { maximumFractionDigits: 0 })} km/s`} />
              <MetricRow k="Power Output" v={`${metrics.pOut.toFixed(2)} GW`} />
              <MetricRow k="Efficiency" v={`${metrics.efficiency.toFixed(1)}%`} />
              <MetricRow k="Core Temp" v={`${metrics.coreTemp.toFixed(0)} K`} />

              <div className="pt-2 text-xs text-slate-400">
                <div className="font-semibold text-slate-300 mb-1">Analogy → your model traits</div>
                <ul className="list-disc ml-4 space-y-1">
                  <li><span className="text-slate-200">Sanitize</span> ≈ <span className="text-slate-200">Dampening</span>: stabilizes the field and prevents catastrophic flare‑ups (XSS).</li>
                  <li><span className="text-slate-200">Streaming</span> → higher perceived <span className="text-slate-200">warp</span>: users feel speed even if raw power is unchanged.</li>
                  <li><span className="text-slate-200">Retries/Backoff</span> = keeping <span className="text-slate-200">phase sync</span> in bounds under turbulence.</li>
                  <li><span className="text-slate-200">Proactivity idle</span> ↔ <span className="text-slate-200">power allocation</span>: too high and you lurch; too low and you idle forever.</li>
                </ul>
                <div className="mt-2">These formulas are an educational toy, inspired by your Quantum Harmonic Drive demo.</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function RangeRow({ label, value, setValue, min, max, step, suffix }) {
  return (
    <div>
      <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
        <div>{label}</div>
        <div className="text-slate-300">{value}{suffix||""}</div>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => setValue(Number(e.target.value))}
        className="w-full h-2 rounded bg-slate-800"
      />
    </div>
  );
}

function MetricRow({ k, v }) {
  return (
    <div className="flex items-center justify-between text-sm">
      <div className="text-slate-400">{k}</div>
      <div className="font-semibold text-slate-200">{v}</div>
    </div>
  );
}

export default function App(){
  const [models, setModels] = useState(()=> load() || [PREFILL_SUPERHUMAN]);
  const [active, setActive] = useState(0);
  const [aIdx, setAIdx] = useState(0);
  const [bIdx, setBIdx] = useState(models.length>1?1:0);
  const [showHints, setShowHints] = useState(false);

  useEffect(()=>{ save(models); if(active>=models.length) setActive(models.length-1); if(aIdx>=models.length) setAIdx(models.length-1); if(bIdx>=models.length) setBIdx(models.length-1); }, [models]);

  const update = (idx, next) => setModels(m => m.map((x,i)=> i===idx? clone(next): x));

  const add = () => { setModels(m=> [...m, clone(DEFAULT_MODEL)]); setActive(models.length); };
  const dup = () => { if(active==null) return; setModels(m=> { const cp = clone(m[active]); cp.name = (cp.name||"Unnamed")+" (copy)"; return [...m, cp]; }); };
  const del = () => { if(active==null) return; setModels(m=> m.filter((_,i)=> i!==active)); setActive(0); };

  const exportJSON = () => {
    const blob = new Blob([JSON.stringify(models, null, 2)], {type:"application/json"});
    const url = URL.createObjectURL(blob); const a = document.createElement("a"); a.href=url; a.download="base-models-lite.json"; a.click(); URL.revokeObjectURL(url);
  };

  const importJSON = (e) => {
    const file = e.target.files?.[0]; if(!file) return; const reader = new FileReader();
    reader.onload = () => { try { const parsed = JSON.parse(reader.result); if(!Array.isArray(parsed)) throw new Error("expected an array"); setModels(parsed); } catch(err){ alert("Import failed: "+err.message);} };
    reader.readAsText(file);
  };

  const quickPaste = () => {
    const text = prompt("Paste a JSON object of traits (we'll coerce unknown fields):");
    if(!text) return; try{ const obj = JSON.parse(text); const next = { ...DEFAULT_MODEL, ...obj }; setModels(m=> [...m, next]); setActive(models.length); } catch(err){ alert("Parse error: "+err.message); }
  };

  const activeModel = models[active];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-4 md:p-8">
      <div className="max-w-6xl mx-auto border border-slate-800 rounded-2xl overflow-hidden shadow-2xl">
        <Header onOpenHints={() => setShowHints(true)} />
        <QuickLessonModal open={showHints} onClose={() => setShowHints(false)} />
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-0">
          {/* Sidebar */}
          <div className="lg:col-span-1 p-4 bg-slate-950 border-r border-slate-800 space-y-3">
            <Toolbar onAdd={add} onDuplicate={dup} onDelete={del} onExport={exportJSON} onImport={importJSON} onQuickPaste={quickPaste} canDup={models.length>0} canDel={models.length>0}/>
            <div className="grid gap-2 mt-2">
              {models.map((m,i)=> <ModelCard key={i} m={m} active={i===active} onClick={()=>setActive(i)}/>) }
            </div>
          </div>

          {/* Editor */}
          <div className="lg:col-span-2 p-4 bg-slate-950/60">
            <div className="text-sm font-semibold mb-3">Model</div>
            <ModelEditor model={activeModel} onChange={(v)=>update(active, v)} />
          </div>

          {/* Diff */}
          <div className="lg:col-span-1 p-4 bg-slate-950/60 border-l border-slate-800">
            <div className="text-sm font-semibold mb-3">Compare</div>
            <div className="flex gap-2 mb-3">
              <select className="flex-1 px-3 py-2 rounded-lg bg-slate-900 border border-slate-800" value={aIdx} onChange={(e)=>setAIdx(Number(e.target.value))}>
                {models.map((m,i)=> <option key={i} value={i}>A: {m.name}</option>)}
              </select>
              <select className="flex-1 px-3 py-2 rounded-lg bg-slate-900 border border-slate-800" value={bIdx} onChange={(e)=>setBIdx(Number(e.target.value))}>
                {models.map((m,i)=> <option key={i} value={i}>B: {m.name}</option>)}
              </select>
            </div>
            <div className="h-[55vh] rounded-xl border border-slate-800 p-2 bg-slate-950 overflow-auto">
              <DiffTable a={models[aIdx]} b={models[bIdx]} />
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto mt-6 grid lg:grid-cols-2 gap-4">
        <div className="p-4 rounded-2xl border border-slate-800 bg-slate-950/80">
          <div className="text-sm font-semibold">What changed vs Full</div>
          <ul className="text-sm text-slate-300 list-disc ml-4 mt-2 space-y-1">
            <li>Collapsed <span className="text-slate-200">security</span>, <span className="text-slate-200">error policy</span>, and <span className="text-slate-200">rendering</span> into 5 fields that actually move behavior.</li>
            <li>Removed nested editors (KV/arrays) except for gotchas (comma list) and a raw JSON box for extras.</li>
            <li>Added <span className="text-slate-200">Quick paste</span> to drop raw JSON traits without ceremony.</li>
          </ul>
        </div>
        <div className="p-4 rounded-2xl border border-slate-800 bg-slate-950/80">
          <div className="text-sm font-semibold">Suggested usage</div>
          <ol className="text-sm text-slate-300 list-decimal ml-4 mt-2 space-y-1">
            <li>Add a base, paste its traits, tweak a few booleans.</li>
            <li>Select two in the right-side compare and eyeball the diff.</li>
            <li>Export JSON when you want a snapshot; re-import later.</li>
          </ol>
        </div>
      </div>
    </div>
  );
}
