"""
Base Engine

This module provides the base engine class for all specialized engines
in the HAP AGI system, defining a common interface.
"""

import os
import sys
import json
import logging
from datetime import datetime
from typing import Dict, List, Any, Optional, Union, Tuple, Set

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class BaseEngine:
    """
    Base engine class that defines the common interface for all engines.
    All specialized engines must inherit from this class.
    """
    
    def __init__(self, 
                 name: str,
                 version: str = "1.0.0",
                 description: str = "",
                 use_hap: bool = True,
                 harmonic_base: float = 1.618,
                 quantum_factor: float = 0.01):
        """
        Initialize the base engine.
        
        Args:
            name: Name of the engine
            version: Version string
            description: Engine description
            use_hap: Whether to use Harmonic Algebraic Probability
            harmonic_base: Harmonic base parameter (default: phi)
            quantum_factor: Quantum influence factor (0.0 to 1.0)
        """
        self.name = name
        self.version = version
        self.description = description
        self.use_hap = use_hap
        self.harmonic_base = harmonic_base
        self.quantum_factor = quantum_factor
        
        # Common properties
        self.initialized = False
        self.creation_time = datetime.now().isoformat()
        self.last_update_time = self.creation_time
        self.update_count = 0
        
        # Initialize HAP processor if needed
        if use_hap:
            try:
                from harmonic_algebraic_probability import HAPProcessor
                self.hap_processor = HAPProcessor(
                    harmonic_base=harmonic_base,
                    dimension=3,
                    quantum_factor=quantum_factor
                )
            except ImportError:
                logger.warning("HAPProcessor not available. Running without HAP.")
                self.hap_processor = None
                self.use_hap = False
        else:
            self.hap_processor = None
        
        # Meta information
        self.meta = {
            "name": name,
            "version": version,
            "description": description,
            "created": self.creation_time,
            "last_updated": self.last_update_time,
            "update_count": self.update_count,
            "capabilities": self.get_capabilities(),
            "configuration": {
                "use_hap": use_hap,
                "harmonic_base": harmonic_base,
                "quantum_factor": quantum_factor
            }
        }
        
        self.initialized = True
        logger.info(f"Initialized {name} engine (v{version})")
    
    def get_capabilities(self) -> List[str]:
        """
        Get a list of capabilities provided by this engine.
        To be overridden by subclasses.
        
        Returns:
            List of capability strings
        """
        return ["base_functionality"]
    
    def process(self, input_data: Any, **kwargs) -> Dict[str, Any]:
        """
        Process input data. To be overridden by subclasses.
        
        Args:
            input_data: Input data to process
            **kwargs: Additional keyword arguments
            
        Returns:
            Dictionary with processed results
        """
        return {
            "status": "error", 
            "message": "Base process method called. This should be overridden."
        }
    
    def update(self, **kwargs) -> Dict[str, Any]:
        """
        Update engine state or configuration.
        
        Args:
            **kwargs: Configuration updates
            
        Returns:
            Status dictionary
        """
        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)
                
                # Update meta configuration if applicable
                if key in self.meta["configuration"]:
                    self.meta["configuration"][key] = value
        
        self.last_update_time = datetime.now().isoformat()
        self.update_count += 1
        self.meta["last_updated"] = self.last_update_time
        self.meta["update_count"] = self.update_count
        
        return {"status": "success", "message": "Engine updated successfully"}
    
    def reset(self) -> Dict[str, Any]:
        """
        Reset engine state to initial conditions.
        
        Returns:
            Status dictionary
        """
        self.last_update_time = datetime.now().isoformat()
        self.update_count += 1
        self.meta["last_updated"] = self.last_update_time
        self.meta["update_count"] = self.update_count
        
        return {"status": "success", "message": "Engine reset successfully"}
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Convert engine to a dictionary representation.
        
        Returns:
            Dictionary representation of the engine
        """
        return {
            "meta": self.meta,
            "state": {
                "initialized": self.initialized,
                "creation_time": self.creation_time,
                "last_update_time": self.last_update_time,
                "update_count": self.update_count
            }
        }
    
    def save(self, filepath: str) -> str:
        """
        Save engine state to a file.
        
        Args:
            filepath: Path to save the engine state
            
        Returns:
            Path to the saved file
        """
        # Ensure directory exists
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        
        # Save to file
        with open(filepath, 'w') as f:
            json.dump(self.to_dict(), f, indent=2)
        
        logger.info(f"Engine saved to {filepath}")
        return filepath
    
    @classmethod
    def load(cls, filepath: str) -> "BaseEngine":
        """
        Load engine state from a file.
        
        Args:
            filepath: Path to the saved engine state
            
        Returns:
            Loaded engine instance
        """
        # Load from file
        with open(filepath, 'r') as f:
            data = json.load(f)
        
        # Create instance
        meta = data["meta"]
        instance = cls(
            name=meta["name"],
            version=meta["version"],
            description=meta["description"],
            use_hap=meta["configuration"]["use_hap"],
            harmonic_base=meta["configuration"]["harmonic_base"],
            quantum_factor=meta["configuration"]["quantum_factor"]
        )
        
        # Update state
        instance.creation_time = data["state"]["creation_time"]
        instance.last_update_time = data["state"]["last_update_time"]
        instance.update_count = data["state"]["update_count"]
        
        logger.info(f"Engine loaded from {filepath}")
        return instance