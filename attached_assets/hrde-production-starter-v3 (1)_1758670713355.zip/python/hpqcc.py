def _xor_cycle(bs: bytes, key: bytes) -> bytes:
    out = bytearray()
    for i, b in enumerate(bs): out.append(b ^ key[i % len(key)])
    return bytes(out)
def compress(data: bytes, key: bytes=b"prime") -> bytes: return _xor_cycle(data, key)
def decompress(data: bytes, key: bytes=b"prime") -> bytes: return _xor_cycle(data, key)
