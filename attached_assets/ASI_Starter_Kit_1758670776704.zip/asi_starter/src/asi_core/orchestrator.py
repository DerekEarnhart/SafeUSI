from __future__ import annotations
from typing import Dict, Any, List, Callable
from dataclasses import dataclass, field
from .memory import InMemoryVectorStore
from .planner import naive_plan
from .safety import policy_allows

@dataclass
class Tool:
    name: str
    call: Callable[[Dict[str, Any]], Dict[str, Any]]
    doc: str = ""

@dataclass
class Agent:
    name: str
    tools: Dict[str, Tool]
    memory: InMemoryVectorStore

    def act(self, step: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
        text = step["text"]
        if not policy_allows(text):
            return {"error": "Policy violation", "step": step}
        # Pick a tool naively by name matching
        for tname, tool in self.tools.items():
            if any(k in text.lower() for k in tname.split("_")):
                try:
                    out = tool.call({"input": text, "context": context})
                    self.memory.add(f"{self.name}:{text}", {"who": self.name, "result": str(out)})
                    return {"tool": tname, "result": out}
                except Exception as e:
                    return {"tool": tname, "error": str(e)}
        # default: use first tool
        if self.tools:
            tname, tool = next(iter(self.tools.items()))
            try:
                out = tool.call({"input": text, "context": context})
                self.memory.add(f"{self.name}:{text}", {"who": self.name, "result": str(out)})
                return {"tool": tname, "result": out}
            except Exception as e:
                return {"tool": tname, "error": str(e)}
        return {"error": "No tools available"}

@dataclass
class Orchestrator:
    tools: Dict[str, Tool] = field(default_factory=dict)
    agents: List[Agent] = field(default_factory=list)

    def register_tool(self, tool: Tool):
        self.tools[tool.name] = tool

    def add_agent(self, name: str, memory_top_k: int = 8):
        mem = InMemoryVectorStore(top_k=memory_top_k)
        self.agents.append(Agent(name=name, tools=self.tools, memory=mem))

    def run(self, task: str, max_steps: int = 8) -> Dict[str, Any]:
        plan = naive_plan(task)
        context = {"task": task, "plan": plan}
        results = []
        for i, step in enumerate(plan[:max_steps], 1):
            agent = self.agents[i % len(self.agents)] if self.agents else None
            if not agent:
                return {"error": "No agents configured"}
            res = agent.act(step, context)
            results.append({"step": step, "agent": agent.name, "output": res})
        return {"task": task, "steps_run": len(results), "results": results}
