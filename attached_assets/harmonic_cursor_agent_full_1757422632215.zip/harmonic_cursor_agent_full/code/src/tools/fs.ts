import * as fsp from 'fs/promises';
export async function read(path: string) { return fsp.readFile(path, 'utf8'); }
export async function write(path: string, content: string) { await fsp.writeFile(path, content, 'utf8'); return true; }
export async function diff(path: string, newContent: string) {
  const oldContent = await read(path).catch(() => '');
  return `--- ${path}\n+++ ${path}\n-${oldContent}\n+${newContent}`;
}
export async function applyDiff(patch: string) { return { ok: true, patchLen: patch.length }; }
