
import torch
from wsmpro.utils import build_omega, symmetrize, cayley

def test_cayley_symplectic():
    torch.manual_seed(0)
    n = 4
    d = 2*n
    Omega = build_omega(n, dtype=torch.float64)
    # Random symmetric H
    A = torch.randn(d,d, dtype=torch.float64)
    H = symmetrize(A)
    S = cayley(Omega @ H)
    lhs = S.T @ Omega @ S
    assert torch.allclose(lhs, Omega, atol=1e-6)

def test_expm_symplectic():
    torch.manual_seed(1)
    n = 3
    d = 2*n
    Omega = build_omega(n, dtype=torch.float64)
    A = torch.randn(d,d, dtype=torch.float64)
    H = (A + A.T)/2
    S = torch.matrix_exp(Omega @ H)
    lhs = S.T @ Omega @ S
    assert torch.allclose(lhs, Omega, atol=1e-6)
