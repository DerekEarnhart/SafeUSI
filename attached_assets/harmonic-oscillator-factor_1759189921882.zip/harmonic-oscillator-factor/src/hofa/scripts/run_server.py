from fastapi import FastAPI
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel
import numpy as np
from hofa.lindblad import step

app = FastAPI(title="CCR-Factor Playground")

class Req(BaseModel):
    rho: list[list[float]]
    H:   list[list[float]]
    K:   list[list[float]]
    dt:  float = 0.01

@app.get("/", response_class=HTMLResponse)
def home():
    return """<!doctype html><meta charset="utf-8">
    <body style="font-family:system-ui;background:#0b1220;color:#cfe5ff;padding:1.5rem">
      <h3>CCR-Factor Playground</h3>
      <p>POST <code>/step</code> with JSON {{rho,H,K,dt}}. Server is alive.</p>
    </body>"""

@app.post("/step")
def _step(req: Req):
    r = np.array(req.rho, dtype=complex)
    H = np.array(req.H,   dtype=complex)
    K = np.array(req.K,   dtype=complex)
    out = step(r, H, K, req.dt)
    return JSONResponse({"rho": out.tolist()})
