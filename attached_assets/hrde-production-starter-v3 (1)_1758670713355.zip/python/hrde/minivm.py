import os, subprocess, shlex, sys
from pathlib import Path
_ON_WINDOWS = sys.platform.startswith("win")
if not _ON_WINDOWS:
    import resource  # POSIX only
class MiniVM:
    def __init__(self, workspace: str):
        self.ws = Path(workspace).resolve(); self.ws.mkdir(parents=True, exist_ok=True)
    def _guard(self, path: str) -> Path:
        p = (self.ws / path).resolve()
        if not str(p).startswith(str(self.ws)): raise PermissionError("Path escapes workspace")
        return p
    def write(self, rel: str, text: str):
        p = self._guard(rel); p.parent.mkdir(parents=True, exist_ok=True); p.write_text(text)
    def read(self, rel: str) -> str: return self._guard(rel).read_text()
    def append(self, rel: str, text: str):
        p = self._guard(rel); 
        with p.open("a", encoding="utf-8") as f: f.write(text)
    def ls(self) -> str:
        out=[]; 
        for root,_,files in os.walk(self.ws):
            for f in files: out.append(str(Path(root,f).relative_to(self.ws)))
        return "\n".join(sorted(out))
    def run(self, cmd: str) -> tuple[int,str,str]:
        preexec=None; creationflags=0
        if not _ON_WINDOWS:
            def set_limits():
                resource.setrlimit(resource.RLIMIT_CPU, (2,2))
                resource.setrlimit(resource.RLIMIT_AS, (512*1024*1024, 512*1024*1024))
                resource.setrlimit(resource.RLIMIT_FSIZE, (32*1024*1024, 32*1024*1024))
            preexec=set_limits
        else:
            creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        proc = subprocess.Popen(shlex.split(cmd), cwd=self.ws, stdout=subprocess.PIPE, stderr=subprocess.PIPE, preexec_fn=preexec if not _ON_WINDOWS else None, creationflags=creationflags)
        out, err = proc.communicate(timeout=30)
        return proc.returncode, out.decode(errors="ignore"), err.decode(errors="ignore")
