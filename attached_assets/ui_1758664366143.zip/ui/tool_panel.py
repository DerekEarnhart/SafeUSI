class ToolPanel:
    """
    Displays and allows interaction with created tools.
    """
    def list_tools(self):
        return []
