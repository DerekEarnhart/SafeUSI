from __future__ import annotations

BANNED_KEYWORDS = {"explosives", "pathogen", "bioweapon", "harm", "illegal"}

def policy_allows(text: str) -> bool:
    t = text.lower()
    return not any(k in t for k in BANNED_KEYWORDS)
