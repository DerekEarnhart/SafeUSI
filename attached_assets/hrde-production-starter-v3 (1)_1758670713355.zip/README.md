# HRDE Production Starter (Windows-patched, Wrangler 4)

Dev quickstart (Windows PowerShell):
```powershell
./setup.ps1
./run_dev.ps1
```

Dev quickstart (macOS/Linux):
```bash
./setup.sh && ./run_dev.sh
```
