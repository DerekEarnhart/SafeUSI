import torch

def make_omega(d: int) -> torch.Tensor:
    assert d % 2 == 0, "State dimension must be even (2n)."
    n = d // 2
    O = torch.zeros(d, d)
    O[:n, n:] = torch.eye(n)
    O[n:, :n] = -torch.eye(n)
    return O

@torch.no_grad()
def symplectic_error(S: torch.Tensor, Omega: torch.Tensor) -> torch.Tensor:
    if Omega.dim() == 2:
        Omega = Omega.expand(S.shape[0], -1, -1)
    err = (S.transpose(-1,-2) @ Omega @ S) - Omega
    return torch.linalg.norm(err, ord="fro", dim=(-2,-1))

def cayley_symplectic(A: torch.Tensor) -> torch.Tensor:
    B = 0.5 * A
    I = torch.eye(A.shape[-1], device=A.device, dtype=A.dtype).expand_as(A)
    return torch.linalg.solve(I - B, I + B)

def symplectic_regularizer(S: torch.Tensor, Omega: torch.Tensor) -> torch.Tensor:
    if Omega.dim() == 2:
        Omega = Omega.expand(S.shape[0], -1, -1)
    E = (S.transpose(-1,-2) @ Omega @ S) - Omega
    return (E**2).sum(dim=(-2,-1)).mean()

def apply_dynamic_quantization(model):
    import torch.nn as nn
    from torch.quantization import quantize_dynamic
    model.readout = quantize_dynamic(model.readout, {nn.Linear}, dtype=torch.qint8)
    for cell in model.cells:
        if hasattr(cell, "ng") and cell.ng is not None:
            cell.ng = quantize_dynamic(cell.ng, {nn.Linear}, dtype=torch.qint8)
        cell.gauss.H_net = quantize_dynamic(cell.gauss.H_net, {nn.Linear}, dtype=torch.qint8)
        cell.gauss.xi_net = quantize_dynamic(cell.gauss.xi_net, {nn.Linear}, dtype=torch.qint8)
    return model
