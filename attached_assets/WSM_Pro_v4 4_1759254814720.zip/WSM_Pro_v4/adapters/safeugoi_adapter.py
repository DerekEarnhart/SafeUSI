
import torch
from wsmpro.model import WSMForCausalLM
from wsmpro.tokenization import load_tokenizer

def load_wsm_model(ckpt_path: str, device: str = "cuda", tokenizer: str = "./assets/tokenizer"):
    tok = load_tokenizer(tokenizer)
    model = WSMForCausalLM()
    try:
        state = torch.load(ckpt_path, map_location="cpu")
        if isinstance(state, dict) and 'state_dict' in state:
            state = state['state_dict']
        model.load_state_dict(state, strict=False)
    except FileNotFoundError:
        # Fresh model with random weights; callers can train or distill
        pass
    model.to(device if torch.cuda.is_available() and device.startswith("cuda") else "cpu")
    model.eval()
    return tok, model
