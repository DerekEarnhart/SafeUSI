
# pipeline_server.py
# A tiny FastAPI server that exposes a natural-language endpoint.
# It uses your plain-English presets and WSM adapter from the earlier bundle.

import os, sys, json
from typing import List, Dict, Any
from fastapi import FastAPI
from pydantic import BaseModel

# If needed, adjust sys.path so we can import your local modules when this file
# sits outside the WSM bundle.
sys.path.append(os.getcwd())

# Import plain-English mapping (from previous helper)
try:
    from plain_english_presets import parse_presets, merge_presets, PRESETS
except Exception:
    # Inline fallback if the module isn't on PYTHONPATH
    from typing import Tuple
    PRESETS = {
        "fast_local": {"model":{"backend":"wsm","wsm":{"mode":"cayley","device":"cpu"}},"runtime":{"quantize_int8":True}},
        "accuracy_first":{"model":{"backend":"wsm","wsm":{"mode":"expm","device":"cuda"}},"runtime":{"quantize_int8":False}},
        "no_make_stuff_up":{"decoding":{"abstain":True,"max_new_tokens":128}},
        "simple_language":{"style":{"reading_level":"grade6","avoid_jargon":True},"decoding":{"max_new_tokens":80}},
    }
    import re
    RULES = [
        (r"\bfast\b|\bquick\b|\blaptop\b|\bon my laptop\b|\brun on cpu\b", "fast_local"),
        (r"\baccurate\b|\bprecise\b|\bbest quality\b|\bcareful and exact\b", "accuracy_first"),
        (r"\bdon'?t make stuff up\b|\bno make stuff up\b|\bonly facts\b|\bbe certain\b|\bdon'?t guess\b", "no_make_stuff_up"),
        (r"\bsimple words\b|\bfor kids\b|\bexplain like i'?m (\d+|ten|10)\b|\btalk normal\b|\bno math class\b", "simple_language"),
    ]
    def parse_presets(text: str):
        t = text.lower().strip()
        picked = [name for pat,name in RULES if re.search(pat, t)]
        return picked or ["fast_local"]
    def _deep_merge(a,b):
        from copy import deepcopy
        if not isinstance(a,dict) or not isinstance(b,dict): return deepcopy(b)
        out = dict(a)
        for k,v in b.items():
            out[k] = _deep_merge(out[k], v) if k in out else v
        return out
    def merge_presets(base_cfg: dict, presets: dict, names: List[str]):
        cfg = dict(base_cfg or {})
        for n in names: cfg = _deep_merge(cfg, presets.get(n, {}))
        return cfg

# Import WSM adapter
try:
    from adapters.safeugoi_adapter import load_wsm_model
except Exception as e:
    raise RuntimeError("WSM adapter not found. Place this file next to your WSM_Pro_v4 bundle or add it to PYTHONPATH.") from e

# Post-processing helpers
from pipeline_helpers import wrap_prompt, simplify_text, auto_glossary_once

# Load model/tokenizer once
tok, model = load_wsm_model("./wsm_ckpt.pt", device="cuda")

app = FastAPI()

class NLRequest(BaseModel):
    text: str
    mode: str | None = None  # optional: "fast_local", "accuracy_first", etc.
    max_new_tokens: int | None = None

@app.get("/health")
def health():
    return {"ok": True}

@app.post("/nl")
def natural_language(req: NLRequest):
    # 1) Choose presets from the user's plain text (and optional explicit mode)
    names = parse_presets(req.text)
    if req.mode and req.mode in PRESETS and req.mode not in names:
        names.append(req.mode)
    cfg = merge_presets({}, PRESETS, names)

    # 2) Wrap the prompt for clarity
    style = cfg.get("style", {}).get("reading_level", "grade6")
    prompt = wrap_prompt(req.text, style="grade6" if "simple_language" in names else "clear")

    # 3) Decode params
    max_new = req.max_new_tokens or cfg.get("decoding", {}).get("max_new_tokens", 128)

    # 4) Run model
    ids = tok(prompt, return_tensors="pt")["input_ids"]
    out_ids = model.generate(ids, max_new_tokens=max_new, temperature=1.0, top_p=0.9)
    raw = tok.decode(out_ids[0].tolist(), skip_special_tokens=True)

    # 5) Post-process for plain language + glossary once
    simple = simplify_text(raw, style="grade6" if "simple_language" in names else "clear")
    final = auto_glossary_once(simple)

    return {"picked_presets": names, "config": cfg, "output": final}
