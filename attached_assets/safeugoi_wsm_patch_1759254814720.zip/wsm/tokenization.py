\
from typing import List, Dict, Any
from dataclasses import dataclass

try:
    from transformers import AutoTokenizer
except Exception as e:
    AutoTokenizer = None

@dataclass
class TokenizerWrapper:
    """Thin wrapper so you can swap in your own tokenizer if your repo has one."""
    name_or_path: str = "gpt2"

    def __post_init__(self):
        if AutoTokenizer is None:
            raise RuntimeError("HuggingFace transformers not installed. Please `pip install transformers`")
        self.tok = AutoTokenizer.from_pretrained(self.name_or_path)
        if self.tok.pad_token is None:
            # GPT2 family has no pad token by default; set EOS as PAD
            self.tok.pad_token = self.tok.eos_token

    @property
    def vocab_size(self) -> int:
        return self.tok.vocab_size

    def encode(self, text: str, add_special_tokens: bool = False) -> List[int]:
        return self.tok.encode(text, add_special_tokens=add_special_tokens)

    def batch_encode(self, texts: List[str], max_length: int = None, truncation: bool = True) -> Dict[str, Any]:
        return self.tok(texts, return_tensors="pt", padding=True, truncation=truncation, max_length=max_length)

    def decode(self, ids: List[int]) -> str:
        return self.tok.decode(ids, skip_special_tokens=True)
