# bio_bridge_server.py
# FastAPI backend: multi-entity simulation with optional auth token and richer schema.
#
# Endpoints
#   GET    /api/state                 → {entities:[...]} (or one via ?id=...)
#   POST   /api/tune                  → adjust neurotransmitters for one entity
#   POST   /api/entity                → create a new entity (JSON: {"id": "bio2"})
#   DELETE /api/entity                → delete an entity (?id=bio2)
#   GET    /api/schema                → JSON schema for entity objects
#   WS     /ws/state?token=...        → live streaming of all entities
#
# Run
#   export BRIDGE_TOKEN="changeme"   # optional
#   pip install fastapi uvicorn[standard]
#   uvicorn bio_bridge_server:app --reload --host 0.0.0.0 --port 8000

import asyncio
import json
import os
import random
import time
from typing import Dict, Any, Set, Optional

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Query, Header, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

TOKEN = os.getenv("BRIDGE_TOKEN")  # if set, required on API + WS

app = FastAPI(title="BIO↔3D Multi-Entity Bridge", version="0.2.0")

# CORS for local dev UIs
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ----------------------------
# Helpers & sim primitives
# ----------------------------

def now_ts() -> float:
    return time.time()

def clamp(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, x))

def infer_consciousness(neuro: Dict[str, float]) -> str:
    d = neuro.get("dopamine", 0.5)
    s = neuro.get("serotonin", 0.5)
    c = neuro.get("cortisol", 0.5)
    if d > 0.7 and s > 0.7 and c < 0.35:
        return "harmonic"
    if c > 0.7:
        return "stressed"
    if d < 0.35 and s < 0.35:
        return "low"
    return "neutral"

def make_organs() -> list[Dict[str, Any]]:
    return [
        {"name": "heart", "health": 0.92, "temp": 36.8, "pos_rel": {"x": 0.0, "y": 0.0, "z": 0.0}},
        {"name": "brain", "health": 0.95, "temp": 36.6, "pos_rel": {"x": 0.0, "y": 0.25, "z": 0.0}},
        {"name": "lungs", "health": 0.9,  "temp": 36.7, "pos_rel": {"x": 0.0, "y": 0.05, "z": -0.05}},
        {"name": "liver", "health": 0.88, "temp": 36.9, "pos_rel": {"x": 0.05, "y": -0.05, "z": 0.0}},
    ]

def make_entity(entity_id: str) -> Dict[str, Any]:
    neuro = {"dopamine": 0.55, "serotonin": 0.55, "cortisol": 0.35}
    return {
        "id": entity_id,
        "timestamp": now_ts(),
        "pos": {"x": random.uniform(-0.5,0.5), "y": random.uniform(-0.5,0.5), "z": random.uniform(-0.5,0.5)},
        "consciousness": infer_consciousness(neuro),
        "metrics": {"glucose": 95.0, "heart_rate": 72.0, "o2": 0.98, "temp": 36.8},
        "neuro": neuro,
        "systems": {
            "cardiovascular": {"load": 0.35, "hrv": 0.62},
            "immune": {"load": 0.25, "inflammation": 0.12},
            "neural": {"load": 0.4, "coherence": 0.58},
        },
        "organs": make_organs(),
    }

STATE: Dict[str, Dict[str, Any]] = {
    "bio1": make_entity("bio1"),
    "bio2": make_entity("bio2"),
}

WS_CLIENTS: Set[WebSocket] = set()

def auth_ok(authorization: Optional[str], token_q: Optional[str] = None) -> bool:
    if not TOKEN:
        return True  # open mode
    if authorization and authorization.startswith("Bearer "):
        return authorization.split(" ", 1)[1] == TOKEN
    if token_q and token_q == TOKEN:
        return True
    return False

# ----------------------------
# Background simulator
# ----------------------------

async def simulator():
    while True:
        for ent in STATE.values():
            # Position jitter
            ent["pos"]["x"] += random.uniform(-0.02, 0.02)
            ent["pos"]["y"] += random.uniform(-0.02, 0.02)
            ent["pos"]["z"] += random.uniform(-0.02, 0.02)

            # Metrics drift
            m = ent["metrics"]
            m["glucose"] = clamp(m["glucose"] + random.uniform(-0.8, 0.8), 70.0, 140.0)
            m["heart_rate"] = clamp(m["heart_rate"] + random.uniform(-1.2, 1.2), 50.0, 110.0)
            m["o2"] = clamp(m["o2"] + random.uniform(-0.005, 0.005), 0.9, 1.0)
            m["temp"] = clamp(m["temp"] + random.uniform(-0.05, 0.05), 35.5, 38.2)

            # Systems drift
            sys = ent["systems"]
            for k in sys:
                for kk in list(sys[k].keys()):
                    sys[k][kk] = clamp(sys[k][kk] + random.uniform(-0.02, 0.02), 0.0, 1.0)

            # Organs drift
            for o in ent["organs"]:
                o["health"] = clamp(o["health"] + random.uniform(-0.01, 0.015), 0.4, 1.0)
                o["temp"] = clamp(o["temp"] + random.uniform(-0.03, 0.03), 35.5, 38.5)

            # Neuro relaxes to mid
            for k in ("dopamine", "serotonin", "cortisol"):
                v = ent["neuro"][k]
                ent["neuro"][k] = clamp(v + (0.5 - v) * 0.02 + random.uniform(-0.01, 0.01), 0.0, 1.0)

            ent["consciousness"] = infer_consciousness(ent["neuro"])
            ent["timestamp"] = now_ts()

        # Broadcast
        if WS_CLIENTS:
            payload = json.dumps({"entities": list(STATE.values())})
            dead = set()
            for ws in WS_CLIENTS:
                try:
                    await ws.send_text(payload)
                except Exception:
                    dead.add(ws)
            for ws in dead:
                WS_CLIENTS.discard(ws)
                try:
                    await ws.close()
                except Exception:
                    pass

        await asyncio.sleep(0.5)  # ~2 FPS

@app.on_event("startup")
async def _startup():
    asyncio.create_task(simulator())

# ----------------------------
# REST API
# ----------------------------

@app.get("/api/state")
async def api_state(request: Request, id: str | None = None, token: str | None = None, authorization: str | None = Header(default=None)):
    if not auth_ok(authorization, token):
        return JSONResponse({"error": "unauthorized"}, status_code=401)
    if id:
        ent = STATE.get(id)
        if not ent:
            return JSONResponse({"error": f"unknown id {id}"}, status_code=404)
        return {"entity": ent}
    return {"entities": list(STATE.values())}

@app.post("/api/tune")
async def api_tune(
    request: Request,
    id: str = Query("bio1"),
    dopamine: float | None = Query(None),
    serotonin: float | None = Query(None),
    cortisol: float | None = Query(None),
    token: str | None = None,
    authorization: str | None = Header(default=None),
):
    if not auth_ok(authorization, token):
        return JSONResponse({"error": "unauthorized"}, status_code=401)
    ent = STATE.get(id)
    if not ent:
        return JSONResponse({"error": f"unknown id {id}"}, status_code=404)
    if dopamine is not None:   ent["neuro"]["dopamine"] = clamp(float(dopamine), 0.0, 1.0)
    if serotonin is not None:  ent["neuro"]["serotonin"] = clamp(float(serotonin), 0.0, 1.0)
    if cortisol is not None:   ent["neuro"]["cortisol"] = clamp(float(cortisol), 0.0, 1.0)
    ent["consciousness"] = infer_consciousness(ent["neuro"])
    ent["timestamp"] = now_ts()
    return {"ok": True, "entity": ent}

@app.post("/api/entity")
async def api_entity_create(request: Request, token: str | None = None, authorization: str | None = Header(default=None)):
    if not auth_ok(authorization, token):
        return JSONResponse({"error": "unauthorized"}, status_code=401)
    body = await request.json()
    new_id = body.get("id")
    if not new_id or not isinstance(new_id, str):
        return JSONResponse({"error": "provide JSON {\"id\": \"your_id\"}"}, status_code=400)
    if new_id in STATE:
        return JSONResponse({"error": f"id {new_id} exists"}, status_code=409)
    STATE[new_id] = make_entity(new_id)
    return {"ok": True, "entity": STATE[new_id]}

@app.delete("/api/entity")
async def api_entity_delete(id: str, token: str | None = None, authorization: str | None = Header(default=None)):
    if not auth_ok(authorization, token):
        return JSONResponse({"error": "unauthorized"}, status_code=401)
    if id not in STATE:
        return JSONResponse({"error": f"unknown id {id}"}, status_code=404)
    del STATE[id]
    return {"ok": True}

@app.get("/api/schema")
async def api_schema():
    """Very lightweight schema for clients to introspect."""
    return {
        "entity": {
            "id": "str",
            "timestamp": "float (unix seconds)",
            "pos": {"x": "float", "y": "float", "z": "float"},
            "consciousness": "harmonic|stressed|low|neutral",
            "metrics": {"glucose": "mg/dL", "heart_rate": "bpm", "o2": "0..1", "temp": "°C"},
            "neuro": {"dopamine": "0..1", "serotonin": "0..1", "cortisol": "0..1"},
            "systems": {
                "cardiovascular": {"load": "0..1", "hrv": "0..1"},
                "immune": {"load": "0..1", "inflammation": "0..1"},
                "neural": {"load": "0..1", "coherence": "0..1"}
            },
            "organs": [{"name": "str", "health": "0..1", "temp": "°C", "pos_rel": {"x":"float","y":"float","z":"float"}}],
        }
    }

# ----------------------------
# WebSocket
# ----------------------------

@app.websocket("/ws/state")
async def ws_state(ws: WebSocket, token: str | None = None):
    # Query params are accessible as function args in FastAPI
    if TOKEN and token != TOKEN:
        await ws.close(code=4401)  # unauthorized
        return
    await ws.accept()
    WS_CLIENTS.add(ws)
    # snapshot
    await ws.send_text(json.dumps({"entities": list(STATE.values())}))
    try:
        while True:
            # passively receive pings or ignore
            _ = await ws.receive_text()
    except WebSocketDisconnect:
        WS_CLIENTS.discard(ws)
    except Exception:
        WS_CLIENTS.discard(ws)
        try:
            await ws.close()
        except Exception:
            pass


