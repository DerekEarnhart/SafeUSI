# Harmonic Resonance Lab: Cross-Domain Sequence Analyzer (v1.1)

This project provides the `resonance_lab_v1_1.py` script, a powerful, dependency-light tool for analyzing various symbolic sequences across different domains. From scientific data to creative glyphs, it uncovers hidden structures and relationships.

## Features

*   **Multi-Encoding Numeric Views:** Analyze sequences in base36, ASCII, ordinal ranks, or using custom mappings.
*   **Rich Single-Sequence Analytics:** Calculate entropy, identify top N-grams, detect periodicities via FFT, and find autocorrelation peaks.
*   **Pairwise/Comparative Analytics:** Quantify relationships between sequences using cross-correlation, mutual information, Levenshtein distance, and Longest Common Subsequence (LCS).
*   **Prime/Attractor Overlays:** Heuristically identify underlying dynamic system behaviors (fixed-point, limit-cycle, chaotic) based on sequence patterns.
*   **Actionable Suggestions:** Receive concrete recommendations for design, optimization, and novel transformations based on analysis results.
*   **CRC32 Identifiers:** Each sequence gets a unique CRC32 hash for easy referencing.
*   **Multiple Compression Ratios:** Zlib and LZMA compression ratios provide insights into sequence compressibility.

## Usage

Ensure `numpy` is installed (`pip install numpy`).

```bash
# Basic: analyze two literal sequences in text report format (default)
python resonance_lab_v1_1.py --codes 6EQUJ5 "chororqokedy"

# Analyze sequences from files (one code per line) and output JSON
python resonance_lab_v1_1.py --files my_data.txt secret_cipher.txt --json

# Provide a custom symbol-to-number map
python resonance_lab_v1_1.py --codes ABC --map '{"A":1,"B":2,"C":3}'

# Detailed analysis with prime/attractor overlay
python resonance_lab_v1_1.py --codes 6EQUJ5 665236 --prime --report text

# Specify histogram bins for mutual information calculation
python resonance_lab_v1_1.py --codes SEQ1 SEQ2 --bins 32 --json
```

## Development & Contributions

This project is designed with minimal dependencies (Python standard library + numpy) to maximize portability and maintainability. Contributions enhancing the analytical capabilities or adding new visualizations are welcome, provided they adhere to the minimal dependency philosophy.
