import os, sys, json, pathlib, readline, uuid, asyncio, threading, queue, textwrap
from datetime import datetime
from prompt_toolkit import prompt
from prompt_toolkit.completion import WordCompleter
from rich.console import Console

# allow import of backend if user cloned Sovereign repo in same parent dir
ROOT = pathlib.Path(__file__).resolve().parent
sys.path.append(str(ROOT.parent / "sovereign_ha_agi" / "backend"))
try:
    from app import chat as agi_chat
except Exception as exc:
    print("Error importing Sovereign backend. Make sure sovereign_ha_agi/backend is next to this folder.")
    sys.exit(1)

console = Console()
system_prompt = "You are Sovereign AGI CLI."
history = []

def run_query(txt:str):
    payload = {"text": f"{system_prompt}\n{txt}"}
    try:
        reply = agi_chat(payload)["reply"]
    except Exception as exc:
        reply = f"[ERROR] {exc}"
    return reply

def main():
    console.print("[bold magenta]Sovereign HA‑AGI CLI[/] — type [cyan]help[/] for commands.")
    while True:
        try:
            user_in = prompt(">>> ")
        except (KeyboardInterrupt, EOFError):
            console.print("\nExiting.")
            break

        if not user_in.strip():
            continue
        if user_in.startswith("/"):
            cmd,*rest = user_in[1:].split(" ",1)
            arg = rest[0] if rest else ""
            if cmd == "help":
                console.print(textwrap.dedent(\"\"\"
                    [bold]Available commands[/]
                    /help             Show this help
                    /sys <text>       Set system prompt
                    /file <path>      Inject file content
                    /loadkb           Re‑index docs/
                    /exit             Quit
                \"\"\"))
                continue
            if cmd == "sys":
                global system_prompt
                system_prompt = arg
                console.print("[green]System prompt updated.[/green]")
                continue
            if cmd == "file":
                p = pathlib.Path(arg)
                if p.exists():
                    content = p.read_text(encoding="utf-8", errors="ignore")[:4000]
                    reply = run_query(f"Here is file {p.name} content:\n\n{content}\n\nRespond usefully.")
                    console.print(reply)
                else:
                    console.print("[red]File not found.[/red]")
                continue
            if cmd == "loadkb":
                reply = run_query("reload_kb")
                console.print(reply)
                continue
            if cmd == "exit":
                break
            console.print("[yellow]Unknown command.[/yellow]")
            continue

        reply = run_query(user_in)
        console.print(reply)

if __name__ == "__main__":
    main()
